var hostname = window.location.hostname;
var modesd = false;
var bigplaylist = false;
const query = window.location.search;
const params = new URLSearchParams(query);
const uiRevision = typeof webUiRevision === 'undefined' ? (params.get('ui') || yoVersion) : webUiRevision;
function uiResource(path) {
  const separator = path.includes('?') ? '&' : '?';
  return `${path}${separator}ui=${encodeURIComponent(uiRevision)}`;
}
function fetchUiResource(path) {
  const assets = window.yoUiAssets;
  if(assets && Object.prototype.hasOwnProperty.call(assets, path))
    return Promise.resolve(new Response(assets[path], {status: 200}));
  return fetch(uiResource(path), {cache: 'no-store'});
}
const yoTitle = 'ёRadio';
let audiopreview=null;
if(params.size>0){
  if(params.has('host')) hostname=params.get('host');
}
var websocket;
var playerUiReady = false;
var initialPlayerMessages = [];
var initialPlayerOverflow = false;
var wserrcnt = 0;
var wstimeout, pongtimeout;
var loaded = false;
var currentItem = 0;
var currentItemSynchronized = false;
var initialPlaylistScrollPending = true;
var playlistLoaded = false;
var loadedPlaylistMode = null;
var playlistRequestSerial = 0;
var stationChangeScrollFrom = null;
var playbackPendingTimer = null;
var playlistmod = new Date().getTime();

window.addEventListener('load', onLoad);

function loadCSS(href){ const link = document.createElement("link"); link.rel = "stylesheet"; link.href = href; document.head.appendChild(link); }
function loadJS(src, callback){ const script = document.createElement("script"); script.src = src; script.type = "text/javascript"; script.async = true; script.onload = callback; document.head.appendChild(script); }

function websocketBootstrapEnabled(){
  return typeof webSocketInitialState !== 'undefined' && webSocketInitialState === true &&
    ['/','/index.html'].includes(window.location.pathname);
}
function initialPlayerStateReady(){
  playerUiReady = true;
  const pending = initialPlayerMessages;
  const resync = initialPlayerOverflow;
  initialPlayerMessages = [];
  initialPlayerOverflow = false;
  pending.forEach(data => onMessage({data}));
  if(!websocketBootstrapEnabled() || resync) websocket.send('getindex=1');
}
function initWebSocket() {
  clearTimeout(wstimeout);
  console.log('Trying to open a WebSocket connection...');
  initialPlayerMessages = [];
  initialPlayerOverflow = false;
  const initial = websocketBootstrapEnabled() ? '?initial=1' : '';
  websocket = new WebSocket(`ws://${hostname}/ws${initial}`);
  websocket.onopen    = onOpen;
  websocket.onclose   = onClose;
  websocket.onmessage = onMessage;
}
function onLoad(event) { initWebSocket(); }
function pingUp(){
  if(!['/','/index.html'].includes(window.location.pathname)) return;
  pongtimeout = setTimeout(() => {
    if(!bigplaylist){
      console.log('Connection closed');
      websocket.close();
    }
  }, 5000);
}
function resyncCurrentPage(){
  if(typeof playMode === 'undefined') return;
  const pathname = window.location.pathname;
  if(playMode=="player"){
    if(['/','/index.html'].includes(pathname) && !websocketBootstrapEnabled()) websocket.send('getindex=1');
    if(pathname=='/settings.html'){
      websocket.send('getsystem=1');
      websocket.send('getscreen=1');
      websocket.send('gettimezone=1');
      websocket.send('getweather=1');
      websocket.send('getcontrols=1');
      websocket.send('getactive=1');
    }
  }else{
    websocket.send('getactive=1');
  }
}
function onOpen(event) {
  console.log('Connection opened');
  pingUp();
  if(!loaded){
    continueLoading(playMode); //playMode in variables.js
    loaded = true;
  }else{
    resyncCurrentPage();
  }
  wserrcnt=0;
}
function onClose(event) {
  setPlaybackPending(false);
  wserrcnt++;
  //console.log('Connection closed');
  clearTimeout(pongtimeout);
  wstimeout=setTimeout(initWebSocket, wserrcnt<10?2000:120000);
}
function secondToTime(seconds){
  if(seconds>=3600){
    return new Date(seconds * 1000).toISOString().substring(11, 19);
  }else{
    return new Date(seconds * 1000).toISOString().substring(14, 19);
  }
}
function showById(show,hide){
  show.forEach(item=>{ getId(item).classList.remove('hidden'); });
  hide.forEach(item=>{ getId(item).classList.add('hidden'); });
}
function applyVolumeScale() {
  const slider = getId('volume');
  if(!slider) return;
  slider.min = '0';
  slider.max = typeof volumeMax !== 'undefined' && volumeMax === 100 ? '100' : '254';
  slider.step = '1';
}
function applyPlayerCapabilities() {
  applyVolumeScale();
  if(typeof equalizerEnabled !== 'undefined' && !equalizerEnabled) {
    ['bass', 'middle', 'trebble'].forEach(id => {
      const control = getId(id);
      if(control) control.closest('li').remove();
    });
  }
}
function onMessage(event) {
  // Native bootstrap can arrive before asynchronous fragment installation.
  // Bound the queue; overflow requests a fresh state after the DOM is ready.
  if(websocketBootstrapEnabled() && !playerUiReady){
    if(initialPlayerMessages.length < 16) initialPlayerMessages.push(event.data);
    else initialPlayerOverflow = true;
    return;
  }
  try{
    const data = JSON.parse(escapeData(event.data));
    /*ir*/
    if(typeof data.ircode !== 'undefined'){
      getId('protocol').innerText=data.protocol;
      classEach('irrecordvalue', function(el){ if(el.hasClass("active")) el.innerText='0x'+data.ircode.toString(16).toUpperCase(); });
      return;
    }
    if(typeof data.irvals !== 'undefined'){
      classEach('irrecordvalue', function(el,i){ var val = data.irvals[i]; if(val>0) el.innerText='0x'+val.toString(16).toUpperCase(); else el.innerText=""; });
      return;
    }
    /*end ir*/
    if(typeof data.redirect !== 'undefined'){
      getId("mdnsnamerow").innerHTML=`<h3 style="line-height: 37px;color: #aaa; margin: 0 auto;">redirecting to ${data.redirect}</h3>`;
      setTimeout(function(){ window.location.href=data.redirect; }, 4000);
      return;
    }
    if(typeof data.playermode !== 'undefined') { //Web, SD
      modesd = data.playermode=='modesd';
      classEach('modeitem', function(el){ el.classList.add('hidden') });
      if(modesd) showById(['modesd', 'sdsvg'],['plsvg']); else showById(['modeweb','plsvg','bitinfo'],['sdsvg','snuffle']);
      showById(['volslider'],['sdslider']);
      getId('toggleplaylist').classList.remove('active');
      if(shouldReloadPlaylist(data.playermode)) {
        setPlaylistMod();
        generatePlaylist(`http://${hostname}/data/playlist.csv`+"?"+playlistmod);
      }
      return;
    }
    if(typeof data.sdinit !== 'undefined') {
      if(data.sdinit==1) {
        getId('playernav').classList.add("sd");
        getId('volmbutton').classList.add("hidden");
      }else{
        getId('playernav').classList.remove("sd");
        getId('volmbutton').classList.remove("hidden");
      }
    }
    if(typeof data.sdpos !== 'undefined' && getId("sdpos")){
      if(data.sdtpos==0 && data.sdtend==0){
        getId("sdposvalscurrent").innerHTML="00:00";
        getId("sdposvalsend").innerHTML="00:00";
        getId("sdpos").value = data.sdpos;
        fillSlider(getId("sdpos"));
      }else{
        getId("sdposvalscurrent").innerHTML=secondToTime(data.sdtpos);
        getId("sdposvalsend").innerHTML=secondToTime(data.sdtend);
        getId("sdpos").value = data.sdpos;
        fillSlider(getId("sdpos"));
      }
      return;
    }
    if(typeof data.sdmin !== 'undefined' && getId("sdpos")){
      getId("sdpos").attr('min',data.sdmin); 
      getId("sdpos").attr('max',data.sdmax); 
      return;
    }
    if(typeof data.snuffle!== 'undefined'){
      if(data.snuffle==1){
        getId("snuffle").classList.add("active");
      }else{
        getId("snuffle").classList.remove("active");
      }
      return;
    }
    if(typeof data.payload !== 'undefined'){
      data.payload.forEach(item=> {
        setupElement(item.id, item.value);
      });
    }else{
      if(typeof data.current !== 'undefined') { setCurrentItem(data.current, shouldScrollCurrentItem(data.current)); return; }
      if(typeof data.file !== 'undefined') { setPlaylistMod(); generatePlaylist(data.file+"?"+playlistmod); websocket.send('submitplaylistdone=1'); return; }
      if(typeof data.hide !== 'undefined'){ data.hide.forEach(hideUnsupportedSetting); return; }
      if(typeof data.act !== 'undefined'){ data.act.forEach(showclass=> { classEach(showclass, function(el) { el.classList.remove("hidden"); }); }); return; }
      if(typeof data.mdns !== 'undefined' && getId("radiolink")){
        const rhost = (hostname==`${data.mdns}.local`)?data.ipaddr:`${data.mdns}.local`;
        getId("radiolink").innerHTML=`<a href="http://${rhost}/settings.html">http://${rhost}/</a>`;
      }
      Object.keys(data).forEach(key=>{
        setupElement(key, data[key]);
      });
    }
  }catch(e){
    console.log("ws.onMessage error:", event.data);
  }
}
function escapeData(data){
  let m=data.match(/{.+?:\s"(.+?)"}/);
  if(m!==null){
    let m1 = m[1];
    if(m1.indexOf('"') !== -1){
      let mq=m1.replace(/["]/g, '\\\"');
      return data.replace(m1,mq);
    }
  }
  return data;
}
function getId(id,patent=document){
  return patent.getElementById(id);
}
function classEach(classname, callback) {
  document.querySelectorAll(`.${classname}`).forEach((item, index) => callback(item, index));
}
function quoteattr(s) {
  return ('' + s)
    .replace(/&/g, '&amp;')
    .replace(/'/g, '&apos;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;');
}
HTMLElement.prototype.attr = function(name, value=null){
  if(value!==null){
    return this.setAttribute(name, value);
  }else{
    return this.getAttribute(name);
  }
}
HTMLElement.prototype.hasClass = function(className){
  return this.classList.contains(className);
}
function fillSlider(sl){
  const slaveid = sl.dataset.slaveid;
  const value = (sl.value-sl.min)/(sl.max-sl.min)*100;
  if(slaveid) getId(slaveid).innerText=sl.value;
  sl.style.background = 'linear-gradient(to right, var(--accent-dark) 0%,  var(--accent-dark) ' + value + '%, var(--odd-bg-color) ' + value + '%, var(--odd-bg-color) 100%)';
}
function setPlaybackPending(pending){
  const button = getId('playbutton');
  if(!button) return;
  clearTimeout(playbackPendingTimer);
  playbackPendingTimer = null;
  button.classList.toggle('connecting', pending);
  button.attr('aria-disabled', pending ? 'true' : 'false');
  if(pending) playbackPendingTimer = setTimeout(() => setPlaybackPending(false), 15000);
}
function requestStationChangeScroll(){
  stationChangeScrollFrom = Number(currentItem);
}
function takeStationChangeScroll(item){
  if(stationChangeScrollFrom === null || Number(item) === stationChangeScrollFrom) return false;
  stationChangeScrollFrom = null;
  return true;
}
function shouldScrollCurrentItem(item){
  const initial = initialPlaylistScrollPending && playlistLoaded;
  const changed = currentItemSynchronized && Number(item) !== Number(currentItem);
  const requested = takeStationChangeScroll(item);
  if(initial) initialPlaylistScrollPending = false;
  currentItemSynchronized = true;
  return initial || requested || changed;
}
function shouldReloadPlaylist(mode){
  const changed = loadedPlaylistMode !== mode;
  loadedPlaylistMode = mode;
  return changed;
}
function hideUnsupportedSetting(id){
  const element = getId(id);
  if(!element) return;
  const wrapper = element.closest('.inputwrap');
  (wrapper || element).classList.add('hidden');
}
function setupElement(id,value){
  if(id=="connecting"){ setPlaybackPending(!!value); return; }
  if(id=="commandError"){ alert(value); return; }
  if(id=="nativeAppearance"){
    const row = getId('upst')?.closest('.flex-row');
    const system = getId('group_system');
    if(value && row && system){ row.classList.remove('hidden'); system.appendChild(row);
      document.querySelector('[data-command="format"]')?.classList.add('hidden'); }
    return;
  }
  if(id=="abuffmax"){
    const audioBuffer = getId("abuff");
    if(audioBuffer) audioBuffer.max=value;
    return;
  }
  if(id=="upst") document.documentElement.classList.toggle("station-uppercase", !!value);
  if(id=="playerwrap" && value=="playing") setPlaybackPending(false);
  const element = getId(id);
  if(id=="rssi"){ clearTimeout(pongtimeout); pingUp(); }
  if(element){
    if(id=="heap"){
      element.style.width=`${value}%`;
      return;
    }
    if(element.classList.contains("checkbox")){
      element.classList.remove("checked");
      if(value) element.classList.add("checked");
    }
    if(element.classList.contains("classchange")){
      element.attr("class", "classchange");
      element.classList.add(value);
    }
    if(element.classList.contains("text")){
      element.innerText=value;
      if(id=='meta' || id=='nameset') setCurrentItem(currentItem, false);
    }
    if(element.type==='text' || element.type==='number' || element.type==='password' || element.tagName==='SELECT'){
      element.value=value;
    }
    if(element.type==='range'){
      element.value=value;
      fillSlider(element);
    }
  }
}
/***--- playlist ---***/
function setCurrentItem(item, shouldScroll=false){
  currentItem=item;
  const playlist = getId("playlist");
  if(!playlist) return;
  let activeItem = null;
  playlist.querySelectorAll('li[attr-id]').forEach(row => {
    row.classList.add('play');
    const active = Number(row.attr('attr-id')) === Number(currentItem);
    row.classList.toggle('active', active);
    if(active && !row.classList.contains('filtered')) activeItem = row;
  });
  if(activeItem && shouldScroll) {
    playlist.scrollTo({
      top: activeItem.offsetTop-playlist.offsetHeight/2+activeItem.offsetHeight/2,
      left: 0,
      behavior: 'smooth'
    });
  }
}
function normalizeStationName(value){
  return String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase()
    .trim();
}
function filterPlaylist(value){
  const terms = normalizeStationName(value).split(/\s+/).filter(Boolean);
  let visible = 0;
  getId('playlist').querySelectorAll('li.play').forEach(item => {
    const name = normalizeStationName(item.dataset.name);
    const matches = terms.every(term => name.includes(term));
    item.classList.toggle('filtered', !matches);
    if(matches) visible++;
  });
  const empty = getId('playlistempty');
  if(empty) empty.classList.toggle('hidden', terms.length === 0 || visible > 0);
}
function initPLEditor(){
  ple= getId('pleditorcontent');
  if(!ple) return;
  let html='';
  ple.innerHTML="";
  pllines = getId('playlist').querySelectorAll('li');
  pllines.forEach((item,index)=>{
    html+=`<li class="pleitem" id="${'plitem'+index}"><span class="grabbable" draggable="true">${("00"+(index+1)).slice(-3)}</span>
      <span class="pleinput plecheck"><input type="checkbox" class="plcb" /></span>
      <input class="pleinput plename" type="text" value="${quoteattr(item.dataset.name)}" maxlength="140" />
      <input class="pleinput pleurl" type="text" value="${item.dataset.url}" maxlength="140" />
      <span class="pleinput pleplay" data-command="preview">&#9658;</span>
      <input class="pleinput pleovol" type="number" min="-64" max="64" step="1" value="${item.dataset.ovol}" />
      </li>`;
  });
  ple.innerHTML=html;
}
function handlePlaylistData(fileData, previousScrollTop = null) {
  if(typeof fileData !== 'string') return false;
  const ul = getId('playlist');
  if(previousScrollTop === null) previousScrollTop = ul.scrollTop;
  const lines = fileData.split('\n');
  let li='', html='', validRows=0;
  for(var i = 0;i < lines.length;i++){
    let line = lines[i].split('\t');
    if(line.length==3){
      const active=(i+1==currentItem)?' active':'';
      li=`<li attr-id="${i+1}" class="play${active}" data-name="${line[0].trim()}" data-url="${line[1].trim()}" data-ovol="${line[2].trim()}"><span class="text">${line[0].trim()}</span><span class="count">${i+1}</span></li>`;
      html += li;
      validRows++;
    }
  }
  if(fileData.trim() && validRows==0) return false;
  ul.innerHTML=html;
  playlistLoaded = true;
  const initialScroll = initialPlaylistScrollPending && Number(currentItem) > 0;
  setCurrentItem(currentItem, initialScroll);
  if(initialScroll) initialPlaylistScrollPending = false;
  const filter = getId('playlistfilter');
  filterPlaylist(filter ? filter.value : '');
  // Do not cancel the initial smooth scroll with an immediate restoration.
  if(!initialScroll) ul.scrollTop = previousScrollTop;
  if(!modesd) initPLEditor();
  return true;
}
function fetchPlaylist(path, attemptsLeft){
  return fetch(path, {cache: 'no-store'}).then(response => {
    if(response.ok === false) throw new Error(`HTTP ${response.status}`);
    return response.text();
  }).catch(error => {
    if(attemptsLeft <= 1) throw error;
    return new Promise(resolve => setTimeout(resolve, 250)).then(() => fetchPlaylist(path, attemptsLeft-1));
  });
}
function generatePlaylist(path){
  path = path.replace(/:\/\/.+?\//, `://${hostname}/`);
  const playlist = getId('playlist');
  const previousScrollTop = playlist.scrollTop;
  const requestSerial = ++playlistRequestSerial;
  bigplaylist = true;
  return fetchPlaylist(path, 3).then(plcontent => {
    if(requestSerial !== playlistRequestSerial) return false;
    return handlePlaylistData(plcontent, previousScrollTop);
  }).catch(error => {
    console.log('Playlist loading failed:', error.message);
    return false;
  }).then(success => {
    if(requestSerial === playlistRequestSerial) bigplaylist = false;
    return success;
  });
}
function plAdd(){
  let ple=getId('pleditorcontent');
  let plitem = document.createElement('li');
  let cnt=ple.getElementsByTagName('li');
  plitem.attr('class', 'pleitem');
  plitem.attr('id', 'plitem'+(cnt.length));
  plitem.innerHTML = '<span class="grabbable" draggable="true">'+("00"+(cnt.length+1)).slice(-3)+'</span>\
      <span class="pleinput plecheck"><input type="checkbox" /></span>\
      <input class="pleinput plename" type="text" value="" maxlength="140" />\
      <input class="pleinput pleurl" type="text" value="" maxlength="140" />\
      <span class="pleinput pleplay" data-command="preview">&#9658;</span>\
      <input class="pleinput pleovol" type="number" min="-30" max="30" step="1" value="0" />';
  ple.appendChild(plitem);
  ple.scrollTo({
    top: ple.scrollHeight,
    left: 0,
    behavior: 'smooth'
  });
}
function plRemove(){
  let items=getId('pleditorcontent').getElementsByTagName('li');
  let pass=[];
  for (let i = 0; i <= items.length - 1; i++) {
    if(items[i].getElementsByTagName('span')[1].getElementsByTagName('input')[0].checked) {
      pass.push(items[i]);
    }
  }
  if(pass.length==0) {
    alert('Choose something first');
    return;
  }
  for (var i = 0; i < pass.length; i++)
  {
    pass[i].remove();
  }
  items=getId('pleditorcontent').getElementsByTagName('li');
  for (let i = 0; i <= items.length-1; i++) {
    items[i].getElementsByTagName('span')[0].innerText=("00"+(i+1)).slice(-3);
  }
}
function submitPlaylist(){
  var items=getId("pleditorcontent").getElementsByTagName("li");
  var output="";
  for (var i = 0; i <= items.length - 1; i++) {
    inputs=items[i].getElementsByTagName("input");
    if(inputs[1].value == "" || inputs[2].value == "") continue;
    let ovol = inputs[3].value;
    if(ovol < -30) ovol = -30;
    if(ovol > 30) ovol = 30;
    output+=inputs[1].value+"\t"+inputs[2].value+"\t"+inputs[3].value+"\n";
  }
  let file = new File([output], "tempplaylist.csv",{type:"text/plain;charset=utf-8", lastModified:new Date().getTime()});
  let container = new DataTransfer();
  container.items.add(file);
  let fileuploadinput=getId("file-upload");
  fileuploadinput.files = container.files;
  doPlUpload(fileuploadinput);
  toggleTarget(0, 'pleditorwrap');
}
function setPlaylistMod(){
  playlistmod = new Date().getTime();
  localStorage.setItem("playlistmod", playlistmod);
}
function reportUploadFailure(xhr){ alert('Upload failed: '+(xhr.responseText || 'network error')); }
function doPlUpload(finput) {
  //playlistmod = new Date().getTime();
  websocket.send("submitplaylist=1");
  var formData = new FormData();
  formData.append("plfile", finput.files[0]);
  var xhr = new XMLHttpRequest();
  xhr.open("POST",`http://${hostname}/upload`,true);
  xhr.onload = () => { if(xhr.status < 200 || xhr.status >= 300) reportUploadFailure(xhr); };
  xhr.onerror = () => reportUploadFailure(xhr);
  xhr.send(formData);
  finput.value = '';
}
/***--- eof playlist ---***/
function toggleTarget(el, id){
  const target = getId(id);
  if(id=='pleditorwrap'){
    audiopreview.pause();
    audiopreview.src='';
    getId('previewinfo').innerHTML='';
  }
  if(target){
    if(id=='pleditorwrap' && modesd) {
      getId('sdslider').classList.toggle('hidden');
      getId('volslider').classList.toggle('hidden');
      getId('bitinfo').classList.toggle('hidden');
      getId('snuffle').classList.toggle('hidden');
    }else target.classList.toggle("hidden");
    getId(target.dataset.target).classList.toggle("active");
  }
}
function checkboxClick(cb, command){
  cb.classList.toggle("checked");
  websocket.send(`${command}=${cb.classList.contains("checked")?1:0}`);
}
function sliderInput(sl, command){
  websocket.send(`${command}=${sl.value}`);
  fillSlider(sl);
}
function handleWiFiData(fileData) {
  if (!fileData) return;
  var lines = fileData.split('\n');
  for(var i = 0;i < lines.length;i++){
    let line = lines[i].split('\t');
    if(line.length==2){
      if(!getId("ssid"+i)) continue;
      getId("ssid"+i).value=line[0];
      getId("pass"+i).attr('data-pass', line[1].replace(/\r$/, ''));
    }
  }
}
function getWiFi(path){
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4) {
      if (xhr.status == 200) {
        handleWiFiData(xhr.responseText);
      } else {
        handleWiFiData(null);
      }
    }
  };
  xhr.open("GET", path);
  xhr.send(null);
}
function applyTZ(){
  websocket.send("tzh="+getId("tzh").value);
  websocket.send("tzm="+getId("tzm").value);
  websocket.send("sntp2="+getId("sntp2").value);
  websocket.send("sntp1="+getId("sntp1").value);
}
function rebootSystem(info){
  getId("settingscontent").innerHTML=`<h2>${info}</h2>`;
  getId("settingsdone").classList.add("hidden");
  getId("navigation").classList.add("hidden");
  setTimeout(function(){ window.location.href=uiResource('/'); }, 5000);
}
function confirmDestructiveAction(command){
  if(command==="format") {
    return window.confirm(
      "WARNING: This will erase ALL SPIFFS data, including saved Wi-Fi networks, playlists, and the web interface. Continue?"
    ) && window.confirm(
      "FINAL CONFIRMATION: SPIFFS will be completely erased and the web interface will have to be uploaded again. Format SPIFFS now?"
    );
  }
  if(command==="reset") {
    return window.confirm(
      "Reset all radio settings to their defaults? Saved Wi-Fi networks and playlists will be kept. The radio will reboot."
    );
  }
  return false;
}
const SSID_WARNING_TEXT = 'Warning: one or more Wi-Fi names start or end with whitespace. Spaces are part of an SSID, so these are different network names. Save exactly as entered?';
function submitWiFi(){
  var output="";
  var items=document.getElementsByClassName("credential");
  var hasEdgeWhitespace=false;
  for (var i = 0; i <= items.length - 1; i++) {
    inputs=items[i].getElementsByTagName("input");
    if(inputs[0].value == "") continue;
    if(inputs[0].value !== inputs[0].value.trim()) hasEdgeWhitespace=true;
    let ps=inputs[1].value==""?inputs[1].dataset.pass:inputs[1].value;
    output+=inputs[0].value+"\t"+ps+"\n";
  }
  if(hasEdgeWhitespace && !window.confirm(SSID_WARNING_TEXT)) return;
  if(output!=""){ // Well, let's say, quack.
    let file = new File([output], "tempwifi.csv",{type:"text/plain;charset=utf-8", lastModified:new Date().getTime()});
    let container = new DataTransfer();
    container.items.add(file);
    let fileuploadinput=getId("file-upload");
    fileuploadinput.files = container.files;
    var formData = new FormData();
    formData.append("wifile", fileuploadinput.files[0]);
    var xhr = new XMLHttpRequest();
    xhr.open("POST",`http://${hostname}/upload`,true);
    xhr.onload = () => {
      if(xhr.status < 200 || xhr.status >= 300){ reportUploadFailure(xhr); return; }
    getId("settingscontent").innerHTML="<h2>Settings saved. Rebooting...</h2>";
    getId("settingsdone").classList.add("hidden");
    getId("navigation").classList.add("hidden");
    setTimeout(function(){ window.location.href=uiResource('/'); }, 10000);
    };
    xhr.onerror = () => reportUploadFailure(xhr);
    xhr.send(formData);
    fileuploadinput.value = '';
  }
}
function playItem(target){
  const item = target.attr('attr-id');
  stationChangeScrollFrom = null;
  setCurrentItem(item, false);
  websocket.send(`play=${item}`);
}
function hideSpinner(){
  const startupProgress = document.querySelector('body > #progress');
  if(startupProgress) startupProgress.classList.add("hidden");
  getId("content").classList.remove("hidden");
}
function changeMode(el){
  const cmd = el.dataset.command;
  //setPlaylistMod();
  el.classList.add('hidden');
  if(cmd=='web') getId('modesd').classList.remove('hidden');
  else getId('modeweb').classList.remove('hidden');
  websocket.send("newmode="+(cmd=="web"?0:1));
}
function toggleSnuffle(){
  let el = getId('snuffle');
  el.classList.toggle('active');
  websocket.send("snuffle="+el.classList.contains('active'));
}
function previewInfo(text, url='', error=false){
  const previewinfo=getId('previewinfo');
  previewinfo.classList.remove('error');
  if(url!='') previewinfo.innerHTML=`${text} <a href="${url}" target="_blank">${url}</a>`;
  else previewinfo.innerHTML=`${text}`;
  if(error) previewinfo.classList.add('error');
}
const PREVIEW_TIMEOUT = 4000;
function playPreview(root) {
  const streamUrl=root.getElementsByClassName('pleurl')[0].value;
  if(root.hasClass('active')){ root.classList.remove('active'); audiopreview.pause(); previewInfo('Stop playback:', streamUrl); return; }
  classEach('pleitem', function(el){ el.classList.remove('active') });
  if(streamUrl=='' || !audiopreview) { previewInfo("No streams available.", '', true); return; }
  previewInfo('Attempting to play:', streamUrl);
  audiopreview.src = streamUrl;
  audiopreview.load();
  let isTimeout = false;
  const timeout = setTimeout(() => { isTimeout = true; previewInfo("Connection timeout", streamUrl, true); root.classList.remove('active'); audiopreview.pause(); audiopreview.src = ''; return; }, PREVIEW_TIMEOUT);
  const onCanPlay = () => { if (!isTimeout) { clearTimeout(timeout); previewInfo('Playback', streamUrl); root.classList.add('active'); audiopreview.play().catch(err => { previewInfo("Playback error:", streamUrl, true); root.classList.remove('active'); return; }); }  };
  const onError = () => { if (!isTimeout) { clearTimeout(timeout); root.classList.remove('active'); previewInfo("Error loading stream:", streamUrl, true); audiopreview.src = ''; return; } };
  audiopreview.addEventListener("canplay", onCanPlay, { once: true });
  audiopreview.addEventListener("error", onError, { once: true });
}
function continueLoading(mode){
  if(typeof mode === 'undefined') return;
  if(mode=="player"){
    const plmt = localStorage.getItem("playlistmod");
    if(plmt)
      playlistmod = plmt;
    else
      localStorage.setItem("playlistmod", playlistmod);
    
    const pathname = window.location.pathname;
    if(['/','/index.html'].includes(pathname)){
      document.title = `${yoTitle} - Player`;
      fetchUiResource('player.html').then(response => response.text()).then(player => { 
        getId('content').classList.add('idx');
        getId('content').innerHTML = player;
        applyPlayerCapabilities();
        fetchUiResource('logo.svg').then(response => response.text()).then(svg => { 
          getId('logo').innerHTML = svg;
          hideSpinner();
          audiopreview=getId('audiopreview');
        });
        getId("version").innerText=` | v${yoVersion}`;
        document.querySelectorAll('input[type="range"]').forEach(sl => { fillSlider(sl); });
        initialPlayerStateReady();
        //generatePlaylist(`http://${hostname}/data/playlist.csv`+"?"+new Date().getTime());
      });
    }
    if(pathname=='/settings.html'){
      document.title = `${yoTitle} - Settings`;
      fetchUiResource('options.html').then(response => response.text()).then(options => {
        getId('content').innerHTML = options; 
        fetchUiResource('logo.svg').then(response => response.text()).then(svg => { 
          getId('logo').innerHTML = svg;
          hideSpinner();
        });
        getId("version").innerText=` | v${yoVersion}`;
        document.querySelectorAll('input[type="range"]').forEach(sl => { fillSlider(sl); });
        websocket.send('getsystem=1');
        websocket.send('getscreen=1');
        websocket.send('gettimezone=1');
        websocket.send('getweather=1');
        websocket.send('getcontrols=1');
        getWiFi(`http://${hostname}/data/wifi.csv`+"?"+new Date().getTime());
        websocket.send('getactive=1');
        classEach("reset", function(el){ el.innerHTML='<svg viewBox="0 0 16 16" class="fill"><path d="M8 3v5a36.973 36.973 0 0 1-2.324-1.166A44.09 44.09 0 0 1 3.417 5.5a52.149 52.149 0 0 1 2.26-1.32A43.18 43.18 0 0 1 8 3z"/><path d="M7 5v1h4.5C12.894 6 14 7.106 14 8.5S12.894 11 11.5 11H1v1h10.5c1.93 0 3.5-1.57 3.5-3.5S13.43 5 11.5 5h-4z"/></svg>'; });
      });
    }
    if(pathname=='/update.html'){
      document.title = `${yoTitle} - Update`;
      fetchUiResource('updform.html').then(response => response.text()).then(updform => {
        getId('content').classList.add('upd');
        getId('content').innerHTML = updform;
        configureFirmwareUpdate(); 
        fetchUiResource('logo.svg').then(response => response.text()).then(svg => { 
          getId('logo').innerHTML = svg;
          hideSpinner();
        });
        getId("version").innerText=` | v${yoVersion}`;
      });
    }
    if(pathname=='/ir.html'){
      document.title = `${yoTitle} - IR Recorder`;
      fetchUiResource('irrecord.html').then(response => response.text()).then(ircontent => {
        getId('content').innerHTML = ircontent;
        loadCSS(uiResource('ir.css'));
        loadJS(uiResource('ir.js'), () => {
          fetchUiResource('logo.svg').then(response => response.text()).then(svg => { 
            getId('logo').innerHTML = svg;
            initControls();
            hideSpinner();
          });
        });
        getId("version").innerText=` | v${yoVersion}`;
      });
    }
  }else{ // AP mode
    fetchUiResource('options.html').then(response => response.text()).then(options => {
      getId('content').innerHTML = options; 
      fetchUiResource('logo.svg').then(response => response.text()).then(svg => { 
        getId('logo').innerHTML = svg;
        hideSpinner();
      });
      getId("version").innerText=` | v${yoVersion}`;
      getWiFi(`http://${hostname}/data/wifi.csv`+"?"+new Date().getTime());
      websocket.send('getactive=1');
    });
  }
  if(loaded) return;
  document.body.addEventListener('click', (event) => {
    let target = event.target.closest('div, span, li');
    if(!target) return;
    if(target.classList.contains("knob")) target = target.parentElement;
    if(target.classList.contains("snfknob")) target = target.parentElement;
    if(target.id === 'nameset') { setCurrentItem(currentItem, true); return; }
    if(target.classList.contains("play")) { playItem(target); return; }
    if(target.parentElement && target.parentElement.classList.contains("play")){ playItem(target.parentElement); return; }
    if(target.classList.contains("navitem")) { getId(target.dataset.target).scrollIntoView({ behavior: 'smooth' }); return; }
    if(target.classList.contains("reset")) { websocket.send("reset="+target.dataset.name); return; }
    if(target.classList.contains("done")) { window.location.href=uiResource('/'); return; }
    let command = target.dataset.command;
    if (command){
      if(target.classList.contains("local")){
        switch(command){
          case "toggle": toggleTarget(target, target.dataset.target); break;
          case "settings": window.location.href=uiResource('/settings.html'); break;
          case "plimport": break;
          case "plexport": window.open(`http://${hostname}/data/playlist.csv`); break;
          case "pladd": plAdd(); break;
          case "pldel": plRemove(); break;
          case "plsubmit": submitPlaylist(); break;
          case "fwupdate": window.location.href=uiResource('/update.html'); break;
          case "webboard": window.location.href=`http://${hostname}/webboard`; break;
          case "setupir": window.location.href=uiResource('/ir.html'); break;
          case "applyweather":
            let key=getId("wkey").value;
            if(key!=""){
              websocket.send("lat="+getId("wlat").value);
              websocket.send("lon="+getId("wlon").value);
              websocket.send("key="+key);
            }
            break;
          case "applytz": applyTZ(); break;
          case "wifiexport": window.open(`http://${hostname}/data/wifi.csv`+"?"+new Date().getTime()); break;
          case "wifiupload": submitWiFi(); break;
          case "reboot": websocket.send("reboot=1"); rebootSystem('Rebooting...'); break;
          case "format":
            if(confirmDestructiveAction(command)) {
              websocket.send("format=1");
              rebootSystem('Format SPIFFS. Rebooting...');
            }
            break;
          case "reset":
            if(confirmDestructiveAction(command)) {
              websocket.send("reset=1");
              rebootSystem('Reset settings. Rebooting...');
            }
            break;
          case "snuffle": toggleSnuffle(); break;
          case "rebootmdns": websocket.send(`mdnsname=${getId('mdns').value}`); websocket.send("rebootmdns=1"); break;
          default: break;
        }
      }else{
        if(target.classList.contains("checkbox")) checkboxClick(target, command);
        if(target.classList.contains("cmdbutton")) {
          if(target.id === 'playbutton') {
            if(target.classList.contains('connecting')) return;
            const player = getId('playerwrap');
            const startingPlayback = player && player.classList.contains('stopped');
            if(startingPlayback) {
              stationChangeScrollFrom = null;
              setCurrentItem(currentItem, true);
              setPlaybackPending(true);
            }
          }
          if(target.id === 'prevbutton' || target.id === 'nextbutton') requestStationChangeScroll();
          websocket.send(`${command}=1`);
        }
        if(target.classList.contains("modeitem")) changeMode(target);
        if(target.hasClass("pleplay")) playPreview(target.parentElement);
        if(target.classList.contains("play")){
          const item = target.attr('attr-id');
          stationChangeScrollFrom = null;
          setCurrentItem(item, false);
          websocket.send(`${command}=${item}`);
        }
      }
      event.preventDefault(); event.stopPropagation();
    }
  });
  document.body.addEventListener('input', (event) => {
    let target = event.target;
    if(target.id === 'playlistfilter') {
      filterPlaylist(target.value);
      return;
    }
    let command = target.dataset.command;
    if (!command) { command = target.parentElement.dataset.command; target = target.parentElement; }
    if (command) {
      if(target.classList.contains("local")){
        switch(command){
          case "plselect": let ch=target.checked; classEach('plcb', function(el){ el.checked=ch; });
          default: break;
        };
        return;
      }
      if(target.type==='range') sliderInput(target, command);  //<-- range
      else websocket.send(`${command}=${target.value}`);       //<-- other
      event.preventDefault(); event.stopPropagation();
    }
  });
  document.body.addEventListener('mousewheel', (event) => {
    const target = event.target;
    if(target.type==='range'){
      const command = target.dataset.command;
      target.valueAsNumber += event.deltaY>0?-1:1;
      if (command) {
        sliderInput(target, command);
      }
    }
  });
}
/** UPDATE **/
var uploadWithError = false;
var firmwareUploading = false;
var firmwareInfo = null;
var firmwareInfoTimer = null;
function scheduleFirmwareInfo(){
  clearTimeout(firmwareInfoTimer);
  firmwareInfoTimer=setTimeout(refreshFirmwareInfo, 5000);
}
function configureFirmwareUpdate(){
  if(typeof nativeFirmwareOnly !== 'undefined' && nativeFirmwareOnly === true){
    getId('uploadtype2').closest('label').classList.add('hidden');
    getId('uploadtype1').checked=true;
    const board = typeof nativeFirmwareName === 'string' ? nativeFirmwareName : 'ESP8266 native';
    getId('uploadstatus').textContent='Choose '+board+' app.bin. For WebUI files use Board.';
    getId('binfile').accept='.bin';
  }
  // C3 refreshes its idle timer while this page is open. No saved setting is
  // changed. Pause these requests during the upload, which has its own guard.
  if(typeof nativeFirmwareInfo === 'string') refreshFirmwareInfo();
}
function refreshFirmwareInfo(){
  if(firmwareUploading || pathname !== '/update.html') return;
  fetch(nativeFirmwareInfo, {cache:'no-store', signal:AbortSignal.timeout(5000)})
    .then(response => { if(!response.ok) throw Error('Radio unavailable'); return response.json(); })
    .then(info => { firmwareInfo=info; getId('version').textContent=' | '+info.version; })
    .catch(() => { if(!firmwareUploading) getId('uploadstatus').textContent='Radio unavailable. If asleep, hold BOOT for over 500 ms, release it and retry.'; })
    .finally(() => { if(!firmwareUploading) scheduleFirmwareInfo(); });
}
function firmwareUploadFailed(message){
  uploadWithError=true;
  firmwareUploading=false;
  getId('updateform').attr('class','');
  getId('updateprogress').hidden=true;
  getId('updateprogress').value=0;
  getId('update_cancel_button').hidden=false;
  getId('uploadstatus').textContent=message;
  if(typeof nativeFirmwareInfo === 'string') scheduleFirmwareInfo();
}
function doUpdate(el) {
  const binfile = getId('binfile').files[0];
  if(!binfile){ alert('Choose something first'); return; }
  if(firmwareUploading) return;
  if(!binfile.size || (firmwareInfo && binfile.size > firmwareInfo.max_size)){
    firmwareUploadFailed('Choose a non-empty app.bin that fits this board.'); return;
  }
  firmwareUploading=true;
  clearTimeout(firmwareInfoTimer);
  getId('updateform').attr('class','hidden');
  getId('updateprogress').value=0;
  getId('updateprogress').hidden=false;
  getId('update_cancel_button').hidden=true;
  const formData = new FormData();
  formData.append('updatetarget', getId('uploadtype1').checked?'firmware':'spiffs');
  formData.append('update', binfile);
  const xhr = new XMLHttpRequest();
  uploadWithError=false;
  xhr.upload.addEventListener('progress', progressHandler, false);
  xhr.addEventListener('load', completeHandler, false);
  xhr.addEventListener('error', errorHandler, false);
  xhr.addEventListener('abort', abortHandler, false);
  xhr.addEventListener('timeout', () => firmwareUploadFailed('Upload timed out. Check the radio before retrying.'), false);
  xhr.open('POST', '/update', true);
  xhr.timeout=210000;
  xhr.send(formData);
}
function progressHandler(event) {
  if(!event.lengthComputable) return;
  const percent = Math.round(event.loaded / event.total * 100);
  getId('updateprogress').value=percent;
  getId('uploadstatus').textContent=percent >= 100 ?
    'Upload sent. Please wait for firmware verification...' : percent+'% uploaded | please wait...';
}
var tickcount=0;
function rebootingProgress(){
  getId('updateprogress').value=Math.round(tickcount/7);
  tickcount+=14;
  if(tickcount>700) location.href=uiResource('/');
  else setTimeout(rebootingProgress, 200);
}
function completeHandler(event) {
  const xhr=event.target;
  if(xhr.status < 200 || xhr.status >= 300 || xhr.responseText.trim() !== 'OK'){
    firmwareUploadFailed(xhr.responseText || 'Upload failed (HTTP '+xhr.status+').');
    return;
  }
  getId('uploadstatus').textContent='Upload complete, rebooting...';
  tickcount=0;
  rebootingProgress();
}
function errorHandler(event) { firmwareUploadFailed('Upload failed. Check the connection and retry.'); }
function abortHandler(event) { firmwareUploadFailed('Upload aborted.'); }
/** UPDATE **/
