"""Analyze frozen setup-owner and parser/test units with Xtensa Clang."""
import hashlib, json, re, subprocess, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
CAPTURE = ROOT / '.build/vorbis-setup-owner-host-20261026-01'
OUT = ROOT / '.build/vorbis-setup-owner-lint-20261026-01'
TOOL = Path('C:/Work/yoRadio/.idf/tools-v6.0.2/tools/esp-clang/esp-20.1.1_20250829/esp-clang/bin/clang-tidy.exe')
BUILTINS = TOOL.parent.parent / 'lib/clang/20/include'
PICOLIBC = Path('C:/Work/yoRadio/.idf/tools-v6.0.2/tools/xtensa-esp-elf/esp-15.2.0_20251204/xtensa-esp-elf/picolibc/include')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
host = json.loads((CAPTURE / 'report.json').read_text('utf-8'))
assert host['completed'] and host['passed'] and not OUT.exists()
OUT.mkdir()
(OUT / 'runner.py').write_bytes(Path(__file__).read_bytes())
(OUT / 'clang-tidy.yaml').write_bytes((ROOT / '.clang-tidy').read_bytes())
numeric = CAPTURE / 'sources/components/native_vorbis_numeric'
owner = CAPTURE / 'sources/components/native_vorbis_setup_owner'
native = CAPTURE / 'sources/native'
includes = [numeric / 'include', owner / 'include', native, CAPTURE]
report = dict(completed=False, warnings=0, errors=0, commands=[], inputs={},
    tool_sha256=sha(TOOL), host_report_sha256=sha(CAPTURE / 'report.json'),
    scope='Six frozen units, explicit Xtensa Clang flags; no SDK or whole-radio analysis.')
def save():
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
save()
units = [numeric / (name + '.c') for name in ('quant', 'codebook', 'setup')]
units += [owner / 'setup_owner.c', native / 'vorbis_setup_owner_test.c', native / 'vorbis_setup_owner_host.c']
for index, source in enumerate(units):
    report['inputs'][str(source)] = sha(source)
    stem = f'{index:02d}-' + source.stem
    command = [str(TOOL), str(source), '--config-file=' + str(OUT / 'clang-tidy.yaml'),
        '--header-filter=.*', '--export-fixes=' + str(OUT / (stem + '.yaml')), '--',
        '--target=xtensa-esp-elf', '-mcpu=esp32', '-std=gnu17', '-O2', '-D_GNU_SOURCE=1',
        '-UNDEBUG', '-fno-fast-math', '-ffp-contract=off', '-nostdinc',
        '-isystem', str(BUILTINS), '-isystem', str(PICOLIBC),
        *['-I' + str(path) for path in includes]]
    row = dict(source=source.name, argv=command)
    report['commands'].append(row)
    child, started = None, time.monotonic()
    try:
        with (OUT / (stem + '.stdout.log')).open('xb') as stdout, (OUT / (stem + '.stderr.log')).open('xb') as stderr:
            child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                creationflags=subprocess.CREATE_NO_WINDOW)
            row['pid'] = child.pid
            row['returncode'] = child.wait(timeout=60)
    finally:
        if child is not None and child.poll() is None:
            child.kill()
            child.wait(timeout=5)
            row['forced_stop'] = True
        row['elapsed_seconds'] = time.monotonic() - started
        diagnostics = []
        for stream in ('stdout', 'stderr'):
            path = OUT / (stem + '.' + stream + '.log')
            row[stream + '_sha256'] = sha(path)
            diagnostics.append(path.read_text('utf-8', errors='replace'))
        text = '\n'.join(diagnostics)
        row['warnings'] = len(re.findall(r': warning:', text))
        row['errors'] = len(re.findall(r': (?:error|fatal error):', text))
        report['warnings'] += row['warnings']
        report['errors'] += row['errors']
        save()
    print(json.dumps({key: row[key] for key in ('source', 'returncode', 'warnings', 'errors')}), flush=True)
    assert row['returncode'] == 0 and row['errors'] == 0 and not row.get('forced_stop')
assert all(sha(path) == digest for path, digest in report['inputs'].items())
report['completed'] = True
save()
