/mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-setup-owner-host-20261026-02/objects/05.o: \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-setup-owner-host-20261026-02/sources/native/vorbis_setup_owner_host.c \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-setup-owner-host-20261026-02/sources/native/vorbis_setup_owner_test.h
