/mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-setup-owner-host-20261026-02/objects/03.o: \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-setup-owner-host-20261026-02/sources/components/native_vorbis_setup_owner/setup_owner.c \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-setup-owner-host-20261026-02/sources/components/native_vorbis_setup_owner/include/native_vorbis_setup_owner.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-setup-owner-host-20261026-02/sources/components/native_vorbis_numeric/include/native_vorbis_setup.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-setup-owner-host-20261026-02/sources/components/native_vorbis_numeric/include/native_vorbis_codebook.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-setup-owner-host-20261026-02/sources/components/native_vorbis_numeric/include/native_vorbis_quant.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-setup-owner-host-20261026-02/sources/components/native_vorbis_numeric/include/native_vorbis_floor0.h
