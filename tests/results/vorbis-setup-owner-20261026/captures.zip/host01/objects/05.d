/mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-setup-owner-host-20261026-01/objects/05.o: \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-setup-owner-host-20261026-01/sources/native/vorbis_setup_owner_host.c \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-setup-owner-host-20261026-01/sources/native/vorbis_setup_owner_test.h
