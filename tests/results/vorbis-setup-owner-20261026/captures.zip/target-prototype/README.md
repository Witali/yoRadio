# Independent setup-owner metadata fixture

This project consumes the exact frozen component sources, portable lifetime
fixture and oracle header from a successful setup-owner host run. It opens
identification/setup pairs, checks retained views after freeing the original
packets, and exercises allocation refusal, replacement and allocator lifetimes.

The core0 coordinator starts a core1 priority0 worker with16384 stack bytes.
Normal time slicing, the watchdog and both idle-task checks remain enabled.
The worker yields between cases and at portable fixture polling points.

Every host case runs, including the original31 header pairs. Native execution
does not repeat host bit-prefix sweeps; the per-case and final UART records
explicitly report`prefix_sweeps=0`. This is not audio/DSP/PCM, full decoder,
production radio or physical resource qualification. Its raw QEMU test image
is not a production firmware handoff. No deferred fixture is modified or run.

Use`tests/run-vorbis-setup-owner-qemu.py` to create a fresh campaign, validate
the successful host input identities, build against pinned ESP-IDF6.0.2,
retain actual objects/dependencies/ELF/configuration/stack records and execute
QEMU. The project does not open COM ports, flash hardware or use networking.
