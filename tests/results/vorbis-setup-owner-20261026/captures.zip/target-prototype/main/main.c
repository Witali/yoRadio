/* Independent exact setup-owner metadata/lifetime fixture; no audio or DSP. */
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "vorbis_setup_owner_test.h"

#if !CONFIG_IDF_TARGET_ESP32
#error "The setup-owner fixture targets ESP32"
#endif
#if configUSE_TIME_SLICING != 1
#error "The equal-priority worker requires normal idle-task time slicing"
#endif
#if !CONFIG_ESP_TASK_WDT_EN || !CONFIG_ESP_TASK_WDT_INIT || \
    !CONFIG_ESP_TASK_WDT_CHECK_IDLE_TASK_CPU0 || !CONFIG_ESP_TASK_WDT_CHECK_IDLE_TASK_CPU1
#error "Watchdog and both idle checks remain enabled"
#endif

static TaskHandle_t coordinator;

void owner_test_poll(void) {
    vTaskDelay(1);
}

static void worker(void *unused) {
    (void)unused;
    printf("OWNER_WORKER core=%d priority=%u stack=16384\n",
           xPortGetCoreID(), (unsigned)uxTaskPriorityGet(NULL));
    const size_t count = owner_test_case_count();
    assert(count == OWNER_EXPECTED_CASES);
    for (size_t index = 0; index < count; ++index) {
        owner_test_run_case(index, false);
        owner_test_totals_t totals = owner_test_totals();
        assert(totals.cases == index + 1);
        printf("OWNER_CASE index=%u cases=%" PRIu64 " checks=%" PRIu64
               " successes=%" PRIu64 " parse_failures=%" PRIu64
               " allocation_refusals=%" PRIu64 " prefix_sweeps=0 core=%d\n",
               (unsigned)index, totals.cases, totals.checks, totals.successful_opens,
               totals.parse_failures, totals.allocation_refusals, xPortGetCoreID());
        fflush(stdout);
        vTaskDelay(1);
    }
    owner_test_totals_t totals = owner_test_totals();
    printf("OWNER_PASS cases=%" PRIu64 " checks=%" PRIu64 " successes=%" PRIu64
           " parse_failures=%" PRIu64 " allocation_refusals=%" PRIu64
           " live=0 bytes=0 prefix_sweeps=0 core=%d minimum_free=%u remaining_stack=%u\n",
           totals.cases, totals.checks, totals.successful_opens, totals.parse_failures,
           totals.allocation_refusals, xPortGetCoreID(),
           (unsigned)esp_get_minimum_free_heap_size(), (unsigned)uxTaskGetStackHighWaterMark(NULL));
    fflush(stdout);
    xTaskNotifyGive(coordinator);
    vTaskDelete(NULL);
}

void app_main(void) {
    coordinator = xTaskGetCurrentTaskHandle();
    printf("OWNER_BEGIN cases=%d prefix_sweeps=0 coordinator=%d worker=1 host=%s fixture=%s data=%s\n",
           OWNER_EXPECTED_CASES, xPortGetCoreID(), OWNER_HOST_REPORT_SHA256,
           OWNER_FIXTURE_SHA256, OWNER_CASES_SHA256);
    fflush(stdout);
    assert(xTaskCreatePinnedToCore(worker, "setup_owner", 16384, NULL, 0, NULL, 1) == pdPASS);
    assert(ulTaskNotifyTake(pdTRUE, portMAX_DELAY) == 1);
    printf("OWNER_STOP status=PASSED core=%d\n", xPortGetCoreID());
    fflush(stdout);
    esp_restart();
}
