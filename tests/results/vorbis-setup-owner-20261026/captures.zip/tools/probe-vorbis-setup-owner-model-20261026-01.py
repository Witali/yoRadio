import importlib.util, json
from pathlib import Path
root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('owner_model', root / 'tests/test-vorbis-setup-owner.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
subject = module.load(root / 'tests/test-vorbis-setup.py', 'setup_oracle')
model = module.cases(subject, (root / 'tests/target/cyd_vorbis_format_qemu/main/fixture.h').read_bytes(), module.ORIGINAL.read_bytes())
report = dict(cases=len(model['cases']), valid=sum(row['status'] == 0 for row in model['cases']),
    invalid=sum(row['status'] == -1 for row in model['cases']), truncated=sum(row['status'] == -3 for row in model['cases']),
    original31=sum(row['original31'] for row in model['cases']),
    expected_words=sum(len(row['expected']) for row in model['cases']),
    max_setup_bytes=max(len(row['setup_hex']) // 2 for row in model['cases']),
    generated_header_bytes=len(module.target_header(model)))
print(json.dumps(report))
