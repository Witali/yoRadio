"""Retain both real host runs, Clang results and the unrun target prototype."""
import hashlib, json, zipfile
from datetime import datetime, timezone
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'tests/results/vorbis-setup-owner-20261026'
assert not OUT.exists()
OUT.mkdir(parents=True)
files = {}
for folder, prefix in (
    (ROOT / '.build/vorbis-setup-owner-host-20261026-01', 'host01'),
    (ROOT / '.build/vorbis-setup-owner-host-20261026-02', 'host02'),
    (ROOT / '.build/vorbis-setup-owner-lint-20261026-01', 'lint01'),
    (ROOT / '.build/vorbis-setup-owner-lint-20261026-02', 'lint02'),
    (ROOT / '.build/vorbis-setup-owner-validation-20261026-01', 'validation'),
    (ROOT / 'tests/target/vorbis_setup_owner_qemu', 'target-prototype')):
    assert folder.is_dir() and folder.resolve().is_relative_to(ROOT)
    for path in sorted(folder.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            name = prefix + '/' + path.relative_to(folder).as_posix()
            assert name not in files
            files[name] = path.read_bytes()
sha = lambda body: hashlib.sha256(body).hexdigest()
prototype = {name.removeprefix('target-prototype/'): sha(body)
    for name, body in files.items() if name.startswith('target-prototype/')}
assert set(prototype) == {'CMakeLists.txt', 'README.md', 'main/CMakeLists.txt', 'main/main.c',
    'partitions.csv', 'sdk-build.ps1', 'sdkconfig.esp32.defaults'}
assert not (ROOT / 'tests/run-vorbis-setup-owner-qemu.py').exists()
assert not (ROOT / 'tests/test-vorbis-setup-owner-protocol.py').exists()
assert not list((ROOT / '.build').glob('vorbis-setup-owner-esp32-*'))
observation = dict(observed_at=datetime.now(timezone.utc).isoformat(),
    observation_source='Target-agent reports plus root read-only filesystem checks.',
    controller_present=False, protocol_tests_present=False, target_campaign_present=False,
    SDK_or_QEMU_started=False, explicit_safety_rejection_reported=False,
    cause=None, tool_response='aborted before dispatch',
    controller_write_attempts=2, identical_retry=True,
    alternate_agent_path_or_tool_used=False, prototype_files=prototype,
    subset_prefix_flag=0, full_native_gate_requires_all_prefix_sweeps=True)
files['observations/target-preparation.json'] = (json.dumps(observation, indent=2) + '\n').encode()
for path in (Path(__file__), ROOT / '.build/cyd-vorbis-format-command-01.py',
    ROOT / '.build/lint-vorbis-setup-owner-20261026-01.py',
    ROOT / '.build/lint-vorbis-setup-owner-20261026-02.py',
    ROOT / '.build/probe-vorbis-setup-owner-model-20261026-01.py'):
    files['tools/' + path.name] = path.read_bytes()
archive = OUT / 'captures.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 10, 26, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        zipped.writestr(info, body)
manifest = dict(schema='vorbis-setup-owner-evidence-v1', archive_sha256=sha(archive.read_bytes()),
    files={name: dict(bytes=len(body), sha256=sha(body)) for name, body in sorted(files.items())})
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(dict(archive_sha256=manifest['archive_sha256'], archive_bytes=archive.stat().st_size,
    members=len(files), manifest_sha256=sha((OUT / 'manifest.json').read_bytes()))))
