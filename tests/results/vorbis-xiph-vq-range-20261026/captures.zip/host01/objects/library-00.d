/mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/objects/library-00.o: \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/generated/ported/sharedbook.c \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/sources/native/vorbis_xiph_alloc_inject.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/sources/native/vorbis_xiph_alloc.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/generated/base/upstream/libogg/include/ogg/os_types.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/generated/base/platform/ogg/config_types.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/generated/base/upstream/libogg/include/ogg/ogg.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/generated/base/upstream/libvorbis/lib/os.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/generated/base/upstream/libvorbis/lib/misc.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/generated/ported/include/vorbis/codec.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/generated/base/upstream/libvorbis/lib/misc.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/generated/base/upstream/libvorbis/lib/codebook.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/generated/base/upstream/libvorbis/lib/scales.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/generated/base/upstream/libvorbis/lib/os.h
