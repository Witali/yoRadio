/mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/objects/capture.o: \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/sources/native/vorbis_xiph_vq_range_host.c \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/generated/base/upstream/libvorbis/lib/codebook.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/generated/base/upstream/libogg/include/ogg/ogg.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/generated/base/upstream/libogg/include/ogg/os_types.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/generated/base/platform/ogg/config_types.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/sources/components/native_vorbis_numeric/include/native_vorbis_quant.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/sources/components/native_vorbis_numeric/include/native_vorbis_floor0.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-01/sources/native/vorbis_xiph_alloc.h
