/mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-02/objects/alloc.o: \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-02/sources/native/vorbis_xiph_alloc.c \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-vq-range-host-20261026-02/sources/native/vorbis_xiph_alloc.h
