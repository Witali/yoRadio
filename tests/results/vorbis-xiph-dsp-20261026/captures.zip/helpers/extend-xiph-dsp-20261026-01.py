import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
port=ROOT/'idf/components/native_vorbis_xiph_port'
base=ROOT/'idf/components/native_vorbis_xiph'
source=(base/'upstream/libvorbis/lib/block.c').read_bytes()
def fragment(name,begin,end,transform):
    a=source.index(begin);b=source.index(end,a)
    before=source[a:b].rstrip(b'\r\n')+b'\n';assert source.count(before)==1
    (port/('edits/'+name+'.before.c')).write_bytes(before)
    (port/('edits/'+name+'.after.c')).write_bytes(transform(before.decode()).encode())
def shared(body):
    body='#include "native_vorbis_xiph_dsp_error.h"\n\n'+body
    body=body.replace('codec_setup_info *ci=vi->codec_setup;','codec_setup_info *ci=vi?vi->codec_setup:NULL;',1)
    body=body.replace('  if(ci==NULL||','  if(!v)return 1;\n  memset(v,0,sizeof(*v));\n  if(ci==NULL||',1)
    body=body.replace('  memset(v,0,sizeof(*v));\n  b=v->backend_state=_ogg_calloc(1,sizeof(*b));\n\n  v->vi=vi;', '  v->vi=vi;\n  b=v->backend_state=_ogg_calloc(1,sizeof(*b));\n  if(!b)goto abort_init;',1)
    for line in('  b->transform[0]=_ogg_calloc(VI_TRANSFORMB,sizeof(*b->transform[0]));',
                 '  b->transform[1]=_ogg_calloc(VI_TRANSFORMB,sizeof(*b->transform[1]));',
                 '  b->transform[0][0]=_ogg_calloc(1,sizeof(mdct_lookup));',
                 '  b->transform[1][0]=_ogg_calloc(1,sizeof(mdct_lookup));'):
        field=line.strip().split('=')[0];body=body.replace(line,line+'\n  if(!'+field+')goto abort_init;',1)
    body=body.replace('  mdct_init(b->transform[0][0],ci->blocksizes[0]>>hs);','  if(native_xiph_mdct_init(b->transform[0][0],ci->blocksizes[0]>>hs))goto abort_init;')
    body=body.replace('  mdct_init(b->transform[1][0],ci->blocksizes[1]>>hs);','  if(native_xiph_mdct_init(b->transform[1][0],ci->blocksizes[1]>>hs))goto abort_init;')
    # Both branches use the same owned codebook-array allocation. This does
    # not qualify the other encoder-only initialization routines.
    body=body.replace('      ci->fullbooks=_ogg_calloc(ci->books,sizeof(*ci->fullbooks));', '      ci->fullbooks=_ogg_calloc(ci->books,sizeof(*ci->fullbooks));\n      if(!ci->fullbooks)goto abort_init;')
    body=body.replace('  v->pcm=_ogg_malloc(vi->channels*sizeof(*v->pcm));','  v->pcm=_ogg_calloc(vi->channels,sizeof(*v->pcm));\n  if(!v->pcm)goto abort_init;')
    body=body.replace('  v->pcmret=_ogg_malloc(vi->channels*sizeof(*v->pcmret));','  v->pcmret=_ogg_malloc(vi->channels*sizeof(*v->pcmret));\n  if(!v->pcmret)goto abort_init;')
    body=body.replace('    for(i=0;i<vi->channels;i++)\n      v->pcm[i]=_ogg_calloc(v->pcm_storage,sizeof(*v->pcm[i]));','    for(i=0;i<vi->channels;i++){\n      v->pcm[i]=_ogg_calloc(v->pcm_storage,sizeof(*v->pcm[i]));\n      if(!v->pcm[i])goto abort_init;\n    }')
    body=body.replace('  b->flr=_ogg_calloc(ci->floors,sizeof(*b->flr));','  b->flr=_ogg_calloc(ci->floors,sizeof(*b->flr));\n  if(!b->flr)goto abort_init;')
    body=body.replace('  b->residue=_ogg_calloc(ci->residues,sizeof(*b->residue));','  b->residue=_ogg_calloc(ci->residues,sizeof(*b->residue));\n  if(!b->residue)goto abort_init;')
    body=body.replace('  for(i=0;i<ci->floors;i++)\n    b->flr[i]=_floor_P[ci->floor_type[i]]->\n      look(v,ci->floor_param[i]);','  for(i=0;i<ci->floors;i++){\n    b->flr[i]=_floor_P[ci->floor_type[i]]->\n      look(v,ci->floor_param[i]);\n    if(!b->flr[i])goto abort_init;\n  }')
    body=body.replace('  for(i=0;i<ci->residues;i++)\n    b->residue[i]=_residue_P[ci->residue_type[i]]->\n      look(v,ci->residue_param[i]);','  for(i=0;i<ci->residues;i++){\n    b->residue[i]=_residue_P[ci->residue_type[i]]->\n      look(v,ci->residue_param[i]);\n    if(!b->residue[i])goto abort_init;\n  }')
    body=body.replace('  vorbis_dsp_clear(v);\n  return -1;',' abort_init:\n  vorbis_dsp_clear(v);\n  return -1;')
    return body
def clear(body):
    old='      _ogg_free(v->pcm);\n      if(v->pcmret)_ogg_free(v->pcmret);\n    }'
    new='      _ogg_free(v->pcm);\n    }\n    if(v->pcmret)_ogg_free(v->pcmret);'
    assert body.count(old)==1;return body.replace(old,new)
fragment('block-dsp-init',b'static int _vds_shared_init(',b'/* arbitrary settings',shared)
fragment('block-dsp-clear',b'void vorbis_dsp_clear(',b'float **vorbis_analysis_buffer',clear)
(port/'include/native_vorbis_xiph_dsp_error.h').write_text('''/* Private checked initializer for the source-built decoder.
   The original mdct.h declaration and void wrapper remain unchanged.
   A fresh lookup is zeroed on failure and may be cleared safely. */
#ifndef NATIVE_VORBIS_XIPH_DSP_ERROR_H
#define NATIVE_VORBIS_XIPH_DSP_ERROR_H
#include "mdct.h"
int native_xiph_mdct_init(mdct_lookup *,int);
#endif
''',encoding='utf-8',newline='\n')
path=port/'edits.json';changes=json.loads(path.read_bytes());assert len(changes['edits'])==16
for name,unit in(('block-dsp-init','block'),('block-dsp-clear','block'),('mdct-init','mdct'),('floor0-look','floor0'),('floor1-look','floor1'),('residue-look','res0'),('residue-free-look','res0')):
    changes['edits'].append(dict(source='upstream/libvorbis/lib/'+unit+'.c',before='edits/'+name+'.before.c',after='edits/'+name+'.after.c'))
path.write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8',newline='\n')
path=port/'prepare.py';text=path.read_text().replace("len(changes['edits']) == 16, 'sixteen exact reviewed edits'","len(changes['edits']) == 23, 'twenty-three exact reviewed edits'")
text=text.replace("'upstream/libvorbis/lib/info.c'},", "'upstream/libvorbis/lib/info.c', 'upstream/libvorbis/lib/mdct.c'},").replace('only the nine reviewed translation units change','only the ten reviewed translation units change')
text=text.replace("    units = [dict(original=name,", "    generated['ported/native_vorbis_xiph_dsp_error.h'] = edits['include/native_vorbis_xiph_dsp_error.h']\n    units = [dict(original=name,")
path.write_text(text,encoding='utf-8',newline='\n')
path=port/'CMakeLists.txt';text=path.read_text().replace('set(xiph_ported_units block sharedbook codebook floor0 floor1 res0 mapping0 info)','set(xiph_ported_units block sharedbook codebook floor0 floor1 res0 mapping0 info mdct)');path.write_text(text,encoding='utf-8',newline='\n')
path=port/'README.md';text=path.read_text().replace('only nine modified translation units and one owned private header','only ten modified translation units and two owned private headers')
text=text.replace('Neither production application selects this component.', '''Seven additional edits check the shared decoder DSP, MDCT and floor/residue
lookup initialization, with partial-owned arrays safe for cleanup. The PCM
pointer array is zero-initialized; pcmret is freed independently. A private
checked MDCT initializer preserves the original void wrapper and transform
arithmetic. Public synthesis initialization retains its documented 0/1 return
contract. Failed initialization may have consumed static books; callers close
the entire stream and replay headers to recover. Encoder-only paths and packet
allocations are not covered by this decoder-init change.

Neither production application selects this component.''')
text=text.replace('other block, DSP,\npacket floor and residue allocations still require qualification.', 'packet arena/floor/residue and allocating comment utilities still require\nqualification.')
path.write_text(text,encoding='utf-8',newline='\n')
path=port/'port-manifest.json';manifest=json.loads(path.read_bytes());manifest['files']={p.relative_to(port).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(port.rglob('*'))if p.is_file()and p!=path}
path.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(port=hashlib.sha256(path.read_bytes()).hexdigest(),generator=hashlib.sha256((port/'prepare.py').read_bytes()).hexdigest(),entries=len(manifest['files']))))
