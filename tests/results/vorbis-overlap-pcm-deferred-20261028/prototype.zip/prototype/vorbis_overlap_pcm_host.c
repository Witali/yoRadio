// Compose the complete guarded overlap fixture with the public exact PCM API.
#include "native_vorbis_overlap.h"
#include "native_vorbis_pcm.h"

static native_vorbis_numeric_status_t capture_overlap_push(
    native_vorbis_overlap_t *, const native_vorbis_transform_block_t *, size_t,
    double *, size_t, double *, size_t, native_vorbis_overlap_terms_t *);

// Keep the original fixture/controls unchanged. Every actual successful public
// push is observed, including count-zero priming; no result vector is replaced.
#define native_vorbis_overlap_push capture_overlap_push
#define main native_vorbis_overlap_fixture_main
#include "vorbis_overlap_host.c"
#undef main
#undef native_vorbis_overlap_push

static FILE *pcm_capture;
static uint64_t composed_rows, composed_values;

static native_vorbis_numeric_status_t capture_overlap_push(
    native_vorbis_overlap_t *state,
    const native_vorbis_transform_block_t *source, size_t source_capacity,
    double *previous, size_t previous_capacity, double *current, size_t current_capacity,
    native_vorbis_overlap_terms_t *result) {
    native_vorbis_numeric_status_t status = native_vorbis_overlap_push(state, source,
        source_capacity, previous, previous_capacity, current, current_capacity, result);
    if (status != NATIVE_VORBIS_NUMERIC_OK) return status;
    uint32_t count = result->previous.count;
    CHECK(result->current.count == count);
    buffer_t output = make(count * sizeof(int16_t));
    buffer_t previous_before = make(count * sizeof(double));
    buffer_t current_before = make(count * sizeof(double));
    unsigned char result_before[sizeof(*result)];
    memcpy(result_before, result, sizeof(result_before));
    if (count) {
        memcpy(previous_before.data, result->previous.samples, previous_before.bytes);
        memcpy(current_before.data, result->current.samples, current_before.bytes);
    }
    int16_t *pcm = count ? (int16_t *)output.data : NULL;
    CHECK(native_vorbis_pcm_s16_pair(&result->previous, count, &result->current, count, pcm, count) == 0);
    CHECK(memcmp(result_before, result, sizeof(result_before)) == 0);
    if (count) {
        CHECK(memcmp(previous_before.data, result->previous.samples, previous_before.bytes) == 0);
        CHECK(memcmp(current_before.data, result->current.samples, current_before.bytes) == 0);
    }
    guards(&output);
    put32(pcm_capture, count);
    put64(pcm_capture, (uint64_t)result->previous.exponent);
    put64(pcm_capture, (uint64_t)result->current.exponent);
    values(pcm_capture, result->previous.samples, count);
    values(pcm_capture, result->current.samples, count);
    for (uint32_t i = 0; i < count; ++i) {
        uint16_t word = (uint16_t)pcm[i];
        unsigned char bytes[2] = {(unsigned char)word, (unsigned char)(word >> 8)};
        CHECK(fwrite(bytes, 1, 2, pcm_capture) == 2);
    }
    ++composed_rows; composed_values += count;
    destroy(&current_before); destroy(&previous_before); destroy(&output);
    return status;
}

int main(int argc, char **argv) {
    CHECK(argc == 3); pcm_capture = fopen(argv[2], "wb"); CHECK(pcm_capture);
    CHECK(fwrite("VOPCM001", 1, 8, pcm_capture) == 8);
    CHECK(native_vorbis_overlap_fixture_main(2, argv) == 0);
    put32(pcm_capture, UINT32_MAX); put64(pcm_capture, composed_rows); put64(pcm_capture, composed_values);
    CHECK(fclose(pcm_capture) == 0);
    printf("OVERLAP_PCM rows=%" PRIu64 " values=%" PRIu64 "\n", composed_rows, composed_values);
    return 0;
}
