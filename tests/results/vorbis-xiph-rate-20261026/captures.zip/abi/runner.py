"""Owned C/C++ public-header entry and layout probes against frozen sources."""
import hashlib,itertools,json,subprocess,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
HOST=ROOT/'.build/vorbis-xiph-rate-host-20261026-02'
OUT=ROOT/'.build/vorbis-xiph-rate-abi-host-20261026-01'
host=json.loads((HOST/'report.json').read_bytes());assert host['completed'] and host['passed'] and not OUT.exists()
OUT.mkdir();(OUT/'objects').mkdir();(OUT/'runner.py').write_bytes(Path(__file__).read_bytes());(OUT/'supervisor.py').write_bytes((HOST/'supervisor.py').read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
linux=lambda p:'/mnt/'+Path(p).resolve().as_posix()[0].lower()+Path(p).resolve().as_posix()[2:]
report=dict(completed=False,commands=[],probes=[],host_report_sha256=sha(HOST/'report.json'),target_runtime=False)
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(name,argv,expected=0):
    nonce=uuid.uuid4().hex;request=OUT/(name+'.request.json');receipt=OUT/(name+'.receipt.json')
    request.write_text(json.dumps(dict(nonce=nonce,argv=argv,timeout=60,receipt=linux(receipt),stop=linux(OUT/(name+'.stop')))),encoding='utf-8')
    row=dict(name=name,argv=argv,nonce=nonce,request_sha256=sha(request),expected_exit=expected);report['commands'].append(row);child=None;save()
    try:
        with(OUT/(name+'.stdout.log')).open('xb')as so,(OUT/(name+'.stderr.log')).open('xb')as se:
            child=subprocess.Popen(['wsl.exe','--exec','python3',linux(OUT/'supervisor.py'),linux(request)],stdout=so,stderr=se,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
            row['transport_pid']=child.pid;row['transport_exit']=child.wait(timeout=80)
    finally:
        if child is not None and child.poll()is None:
            (OUT/(name+'.stop')).write_text(nonce)
            try:child.wait(timeout=15)
            except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
            row['forced_stop']=True
        row['supervisor']=json.loads(receipt.read_text())if receipt.exists()else{}
        for stream in('stdout','stderr'):row[stream+'_sha256']=sha(OUT/(name+'.'+stream+'.log'))
        save()
    actual=row['supervisor']
    assert row['transport_exit']==0 and not row.get('forced_stop') and actual['nonce']==nonce and actual['request_sha256']==row['request_sha256']
    assert actual['state']=='terminal' and actual['final'] and actual['child_reaped'] and actual['group_gone'] and actual['new_session'] and actual['child_pid']==actual['owned_pgid'] and actual['child_returncode']==expected

layout='''#include <limits.h>
#include <stddef.h>
#ifndef NATIVE_VORBIS_XIPH_RATE_API
#error "Owned rate header not selected"
#endif
#ifdef __cplusplus
template<class A,class B> struct same_type { static constexpr bool value=false; };
template<class A> struct same_type<A,A> { static constexpr bool value=true; };
#define ASSERT static_assert
#define ALIGN alignof
#define SAME(A,B) same_type<A,B>::value
#else
#define ASSERT _Static_assert
#define ALIGN _Alignof
#define SAME(A,B) _Generic((A)0,B:1,default:0)
#endif
struct original_info_layout { int version,channels;long rate,bitrate_upper,bitrate_nominal,bitrate_lower,bitrate_window;void *codec_setup; };
ASSERT(NATIVE_VORBIS_XIPH_RATE_API==1,"rate capability");
ASSERT(sizeof(vorbis_info)==sizeof(struct original_info_layout),"original size");
ASSERT(ALIGN(vorbis_info)==ALIGN(struct original_info_layout),"original alignment");
#define OFFSET(field) ASSERT(offsetof(vorbis_info,field)==offsetof(struct original_info_layout,field),"original offset " #field)
OFFSET(version);OFFSET(channels);OFFSET(rate);OFFSET(bitrate_upper);OFFSET(bitrate_nominal);OFFSET(bitrate_lower);OFFSET(bitrate_window);OFFSET(codec_setup);
ASSERT((native_xiph_sample_rate_t)0xffffffffUL>0,"full positive uint32 range");
#if ULONG_MAX==0xffffffffUL
ASSERT(SAME(native_xiph_sample_rate_t,unsigned long),"32-bit rate type");
#else
ASSERT(SAME(native_xiph_sample_rate_t,long),"wide long original type");
#endif
'''
generated=HOST/'generated';public=generated/'ported/include';base_public=generated/'base/upstream/libvorbis/include'
includes=[public,generated/'base/upstream/libogg/include',generated/'base/platform']
for language,compiler,standard,extension in [('c','gcc','c11','c'),('cpp','g++','c++17','cc')]:
    run(language+'-version',[compiler,'--version']);run(language+'-machine',[compiler,'-dumpmachine'])
    for index,headers in enumerate(itertools.permutations(('codec.h','vorbisenc.h','vorbisfile.h'))):
        name=language+'-'+str(index);source=OUT/(name+'.'+extension)
        source.write_text('#define OV_EXCLUDE_STATIC_CALLBACKS 1\n'+''.join('#include "vorbis/'+header+'"\n'for header in headers)+layout,encoding='utf-8',newline='\n')
        obj=OUT/'objects'/(name+'.o');dependency=obj.with_suffix('.d')
        argv=[compiler,'-std='+standard,'-Wall','-Wextra','-Werror','-MMD','-MF',linux(dependency),*['-I'+linux(p)for p in includes],'-c',linux(source),'-o',linux(obj)]
        run('compile-'+name,argv)
        tokens=dependency.read_text().replace('\\\n',' ').split();selected=[value for value in tokens if value.endswith('/vorbis/codec.h')]
        assert set(selected)=={linux(public/'vorbis/codec.h')}
        assert all(linux(public/'vorbis'/header)in tokens for header in headers)
        report['probes'].append(dict(name=name,language=language,order=headers,source_sha256=sha(source),object_sha256=sha(obj),dependency_sha256=sha(dependency),codec_header=selected));save()
    # A misplaced original public include must fail the same capability/layout probe.
    name=language+'-original-first';source=OUT/(name+'.'+extension)
    source.write_text('#define OV_EXCLUDE_STATIC_CALLBACKS 1\n#include "vorbis/vorbisfile.h"\n'+layout,encoding='utf-8',newline='\n')
    run('compile-'+name,[compiler,'-std='+standard,'-I'+linux(base_public),*['-I'+linux(p)for p in includes],'-c',linux(source),'-o',linux(OUT/'objects'/(name+'.o'))],expected=1)
    assert 'Owned rate header not selected'in(OUT/('compile-'+name+'.stderr.log')).read_text()
report.update(completed=True,positive_probes=12,negative_header_selection_probes=2,source_only=True,all_public_orders=True);save()
print(json.dumps({key:report[key]for key in('completed','positive_probes','negative_header_selection_probes','source_only','all_public_orders')}))
