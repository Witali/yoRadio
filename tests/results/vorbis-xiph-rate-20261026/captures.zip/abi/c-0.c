#define OV_EXCLUDE_STATIC_CALLBACKS 1
#include "vorbis/codec.h"
#include "vorbis/vorbisenc.h"
#include "vorbis/vorbisfile.h"
#include <limits.h>
#include <stddef.h>
#ifndef NATIVE_VORBIS_XIPH_RATE_API
#error "Owned rate header not selected"
#endif
#ifdef __cplusplus
template<class A,class B> struct same_type { static constexpr bool value=false; };
template<class A> struct same_type<A,A> { static constexpr bool value=true; };
#define ASSERT static_assert
#define ALIGN alignof
#define SAME(A,B) same_type<A,B>::value
#else
#define ASSERT _Static_assert
#define ALIGN _Alignof
#define SAME(A,B) _Generic((A)0,B:1,default:0)
#endif
struct original_info_layout { int version,channels;long rate,bitrate_upper,bitrate_nominal,bitrate_lower,bitrate_window;void *codec_setup; };
ASSERT(NATIVE_VORBIS_XIPH_RATE_API==1,"rate capability");
ASSERT(sizeof(vorbis_info)==sizeof(struct original_info_layout),"original size");
ASSERT(ALIGN(vorbis_info)==ALIGN(struct original_info_layout),"original alignment");
#define OFFSET(field) ASSERT(offsetof(vorbis_info,field)==offsetof(struct original_info_layout,field),"original offset " #field)
OFFSET(version);OFFSET(channels);OFFSET(rate);OFFSET(bitrate_upper);OFFSET(bitrate_nominal);OFFSET(bitrate_lower);OFFSET(bitrate_window);OFFSET(codec_setup);
ASSERT((native_xiph_sample_rate_t)0xffffffffUL>0,"full positive uint32 range");
#if ULONG_MAX==0xffffffffUL
ASSERT(SAME(native_xiph_sample_rate_t,unsigned long),"32-bit rate type");
#else
ASSERT(SAME(native_xiph_sample_rate_t,long),"wide long original type");
#endif
