from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
body=(ROOT/'tests/test-vorbis-xiph-comments.py').read_bytes().decode()
def replace(before,after):
    global body
    assert before in body,before
    body=body.replace(before,after)
replace('''"""Independent metadata-only API regression under host ASan/UBSan.

No raw headers, DSP, packet decoder or deferred target gate executes. All
source bytes and owned Linux process-group receipts are retained.
"""''','''"""Unsigned-rate identification/comment metadata under host ASan/UBSan.

No setup header, DSP initialization, audio packet decoder or deferred target
fixture executes. Complete sources and owned process receipts are retained.
"""''')
replace('raw_header_decoder_executed=False','raw_header_decoder_executed=True,identification_header_executed=True,comment_header_executed=True,setup_header_executed=False')
replace('vorbis_xiph_comments_host.c','vorbis_xiph_rate_host.c')
replace('vorbis_xiph_comments.c','vorbis_xiph_rate.c')
replace("'owned_xiph_comment_prepare'","'owned_xiph_rate_prepare'")
replace("('alloc','comments','comments_host')","('alloc','rate','rate_host')")
replace("binary=out/'comment-tests'","binary=out/'rate-tests'")
replace("'-ffunction-sections','-fdata-sections'","'-ffunction-sections','-fdata-sections','-MMD'")
replace("r'COMMENT_PASS cases=([1-9][0-9]*) live=0 bytes=0\\s*'","r'RATE_PASS scenarios=([1-9][0-9]*) live=0 bytes=0\\s*'")
replace('complete asserted metadata result without sanitizer diagnostics','complete asserted identification/comment metadata result without sanitizer diagnostics')
replace("cases=int(match[1])","scenarios=int(match[1])")
replace("'passed','cases','library_units'","'passed','scenarios','library_units'")
replace("        need(all(sha(Path(path).read_bytes())",'''        dependencies={}
        for index,unit in enumerate(porting['compiled_units']):
            path=out/'objects'/f'library-{index:02d}.d'
            tokens=path.read_text().replace('\\\\\\n',' ').split()
            selected=[value for value in tokens if value.endswith('/vorbis/codec.h')]
            if selected:need(set(selected)=={linux(generated/'ported/include/vorbis/codec.h')},'selected owned public header in '+unit['compiled'])
            dependencies[unit['original']]=dict(sha256=sha(path.read_bytes()),codec_header=selected)
        need(dependencies['upstream/libvorbis/lib/info.c']['codec_header'] and dependencies['upstream/libvorbis/lib/block.c']['codec_header'],'rate consumers select owned public header')
        report['library_dependencies']=dependencies
        need(all(sha(Path(path).read_bytes())''')
(ROOT/'tests/test-vorbis-xiph-rate.py').write_bytes(body.encode())
print('Prepared independent unsigned-rate metadata host runner')
