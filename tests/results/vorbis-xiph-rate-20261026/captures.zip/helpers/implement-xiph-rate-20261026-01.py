"""Declare a complete unsigned-rate overlay beside the unchanged Xiph baseline."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'idf/components/native_vorbis_xiph'
PORT=ROOT/'idf/components/native_vorbis_xiph_port'
sha=lambda body:hashlib.sha256(body).hexdigest()
assert sha((BASE/'component-manifest.json').read_bytes())=='897096caf216de0e161f4fd833037863f8e2dc3da0531e34b851503f932f4b14'
edits=json.loads((PORT/'edits.json').read_bytes());assert len(edits['edits'])==33
def change(body,before,after):
    assert body.count(before)==1,before
    return body.replace(before,after,1)
def update(path,before,after):path.write_bytes(change(path.read_bytes().decode(),before,after).encode())
def add(source,stem,extension,before,after):
    assert (BASE/source).read_bytes().decode().count(before)==1 and before!=after
    for suffix,body in [('before',before),('after',after)]:
        (PORT/'edits'/(stem+'.'+suffix+'.'+extension)).write_bytes(body.encode())
    edits['edits'].append(dict(source=source,before=f'edits/{stem}.before.{extension}',after=f'edits/{stem}.after.{extension}'))

source='upstream/libvorbis/include/vorbis/codec.h';original=(BASE/source).read_bytes().decode()
before=original[:original.index('  long rate;\n')+len('  long rate;\n')]
after=change(before,'#define _vorbis_codec_h_\n','''#define _vorbis_codec_h_

#include <limits.h>
#define NATIVE_VORBIS_XIPH_RATE_API 1

/* Resource-port extension: preserve the positive unsigned32 bitstream rate.
   Layout stays that of long; consumers must use these matching headers. */
#if ULONG_MAX == 0xffffffffUL
typedef unsigned long native_xiph_sample_rate_t;
#else
typedef long native_xiph_sample_rate_t;
#endif
''')
after=change(after,'  long rate;\n','  native_xiph_sample_rate_t rate;\n')
add(source,'codec-rate-field','h',before,after)

before='''  vi->channels=oggpack_read(opb,8);
  vi->rate=oggpack_read(opb,32);
'''
after='''  vi->channels=oggpack_read(opb,8);
  {
    /* Two checked pieces keep valid 0xffffffff distinct from EOP on ILP32. */
    long low=oggpack_read(opb,16);
    long high=oggpack_read(opb,16);
    if(low<0 || high<0)goto err_out;
    vi->rate=((unsigned long)high<<16)|(unsigned long)low;
  }
'''
add('upstream/libvorbis/lib/info.c','info-rate','c',before,after)
(PORT/'edits.json').write_text(json.dumps(edits,indent=2)+'\n',encoding='utf-8',newline='\n')
update(PORT/'prepare.py',"BASE_SHA = '897096caf216de0e161f4fd833037863f8e2dc3da0531e34b851503f932f4b14'", "BASE_SHA = '897096caf216de0e161f4fd833037863f8e2dc3da0531e34b851503f932f4b14'\nPUBLIC_HEADER = 'upstream/libvorbis/include/vorbis/codec.h'")
update(PORT/'prepare.py',"len(changes['edits']) == 33, 'thirty-three exact reviewed edits'", "len(changes['edits']) == 35, 'thirty-five exact reviewed edits'")
update(PORT/'prepare.py',"need(source in baseline['compile_sources'], 'only a declared compiled source can change')", "need(source in baseline['compile_sources'] or source == PUBLIC_HEADER,\n             'only a declared compiled source or the rate public header can change')")
update(PORT/'prepare.py',"'upstream/libvorbis/lib/synthesis.c'},", "'upstream/libvorbis/lib/synthesis.c', PUBLIC_HEADER},")
update(PORT/'prepare.py',"'only the eleven reviewed translation units change'", "'only eleven reviewed C units and the rate public header change'")
update(PORT/'prepare.py',"generated.update({'ported/' + PurePosixPath(name).name: body for name, body in modified.items()})", "generated.update({'ported/' + PurePosixPath(name).name: body for name, body in modified.items()\n                      if name != PUBLIC_HEADER})\n    public_headers = []\n    for name in ('codec.h', 'vorbisenc.h', 'vorbisfile.h'):\n        origin = 'upstream/libvorbis/include/vorbis/' + name\n        destination = 'ported/include/vorbis/' + name\n        generated[destination] = modified.get(origin, original[origin])\n        public_headers.append(dict(original=origin, generated=destination, modified=origin in modified))")
update(PORT/'prepare.py',"compiled_units=units, files=", "compiled_units=units, public_headers=public_headers, files=")
update(PORT/'CMakeLists.txt','    INCLUDE_DIRS "${xiph_generated}/base/upstream/libvorbis/include"','    INCLUDE_DIRS "${xiph_generated}/ported/include"')
update(PORT/'README.md','under `base/`, and creates only eleven modified translation units and four owned\nprivate headers under `ported/`.', 'under `base/`, and creates eleven modified C units, four owned private headers\nand a three-file public header overlay under `ported/`. Two overlay headers\nremain byte-identical; the codec header declares the unsigned-rate extension.')
update(PORT/'README.md','Neither production application selects this component.', '''The public rate field now uses unsigned long where long is32 bits; on LP64 it
retains long. This represents the entire positive unsigned32 identification
rate without clamping or storing negative bits. Public struct storage, alignment
and offsets stay unchanged, while the source signedness is an explicit32-bit
API extension. Consumers must rebuild with the matching generated headers;
old binaries using signed long cannot interpret newly accepted high values.
Two checked16-bit reads distinguish0xffffffff from EOP. Zero remains invalid,
signed bitrate hints stay unchanged, and existing granule_time division sees
the positive rate directly. No physical output-rate capability is implied.
The overlay exports codec.h plus unchanged vorbisenc.h/vorbisfile.h copies so
their quoted sibling include selects the same type. Encoder and convenience
library rate consumers remain separately unqualified.

Neither production application selects this component.''')

manifest=json.loads((PORT/'port-manifest.json').read_bytes())
manifest['files']={path.relative_to(PORT).as_posix():sha(path.read_bytes())for path in sorted(PORT.rglob('*'))if path.is_file()and path.name!='port-manifest.json'}
(PORT/'port-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
digest=sha((PORT/'port-manifest.json').read_bytes());generator=sha((PORT/'prepare.py').read_bytes())

# The current packet driver must compile against exactly the exported overlay.
for name in ('test-vorbis-xiph-packets.py','test-vorbis-xiph-comments.py'):
    update(ROOT/'tests'/name,"generated/'base/upstream/libvorbis/include'", "generated/'ported/include'")
path=ROOT/'tests/test-vorbis-xiph-port-generation.py';body=path.read_bytes().decode()
for before,after in [
 ('400e4c3f3b01fec11d7d051d3a0cef62cc7e0528eb71962bd6e015ab8bf95355',digest),
 ('873472c0a30c955fa5d81528195ef71e4f476915b1ac8b64dd1d04dbae7f0251',generator),
 ('thirty_three_edit_eleven_unit','thirty_five_edit_eleven_unit_and_public_overlay'),
 ('len(result),132','len(result),135'),('len(changes),33','len(changes),35'),("len(record['edits']),33","len(record['edits']),35"),
 ('thirty-three exact reviewed edits','thirty-five exact reviewed edits')]:
    assert before in body,before
    body=body.replace(before,after)
body=change(body,"        expected_ports.update('ported/'+name for name in private_headers)","        expected_ports.update('ported/'+name for name in private_headers)\n        expected_ports.update('ported/include/vorbis/'+name for name in ('codec.h','vorbisenc.h','vorbisfile.h'))")
body=change(body,"        for name,value in expected.items():self.assertEqual(result['ported/'+Path(name).name],value)","        for name,value in expected.items():\n            destination='ported/include/vorbis/codec.h' if name=='upstream/libvorbis/include/vorbis/codec.h' else 'ported/'+Path(name).name\n            self.assertEqual(result[destination],value)\n        self.assertEqual(record['public_headers'],[dict(original='upstream/libvorbis/include/vorbis/'+name,generated='ported/include/vorbis/'+name,modified=name=='codec.h')for name in ('codec.h','vorbisenc.h','vorbisfile.h')])\n        for name in ('vorbisenc.h','vorbisfile.h'):\n            self.assertEqual(result['ported/include/vorbis/'+name],upstream_before['upstream/libvorbis/include/vorbis/'+name])")
path.write_bytes(body.encode())
print(json.dumps(dict(edits=35,public_overlay_headers=3,generated_files=135,port_manifest_sha256=digest,generator_sha256=generator)))
