import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PORT=ROOT/'idf/components/native_vorbis_xiph_port'
sha=lambda body:hashlib.sha256(body).hexdigest()
manifest=json.loads((PORT/'port-manifest.json').read_bytes())
manifest['files']={p.relative_to(PORT).as_posix():sha(p.read_bytes())for p in sorted(PORT.rglob('*'))if p.is_file()and p.name!='port-manifest.json'}
(PORT/'port-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
digest=sha((PORT/'port-manifest.json').read_bytes())
path=ROOT/'tests/test-vorbis-xiph-port-generation.py';body=path.read_bytes();old=b"PORT_SHA='0d13c3a7f9a0c9d8d68044dc6b2cf2e805bc4cc2804b0a3d6d985e6d99946353'"
assert body.count(old)==1;path.write_bytes(body.replace(old,b"PORT_SHA='"+digest.encode()+b"'"))
print(json.dumps(dict(port_manifest_sha256=digest,generator_sha256=sha((PORT/'prepare.py').read_bytes()))))
