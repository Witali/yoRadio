"""Collect unsigned-rate metadata, ABI and original PCM evidence separately."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'tests/results/vorbis-xiph-rate-20261026'
assert not OUT.exists();OUT.mkdir(parents=True);bodies={}
def add(path,name):
    assert path.resolve().is_relative_to(ROOT) and path.is_file()
    body=path.read_bytes();assert name not in bodies or bodies[name]==body;bodies[name]=body
def tree(folder,prefix):
    base=ROOT/folder;assert base.is_dir()
    for path in sorted(base.rglob('*')):
        if path.is_file():add(path,prefix+'/'+path.relative_to(base).as_posix())
for folder,prefix in(
    ('.build/vorbis-xiph-rate-host-20261026-01','host-first'),
    ('.build/vorbis-xiph-rate-host-20261026-02','host'),
    ('.build/vorbis-xiph-rate-packets-host-20261026-01','packets'),
    ('.build/vorbis-xiph-rate-abi-host-20261026-01','abi'),
    ('.build/vorbis-xiph-rate-lint-20261026-01','lint'),
    ('.build/vorbis-xiph-rate-api-doc-equivalence-20261026-01','equivalence'),
    ('.build/vorbis-xiph-rate-validation-20261026-01','receipts')):tree(folder,prefix)
native_root=ROOT/'.build/vorbis-xiph-rate-esp32-20261026-01'
native=json.loads((native_root/'report.json').read_bytes())
assert native['completed'] and native['metadata_qualified'] and native['ILP32_runtime_qualified']
assert not native['packet_decoder_executed'] and not native['dsp_gate_qualified'] and not native['wide_amplitude_qualified']
for path in native_root.iterdir():
    if path.is_file():add(path,'native/'+path.name)
for name in('sources','project'):tree(native_root.relative_to(ROOT)/name,'native/'+name)
for name,digest in native['build_outputs'].items():
    path=native_root/name;assert hashlib.sha256(path.read_bytes()).hexdigest()==digest;add(path,'native/'+name)
for name in('cyd-vorbis-format-command-01.py','implement-xiph-rate-20261026-01.py',
             'seal-xiph-rate-20261026-01.py','prepare-xiph-rate-host-20261026-01.py',
             'abi-xiph-rate-host-20261026-01.py','clarify-xiph-rate-api-20261026-01.py',
             'lint-xiph-rate-20261026-01.py','collect-xiph-rate-20261026-01.py'):
    add(ROOT/'.build'/name,'helpers/'+name)
for name in('test-vorbis-xiph-rate.py','test-vorbis-xiph-packets.py','test-vorbis-xiph-comments.py',
             'test-vorbis-xiph-port-generation.py','run-vorbis-xiph-rate-qemu.py',
             'test-vorbis-xiph-rate-protocol.py','verify-vorbis-xiph-packets-checkpoint.py',
             'verify-vorbis-xiph-rate-checkpoint.py'):
    add(ROOT/'tests'/name,'sources/tests/'+name)
manifest={'schema':'vorbis-xiph-rate-checkpoint-v1','files':{name:{'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body)}for name,body in sorted(bodies.items())}}
raw=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(OUT/'captures.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as archive:
    for name,body in sorted(bodies.items()):archive.writestr(name,body)
    archive.writestr('manifest.json',raw)
record=dict(sha256=hashlib.sha256((OUT/'captures.zip').read_bytes()).hexdigest(),bytes=(OUT/'captures.zip').stat().st_size,members=len(bodies)+1,manifest_sha256=hashlib.sha256(raw).hexdigest(),host_metadata_qualified=True,ESP32_ILP32_metadata_qualified=True,host_PCM_qualified=True,native_PCM_qualified=False,deferred_DSP_gate_qualified=False,wide_amplitude_qualified=False)
(OUT/'archive.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record))
