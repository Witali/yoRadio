/mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-01/objects/fixture-rate.o: \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-01/sources/native/vorbis_xiph_rate.c \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-01/generated/ported/include/vorbis/codec.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-01/generated/base/upstream/libogg/include/ogg/ogg.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-01/generated/base/upstream/libogg/include/ogg/os_types.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-01/generated/base/platform/ogg/config_types.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-01/sources/native/vorbis_xiph_alloc.h
