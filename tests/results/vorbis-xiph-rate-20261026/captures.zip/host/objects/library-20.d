/mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/objects/library-20.o: \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/generated/ported/bitwise.c \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/sources/native/vorbis_xiph_alloc_inject.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/sources/native/vorbis_xiph_alloc.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/generated/base/upstream/libogg/include/ogg/os_types.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/generated/base/platform/ogg/config_types.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/generated/base/upstream/libogg/include/ogg/ogg.h
