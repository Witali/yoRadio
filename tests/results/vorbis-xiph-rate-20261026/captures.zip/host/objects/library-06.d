/mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/objects/library-06.o: \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/generated/base/upstream/libvorbis/lib/lpc.c \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/sources/native/vorbis_xiph_alloc_inject.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/sources/native/vorbis_xiph_alloc.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/generated/base/upstream/libogg/include/ogg/os_types.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/generated/base/platform/ogg/config_types.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/generated/base/upstream/libvorbis/lib/os.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/generated/base/upstream/libvorbis/lib/misc.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/generated/ported/include/vorbis/codec.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/generated/base/upstream/libogg/include/ogg/ogg.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/generated/base/upstream/libvorbis/lib/smallft.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/generated/base/upstream/libvorbis/lib/lpc.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/generated/base/upstream/libvorbis/lib/scales.h
