/mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/objects/fixture-rate_host.o: \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/sources/native/vorbis_xiph_rate_host.c \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-xiph-rate-host-20261026-02/sources/native/vorbis_xiph_alloc.h
