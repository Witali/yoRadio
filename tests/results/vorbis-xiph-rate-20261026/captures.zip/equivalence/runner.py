"""Correct a stale type claim and prove that no implementation byte changes."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PORT=ROOT/'idf/components/native_vorbis_xiph_port'
HOST=ROOT/'.build/vorbis-xiph-rate-host-20261026-02/sources/components/native_vorbis_xiph_port'
OUT=ROOT/'.build/vorbis-xiph-rate-api-doc-equivalence-20261026-01'
assert not OUT.exists();OUT.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
before={p.relative_to(PORT).as_posix():p.read_bytes()for p in PORT.rglob('*')if p.is_file()}
frozen={p.relative_to(HOST).as_posix():p.read_bytes()for p in HOST.rglob('*')if p.is_file()}
assert before==frozen and sha(before['port-manifest.json'])=='5eaf91336853646962c77e729d3acb95b668ea64f29bd07607fe11234c2551e5'
old=b'same base-library units, types, floating configuration'
assert before['README.md'].count(old)==1
(PORT/'README.md').write_bytes(before['README.md'].replace(old,b'same base-library units, floating configuration'))
manifest=json.loads(before['port-manifest.json'])
manifest['files']={p.relative_to(PORT).as_posix():sha(p.read_bytes())for p in sorted(PORT.rglob('*'))if p.is_file()and p.name!='port-manifest.json'}
(PORT/'port-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
after={p.relative_to(PORT).as_posix():p.read_bytes()for p in PORT.rglob('*')if p.is_file()}
changed={name for name in before if before[name]!=after[name]}
assert set(before)==set(after) and changed=={'README.md','port-manifest.json'}
digest=sha(after['port-manifest.json'])
path=ROOT/'tests/test-vorbis-xiph-port-generation.py';body=path.read_bytes();old_pin=b"PORT_SHA='5eaf91336853646962c77e729d3acb95b668ea64f29bd07607fe11234c2551e5'"
assert body.count(old_pin)==1;path.write_bytes(body.replace(old_pin,b"PORT_SHA='"+digest.encode()+b"'"))
report=dict(completed=True,host_port_manifest_sha256=sha(before['port-manifest.json']),current_port_manifest_sha256=digest,changed_files=sorted(changed),implementation_files_unchanged=True,
    files={name:dict(before_sha256=sha(before[name]),after_sha256=sha(after[name]))for name in sorted(before)})
(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
for name in changed:(OUT/('current-'+name)).write_bytes(after[name])
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({key:report[key]for key in('completed','host_port_manifest_sha256','current_port_manifest_sha256','changed_files','implementation_files_unchanged')}))
