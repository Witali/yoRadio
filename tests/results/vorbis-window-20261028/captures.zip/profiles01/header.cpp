#include "native_vorbis_window.h"
extern "C" auto window_api_probe() -> decltype(&native_vorbis_window_apply) { return &native_vorbis_window_apply; }
