import hashlib,json,os,re,struct,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parents[1]
O=R/'.build/vorbis-window-profiles-20261028-02'
O.mkdir(exist_ok=False)
S=R/'.build/vorbis-window-host-20261028-04/sources'
inc=['-I'+str(p) for p in sorted((S/'components').glob('*/include'))]
report=dict(completed=False,passed=False,commands=[],objects=[])
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(): (O/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(name,argv):
    row=dict(name=name,argv=list(map(str,argv)));report['commands'].append(row);save()
    started=time.monotonic()
    with (O/(name+'.stdout.log')).open('xb') as so,(O/(name+'.stderr.log')).open('xb') as se:
        child=subprocess.Popen(argv,cwd=R,stdin=subprocess.DEVNULL,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid']=child.pid
        try: row['returncode']=child.wait(timeout=45)
        except BaseException:
            subprocess.run(['taskkill.exe','/PID',str(child.pid),'/T','/F'],capture_output=True,timeout=10,creationflags=subprocess.CREATE_NO_WINDOW)
            child.wait(timeout=10);raise
    row.update(elapsed_seconds=time.monotonic()-started,
        stdout_sha256=h(O/(name+'.stdout.log')),stderr_sha256=h(O/(name+'.stderr.log')));save()
    assert row['returncode']==0,name
    return (O/(name+'.stdout.log')).read_text('utf-8',errors='replace')+(O/(name+'.stderr.log')).read_text('utf-8',errors='replace')
try:
    probe=O/'header.cpp'
    probe.write_text('#include "native_vorbis_window.h"\nextern "C" auto window_api_probe() -> decltype(&native_vorbis_window_apply) { return &native_vorbis_window_apply; }\n',encoding='utf-8',newline='\n')
    toolroot=Path('C:/Work/yoRadio/.idf')
    profiles=[('lx6',toolroot/'tools-v6.0.2/tools/xtensa-esp-elf/esp-15.2.0_20251204/xtensa-esp-elf/bin/xtensa-esp32-elf-gcc.exe',[]),
        ('rv32',toolroot/'tools-v6.1/tools/riscv32-esp-elf/esp-15.2.0_20251204/riscv32-esp-elf/bin/riscv32-esp-elf-gcc.exe',['-march=rv32imc','-mabi=ilp32'])]
    for name,gcc,extra in profiles:
        run(name+'-version',[str(gcc),'--version'])
        for unit,path,lang in [('window',S/'components/native_vorbis_window/window.c','c'),('header',probe,'c++')]:
            compiler=gcc if lang=='c' else gcc.with_name(gcc.name.replace('-gcc.exe','-g++.exe'))
            target=O/(name+'-'+unit+'.o')
            run(name+'-'+unit,[str(compiler),*extra,'-O2','-fno-inline','-fno-fast-math','-ffp-contract=off','-fstack-usage',
                '-Wall','-Wextra','-Werror','-std=gnu17' if lang=='c' else '-std=gnu++17',*inc,'-c',str(path),'-o',str(target)])
            body=target.read_bytes();assert body[:5]==b'\x7fELF\x01'
            report['objects'].append(dict(name=target.name,sha256=h(target),elf_machine=struct.unpack_from('<H',body,18)[0]))
    tidy=toolroot/'tools-v6.0.2/tools/esp-clang/esp-20.1.1_20250829/esp-clang/bin/clang-tidy.exe'
    cfg=O/'clang-tidy.yaml';cfg.write_bytes((R/'.clang-tidy').read_bytes())
    builtin=tidy.parent.parent/'lib/clang/20/include'
    libc=toolroot/'tools-v6.0.2/tools/xtensa-esp-elf/esp-15.2.0_20251204/xtensa-esp-elf/picolibc/include'
    report['lint']=[]
    for name,path in [('window',S/'components/native_vorbis_window/window.c'),('fixture',S/'native/vorbis_window_host.c')]:
        text=run('lint-'+name,[str(tidy),str(path),'--config-file='+str(cfg),'--header-filter=.*','--export-fixes='+str(O/(name+'.yaml')),'--',
            '--target=xtensa-esp-elf','-mcpu=esp32','-std=gnu17','-O2','-UNDEBUG','-fno-fast-math','-ffp-contract=off',
            '-nostdinc','-isystem',str(builtin),'-isystem',str(libc),*inc])
        row=dict(unit=name,warnings=len(re.findall(r': warning:',text)),errors=len(re.findall(r': error:',text)))
        report['lint'].append(row);assert not row['errors']
    report['stack_records']={p.name:p.read_text('utf-8') for p in O.glob('*.su')}
    report.update(completed=True,passed=True);save()
    print(json.dumps(dict(passed=True,commands=len(report['commands']),objects=report['objects'],lint=report['lint'],stack_records=report['stack_records'])))
except BaseException as e:
    report['error']=repr(e);save();raise
