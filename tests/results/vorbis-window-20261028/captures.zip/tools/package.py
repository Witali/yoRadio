import argparse,hashlib,importlib.util,json,re,struct,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('kind',choices=['normalized','window']);a=p.parse_args()
h=lambda b:hashlib.sha256(b).hexdigest()
def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def need(x,msg):
    if not x:raise ValueError(msg)
if a.kind=='normalized':
    subject=module(R/'tests/test-vorbis-normalized-transform.py','root_normalized_reader')
    oracle=module(R/'tests/test-vorbis-transform.py','root_transform_oracle')
    final=R/'.build/vorbis-normalized-transform-host-20261028-04'
    report=json.loads((final/'report.json').read_bytes())
    measured=subject.compare((final/'capture.bin').read_bytes(),oracle)
    need(measured==report['measurements'],'root full normalized replay')
    for name,pin in report['inputs'].items():
        need(h((R/name).read_bytes())==pin['sha256']==h((final/pin['snapshot']).read_bytes()),'current exact source')
    subject_path=R/'tests/test-vorbis-normalized-transform.py'
    groups=[(f'host{i:02}',R/f'.build/vorbis-normalized-transform-host-20261028-{i:02}') for i in range(1,5)]
    groups += [(f'gcc{i:02}',R/f'.build/vorbis-normalized-transform-gcc-20261028-{i:02}') for i in range(1,3)]
    groups += [(f'lint{i:02}',R/f'.build/vorbis-normalized-transform-lint-20261028-{i:02}') for i in range(1,3)]
    scripts=['compile-vorbis-normalized-transform-profiles-20261028-01.py','lint-vorbis-normalized-transform-20261028-01.py']
    folder=R/'tests/results/vorbis-normalized-transform-20261028'
    final_group='host04'
else:
    subject=module(R/'tests/test-vorbis-window.py','root_window_reader')
    final=R/'.build/vorbis-window-host-20261028-04'
    report=json.loads((final/'report.json').read_bytes())
    measured=subject.inspect_capture((final/'capture.bin').read_bytes())
    need(measured==report['measurements'],'root full window replay')
    need(subject.corruption_controls((final/'capture.bin').read_bytes())==report['corruption_controls'],'root corruption controls')
    for name,digest in report['sources'].items():need(h((final/'sources'/name).read_bytes())==digest,'exact frozen source')
    for name in ['window.c','include/native_vorbis_window.h']:
        need((R/'idf/components/native_vorbis_window'/name).read_bytes()==(final/'sources/components/native_vorbis_window'/name).read_bytes(),'current window source')
    subject_path=R/'tests/test-vorbis-window.py'
    groups=[(f'host{i:02}',R/f'.build/vorbis-window-host-20261028-{i:02}') for i in range(1,5)]
    groups += [(f'profiles{i:02}',R/f'.build/vorbis-window-profiles-20261028-{i:02}') for i in range(1,3)]
    scripts=['vorbis-window-profiles-20261028.py']
    folder=R/'tests/results/vorbis-window-20261028'
    final_group='host04'
need(report['completed'] and report['passed'],'actual final test passed')
for row in report['commands']:
    supervisor=row['supervisor']
    need(row['transport_exit']==0 and supervisor['state']=='terminal' and supervisor['child_returncode']==0
        and supervisor['child_reaped'] and supervisor['group_gone'],'each command terminal and clean')
replay=dict(passed=True,scope=a.kind,reader_sha256=h(subject_path.read_bytes()),
    capture_sha256=h((final/'capture.bin').read_bytes()),measurements=measured,
    commands_replayed=len(report['commands']),commands_reexecuted=0,
    source_checks=True,archived_code_executed=False,files_extracted=False,
    native_executed=False,production_selected=False)
if a.kind=='window':replay['corruption_controls']=report['corruption_controls']
folder.mkdir(exist_ok=False)
entries={}
for label,source in groups:
    need(source.is_dir(),'preserved attempt exists')
    for path in sorted(source.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:continue
        rel=path.relative_to(source)
        # Captures, sources, commands, diagnostics and source-profile ELF remain.
        # Host executables/objects are rebuildable and have recorded hashes.
        if label.startswith('host') and (rel.parts[0]=='objects' or path.name in ['window','normalized-transform']):continue
        entries[label+'/'+rel.as_posix()]=path.read_bytes()
for name in scripts:entries['tools/'+name]=(R/'.build'/name).read_bytes()
for label,source in groups:
    for suffix in ['.outer.json','.outer.stdout.log','.outer.stderr.log']:
        path=source.with_name(source.name+suffix)
        if path.is_file():entries['outer/'+label+suffix]=path.read_bytes()
entries['tools/package.py']=Path(__file__).read_bytes()
archive=folder/'captures.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,body in sorted(entries.items()):
        info=zipfile.ZipInfo(name,(2026,10,28,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o100644<<16;z.writestr(info,body)
manifest=dict(archive_sha256=h(archive.read_bytes()),archive_bytes=archive.stat().st_size,
    final_group=final_group,files=[dict(path=name,bytes=len(body),sha256=h(body)) for name,body in sorted(entries.items())])
(folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
(folder/'replay.json').write_text(json.dumps(replay,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(passed=True,kind=a.kind,archive_bytes=archive.stat().st_size,
    members=len(entries),uncompressed_bytes=sum(map(len,entries.values())),archive_sha256=manifest['archive_sha256'],
    manifest_sha256=h((folder/'manifest.json').read_bytes()),measurements=measured)))
