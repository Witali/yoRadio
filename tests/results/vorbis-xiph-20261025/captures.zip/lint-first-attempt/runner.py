"""Analyze the isolated baseline with explicit Clang Xtensa flags, not GCC options."""
import ctypes
import hashlib
import json
import re
import subprocess
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
CAPTURE=ROOT/'.build/vorbis-xiph-esp32-20261025-02'
OUT=ROOT/'.build/vorbis-xiph-lint-20261025-01'
TOOL=Path('C:/Work/yoRadio/.idf/tools-v6.0.2/tools/esp-clang/esp-20.1.1_20250829/esp-clang/bin/clang-tidy.exe')
assert not OUT.exists()
OUT.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
native=json.loads((CAPTURE/'report.json').read_text('utf-8'))
database=json.loads((CAPTURE/'build/compile_commands.json').read_text('utf-8'))
manifest=json.loads((ROOT/'idf/components/native_vorbis_xiph/component-manifest.json').read_text('utf-8'))
selected_rows={}
for name,source in [('fixture',CAPTURE/'project/main/main.c')]+[(name,CAPTURE/'sources/components/native_vorbis_xiph'/name)for name in manifest['compile_sources']]:
    rows=[row for row in database if Path(row['file']).resolve()==source.resolve()]
    assert len(rows)==1
    if name!='fixture':assert sha(source)==manifest['files'][name]
    selected_rows[name]=rows[0]
(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
(OUT/'clang-tidy.yaml').write_bytes((ROOT/'.clang-tidy').read_bytes())
report={'completed':False,'scope':'Explicit Clang Xtensa ESP32 analysis of the 22 unmodified upstream units and isolated adapter. Native GCC -I/-D configuration only; GCC machine/optimization flags are not passed to Clang. Not a Clang SDK build or full binary dependency closure.',
    'commands':[],'warnings':0,'errors':0,'tools':{str(TOOL):sha(TOOL)},'inputs':{},'configured_gcc_attempt':'02 failed on upstream misleading indentation; only its configured include/definition recipe is reused, not a native success claim.', 'compile_database_sha256':sha(CAPTURE/'build/compile_commands.json')}
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
def split_windows(command):
    count=ctypes.c_int()
    call=ctypes.windll.shell32.CommandLineToArgvW
    call.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
    call.restype=ctypes.POINTER(ctypes.c_wchar_p)
    pointer=call(command,ctypes.byref(count))
    assert pointer
    try:return [pointer[i]for i in range(count.value)]
    finally:
        ctypes.windll.kernel32.LocalFree.argtypes=[ctypes.c_void_p]
        ctypes.windll.kernel32.LocalFree(pointer)
save()
for index,(name,row)in enumerate(selected_rows.items()):
    source=Path(row['file']);report['inputs'][str(source)]=sha(source)
    args=split_windows(row['command']);selected=[];i=1
    while i<len(args):
        arg=args[i]
        if arg in ('-I','-D','-isystem','-include','-iquote'):
            assert i+1<len(args);selected.extend(args[i:i+2]);i+=2;continue
        if arg.startswith(('-I','-D')):selected.append(arg)
        i+=1
    stem=f'{index:02d}-'+Path(name).stem
    argv=[str(TOOL),str(source),'--config-file='+str(OUT/'clang-tidy.yaml'),'--header-filter=.*','--export-fixes='+str(OUT/(stem+'.yaml')),
          '--','--target=xtensa-esp-elf','-mcpu=esp32','-std=gnu17','-O2','-fno-fast-math','-ffp-contract=off',*selected]
    command={'name':name,'argv':argv,'cwd':row['directory']};report['commands'].append(command);start=time.monotonic()
    child=None
    try:
        with (OUT/(stem+'.stdout.log')).open('xb')as so,(OUT/(stem+'.stderr.log')).open('xb')as se:
            child=subprocess.Popen(argv,cwd=row['directory'],stdin=subprocess.DEVNULL,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
            command['pid']=child.pid;command['returncode']=child.wait(timeout=90)
    finally:
        if child is not None and child.poll()is None:child.kill();child.wait(timeout=5);command['forced_stop']=True
        command['elapsed_seconds']=time.monotonic()-start
        logs=[]
        for stream in ('stdout','stderr'):
            path=OUT/(stem+'.'+stream+'.log');command[stream+'_sha256']=sha(path);logs.append(path.read_text('utf-8',errors='replace'))
        text='\n'.join(logs);command['warnings']=len(re.findall(r': warning:',text));command['errors']=len(re.findall(r': (?:error|fatal error):',text))
        report['warnings']+=command['warnings'];report['errors']+=command['errors'];save()
    print(json.dumps({k:command[k]for k in ('name','returncode','warnings','errors')}),flush=True)
    assert command['returncode']==0 and not command['errors']and not command.get('forced_stop'),name
assert all(sha(path)==digest for path,digest in report['inputs'].items())and sha(TOOL)==report['tools'][str(TOOL)]
report['completed']=True;save()
