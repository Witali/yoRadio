import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent.parent / 'idf/components/native_vorbis_xiph'
template = root / 'upstream/libogg/include/ogg/config_types.h.in'
values = {'INCLUDE_INTTYPES_H': '0', 'INCLUDE_STDINT_H': '1', 'INCLUDE_SYS_TYPES_H': '0',
          'SIZE16': 'int16_t', 'USIZE16': 'uint16_t', 'SIZE32': 'int32_t',
          'USIZE32': 'uint32_t', 'SIZE64': 'int64_t', 'USIZE64': 'uint64_t'}
raw = template.read_bytes()
for key, value in values.items():
    assert raw.count(f'@{key}@'.encode()) == 1
    raw = raw.replace(f'@{key}@'.encode(), value.encode())
assert b'@' not in raw
target = root / 'platform/ogg/config_types.h'
target.parent.mkdir(parents=True, exist_ok=True)
assert not target.exists()
target.write_bytes(raw)
source = json.loads((root / 'SOURCE.json').read_text('utf-8'))
source['platform_config'] = {'template': str(template.relative_to(root).as_posix()),
    'generated': str(target.relative_to(root).as_posix()), 'substitutions': values,
    'sha256': hashlib.sha256(raw).hexdigest()}
(root / 'SOURCE.json').write_text(json.dumps(source, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')
units = 'mdct smallft block envelope window lsp lpc analysis synthesis psy info floor1 floor0 res0 mapping0 registry codebook sharedbook lookup bitrate'.split()
compiled = [f'upstream/libvorbis/lib/{u}.c' for u in units] + ['upstream/libogg/src/bitwise.c', 'upstream/libogg/src/framing.c']
files = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in sorted(root.rglob('*')) if p.is_file() and p.name != 'component-manifest.json'}
assert len(compiled) == 22 and all(c in files for c in compiled)
manifest = {'schema': 'native-vorbis-xiph-source-v1', 'compile_sources': compiled, 'files': files}
dest = root / 'component-manifest.json'
assert not dest.exists()
dest.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'files': len(files), 'compile_sources': len(compiled), 'manifest_sha256': hashlib.sha256(dest.read_bytes()).hexdigest()}))
