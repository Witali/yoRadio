import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent.parent/'idf/components/native_vorbis_xiph'
source=json.loads((root/'SOURCE.json').read_text('utf-8'))
source['encoder_diagnostic_adaptation']={'flag':'-Wno-error=maybe-uninitialized','compiler':'GNU only','files':['upstream/libvorbis/lib/lpc.c','upstream/libvorbis/lib/psy.c'],
    'reason':'Actual GCC15.2 build/probe warnings at lpc.c:78 and psy.c:714. Encoder-only callers provide positive orders/sizes and preceding loops initialize the arrays. Warnings retained; unchanged release baseline, not an arithmetic patch.'}
(root/'SOURCE.json').write_text(json.dumps(source,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
manifest=json.loads((root/'component-manifest.json').read_text('utf-8'))
manifest['files']={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(root.rglob('*'))if p.is_file()and p.name!='component-manifest.json'}
(root/'component-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
print(hashlib.sha256((root/'component-manifest.json').read_bytes()).hexdigest())
