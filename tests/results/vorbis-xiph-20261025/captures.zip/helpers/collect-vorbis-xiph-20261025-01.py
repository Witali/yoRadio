"""Retain the actual finite Xiph evaluation, including earlier failure evidence."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'tests/results/vorbis-xiph-20261025'
assert not OUT.exists()
OUT.mkdir(parents=True)
bodies={}
def add(path,name):
    assert path.resolve().is_relative_to(ROOT)and path.is_file()
    raw=path.read_bytes();assert name not in bodies or bodies[name]==raw
    bodies[name]=raw
def tree(relative,prefix):
    folder=ROOT/relative
    for path in sorted(folder.rglob('*')):
        if path.is_file():add(path,prefix+'/'+path.relative_to(folder).as_posix())
tree('.build/vorbis-xiph-prep-20261025-01','prepared')
tree('.build/vorbis-xiph-validation-20261025-01','receipts')
tree('.build/vorbis-xiph-compare-20261025-01','comparison')
tree('.build/vorbis-xiph-source-20261025-01','download')
for folder,prefix in (('.build/vorbis-xiph-esp32-20261025-01','first-attempt'),('.build/vorbis-xiph-esp32-20261025-02','second-attempt'),('.build/vorbis-xiph-esp32-20261025-03','third-attempt'),('.build/vorbis-xiph-esp32-20261025-04','native')):
    base=ROOT/folder;report=json.loads((base/'report.json').read_text('utf-8'))
    for path in base.iterdir():
        if path.is_file():add(path,prefix+'/'+path.name)
    for sub in ('sources','project','pcm'):
        if(base/sub).is_dir():tree(folder+'/'+sub,prefix+'/'+sub)
    for name,digest in report.get('build_outputs',{}).items():
        path=base/name;assert hashlib.sha256(path.read_bytes()).hexdigest()==digest;add(path,prefix+'/'+name)
    for name in ('build/compile_commands.json','build/project_description.json','build/CMakeCache.txt','build/build.ninja','build/CMakeFiles/rules.ninja','build/config/sdkconfig.h','build/toolchain/cflags','build/specs/picolibc.specs'):
        if(base/name).is_file():add(base/name,prefix+'/'+name)
for folder,prefix in (('vorbis-xiph-lint-20261025-01','lint-first-attempt'),('vorbis-xiph-lint-20261025-02','lint')):
    if(ROOT/'.build'/folder).is_dir():tree('.build/'+folder,prefix)
for index in range(1,4):
    folder=f'.build/vorbis-xiph-gcc-probe-20261025-{index:02d}'
    if(ROOT/folder).is_dir():tree(folder,f'gcc-probe-{index}')
for name in ('cyd-vorbis-format-command-01.py','import-vorbis-xiph-20261025-01.py','finalize-vorbis-xiph-component-20261025-01.py','update-vorbis-xiph-component-20261025-02.py','update-vorbis-xiph-component-20261025-03.py','lint-vorbis-xiph-20261025-01.py','probe-vorbis-xiph-gcc-20261025-01.py','collect-vorbis-xiph-20261025-01.py','vorbis-xiph-pcm-units-before-receipt-selection-20261025-01.py'):
    add(ROOT/'.build'/name,'helpers/'+name)
for name in ('prepare-vorbis-xiph.py','run-vorbis-xiph-qemu.py','test-vorbis-xiph-pcm.py','test-vorbis-xiph-protocol.py','test-vorbis-xiph-pcm-units.py','verify-vorbis-xiph-checkpoint.py'):
    add(ROOT/'tests'/name,'sources/tests/'+name)
manifest={name:{'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}for name,raw in sorted(bodies.items())}
manifest_raw=(json.dumps({'schema':'vorbis-xiph-checkpoint-v1','files':manifest},indent=2)+'\n').encode()
with zipfile.ZipFile(OUT/'captures.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as archive:
    for name,raw in sorted(bodies.items()):archive.writestr(name,raw)
    archive.writestr('manifest.json',manifest_raw)
(OUT/'archive.json').write_text(json.dumps({'sha256':hashlib.sha256((OUT/'captures.zip').read_bytes()).hexdigest(),'bytes':(OUT/'captures.zip').stat().st_size,'members':len(manifest)+1,'manifest_sha256':hashlib.sha256(manifest_raw).hexdigest()},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'members':len(manifest)+1,'bytes':(OUT/'captures.zip').stat().st_size}))
