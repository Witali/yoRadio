"""Fetch pinned public Xiph releases and import unchanged source files only."""
import hashlib
import json
import tarfile
import urllib.request
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent.parent
STAGE = ROOT / '.build/vorbis-xiph-source-20261025-01'
DEST = ROOT / 'idf/components/native_vorbis_xiph'
assert not STAGE.exists() or not any(STAGE.iterdir())
assert not DEST.exists() or not any(DEST.iterdir())
STAGE.mkdir(exist_ok=True)
DEST.mkdir(parents=True, exist_ok=True)
sources = [
    ('libvorbis', '1.3.7', 'vorbis', 'b33cc4934322bcbf6efcbacf49e3ca01aadbea4114ec9589d1b1e9d20f72954b'),
    ('libogg', '1.3.5', 'ogg', 'c4d91be36fc8e54deae7575241e03f4211eb102afb3fc0775fbbc1b740016705'),
]
records = []
for name, version, category, expected in sources:
    filename = f'{name}-{version}.tar.xz'
    base = f'https://ftp.osuosl.org/pub/xiph/releases/{category}/'
    fetched = {}
    for item in ('SHA256SUMS', filename):
        with urllib.request.urlopen(base + item, timeout=45) as response:
            raw = response.read(16 * 1024 * 1024 + 1)
            assert len(raw) <= 16 * 1024 * 1024
            fetched[item] = {'url': base + item, 'final_url': response.url,
                             'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        (STAGE / f'{name}-{item}').write_bytes(raw)
    sums = (STAGE / f'{name}-SHA256SUMS').read_text('ascii')
    assert f'{expected}  {filename}' in sums
    archive = STAGE / f'{name}-{filename}'
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == expected
    prefix = f'{name}-{version}'
    copied = {}
    with tarfile.open(archive, 'r:xz') as stream:
        for member in stream.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == prefix and not any(p in ('..', '.', '') for p in parts)
            assert not PurePosixPath(member.name).is_absolute()
            if member.isdir():
                continue
            assert member.isfile(), f'Non-regular archive member: {member.name}'
            rel = PurePosixPath(*parts[1:])
            selected = (parts[1] in ('lib', 'include') if name == 'libvorbis' else parts[1] in ('src', 'include'))
            selected |= str(rel) in ('COPYING', 'AUTHORS', 'README', 'CHANGES', 'CMakeLists.txt', 'configure.ac')
            if not selected:
                continue
            assert member.size <= 8 * 1024 * 1024
            raw = stream.extractfile(member).read()
            target = DEST / 'upstream' / name / str(rel)
            assert target.resolve().is_relative_to(DEST.resolve()) and not target.exists()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
            copied[str(rel)] = hashlib.sha256(raw).hexdigest()
    records.append({'name': name, 'version': version, 'archive': fetched[filename],
                    'checksums': fetched['SHA256SUMS'], 'files': copied})
result = {'schema': 'native-vorbis-xiph-upstream-v1', 'sources': records,
          'import_policy': 'Regular source/include trees and upstream provenance files; byte-identical, no upstream scripts executed.'}
(DEST / 'SOURCE.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')
(STAGE / 'import.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'status': 'PASS', 'files': sum(len(r['files']) for r in records), 'destination': str(DEST)}))
