import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent.parent/'idf/components/native_vorbis_xiph'
source=json.loads((root/'SOURCE.json').read_text('utf-8'))
source['build_adaptation']={'flag':'-Wno-error=misleading-indentation','scope':'Imported component only; diagnostics remain visible, other warnings-as-errors unchanged.',
    'reason':'Actual ESP-IDF6.0.2/GCC15.2 baseline build rejected unmodified libvorbis block.c:395..397 free/reset statement layout. No upstream arithmetic or source bytes changed.'}
(root/'SOURCE.json').write_text(json.dumps(source,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
manifest=json.loads((root/'component-manifest.json').read_text('utf-8'))
manifest['files']={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(root.rglob('*'))if p.is_file()and p.name!='component-manifest.json'}
(root/'component-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
print(hashlib.sha256((root/'component-manifest.json').read_bytes()).hexdigest())
