"""Compile all baseline units to fresh objects before another full SDK build."""
import ctypes,hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
CAP=ROOT/'.build/vorbis-xiph-esp32-20261025-03'
OUT=ROOT/'.build/vorbis-xiph-gcc-probe-20261025-03'
assert not OUT.exists();OUT.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
report={'completed':False,'commands':[],'scope':'Configured baseline compilation to new probe objects, not SDK/ELF/QEMU qualification. The observed lpc.c maybe-uninitialized diagnostic remains a warning for this probe only.'}
(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
def split(command):
    count=ctypes.c_int();call=ctypes.windll.shell32.CommandLineToArgvW;call.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)];call.restype=ctypes.POINTER(ctypes.c_wchar_p)
    pointer=call(command,ctypes.byref(count));assert pointer
    try:return [pointer[i]for i in range(count.value)]
    finally:
        ctypes.windll.kernel32.LocalFree.argtypes=[ctypes.c_void_p];ctypes.windll.kernel32.LocalFree(pointer)
database=json.loads((CAP/'build/compile_commands.json').read_text('utf-8'))
manifest=json.loads((CAP/'sources/components/native_vorbis_xiph/component-manifest.json').read_text('utf-8'))
sources=[CAP/'project/main/main.c']+[CAP/'sources/components/native_vorbis_xiph'/n for n in manifest['compile_sources']]
save()
for index,source in enumerate(sources):
    rows=[r for r in database if Path(r['file']).resolve()==source.resolve()];assert len(rows)==1;row=rows[0];argv=split(row['command']);name=f'{index:02d}-'+source.stem
    for flag,suffix in (('-o','.obj'),('-MF','.obj.d'),('-MT','.obj')):
        assert argv.count(flag)<=1
        if flag in argv:argv[argv.index(flag)+1]=str(OUT/(name+suffix))
        else:argv.extend([flag,str(OUT/(name+suffix))])
    if '-MD'not in argv and '-MMD'not in argv:argv.append('-MD')
    if source.name=='lpc.c':argv.append('-Wno-error=maybe-uninitialized')
    command={'name':name,'argv':argv,'cwd':row['directory'],'source_sha256':sha(source),'compiler_sha256':sha(argv[0])};report['commands'].append(command);start=time.monotonic()
    with (OUT/(name+'.stdout.log')).open('xb')as so,(OUT/(name+'.stderr.log')).open('xb')as se:
        child=subprocess.Popen(argv,cwd=row['directory'],stdin=subprocess.DEVNULL,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW);command['pid']=child.pid
        try:command['returncode']=child.wait(timeout=60)
        finally:
            if child.poll()is None:child.kill();child.wait(timeout=5);command['forced_stop']=True
    command['elapsed_seconds']=time.monotonic()-start
    for stream in ('stdout','stderr'):command[stream+'_sha256']=sha(OUT/(name+'.'+stream+'.log'))
    save();print(json.dumps({'name':name,'returncode':command['returncode']}),flush=True)
report['completed']=True;report['all_compiled']=all(c['returncode']==0 and not c.get('forced_stop')for c in report['commands']);save()
raise SystemExit(0 if report['all_compiled']else 1)
