import hashlib,importlib.util,json,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[1];h=lambda b:hashlib.sha256(b).hexdigest()
source=R/'tests/test-vorbis-timing.py';spec=importlib.util.spec_from_file_location('root_timing_replay',source)
reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
final=R/'.build/vorbis-timing-host-20261028-03';report=json.loads((final/'report.json').read_bytes())
original=(final/'sources/original31.json').read_bytes();model=reader.corpus(json.loads(original))
capture=(final/'capture.bin').read_bytes();measured=reader.inspect_capture(capture,model)
damaged=reader.corruption_controls(capture,model)
assert report['completed'] and report['passed'] and measured==report['measurements'] and damaged==report['corruption_controls']
assert reader.encode(model)==(final/'input.bin').read_bytes()
assert reader.xiph_fragment((final/'sources/upstream/block.c').read_bytes())==(final/'sources/native/xiph-granule.inc').read_bytes()
for name,digest in report['sources'].items():assert h((final/'sources'/name).read_bytes())==digest
for name in ['timing.c','include/native_vorbis_timing.h']:
    assert (R/'idf/components/native_vorbis_timing'/name).read_bytes()==(final/'sources/components/native_vorbis_timing'/name).read_bytes()
for row in report['commands']:
    s=row['supervisor'];assert row['transport_exit']==0 and s['state']=='terminal' and s['child_returncode']==0 and s['child_reaped'] and s['group_gone']
out=R/'tests/results/vorbis-timing-20261028';out.mkdir(exist_ok=False)
entries={};groups=[(f'host{i:02}',R/f'.build/vorbis-timing-host-20261028-{i:02}') for i in range(1,4)]
groups += [('profiles01',R/'.build/vorbis-timing-profiles-20261028-01'),('fixture-lint01',R/'.build/vorbis-timing-fixture-lint-20261028-01')]
for label,folder in groups:
    assert folder.is_dir()
    for path in sorted(folder.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:continue
        rel=path.relative_to(folder)
        if label.startswith('host') and (rel.parts[0]=='objects' or path.name=='timing'):continue
        entries[label+'/'+rel.as_posix()]=path.read_bytes()
    for suffix in ['.outer.json','.outer.stdout.log','.outer.stderr.log']:
        path=folder.with_name(folder.name+suffix)
        if path.is_file():entries['outer/'+label+suffix]=path.read_bytes()
for name in ['profile-vorbis-timing-20261028.py','lint-vorbis-timing-fixture-20261028.py']:
    path=R/'.build'/name
    if path.is_file():entries['tools/'+name]=path.read_bytes()
entries['tools/package.py']=Path(__file__).read_bytes()
archive=out/'captures.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,body in sorted(entries.items()):
        info=zipfile.ZipInfo(name,(2026,10,28,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,body)
manifest=dict(archive_sha256=h(archive.read_bytes()),archive_bytes=archive.stat().st_size,final_group='host03',
    files=[dict(path=name,bytes=len(body),sha256=h(body)) for name,body in sorted(entries.items())])
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
replay=dict(passed=True,members=len(entries),reader_sha256=h(source.read_bytes()),measurements=measured,corruption_controls=damaged,
    archived_code_executed=False,files_extracted=False,commands_reexecuted=0,decoder_executed=False,native_executed=False)
(out/'replay.json').write_text(json.dumps(replay,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(passed=True,members=len(entries),archive_bytes=archive.stat().st_size,
    uncompressed_bytes=sum(map(len,entries.values())),archive_sha256=manifest['archive_sha256'],
    manifest_sha256=h((out/'manifest.json').read_bytes()),measurements=measured)))
