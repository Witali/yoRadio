#include "native_vorbis_timing.h"
extern "C" auto timing_api_probe() -> decltype(&native_vorbis_timing_push) { return &native_vorbis_timing_push; }
