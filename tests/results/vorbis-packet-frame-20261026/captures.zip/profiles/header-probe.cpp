#include "native_vorbis_packet_frame.h"
#include "native_vorbis_setup_owner.h"
#include <type_traits>
static_assert(sizeof(void*) == 4 && sizeof(long) == 4 && sizeof(size_t) == 4);
static_assert(sizeof(native_vorbis_affine_t) == 16);
static_assert(std::is_same_v<decltype(native_vorbis_frame_floor_t{}.value_offset), size_t>);
using decode_type = native_vorbis_numeric_status_t (*)(const native_vorbis_setup_t*, native_vorbis_packet_t*, const native_vorbis_frame_workspace_t*, native_vorbis_packet_frame_t*);
static_assert(std::is_same_v<decltype(&native_vorbis_frame_decode), decode_type>);
extern "C" int frame_header_probe(void) { return sizeof(native_vorbis_affine_t); }
