"""Retain both exact captures, unfiltered lint and source-only profile objects."""
import hashlib, json, zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'tests/results/vorbis-packet-frame-20261026'
assert not OUT.exists()
OUT.mkdir(parents=True)
files = {}
for folder, prefix in (
    (ROOT / '.build/vorbis-packet-frame-host-20261026-01', 'host01'),
    (ROOT / '.build/vorbis-packet-frame-host-20261026-02', 'host02'),
    (ROOT / '.build/vorbis-packet-frame-lint-20261026-01', 'lint01'),
    (ROOT / '.build/vorbis-packet-frame-lint-20261026-02', 'lint02'),
    (ROOT / '.build/vorbis-packet-frame-gcc-20261026-01', 'profiles'),
    (ROOT / '.build/vorbis-packet-frame-validation-20261026-01', 'validation')):
    assert folder.is_dir() and folder.resolve().is_relative_to(ROOT)
    for path in sorted(folder.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            name = prefix + '/' + path.relative_to(folder).as_posix()
            assert name not in files
            files[name] = path.read_bytes()
for path in (Path(__file__), ROOT / '.build/cyd-vorbis-format-command-01.py',
    ROOT / '.build/lint-packet-frame-20261026-01.py', ROOT / '.build/lint-packet-frame-20261026-02.py',
    ROOT / '.build/compile-packet-frame-profiles.py', ROOT / '.build/probe-packet-frame-model.py'):
    files['tools/' + path.name] = path.read_bytes()
archive = OUT / 'captures.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, body in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 10, 26, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        zipped.writestr(info, body)
sha = lambda body: hashlib.sha256(body).hexdigest()
manifest = dict(schema='vorbis-packet-frame-evidence-v1', archive_sha256=sha(archive.read_bytes()),
    files={name: dict(bytes=len(body), sha256=sha(body)) for name, body in sorted(files.items())})
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(dict(archive_sha256=manifest['archive_sha256'], archive_bytes=archive.stat().st_size,
    members=len(files), manifest_sha256=sha((OUT / 'manifest.json').read_bytes()))))
