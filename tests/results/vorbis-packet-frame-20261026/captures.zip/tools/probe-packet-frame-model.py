import importlib.util, json, time
from collections import Counter
from pathlib import Path
root = Path(__file__).resolve().parents[1]
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
setup = load('probe_setup', root / 'tests/test-vorbis-setup.py')
floor = load('probe_floor', root / 'tests/test-vorbis-floor-packet.py')
residue = load('probe_residue', root / 'tests/test-vorbis-residue.py')
subject = load('probe_frame', root / 'tests/vorbis_packet_frame_model.py')
start = time.monotonic()
model = subject.cases(setup, floor, residue, (root / '.build/vorbis-xiph-prep-20261025-01/cases.json').read_bytes())
statuses = Counter()
floor_eop = zero_grid = 0
for row in model['cases']:
    expected = subject.expected_case(row, setup, floor, residue)
    statuses[str(expected['decode_status'])] += 1
    if expected['frame']:
        floor_eop += expected['frame']['floor_eop']
        zero_grid += expected['frame']['implicit_zero'] and not expected['frame']['floor_eop']
result = dict(cases=len(model['cases']), original=sum(row['id'].startswith('original31-') for row in model['cases']),
    statuses=dict(statuses), floor_eop=floor_eop, implicit_other=zero_grid, seconds=time.monotonic()-start)
print(json.dumps(result))
