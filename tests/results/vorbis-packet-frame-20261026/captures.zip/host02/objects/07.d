/mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-packet-frame-host-20261026-02/objects/07.o: \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-packet-frame-host-20261026-02/sources/components/native_vorbis_packet_frame/packet_frame.c \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-packet-frame-host-20261026-02/sources/components/native_vorbis_packet_frame/include/native_vorbis_packet_frame.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-packet-frame-host-20261026-02/sources/components/native_vorbis_numeric/include/native_vorbis_floor_packet.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-packet-frame-host-20261026-02/sources/components/native_vorbis_numeric/include/native_vorbis_setup.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-packet-frame-host-20261026-02/sources/components/native_vorbis_numeric/include/native_vorbis_codebook.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-packet-frame-host-20261026-02/sources/components/native_vorbis_numeric/include/native_vorbis_quant.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-packet-frame-host-20261026-02/sources/components/native_vorbis_numeric/include/native_vorbis_floor0.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-packet-frame-host-20261026-02/sources/components/native_vorbis_numeric/include/native_vorbis_residue.h
