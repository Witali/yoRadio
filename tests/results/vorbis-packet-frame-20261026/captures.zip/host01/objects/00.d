/mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-packet-frame-host-20261026-01/objects/00.o: \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-packet-frame-host-20261026-01/sources/components/native_vorbis_numeric/floor0.c \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-packet-frame-host-20261026-01/sources/components/native_vorbis_numeric/include/native_vorbis_floor0.h
