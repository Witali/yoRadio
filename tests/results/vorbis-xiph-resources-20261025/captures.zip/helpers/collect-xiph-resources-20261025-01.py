"""Collect completed source, sanitizer, SDK/QEMU and numerical evidence."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'tests/results/vorbis-xiph-resources-20261025'
assert not OUT.exists();OUT.mkdir(parents=True);bodies={}
def add(path,name):
    assert path.resolve().is_relative_to(ROOT)and path.is_file()
    raw=path.read_bytes();assert name not in bodies or bodies[name]==raw;bodies[name]=raw
def tree(folder,prefix):
    base=ROOT/folder
    for path in sorted(base.rglob('*')):
        if path.is_file():add(path,prefix+'/'+path.relative_to(base).as_posix())
tree('.build/vorbis-xiph-resources-host-20261025-01','host-first-attempt')
tree('.build/vorbis-xiph-resources-host-20261025-02','host')
tree('.build/vorbis-xiph-resources-validation-20261025-01','receipts')
tree('.build/vorbis-xiph-port-pcm-20261025-01','comparison')
tree('.build/vorbis-xiph-resources-lint-20261025-01','lint')
folder='.build/vorbis-xiph-resources-esp32-20261025-01';base=ROOT/folder
native=json.loads((base/'report.json').read_text('utf-8'))
assert native['completed']and native['resource_tests_completed']
for path in base.iterdir():
    if path.is_file():add(path,'native/'+path.name)
for sub in('sources','project','pcm'):tree(folder+'/'+sub,'native/'+sub)
for name,digest in native['build_outputs'].items():
    path=base/name;assert hashlib.sha256(path.read_bytes()).hexdigest()==digest;add(path,'native/'+name)
for name in('cyd-vorbis-format-command-01.py','finalize-xiph-port-20261025-01.py','lint-xiph-resources-20261025-01.py','collect-xiph-resources-20261025-01.py','vorbis-xiph-port-protocol-before-tempfix-20261025-01.py'):
    add(ROOT/'.build'/name,'helpers/'+name)
for name in('test-vorbis-xiph-resources.py','test-vorbis-xiph-port-generation.py','test-vorbis-xiph-port-protocol.py','run-vorbis-xiph-port-qemu.py','test-vorbis-xiph-port-pcm.py','test-vorbis-xiph-port-pcm-units.py','verify-vorbis-xiph-resources-checkpoint.py'):
    add(ROOT/'tests'/name,'sources/tests/'+name)
manifest={'schema':'vorbis-xiph-resources-checkpoint-v1','files':{n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}for n,b in sorted(bodies.items())}}
raw=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(OUT/'captures.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as archive:
    for name,body in sorted(bodies.items()):archive.writestr(name,body)
    archive.writestr('manifest.json',raw)
record={'sha256':hashlib.sha256((OUT/'captures.zip').read_bytes()).hexdigest(),'bytes':(OUT/'captures.zip').stat().st_size,'members':len(bodies)+1,'manifest_sha256':hashlib.sha256(raw).hexdigest()}
(OUT/'archive.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record))
