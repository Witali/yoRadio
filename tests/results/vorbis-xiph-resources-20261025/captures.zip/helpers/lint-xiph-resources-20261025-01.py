"""Clang Xtensa analysis of the actual resource-port compilation units."""
import ctypes,hashlib,json,re,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
CAPTURE=ROOT/'.build/vorbis-xiph-resources-esp32-20261025-01'
OUT=ROOT/'.build/vorbis-xiph-resources-lint-20261025-01'
TOOL=Path('C:/Work/yoRadio/.idf/tools-v6.0.2/tools/esp-clang/esp-20.1.1_20250829/esp-clang/bin/clang-tidy.exe')
BUILTINS=TOOL.parent.parent/'lib/clang/20/include'
PICOLIBC=Path('C:/Work/yoRadio/.idf/tools-v6.0.2/tools/xtensa-esp-elf/esp-15.2.0_20251204/xtensa-esp-elf/picolibc/include')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
native=json.loads((CAPTURE/'report.json').read_text('utf-8'))
assert native['completed']and native['whole_module_compiled']and len(native['compile_rows'])==27
assert not OUT.exists();OUT.mkdir();(OUT/'runner.py').write_bytes(Path(__file__).read_bytes());(OUT/'clang-tidy.yaml').write_bytes((ROOT/'.clang-tidy').read_bytes())
report={'completed':False,'warnings':0,'errors':0,'commands':[],'tools':{str(TOOL):sha(TOOL)},'inputs':{},'native_report_sha256':sha(CAPTURE/'report.json'),
    'scope':'27 actual resource-port library/fixture units, explicit Clang Xtensa CPU flags and Picolibc/builtin headers. Only configured include/define/forced-header options are reused from GCC. This is not a Clang SDK build, runtime, or full SDK/header/binary dependency closure.'}
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
def split(command):
    count=ctypes.c_int();call=ctypes.windll.shell32.CommandLineToArgvW;call.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)];call.restype=ctypes.POINTER(ctypes.c_wchar_p);pointer=call(command,ctypes.byref(count));assert pointer
    try:return [pointer[i]for i in range(count.value)]
    finally:
        ctypes.windll.kernel32.LocalFree.argtypes=[ctypes.c_void_p];ctypes.windll.kernel32.LocalFree(pointer)
save()
for index,(name,row)in enumerate(native['compile_rows'].items()):
    source=Path(row['file']);report['inputs'][str(source)]=sha(source);argv=split(row['command']);selected=[];i=1
    while i<len(argv):
        arg=argv[i]
        if arg in('-I','-D','-isystem','-include','-iquote'):selected+=argv[i:i+2];i+=2;continue
        if arg.startswith(('-I','-D')):selected.append(arg)
        i+=1
    stem=f'{index:02d}-'+Path(name).stem
    command=[str(TOOL),str(source),'--config-file='+str(OUT/'clang-tidy.yaml'),'--header-filter=.*','--export-fixes='+str(OUT/(stem+'.yaml')),
        '--','--target=xtensa-esp-elf','-mcpu=esp32','-std=gnu17','-O2','-fno-fast-math','-ffp-contract=off','-nostdinc','-isystem',str(BUILTINS),'-isystem',str(PICOLIBC),*selected]
    result={'name':name,'argv':command,'cwd':row['directory']};report['commands'].append(result);start=time.monotonic();child=None
    try:
        with(OUT/(stem+'.stdout.log')).open('xb')as so,(OUT/(stem+'.stderr.log')).open('xb')as se:
            child=subprocess.Popen(command,cwd=row['directory'],stdin=subprocess.DEVNULL,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW);result['pid']=child.pid;result['returncode']=child.wait(timeout=90)
    finally:
        if child is not None and child.poll()is None:child.kill();child.wait(timeout=5);result['forced_stop']=True
        result['elapsed_seconds']=time.monotonic()-start;text=[]
        for stream in('stdout','stderr'):
            path=OUT/(stem+'.'+stream+'.log');result[stream+'_sha256']=sha(path);text.append(path.read_text('utf-8',errors='replace'))
        text='\n'.join(text);result['warnings']=len(re.findall(r': warning:',text));result['errors']=len(re.findall(r': (?:error|fatal error):',text));report['warnings']+=result['warnings'];report['errors']+=result['errors'];save()
    print(json.dumps({k:result[k]for k in('name','returncode','warnings','errors')}),flush=True)
    assert result['returncode']==0 and not result['errors']and not result.get('forced_stop'),name
assert all(sha(p)==digest for p,digest in report['inputs'].items())and sha(TOOL)==report['tools'][str(TOOL)]
report['completed']=True;save()
