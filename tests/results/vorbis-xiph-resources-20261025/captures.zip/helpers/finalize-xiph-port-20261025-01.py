import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent.parent/'idf/components/native_vorbis_xiph_port'
files={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(root.rglob('*'))if p.is_file()and p.name!='port-manifest.json'}
record={'schema':'native-vorbis-xiph-resource-port-v1','base_manifest_sha256':'897096caf216de0e161f4fd833037863f8e2dc3da0531e34b851503f932f4b14','files':files}
(root/'port-manifest.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'files':len(files),'sha256':hashlib.sha256((root/'port-manifest.json').read_bytes()).hexdigest()}))
