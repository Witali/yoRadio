#include "native_vorbis_window_exact.h"
extern "C" auto window_prepare_probe() -> decltype(&native_vorbis_window_exact_prepare) { return &native_vorbis_window_exact_prepare; }
extern "C" auto window_at_probe() -> decltype(&native_vorbis_window_exact_at) { return &native_vorbis_window_exact_at; }
