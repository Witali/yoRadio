"""Preserve every exact-window campaign and source-only diagnostic attempt."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'tests/results/vorbis-window-exact-20261028'
def sha(body):return hashlib.sha256(body).hexdigest()
assert not DEST.exists(),'fresh evidence folder required'
groups={f'host{i:02d}':ROOT/f'.build/vorbis-window-exact-host-20261028-{i:02d}' for i in range(1,5)}
groups.update({f'profiles{i:02d}':ROOT/f'.build/vorbis-window-exact-profiles-20261028-{i:02d}' for i in range(1,3)})
groups.update({f'fixture-lint{i:02d}':ROOT/f'.build/vorbis-window-exact-fixture-lint-20261028-{i:02d}' for i in range(1,5)})
files={};omitted=[]
for group,base in groups.items():
    assert base.is_dir(),str(base)
    for path in sorted(base.rglob('*')):
        if not path.is_file():continue
        rel=path.relative_to(base).as_posix();body=path.read_bytes();name=group+'/'+rel
        if rel=='window-exact':omitted.append(dict(path=name,bytes=len(body),sha256=sha(body),reason='Rebuildable host executable; complete inputs/source/hash retained.'))
        else:files[name]=body
scripts=['profile-vorbis-window-exact-20261028.py','profile-vorbis-window-exact-20261028-02.py',
    'normalize-vorbis-window-exact-profile-reports-20261028.py',Path(__file__).name]
scripts.extend(p.name for p in (ROOT/'.build').glob('*window-exact*fixture*.py'))
for name in sorted(set(scripts)):files['tools/'+name]=(ROOT/'.build'/name).read_bytes()
seal='vorbis-window-exact-final-seal-20261028-01.json'
files['receipts/'+seal]=(ROOT/'.build'/seal).read_bytes()
DEST.mkdir(parents=True)
archive=DEST/'captures.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,body in sorted(files.items()):
        entry=zipfile.ZipInfo(name,(2026,10,28,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED
        entry.create_system=3;entry.external_attr=0o100644<<16;z.writestr(entry,body)
body=archive.read_bytes()
manifest=dict(archive_sha256=sha(body),archive_bytes=len(body),
    files=[dict(path=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(files.items())],omitted=omitted)
manifest_body=(json.dumps(manifest,indent=2)+'\n').encode();(DEST/'manifest.json').write_bytes(manifest_body)
print(json.dumps(dict(archive_sha256=sha(body),manifest_sha256=sha(manifest_body),members=len(files),
    archive_bytes=len(body),decoded_bytes=sum(map(len,files.values())),omitted_executables=len(omitted))))
