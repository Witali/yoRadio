"""Preserve and repair only the accidental trailer in profile JSON receipts."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(body):return hashlib.sha256(body).hexdigest()
expected='extern "C" auto window_product_probe() -> decltype(&native_vorbis_window_multiply_exact) { return &native_vorbis_window_multiply_exact; }'
for attempt in (1,2):
    folder=ROOT/f'.build/vorbis-window-exact-profiles-20261028-{attempt:02d}'
    original=(folder/'report.json').read_bytes();text=original.decode('utf-8')
    value,end=json.JSONDecoder().raw_decode(text)
    assert text[end:].strip()==expected,'only the known accidental trailer is removed'
    corrected=(json.dumps(value,indent=2)+'\n').encode()
    target=folder/'report-corrected.json';receipt=folder/'metadata-correction.json'
    assert not target.exists() and not receipt.exists()
    target.write_bytes(corrected)
    result=dict(original_sha256=sha(original),corrected_sha256=sha(corrected),
        reason='A probe insertion matched the report save string instead of header.cpp and appended a C++ declaration after the JSON document.',
        change='Remove that exact known trailer only; retain the original receipt and all command/source/object/diagnostic fields.',
        commands_reexecuted=0,compiler_inputs_changed=False)
    receipt.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(dict(attempt=attempt,passed=value['passed'],commands=len(value['commands']),metadata_only=True)))
