"""Frozen host-only control: reset the fairness counter on every packet."""
from pathlib import Path
import hashlib
import json
import resource
import signal
import subprocess

root = Path(__file__).resolve().parents[1]
run = root / '.build/cyd-vendor-public-lifecycle-20261030-04'
out = root / '.build/cyd-vendor-public-lifecycle-control-20261030-01'
assert not out.exists(), 'Use a fresh control output directory.'
out.mkdir()
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
main = root / 'idf/esp32-cyd2usb-native/main'
source = (run / 'production.inc').read_bytes()
needle = b'        esp_audio_simple_dec_raw_t raw = {'
assert source.count(needle) == 1
results = {}
for name, production in [('baseline', source), ('packet-reset', source.replace(
        needle, b'        process_calls = 0; // Deliberate negative control.\n' + needle))]:
    dst = out / name
    dst.mkdir()
    (dst / 'production.inc').write_bytes(production)
    for relative in ['freertos/FreeRTOS.h', 'freertos/semphr.h', 'esp_err.h', 'pdm-tail.inc']:
        target = dst / relative
        target.parent.mkdir(exist_ok=True)
        target.write_bytes((run / relative).read_bytes())
    for relative in ['native_state.c', 'native_state.h', 'native_health.h', 'native_output_metrics.h']:
        (dst / relative).write_bytes((main / relative).read_bytes())
    for relative in ['cyd_lifecycle_test.c', 'audio_power_seam.h']:
        (dst / relative).write_bytes((root / 'tests/native' / relative).read_bytes())
    binary = dst / 'lifecycle'
    cmd = ['gcc', '-std=c11', '-O1', '-g', '-Wall', '-Wextra', '-Werror', '-pthread',
           '-Wno-unused-variable', '-Wno-unused-function', '-fsanitize=address,undefined',
           '-fno-omit-frame-pointer', '-fno-pie', '-no-pie', '-I' + str(dst),
           '-I' + str(root / 'idf/components/native_stream/include'),
           str(dst / 'cyd_lifecycle_test.c'), str(dst / 'native_state.c'), '-o', str(binary)]
    build = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (dst / 'build.log').write_bytes(build.stdout)
    assert build.returncode == 0, build.stdout.decode(errors='replace')
    process = subprocess.run(['env', 'ASAN_OPTIONS=detect_leaks=1:halt_on_error=1',
                             'UBSAN_OPTIONS=halt_on_error=1', str(binary)],
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (dst / 'test.log').write_bytes(process.stdout)
    expected = process.returncode == (0 if name == 'baseline' else -signal.SIGABRT)
    if name == 'packet-reset':
        expected = expected and b'process_calls==97 && delay_calls==3 && pcm.used==1' in process.stdout
    assert expected, (process.returncode, process.stdout.decode(errors='replace'))
    results[name] = {'build_exit': build.returncode, 'runtime_exit': process.returncode,
                     'expected_observation': True, 'sha256': {
                         p.relative_to(dst).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in sorted(dst.rglob('*')) if p.is_file()}}
assert (run / 'production.inc').read_bytes() == source
(out / 'report.json').write_text(json.dumps({'host_only': True,
    'mutation': 'Reset process_calls to zero before every input packet.',
    'canonical_source_modified': False, 'baseline_frozen_run': run.name,
    'results': results}, indent=2) + '\n')
print(json.dumps({'baseline_exit': results['baseline']['runtime_exit'],
                 'deliberate_counter_reset_exit': results['packet-reset']['runtime_exit'],
                 'expected_scheduling_assertion_failed': True}))
