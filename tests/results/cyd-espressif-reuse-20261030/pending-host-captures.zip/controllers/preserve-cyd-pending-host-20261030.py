"""Package completed public host/compile/static-analysis evidence only."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

root = Path(__file__).resolve().parents[1]
destination = root / 'tests/results/cyd-espressif-reuse-20261030'
archive = destination / 'pending-host-captures.zip'
manifest_path = destination / 'pending-host-manifest.json'
assert not archive.exists() and not manifest_path.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
old_paths = ['host-captures.zip', 'host-manifest.json', 'HOST.md']
old = {name: sha((destination / name).read_bytes()) for name in old_paths}
run = root / '.build/cyd-vendor-public-lifecycle-20261030-05'
gcc = root / '.build/cyd-vendor-public-gcc-20261030-02'
lint = root / '.build/cyd-vendor-public-lint-20261030-02'
host_report = json.loads((run / 'report.json').read_bytes())
gcc_report = json.loads((gcc / 'report.json').read_bytes())
assert host_report['passed'] and len(host_report['variants']) == 6
assert gcc_report['passed'] and len(gcc_report['profiles']) == 3
members = {}
origins = {}
def add(path, name, role, expected=None):
    path = Path(path)
    data = path.read_bytes()
    if expected is not None:
        assert sha(data) == expected, f'Pinned input differs: {name}'
    assert not name.startswith('/') and '..' not in Path(name).parts
    assert name not in members
    members[name] = data
    origins[name] = {'role': role, 'source': path.relative_to(root).as_posix()}

for path in sorted(run.rglob('*')):
    if path.is_file():
        add(path, 'host05/' + path.relative_to(run).as_posix(),
            'completed six-variant host evidence')
add(run.with_name(run.name + '-launch.log'), 'host05/launcher.log', 'terminal host05 launcher output')
for relative, expected in host_report['source_sha256'].items():
    add(root / relative, 'sources/repository/' + relative, 'exact host-report-pinned source', expected)
for relative in ['tools/codec_benchmark/run_output_dma_host.py',
                 'idf/components/native_stream/include/stream_probe.h',
                 'idf/components/native_stream/include/stream_tags.h']:
    add(root / relative, 'sources/repository/' + relative, 'host compiler helper or actual public header dependency')

for path in sorted(gcc.iterdir()):
    assert path.is_file()
    add(path, 'gcc02/' + path.name, 'completed actual Xtensa translation-unit evidence')
add(root / '.build/compile-vendor-public-service-02.py', 'controllers/compile-vendor-public-service-02.py',
    'actual GCC02 controller')
tool_metadata = {}
for profile in gcc_report['profiles']:
    assert profile['exit_status'] == 0
    assert profile['source_sha256'] == host_report['source_sha256']['idf/esp32-cyd2usb-native/main/audio_service.c']
    name = profile['profile']
    assert sha((gcc / (name + '.log')).read_bytes()) == profile['log_sha256']
    assert sha((gcc / (name + '.obj')).read_bytes()) == profile['object_sha256']
    build = root / 'idf/esp32-cyd2usb-native' / name
    add(build / 'config/sdkconfig.h', 'gcc02/inputs/' + name + '/sdkconfig.h',
        'report-pinned pre-existing production configuration', profile['config_sha256'])
    add(build / 'compile_commands.json', 'gcc02/inputs/' + name + '/compile_commands.json',
        'report-pinned existing production compilation database', profile['database_sha256'])
    add(build / 'toolchain/cflags', 'gcc02/inputs/' + name + '/toolchain/cflags',
        'response-file input referenced by actual GCC command')
    match = re.match(r'(.+?gcc\.exe) ', profile['command'])
    assert match
    compiler = Path(match[1])
    tool_metadata[compiler.as_posix()] = {'sha256': sha(compiler.read_bytes()),
                                        'binary_archived': False}
for name in ['clang-tidy.log', 'fixes.yaml']:
    add(lint / name, 'lint02/' + name, 'completed focused static-analysis evidence')
assert b'Suppressed 18 warnings' in members['lint02/clang-tidy.log']
assert b'error:' not in members['lint02/clang-tidy.log']
metadata = {'host_compiler': host_report['compiler'], 'host_compiler_binary_archived': False,
            'actual_target_compilers': tool_metadata, 'physical_hardware': False,
            'decoder_or_test_executed_during_preservation': False,
            'host_terminal_exit': 0, 'gcc02_terminal_exit': 0, 'lint02_terminal_exit': 0}
members['tool-and-execution-metadata.json'] = (json.dumps(metadata, indent=2) + '\n').encode()
origins['tool-and-execution-metadata.json'] = {'role': 'observed completed-session/tool metadata',
                                            'source': 'preservation controller'}
add(Path(__file__), 'controllers/preserve-cyd-pending-host-20261030.py', 'data-only preservation controller')

with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
    for name in sorted(members):
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.create_system = 3
        info.external_attr = 0o100644 << 16
        handle.writestr(info, members[name], compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    assert handle.namelist() == sorted(members)
    for name, data in members.items():
        assert handle.read(name) == data
for relative, expected in host_report['source_sha256'].items():
    assert sha((root / relative).read_bytes()) == expected
assert old == {name: sha((destination / name).read_bytes()) for name in old_paths}
manifest = {'scope': 'CYD public pending-input caller: host integration, actual Xtensa TU compile, focused lint',
    'passed': True, 'physical_hardware': False, 'vendor_decoder_executed_by_host': False,
    'linked_firmware': False, 'maintenance_cleanup_host_executed': False,
    'host_variants': list(host_report['variants']), 'primary_source_sha256': host_report['source_sha256'],
    'host_report_sha256': sha((run / 'report.json').read_bytes()),
    'gcc_report_sha256': sha((gcc / 'report.json').read_bytes()),
    'original_host_artifacts_unchanged': old,
    'archive': {'path': archive.name, 'bytes': archive.stat().st_size,
                'sha256': sha(archive.read_bytes()), 'members': len(members)},
    'files': [{'path': name, 'bytes': len(members[name]), 'sha256': sha(members[name]), **origins[name]}
              for name in sorted(members)]}
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'archive': manifest['archive'], 'manifest_sha256': sha(manifest_path.read_bytes()),
                  'pinned_source_checks': len(host_report['source_sha256']),
                  'original_host_artifacts_unchanged': True}))
