
"""Own one Linux session/group; publish nonce-bound terminal/cleanup facts."""
import ctypes,json,os,signal,subprocess,sys,time
from pathlib import Path
request_path=Path(sys.argv[1]).resolve();request=json.loads(request_path.read_text())
receipt=Path(request['receipt']).resolve();stop=Path(request['stop']).resolve()
assert receipt.parent==stop.parent==request_path.parent
nonce=request['nonce'];assert len(nonce)==32 and all(c in '0123456789abcdef' for c in nonce)
timeout=request['timeout'];assert 0<timeout<=180
state=dict(nonce=nonce,request_sha256=__import__('hashlib').sha256(request_path.read_bytes()).hexdigest(),
           supervisor_pid=os.getpid(),state='starting',child_reaped=False,group_gone=False)
child=None;pgid=None;signal_stop=[]
def save():
    tmp=receipt.with_suffix('.tmp');tmp.write_text(json.dumps(state));deadline=time.monotonic()+1
    while True:
        try:tmp.replace(receipt);return
        except PermissionError:
            if time.monotonic()>=deadline:raise
            time.sleep(.01)
def group_exists():
    try:os.killpg(pgid,0);return True
    except ProcessLookupError:return False
def on_signal(number,frame):signal_stop.append(number)
for sig in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):signal.signal(sig,on_signal)
try:
    # Adopt and reap only descendants of this supervisor after a group stop.
    assert ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0
    child=subprocess.Popen(request['argv'],stdin=subprocess.DEVNULL,start_new_session=True)
    pgid=child.pid;assert os.getpgid(child.pid)==pgid and os.getsid(child.pid)==pgid
    state.update(state='running',child_pid=child.pid,owned_pgid=pgid,new_session=True);save()
    deadline=time.monotonic()+timeout
    while child.poll() is None:
        if signal_stop:state.update(state='signal_stop',signals=signal_stop);break
        if stop.exists() and stop.read_text()==nonce:state['state']='stop_requested';break
        if time.monotonic()>=deadline:state['state']='timeout';break
        time.sleep(.02)
    else:state['state']='terminal'
except BaseException as exc:state.update(state='supervisor_error',error=repr(exc))
finally:
    try:
        if child is not None:
            if group_exists():
                if state['state']=='terminal':state['state']='live_descendants_nonpass'
                os.killpg(pgid,signal.SIGKILL);state['group_sigkill_sent']=True
            child.wait(timeout=5);state.update(child_reaped=True,child_returncode=child.returncode)
            deadline=time.monotonic()+5
            while True:
                try:
                    while os.waitpid(-pgid,os.WNOHANG)[0]:pass
                except ChildProcessError:pass
                if not group_exists():state['group_gone']=True;break
                if time.monotonic()>=deadline:break
                time.sleep(.02)
    except BaseException as exc:state['cleanup_error']=repr(exc)
    state['final']=True;save()
sys.exit(0 if state['child_reaped'] and state['group_gone'] and 'cleanup_error' not in state else 1)
