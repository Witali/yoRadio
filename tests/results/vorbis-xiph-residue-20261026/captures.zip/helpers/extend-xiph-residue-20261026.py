import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
port=ROOT/'idf/components/native_vorbis_xiph_port'
body=(ROOT/'idf/components/native_vorbis_xiph/upstream/libvorbis/lib/codebook.c').read_bytes()
start=body.index(b'long vorbis_book_decodevs_add(')
end=body.index(b'/* decode vector / dim granularity',start)
(port/'edits/codebook-residue0.before.c').write_bytes(body[start:end])
after='''long vorbis_book_decodevs_add(codebook *book,float *a,oggpack_buffer *b,int n){
  if(book->used_entries>0){
    int step=n/book->dim;
    int i,j;

    /* Vorbis I 8.6.3: publish each complete vector before the next read.
       Distinct destinations need no partition-sized entry/pointer scratch.
       On EOP the completed word prefix remains, as required by 8.6.2. */
    for(j=0;j<step;j++){
      long entry=decode_packed_entry_number(book,b);
      const float *t;
      if(entry==-1)return(-1);
      t=book->valuelist+entry*book->dim;
      for(i=0;i<book->dim;i++)
        a[j+i*step]+=t[i];
    }
  }
  return(0);
}

'''
(port/'edits/codebook-residue0.after.c').write_bytes(after.encode())
path=port/'edits.json';edits=json.loads(path.read_bytes());assert len(edits['edits'])==8
edits['edits'].append(dict(source='upstream/libvorbis/lib/codebook.c',before='edits/codebook-residue0.before.c',after='edits/codebook-residue0.after.c'))
path.write_text(json.dumps(edits,indent=2)+'\n',encoding='utf-8',newline='\n')
path=port/'prepare.py';text=path.read_text();text=text.replace("len(changes['edits']) == 8, 'eight exact reviewed edits'","len(changes['edits']) == 9, 'nine exact reviewed edits'")
text=text.replace("'upstream/libogg/src/bitwise.c'},","'upstream/libogg/src/bitwise.c', 'upstream/libvorbis/lib/codebook.c'},").replace('only the three reviewed translation units change','only the four reviewed translation units change')
path.write_text(text,encoding='utf-8',newline='\n')
path=port/'CMakeLists.txt';text=path.read_text().replace('unit STREQUAL "block" OR unit STREQUAL "sharedbook"','unit STREQUAL "block" OR unit STREQUAL "sharedbook" OR unit STREQUAL "codebook"');path.write_text(text,encoding='utf-8',newline='\n')
path=port/'README.md';text=path.read_text().replace('only three modified translation units','only four modified translation units')
text=text.replace('Neither production application selects this component.', '''A ninth exact edit removes both partition-sized stack arrays from
`vorbis_book_decodevs_add`. It decodes each word once and scatters directly as
specified by [Vorbis I 8.6.3](https://xiph.org/vorbis/doc/Vorbis_I_spec.html).
On nominal packet EOP, complete earlier words in the current partition remain
published as section 8.6.2 requires. Successful per-sample additions are
unchanged; the separately allocated PCM and codebook value arrays never alias
in the decoder. This adds no allocation or new OOM status. Empty-book, positive
dimension and upper-layer geometry assumptions are otherwise unchanged.

Neither production application selects this component.''')
text=text.replace('In\nparticular, `vorbis_book_decodevs_add` has partition-sized stack scratch outside\nthe decode-book initialization repaired here.','Channel-sized mapping/residue scratch and unchecked allocations elsewhere\nstill require work.')
path.write_text(text,encoding='utf-8',newline='\n')
path=port/'port-manifest.json';manifest=json.loads(path.read_bytes());manifest['files']={p.relative_to(port).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(port.rglob('*'))if p.is_file()and p!=path}
path.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(port=hashlib.sha256(path.read_bytes()).hexdigest(),generator=hashlib.sha256((port/'prepare.py').read_bytes()).hexdigest())))
