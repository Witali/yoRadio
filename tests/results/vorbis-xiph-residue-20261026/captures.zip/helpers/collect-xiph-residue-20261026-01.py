"""Retain the focused residue0 source, regression and original31 evidence."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'tests/results/vorbis-xiph-residue-20261026'
assert not OUT.exists();OUT.mkdir(parents=True);bodies={}
def add(path,name):
    assert path.resolve().is_relative_to(ROOT) and path.is_file()
    raw=path.read_bytes();assert name not in bodies or bodies[name]==raw;bodies[name]=raw
def tree(folder,prefix):
    base=ROOT/folder
    for path in sorted(base.rglob('*')):
        if path.is_file():add(path,prefix+'/'+path.relative_to(base).as_posix())
for folder,prefix in(
    ('.build/vorbis-xiph-residue-host-20261026-01','host'),
    ('.build/vorbis-xiph-residue-baseline-20261026-01','baseline'),
    ('.build/vorbis-xiph-residue-validation-20261026-01','receipts'),
    ('.build/vorbis-xiph-residue-pcm-20261026-01','comparison'),
    ('.build/vorbis-xiph-residue-lint-20261026-01','lint')):tree(folder,prefix)
folder='.build/vorbis-xiph-residue-esp32-20261026-01';base=ROOT/folder
native=json.loads((base/'report.json').read_text('utf-8'))
assert native['completed'] and native['resource_tests_completed']
for path in base.iterdir():
    if path.is_file():add(path,'native/'+path.name)
for sub in('sources','project','pcm'):tree(folder+'/'+sub,'native/'+sub)
for name,digest in native['build_outputs'].items():
    path=base/name;assert hashlib.sha256(path.read_bytes()).hexdigest()==digest;add(path,'native/'+name)
for name in('cyd-vorbis-format-command-01.py','extend-xiph-residue-20261026.py',
             'witness-xiph-residue-20261026-01.py','evaluate-xiph-residue-baseline-20261026-01.py',
             'lint-xiph-residue-20261026-01.py','collect-xiph-residue-20261026-01.py'):
    add(ROOT/'.build'/name,'helpers/'+name)
for name in('test-vorbis-xiph-resources.py','test-vorbis-xiph-port-generation.py',
             'test-vorbis-xiph-port-protocol.py','run-vorbis-xiph-port-qemu.py',
             'test-vorbis-xiph-port-pcm.py','test-vorbis-xiph-port-pcm-units.py',
             'verify-vorbis-xiph-residue-checkpoint.py'):
    add(ROOT/'tests'/name,'sources/tests/'+name)
manifest={'schema':'vorbis-xiph-residue-checkpoint-v1','files':{n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}for n,b in sorted(bodies.items())}}
raw=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(OUT/'captures.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as archive:
    for name,body in sorted(bodies.items()):archive.writestr(name,body)
    archive.writestr('manifest.json',raw)
record={'sha256':hashlib.sha256((OUT/'captures.zip').read_bytes()).hexdigest(),'bytes':(OUT/'captures.zip').stat().st_size,'members':len(bodies)+1,'manifest_sha256':hashlib.sha256(raw).hexdigest()}
(OUT/'archive.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record))
