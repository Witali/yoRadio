"""Re-evaluate the saved, terminal regression witness without executing it."""
import hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
BASE=ROOT/'.build/vorbis-xiph-residue-baseline-20261026-01'
HOST=ROOT/'.build/vorbis-xiph-residue-host-20261026-01'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
report=json.loads((BASE/'report.json').read_text());commands=report['commands']
assert len(commands)==3
for index,row in enumerate(commands):
    value=row['supervisor'];assert value['state']=='terminal' and value['final'] and value['child_reaped'] and value['group_gone'] and value['nonce']==row['nonce']
    assert value['child_returncode']==(0 if index<2 else -6)
    for stream in('stdout','stderr'):assert sha(BASE/(row['name']+'.'+stream+'.log'))==row[stream+'_sha256']
fixture=HOST/'sources/native/vorbis_xiph_residue.c';error=(BASE/'execute.stderr.log').read_text()
match=re.fullmatch(r"baseline-tests: .*/vorbis_xiph_residue.c:([0-9]+): run_case: Assertion `ok' failed\.\s*",error)
assert match;line=int(match[1]);expression='CHECK(memcmp(output.values,expected,sizeof(expected))==0);'
assert fixture.read_text().splitlines()[line-1].strip()==expression
assert (BASE/'codebook.c').read_bytes()==(HOST/'generated/base/upstream/libvorbis/lib/codebook.c').read_bytes()
assert not (BASE/'unexpected-pcm.bin').exists()
evaluation=dict(schema='vorbis-xiph-residue-baseline-evaluation-v1',completed=True,expected_regression=True,decoder_reexecuted=False,
    baseline_report_sha256=sha(BASE/'report.json'),stderr_sha256=sha(BASE/'execute.stderr.log'),fixture_sha256=sha(fixture),
    baseline_source_sha256=sha(BASE/'codebook.c'),failure_line=line,failure_expression=expression,child_returncode=-6,
    original_outer_result='NONPASS: postcheck expected the literal expression, but CHECK deliberately asserts its local ok variable.',
    reason='Original residue0 discards earlier complete words on later-word nominal EOP; the independent complete-word-prefix oracle rejects it.')
path=BASE/'evaluation.json';assert not path.exists();path.write_text(json.dumps(evaluation,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(evaluation))
