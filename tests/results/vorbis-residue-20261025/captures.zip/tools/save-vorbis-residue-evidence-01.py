"""Save the finite residue/coupling checks without copying SDK installations."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent.parent
out = root / 'tests/results/vorbis-residue-20261025'
out.mkdir(parents=True, exist_ok=True)
assert not (out / 'captures.zip').exists()
files = {}
with zipfile.ZipFile(out / 'captures.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    def add(member, path):
        if member in files:
            return
        body = path.read_bytes()
        entry = zipfile.ZipInfo(member, (2026, 10, 25, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(entry, body, compresslevel=9)
        files[member] = {'sha256': hashlib.sha256(body).hexdigest(), 'bytes': len(body)}

    host = root / '.build/vorbis-residue-host-20261025-01'
    report = json.loads((host / 'report.json').read_bytes())
    assert report['completed'] and report['passed'] and report['metadata_controls'] == 37
    for path in sorted(host.rglob('*')):
        if path.is_file() and path != host / 'test':
            add('host/' + path.relative_to(host).as_posix(), path)
    for target in ('esp32', 'esp32c3'):
        directory = root / ('.build/vorbis-residue-' + target + '-20261025-01')
        capture = json.loads((directory / 'report.json').read_bytes())
        assert capture['completed'] and capture['math_capture_completed']
        assert not capture['build_warning_lines']
        paths = {path for path in directory.iterdir() if path.is_file()}
        paths.update(path for path in (directory / 'sources').rglob('*') if path.is_file())
        for name, digest in capture['build_outputs'].items():
            path = directory / name
            assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
            paths.add(path)
        for path in sorted(paths):
            add(target + '/' + path.relative_to(directory).as_posix(), path)
    lint = root / '.build/vorbis-residue-lint-20261025-01'
    for path in sorted(lint.rglob('*')):
        if path.is_file():
            add('lint/' + path.relative_to(lint).as_posix(), path)
    validation = root / '.build/vorbis-residue-validation-20261025-01'
    for path in sorted(validation.iterdir()):
        if path.is_file():
            add('validation/' + path.name, path)
    for number in ():
        history = root / ('.build/vorbis-residue-host-20261025-' + number)
        for path in sorted(history.rglob('*')):
            if path.is_file() and (path.name.endswith(('.json', '.log')) or path.name in ('driver.c', 'test-vorbis-residue.py')):
                add('history/host' + number + '/' + path.relative_to(history).as_posix(), path)
    for name in ('save-vorbis-residue-evidence-01.py', 'check-vorbis-residue-reference-01.py', 'run-vorbis-residue-native-01.py'):
        add('tools/' + name, root / '.build' / name)

manifest = {'schema': 'vorbis-residue-captures-v1', 'files': files,
            'zip_sha256': hashlib.sha256((out / 'captures.zip').read_bytes()).hexdigest(),
            'scope': 'Finite owned residue/coupling checks; no full decoder, production, PCM, hardware or complete SDK dependency qualification.'}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
(out / '.gitattributes').write_text('* -text whitespace=cr-at-eol,-blank-at-eof\n', encoding='ascii')
print(json.dumps({'saved': True, 'members': len(files), 'bytes': (out / 'captures.zip').stat().st_size}))
