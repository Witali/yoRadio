"""Separate exact replay of saved host and native residue observations."""
import hashlib
import importlib.util
import json
from pathlib import Path

root = Path(__file__).resolve().parent.parent
host = root / '.build/vorbis-residue-host-20261025-01'
source = root / 'tests/test-vorbis-residue.py'
assert hashlib.sha256(source.read_bytes()).hexdigest() == '1191a648a9070a995b1e256519ce71891f70779d924db651db16c490c856f31d'
spec = importlib.util.spec_from_file_location('residue_oracle', source)
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)
oracle.REFERENCE = oracle.load_reference(host / 'sources/reference-setup.py')
host_report = json.loads((host / 'report.json').read_bytes())
assert host_report['completed'] and host_report['passed'] and host_report['component_executed']
model = json.loads((host / 'cases.json').read_bytes())
observed = oracle.decode_output((host / 'outputs.bin').read_bytes(), model)
host_check = oracle.compare_all(model, observed['rows'])
assert host_check['passed'] and observed['metadata_controls'] == 37
result = {'completed': False, 'host': host_check, 'targets': {},
          'full_G6_qualified': False, 'PCM_qualified': False,
          'production_integration': False, 'physical_device': False}
target_model = json.loads((host / 'target-cases/cases.json').read_bytes())
expected = json.loads((host / 'target-cases/expected.json').read_bytes())
for target in ('esp32', 'esp32c3'):
    directory = root / ('.build/vorbis-residue-' + target + '-20261025-01')
    capture = json.loads((directory / 'report.json').read_bytes())
    assert capture['completed'] and capture['math_capture_completed'] and capture['source_inputs_unchanged']
    assert capture['whole_module_compiled'] and not capture['build_warning_lines']
    assert len(capture['commands']) == 9
    assert all(c['state'] == 'complete' and c['exit_status'] == 0 for c in capture['commands'])
    checked = oracle.compare_target_rows(target_model, expected, capture['rows'])
    assert checked['passed'], checked['failures'][:1]
    result['targets'][target] = checked
result['completed'] = True
destination = root / '.build/vorbis-residue-validation-20261025-01/reference.json'
destination.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'completed': True, 'host_cases': host_check['cases'],
                  'native_cases': {target: check['cases'] for target, check in result['targets'].items()}}))
