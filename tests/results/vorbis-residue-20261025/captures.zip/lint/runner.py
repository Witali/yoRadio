"""Bounded cross-target Clang-Tidy analysis of the isolated portable component."""
import hashlib,json,os,re,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'.build/vorbis-residue-lint-20261025-01'
OUT.mkdir()
SOURCE=ROOT/'idf/components/native_vorbis_numeric'
def sha(data):return hashlib.sha256(data).hexdigest()
inputs={}
(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
for relative in ('floor0.c','quant.c','codebook.c','setup.c','floor_packet.c','residue.c','include/native_vorbis_floor0.h','include/native_vorbis_quant.h','include/native_vorbis_codebook.h','include/native_vorbis_setup.h','include/native_vorbis_floor_packet.h','include/native_vorbis_residue.h','CMakeLists.txt'):
    body=(SOURCE/relative).read_bytes();destination=OUT/'sources'/relative;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(body)
    inputs[str(SOURCE/relative)]=dict(sha256=sha(body),snapshot=destination.relative_to(OUT).as_posix())
config=ROOT/'.clang-tidy';(OUT/'clang-tidy.yaml').write_bytes(config.read_bytes())
inputs[str(config)]=dict(sha256=sha(config.read_bytes()),snapshot='clang-tidy.yaml')
report=dict(completed=False,scope='Standalone owned component only, real cross-target Clang flags and standard-library headers; no GCC database, SDK build, full SDK dependency closure, application or PCM qualification.',inputs=inputs,commands=[],warnings=0,errors=0,tools={})
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for target,tool,flags in (
 ('esp32',Path('C:/Work/yoRadio/.idf/tools-v6.0.2/tools/esp-clang/esp-20.1.1_20250829/esp-clang/bin/clang-tidy.exe'),['--target=xtensa-esp-elf','-mcpu=esp32']),
 ('esp32c3',Path('C:/Work/yoRadio/.idf/tools-v6.1/tools/esp-clang/esp-21.1.3_20260408/esp-clang/bin/clang-tidy.exe'),['--target=riscv32-esp-elf','-march=rv32imc','-mabi=ilp32'])):
    report['tools'][str(tool)]=sha(tool.read_bytes())
    for source in ('floor0.c','quant.c','codebook.c','setup.c','floor_packet.c','residue.c'):
        name=target+'-'+Path(source).stem
        argv=[str(tool),str(OUT/'sources'/source),'--config-file='+str(OUT/'clang-tidy.yaml'),'--header-filter=.*','--export-fixes='+str(OUT/(name+'.yaml')),'--','-std=c11','-O2','-fno-fast-math','-I'+str(OUT/'sources/include'),*flags]
        row=dict(name=name,argv=argv,cwd=str(OUT));report['commands'].append(row);start=time.monotonic()
        with (OUT/(name+'.stdout.log')).open('xb') as so,(OUT/(name+'.stderr.log')).open('xb') as se:
            child=subprocess.Popen(argv,cwd=OUT,stdin=subprocess.DEVNULL,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
            row['pid']=child.pid
            try:row['returncode']=child.wait(timeout=45)
            finally:
                if child.poll() is None:child.kill();child.wait(timeout=5);row['forced_stop']=True
        row['elapsed_seconds']=time.monotonic()-start
        logs=[]
        for stream in ('stdout','stderr'):
            path=OUT/(name+'.'+stream+'.log');body=path.read_bytes();row[stream+'_sha256']=sha(body);logs.append(body.decode('utf8',errors='replace'))
        text='\n'.join(logs);row['warnings']=len(re.findall(r': warning:',text));row['errors']=len(re.findall(r': (?:error|fatal error):',text))
        report['warnings']+=row['warnings'];report['errors']+=row['errors'];save()
        print(json.dumps({key:row[key] for key in ('name','pid','returncode','warnings','errors')}),flush=True)
        assert row['returncode']==0 and not row.get('forced_stop') and not row['errors'],name
assert all(sha(Path(origin).read_bytes())==pin['sha256']==sha((OUT/pin['snapshot']).read_bytes()) for origin,pin in inputs.items())
report['completed']=True;save()
