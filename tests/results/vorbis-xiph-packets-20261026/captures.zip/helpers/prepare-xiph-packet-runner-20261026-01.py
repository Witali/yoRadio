from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parents[1]
old=(ROOT/'tests/test-vorbis-xiph-resources.py').read_bytes().decode()
def change(before,after):
    global old
    assert old.count(before)==1,before
    old=old.replace(before,after)
change('''"""ASan/UBSan resource regressions and every original31 PCM sample via WSL.

Only the declared upstream source edits are selected. All source snapshots,
owned Linux process-group receipts and measured failures are retained.
"""''','''"""Independent packet-allocation regressions and unchanged original31 PCM.

Each finite stream sweep runs in its own owned host command under ASan/UBSan.
The deferred DSP fixture is neither linked nor executed. All source snapshots,
raw diagnostics and nonce-bound process-group receipts are retained.
"""''')
change("report=dict(completed=False,passed=False,sanitizers=['address','undefined'],commands=[],inputs=ledger,physical_device=False,target_executed=False,production_radio_integration=False,general_OOM_qualified=False,general_16KiB_stack_bound=False)","report=dict(completed=False,passed=False,sanitizers=['address','undefined'],commands=[],inputs=ledger,physical_device=False,target_executed=False,production_radio_integration=False,general_OOM_qualified=False,general_16KiB_stack_bound=False,deferred_DSP_fixture_executed=False,deferred_DSP_gate_resumed=False)")
change("for name in('vorbis_xiph_alloc.h','vorbis_xiph_alloc_inject.h','vorbis_xiph_alloc.c','vorbis_xiph_arena.c','vorbis_xiph_books.c','vorbis_xiph_bits.c','vorbis_xiph_residue.c','vorbis_xiph_headers.c','vorbis_xiph_dsp.c','vorbis_xiph_host.c'):","for name in('vorbis_xiph_alloc.h','vorbis_xiph_alloc_inject.h','vorbis_xiph_alloc.c','vorbis_xiph_packets.c','vorbis_xiph_packets_host.c'):")
change("'owned_xiph_resource_prepare'","'owned_xiph_packet_prepare'")
change("for stem in('alloc','arena','books','bits','residue','headers','dsp','host'):","for stem in('alloc','packets','packets_host'):")
start=old.index("        binary=out/'resource-tests'")
end=old.index("        data=output.read_bytes();",start)
old=old[:start]+'''        binary=out/'packet-tests';run('link',['gcc','-fsanitize=address,undefined','-fno-sanitize-recover=all','-no-pie','-Wl,--gc-sections',*[linux(p)for p in objects],'-lm','-o',linux(binary)])
        environment=['env','ASAN_OPTIONS=detect_leaks=1:abort_on_error=1:allocator_may_return_null=1','UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1',linux(binary)]
        focused={}
        for name,arguments in [('arena',['--arena']),('synthetic',['--synthetic'])]:
            text=run('execute-'+name,[*environment,*arguments])
            need(not(out/('execute-'+name+'.stderr.log')).read_bytes(),'no sanitizer diagnostics '+name)
            focused[name]=text
        sweeps=[]
        for index in range(31):
            name='execute-case-'+str(index).zfill(2);text=run(name,[*environment,'--case',str(index)])
            match=re.fullmatch(r'PACKET_PASS case=([0-9]+) scenarios=([1-9][0-9]*) fatal=([0-9]+) optional=([0-9]+) live=0 bytes=0\\s*',text)
            need(match is not None and int(match[1])==index and not(out/(name+'.stderr.log')).read_bytes(),'complete packet sweep without sanitizer diagnostics '+name)
            sweeps.append(dict(case=index,scenarios=int(match[2]),fatal=int(match[3]),optional=int(match[4])))
            report['sweeps']=sweeps;save()
        output=out/'pcm.bin';text=run('execute-capture',[*environment,'--capture',linux(output)])
        need(re.fullmatch(r'CAPTURE_PASS cases=31 packets=434 pcm_bytes=738560 live=0 bytes=0\\s*',text)is not None,'complete original31 raw capture')
        need(not(out/'execute-capture.stderr.log').read_bytes(),'no original31 sanitizer diagnostics')
        report['focused']=focused
''' + old[end:]
change("report.update(completed=True,passed=True,arena_scenarios=11,book_assertions=int(result[1]),bitreader_assertions=int(result[2]),residue_scenarios=int(result[3]),header_scenarios=int(result[4]),dsp_scenarios=int(result[5]),relations=14,binary_sha256=sha(binary.read_bytes()),capture_sha256=sha(data));save();print(json.dumps({k:report[k]for k in('completed','passed','arena_scenarios','book_assertions','bitreader_assertions','residue_scenarios','header_scenarios','dsp_scenarios','cases','packets','pcm_bytes','max_abs_error')}));return 0", "report.update(completed=True,passed=True,packet_scenarios=sum(row['scenarios']for row in sweeps),fatal_packet_refusals=sum(row['fatal']for row in sweeps),optional_refusals=sum(row['optional']for row in sweeps),relations=14,binary_sha256=sha(binary.read_bytes()),capture_sha256=sha(data));save();print(json.dumps({k:report[k]for k in('completed','passed','packet_scenarios','fatal_packet_refusals','optional_refusals','cases','packets','pcm_bytes','max_abs_error')}));return 0")
(ROOT/'tests/test-vorbis-xiph-packets.py').write_bytes(old.encode())

path=ROOT/'tests/test-vorbis-xiph-port-generation.py'
body=path.read_bytes().decode()
generator=ROOT/'idf/components/native_vorbis_xiph_port/prepare.py'
manifest=generator.parent/'port-manifest.json'
for before,after in [
 ('4ea38a55c69bb4c8dec086972f87b62ef32ca24b9bcf9ef25709b5bdf2bb9928',hashlib.sha256(generator.read_bytes()).hexdigest()),
 ('decee153fa4d2a02802e13eaf5bb527afc6e2346e0a020265cad7531b97e2e6d',hashlib.sha256(manifest.read_bytes()).hexdigest()),
 ('twenty_four_edit_ten_unit','thirty_three_edit_eleven_unit'),
 ("'info','bitwise','mdct')}","'info','bitwise','mdct','synthesis')}"),
 ("'native_vorbis_xiph_comment_error.h')","'native_vorbis_xiph_comment_error.h','native_vorbis_xiph_packet_error.h')"),
 ('len(result),130','len(result),132'),('len(changes),24','len(changes),33'),("len(record['edits']),24","len(record['edits']),33"),
 ('twenty-four exact reviewed edits','thirty-three exact reviewed edits')]:
    assert before in body,before
    body=body.replace(before,after)
path.write_bytes(body.encode())
print('Prepared independent packet runner and updated generator inventory checks')
