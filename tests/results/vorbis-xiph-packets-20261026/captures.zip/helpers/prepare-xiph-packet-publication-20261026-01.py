"""Freeze exact source identities after review and prepare a baseline witness."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PORT=ROOT/'idf/components/native_vorbis_xiph_port'
manifest=json.loads((PORT/'port-manifest.json').read_bytes())
manifest['files']={p.relative_to(PORT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(PORT.rglob('*'))if p.is_file()and p.name!='port-manifest.json'}
(PORT/'port-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
digest=hashlib.sha256((PORT/'port-manifest.json').read_bytes()).hexdigest()
path=ROOT/'tests/test-vorbis-xiph-port-generation.py';body=path.read_bytes()
before=b"PORT_SHA='b0e77efb3a7a2783168ca33cbfe1898a0646345263a7e2bc7c8b7ece0a2299d5'"
assert body.count(before)==1;path.write_bytes(body.replace(before,b"PORT_SHA='"+digest.encode()+b"'"))
print(json.dumps(dict(port_manifest_sha256=digest,generator_sha256=hashlib.sha256((PORT/'prepare.py').read_bytes()).hexdigest())))

prior=(ROOT/'.build/witness-xiph-comments-20261026-01.py').read_bytes().decode()
start=prior.index('def save():');end=prior.index("rows={r['name']",start)
shared=prior[start:end]
prefix='''"""Restore only the original unchecked synthesis PCM allocation calls."""
import hashlib,json,subprocess,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
HOST=ROOT/'.build/vorbis-xiph-packets-host-20261026-03'
OUT=ROOT/'.build/vorbis-xiph-packets-baseline-20261026-01'
assert not OUT.exists();OUT.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
linux=lambda p:'/mnt/'+Path(p).resolve().as_posix()[0].lower()+Path(p).resolve().as_posix()[2:]
original=json.loads((HOST/'report.json').read_text());assert original['passed']
assert original['porting']['compiled_units'][8]['original']=='upstream/libvorbis/lib/synthesis.c'
(OUT/'runner.py').write_bytes(Path(__file__).read_bytes());(OUT/'supervisor.py').write_bytes((HOST/'supervisor.py').read_bytes())
port=HOST/'sources/components/native_vorbis_xiph_port';body=(HOST/'generated/ported/synthesis.c').read_bytes()
before=(port/'edits/synthesis-pcm.before.c').read_bytes();after=(port/'edits/synthesis-pcm.after.c').read_bytes()
assert body.count(after)==1;body=body.replace(after,before,1);(OUT/'synthesis.c').write_bytes(body)
assert body==(HOST/'sources/components/native_vorbis_xiph/upstream/libvorbis/lib/synthesis.c').read_bytes()
report={'completed':False,'expected_regression':False,'host_report_sha256':sha(HOST/'report.json'),'source_sha256':sha(OUT/'synthesis.c'),'commands':[]}
'''
suffix='''rows={r['name']:r['child_argv']for r in original['commands']}
argv=list(rows['compile-library-08']);argv[argv.index('-c')+1]=linux(OUT/'synthesis.c');argv[argv.index('-o')+1]=linux(OUT/'synthesis.o');run('compile-old-synthesis',argv)
argv=[linux(OUT/'synthesis.o')if x==linux(HOST/'objects/library-08.o')else x for x in rows['link']]
argv[argv.index('-o')+1]=linux(OUT/'packet-tests');run('link',argv)
argv=['python3','-c','import os,resource,sys; resource.setrlimit(resource.RLIMIT_CORE,(0,0)); os.execve(sys.argv[1],sys.argv[1:],dict(os.environ,ASAN_OPTIONS="detect_leaks=1:abort_on_error=1:allocator_may_return_null=1",UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1"))',linux(OUT/'packet-tests'),'--case','0']
run('execute',argv,False)
error=(OUT/'execute.stderr.log').read_text();assert '/synthesis.c:'in error and 'vorbis_synthesis'in error and 'runtime error:'in error and 'null pointer'in error
report.update(completed=True,expected_regression=True,deferred_DSP_fixture_executed=False,reason='Original unchecked PCM pointer allocation stores through NULL on the first required packet allocation refusal.',binary_sha256=sha(OUT/'packet-tests'))
save();print(json.dumps({k:report[k]for k in('completed','expected_regression','deferred_DSP_fixture_executed')}))
'''
(ROOT/'.build/witness-xiph-packets-20261026-01.py').write_bytes((prefix+shared+suffix).encode())
