import hashlib,json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'idf/components/native_vorbis_xiph'
PORT=ROOT/'idf/components/native_vorbis_xiph_port'
assert hashlib.sha256((BASE/'component-manifest.json').read_bytes()).hexdigest()=='897096caf216de0e161f4fd833037863f8e2dc3da0531e34b851503f932f4b14'
edits=json.loads((PORT/'edits.json').read_bytes())
assert len(edits['edits'])==24
def source(stem):return (BASE/'upstream/libvorbis/lib'/f'{stem}.c').read_bytes().decode()
def section(stem,start,end):
    body=source(stem);at=body.index(start);return body[at:body.index(end,at)]
def replace(body,before,after):
    assert body.count(before)==1,before
    return body.replace(before,after,1)
def add(stem,name,before,after):
    assert source(stem).count(before)==1 and before!=after,name
    for suffix,body in [('before',before),('after',after)]:
        (PORT/'edits'/f'{name}.{suffix}.c').write_bytes(body.encode())
    edits['edits'].append(dict(source=f'upstream/libvorbis/lib/{stem}.c',before=f'edits/{name}.before.c',after=f'edits/{name}.after.c'))

before=section('block','void *_vorbis_block_alloc(', '/* reap the chain, pull the ripcord */')
after='''#include <limits.h>

void *_vorbis_block_alloc(vorbis_block *vb,long bytes){
  struct alloc_chain *link=NULL;
  void *store;
  long aligned;

  if(!vb || bytes<0 || bytes>LONG_MAX-(WORD_ALIGN-1) ||
     vb->localtop<0 || vb->localalloc<0 || vb->totaluse<0 ||
     vb->localtop>vb->localalloc ||
     (!vb->localstore && (vb->localtop || vb->localalloc)))return NULL;
  aligned=(bytes+(WORD_ALIGN-1)) & ~(WORD_ALIGN-1);
  if((long)(size_t)aligned!=aligned)return NULL;

  /* Zero bytes need no owner, and NULL must never enter pointer arithmetic. */
  if(!aligned)return vb->localstore ? (char *)vb->localstore+vb->localtop : NULL;
  if(aligned<=vb->localalloc-vb->localtop){
    store=(char *)vb->localstore+vb->localtop;
    vb->localtop+=aligned;
    return store;
  }

  /* Existing borrowed pointers stay live until the next ripcord. Prepare
     both new owners before changing any arena accounting or links. */
  if(vb->localstore){
    if(vb->totaluse>LONG_MAX-vb->localtop)return NULL;
    link=_ogg_malloc(sizeof(*link));
    if(!link)return NULL;
  }
  store=_ogg_malloc((size_t)aligned);
  if(!store){
    _ogg_free(link);
    return NULL;
  }
  if(link){
    link->next=vb->reap;
    link->ptr=vb->localstore;
    vb->reap=link;
    vb->totaluse+=vb->localtop;
  }
  vb->localstore=store;
  vb->localalloc=aligned;
  vb->localtop=aligned;
  return store;
}

'''
add('block','block-alloc',before,after)

before='''  vb->pcm=_vorbis_block_alloc(vb,sizeof(*vb->pcm)*vi->channels);
  for(i=0;i<vi->channels;i++)
    vb->pcm[i]=_vorbis_block_alloc(vb,vb->pcmend*sizeof(*vb->pcm[i]));
'''
after='''  vb->pcm=_vorbis_block_alloc(vb,sizeof(*vb->pcm)*vi->channels);
  if(!vb->pcm)return OV_EFAULT;
  for(i=0;i<vi->channels;i++){
    vb->pcm[i]=_vorbis_block_alloc(vb,vb->pcmend*sizeof(*vb->pcm[i]));
    if(!vb->pcm[i])return OV_EFAULT;
  }
'''
add('synthesis','synthesis-pcm',before,after)

before=section('floor0','static void floor0_map_lazy_init(', 'static vorbis_look_floor *floor0_look(')
after=replace(before,'static void floor0_map_lazy_init(', 'static int floor0_map_lazy_init(')
after=replace(after,'    look->linearmap[W]=_ogg_malloc((n+1)*sizeof(**look->linearmap));\n','    look->linearmap[W]=_ogg_malloc((n+1)*sizeof(**look->linearmap));\n    if(!look->linearmap[W])return OV_EFAULT;\n')
assert after.endswith('  }\n}\n\n')
after=after[:-3]+'  return 0;\n}\n\n'
add('floor0','floor0-map',before,after)

before=section('floor0','static void *floor0_inverse1(', 'static int floor0_inverse2(')
after=replace(before,'static void *floor0_inverse1(vorbis_block *vb,vorbis_look_floor *i){', '#include "native_vorbis_xiph_packet_error.h"\n\nvoid *native_xiph_floor0_inverse1(vorbis_block *vb,vorbis_look_floor *i,\n                                  int *failure){')
after=replace(after,'      float *lsp=_vorbis_block_alloc(vb,sizeof(*lsp)*(look->m+b->dim+1));\n', '      float *lsp=_vorbis_block_alloc(vb,sizeof(*lsp)*(look->m+b->dim+1));\n      if(!lsp){*failure=OV_EFAULT;return NULL;}\n')
after+='''static void *floor0_inverse1(vorbis_block *vb,vorbis_look_floor *i){
  int failure=0;
  return native_xiph_floor0_inverse1(vb,i,&failure);
}

'''
add('floor0','floor0-inverse1',before,after)

before='  floor0_map_lazy_init(vb,info,look);\n'
after='  int failure=floor0_map_lazy_init(vb,info,look);\n  if(failure)return failure;\n'
add('floor0','floor0-inverse2',before,after)

before=section('floor1','static void *floor1_inverse1(', 'static int floor1_inverse2(')
after=replace(before,'static void *floor1_inverse1(vorbis_block *vb,vorbis_look_floor *in){', '#include "native_vorbis_xiph_packet_error.h"\n\nvoid *native_xiph_floor1_inverse1(vorbis_block *vb,vorbis_look_floor *in,\n                                  int *failure){')
after=replace(after,'    int *fit_value=_vorbis_block_alloc(vb,(look->posts)*sizeof(*fit_value));\n', '    int *fit_value=_vorbis_block_alloc(vb,(look->posts)*sizeof(*fit_value));\n    if(!fit_value){*failure=OV_EFAULT;return NULL;}\n')
after+='''static void *floor1_inverse1(vorbis_block *vb,vorbis_look_floor *in){
  int failure=0;
  return native_xiph_floor1_inverse1(vb,in,&failure);
}

'''
add('floor1','floor1-inverse1',before,after)

before='''    int ***partword=alloca(ch*sizeof(*partword));

    for(j=0;j<ch;j++)
      partword[j]=_vorbis_block_alloc(vb,partwords*sizeof(*partword[j]));
'''
after='''    int ***partword=alloca(ch*sizeof(*partword));

    if(!partwords || !look->stages)return 0; /* no residual work */
    for(j=0;j<ch;j++){
      partword[j]=_vorbis_block_alloc(vb,partwords*sizeof(*partword[j]));
      if(!partword[j])return OV_EFAULT;
    }
'''
add('res0','residue01-inverse',before,after)

before='''    int **partword=_vorbis_block_alloc(vb,partwords*sizeof(*partword));

    for(i=0;i<ch;i++)if(nonzero[i])break;
    if(i==ch)return(0); /* no nonzero vectors */
'''
after='''    int **partword;

    for(i=0;i<ch;i++)if(nonzero[i])break;
    if(i==ch || !partwords || !look->stages)return(0); /* no residual work */
    partword=_vorbis_block_alloc(vb,partwords*sizeof(*partword));
    if(!partword)return OV_EFAULT;
'''
add('res0','residue2-inverse',before,after)

before=section('mapping0','static int mapping0_inverse(', '/* export hooks */')
after='''#include "native_vorbis_xiph_packet_error.h"

static void *(*const native_xiph_floor_inverse1[])(vorbis_block *,
                                                  vorbis_look_floor *,int *)={
  native_xiph_floor0_inverse1,native_xiph_floor1_inverse1
};
_Static_assert(sizeof(native_xiph_floor_inverse1)/sizeof(*native_xiph_floor_inverse1)
               ==VI_FLOORB,"checked packet floor dispatch matches registry");

'''+before
after=replace(after,'''    floormemo[i]=_floor_P[ci->floor_type[info->floorsubmap[submap]]]->
      inverse1(vb,b->flr[info->floorsubmap[submap]]);
''','''    int failure=0;
    floormemo[i]=native_xiph_floor_inverse1[ci->floor_type[info->floorsubmap[submap]]](
      vb,b->flr[info->floorsubmap[submap]],&failure);
    if(failure)return failure;
''')
after=replace(after,'''    _residue_P[ci->residue_type[info->residuesubmap[i]]]->
      inverse(vb,b->residue[info->residuesubmap[i]],
              pcmbundle,zerobundle,ch_in_bundle);
''','''    int status=_residue_P[ci->residue_type[info->residuesubmap[i]]]->
      inverse(vb,b->residue[info->residuesubmap[i]],
              pcmbundle,zerobundle,ch_in_bundle);
    if(status<0)return status;
''')
after=replace(after,'''    _floor_P[ci->floor_type[info->floorsubmap[submap]]]->
      inverse2(vb,b->flr[info->floorsubmap[submap]],
               floormemo[i],pcm);
''','''    int status=_floor_P[ci->floor_type[info->floorsubmap[submap]]]->
      inverse2(vb,b->flr[info->floorsubmap[submap]],
               floormemo[i],pcm);
    if(status<0)return status;
''')
add('mapping0','mapping-inverse',before,after)

(PORT/'include/native_vorbis_xiph_packet_error.h').write_bytes(b'''/* Private checked packet floor callbacks. NULL with failure==0 remains the
   upstream unused-floor/EOP result. Required allocation failure is OV_EFAULT.
   Public headers and the original registry callback signatures are unchanged. */
#ifndef NATIVE_VORBIS_XIPH_PACKET_ERROR_H
#define NATIVE_VORBIS_XIPH_PACKET_ERROR_H
#include <ogg/ogg.h>
#include "vorbis/codec.h"
#include "codec_internal.h"
void *native_xiph_floor0_inverse1(vorbis_block *,vorbis_look_floor *,int *);
void *native_xiph_floor1_inverse1(vorbis_block *,vorbis_look_floor *,int *);
#endif
''')
(PORT/'edits.json').write_text(json.dumps(edits,indent=2)+'\n',encoding='utf-8',newline='\n')

def update(path,before,after):
    body=path.read_bytes().decode();path.write_bytes(replace(body,before,after).encode())
update(PORT/'prepare.py',"len(changes['edits']) == 24, 'twenty-four exact reviewed edits'", "len(changes['edits']) == 33, 'thirty-three exact reviewed edits'")
update(PORT/'prepare.py',"'upstream/libvorbis/lib/info.c', 'upstream/libvorbis/lib/mdct.c'},", "'upstream/libvorbis/lib/info.c', 'upstream/libvorbis/lib/mdct.c',\n                           'upstream/libvorbis/lib/synthesis.c'},")
update(PORT/'prepare.py',"'only the ten reviewed translation units change'", "'only the eleven reviewed translation units change'")
update(PORT/'prepare.py',"    units = [dict(original=name, compiled=", "    generated['ported/native_vorbis_xiph_packet_error.h'] = edits['include/native_vorbis_xiph_packet_error.h']\n    units = [dict(original=name, compiled=")
update(PORT/'CMakeLists.txt','set(xiph_ported_units block sharedbook codebook floor0 floor1 res0 mapping0 info mdct)', 'set(xiph_ported_units block sharedbook codebook floor0 floor1 res0 mapping0 info mdct synthesis)')
update(PORT/'README.md','ten modified translation units and three owned private headers','eleven modified translation units and four owned private headers')
update(PORT/'README.md','Neither production application selects this component.', '''Nine packet-path edits make arena growth transactional and check PCM, floor
memo, lazy floor0 map and residue allocations. A local checked floor dispatch
distinguishes required allocation failure from nominal unused-floor/EOP; mapping
propagates negative residue/floor statuses before synthesis can return success.
No complete residue partition and no active residue2 channels remain successful
no-work cases. Existing registry callback signatures and public ABI are retained.
The port extends vorbis_synthesis's error results with OV_EFAULT for required
allocation failure; upstream documents 0/OV_ENOTAUDIO/OV_EBADPACKET only. On
any nonzero result the block must not be submitted to synthesis_blockin. Close
the block/DSP/info/comment owners and replay all three headers for recovery.
This does not qualify encoder allocation paths or change nominal EOP behavior.

Neither production application selects this component.''')
update(PORT/'README.md','general OOM recovery or a complete decoder stack bound: packet arena/floor/residue allocation paths still require qualification.', 'general OOM recovery or a complete decoder stack bound: packet-path qualification is recorded separately.')
manifest=json.loads((PORT/'port-manifest.json').read_bytes())
manifest['files']={p.relative_to(PORT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(PORT.rglob('*'))if p.is_file()and p.name!='port-manifest.json'}
(PORT/'port-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(edits=len(edits['edits']),generator_sha256=hashlib.sha256((PORT/'prepare.py').read_bytes()).hexdigest(),port_manifest_sha256=hashlib.sha256((PORT/'port-manifest.json').read_bytes()).hexdigest())))
