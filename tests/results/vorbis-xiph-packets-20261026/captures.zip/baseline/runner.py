"""Restore only the original unchecked synthesis PCM allocation calls."""
import hashlib,json,subprocess,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
HOST=ROOT/'.build/vorbis-xiph-packets-host-20261026-03'
OUT=ROOT/'.build/vorbis-xiph-packets-baseline-20261026-01'
assert not OUT.exists();OUT.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
linux=lambda p:'/mnt/'+Path(p).resolve().as_posix()[0].lower()+Path(p).resolve().as_posix()[2:]
original=json.loads((HOST/'report.json').read_text());assert original['passed']
assert original['porting']['compiled_units'][8]['original']=='upstream/libvorbis/lib/synthesis.c'
(OUT/'runner.py').write_bytes(Path(__file__).read_bytes());(OUT/'supervisor.py').write_bytes((HOST/'supervisor.py').read_bytes())
port=HOST/'sources/components/native_vorbis_xiph_port';body=(HOST/'generated/ported/synthesis.c').read_bytes()
before=(port/'edits/synthesis-pcm.before.c').read_bytes();after=(port/'edits/synthesis-pcm.after.c').read_bytes()
assert body.count(after)==1;body=body.replace(after,before,1);(OUT/'synthesis.c').write_bytes(body)
assert body==(HOST/'sources/components/native_vorbis_xiph/upstream/libvorbis/lib/synthesis.c').read_bytes()
report={'completed':False,'expected_regression':False,'host_report_sha256':sha(HOST/'report.json'),'source_sha256':sha(OUT/'synthesis.c'),'commands':[]}
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(name,argv,success=True):
    nonce=uuid.uuid4().hex;request=OUT/(name+'.request.json');receipt=OUT/(name+'.receipt.json')
    request.write_text(json.dumps(dict(nonce=nonce,argv=argv,timeout=60,receipt=linux(receipt),stop=linux(OUT/(name+'.stop')))),encoding='utf-8')
    row={'name':name,'argv':argv,'nonce':nonce,'request_sha256':sha(request)};report['commands'].append(row);save();child=None
    try:
        with(OUT/(name+'.stdout.log')).open('xb')as so,(OUT/(name+'.stderr.log')).open('xb')as se:
            child=subprocess.Popen(['wsl.exe','--exec','python3',linux(OUT/'supervisor.py'),linux(request)],stdout=so,stderr=se,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
            row['transport_pid']=child.pid;row['transport_exit']=child.wait(timeout=80)
    finally:
        if child is not None and child.poll()is None:
            (OUT/(name+'.stop')).write_text(nonce)
            try:child.wait(timeout=15)
            except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
            row['forced_stop']=True
        row['supervisor']=json.loads(receipt.read_text())if receipt.exists()else{}
        for stream in('stdout','stderr'):row[stream+'_sha256']=sha(OUT/(name+'.'+stream+'.log'))
        save()
    observed=row['supervisor'];assert not row.get('forced_stop')and observed['nonce']==nonce and observed['request_sha256']==row['request_sha256']and observed['final']and observed['child_reaped']and observed['group_gone']and observed['state']=='terminal'
    assert observed['child_returncode']==0 if success else observed['child_returncode']!=0
rows={r['name']:r['child_argv']for r in original['commands']}
argv=list(rows['compile-library-08']);argv[argv.index('-c')+1]=linux(OUT/'synthesis.c');argv[argv.index('-o')+1]=linux(OUT/'synthesis.o');run('compile-old-synthesis',argv)
argv=[linux(OUT/'synthesis.o')if x==linux(HOST/'objects/library-08.o')else x for x in rows['link']]
argv[argv.index('-o')+1]=linux(OUT/'packet-tests');run('link',argv)
argv=['python3','-c','import os,resource,sys; resource.setrlimit(resource.RLIMIT_CORE,(0,0)); os.execve(sys.argv[1],sys.argv[1:],dict(os.environ,ASAN_OPTIONS="detect_leaks=1:abort_on_error=1:allocator_may_return_null=1",UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1"))',linux(OUT/'packet-tests'),'--case','0']
run('execute',argv,False)
error=(OUT/'execute.stderr.log').read_text();assert '/synthesis.c:'in error and 'vorbis_synthesis'in error and 'runtime error:'in error and 'null pointer'in error
report.update(completed=True,expected_regression=True,deferred_DSP_fixture_executed=False,reason='Original unchecked PCM pointer allocation stores through NULL on the first required packet allocation refusal.',binary_sha256=sha(OUT/'packet-tests'))
save();print(json.dumps({k:report[k]for k in('completed','expected_regression','deferred_DSP_fixture_executed')}))
