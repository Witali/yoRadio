"""Seal independent channel-scratch changes and retain their preceding inputs."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PORT=ROOT/'idf/components/native_vorbis_xiph_port'
OUT=ROOT/'.build/vorbis-xiph-channel-scratch-preceding-20261026-01'
assert not OUT.exists();OUT.mkdir()
sha=lambda body:hashlib.sha256(body).hexdigest()
for stem in('mapping-inverse','residue01-inverse'):
    name='idf/components/native_vorbis_xiph_port/edits/'+stem+'.after.c'
    result=subprocess.run(['git','-c','core.longpaths=true','show','0482edee8:'+name],cwd=ROOT,capture_output=True,check=True)
    (OUT/(stem+'.after.c')).write_bytes(result.stdout)
manifest=json.loads((PORT/'port-manifest.json').read_bytes())
manifest['files']={path.relative_to(PORT).as_posix():sha(path.read_bytes())for path in sorted(PORT.rglob('*'))if path.is_file()and path.name!='port-manifest.json'}
(PORT/'port-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
digest=sha((PORT/'port-manifest.json').read_bytes())
path=ROOT/'tests/test-vorbis-xiph-port-generation.py';body=path.read_bytes();old=b"PORT_SHA='908348db2d68684ddb21211b7f255e54a6fa95302567aa27bbc160cca8072894'"
assert body.count(old)==1;path.write_bytes(body.replace(old,b"PORT_SHA='"+digest.encode()+b"'"))
print(json.dumps(dict(port_manifest_sha256=digest,generator_sha256=sha((PORT/'prepare.py').read_bytes()))))
