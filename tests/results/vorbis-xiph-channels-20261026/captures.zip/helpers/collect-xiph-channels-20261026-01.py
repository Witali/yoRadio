"""Retain independent scratch-storage evidence without native execution."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'tests/results/vorbis-xiph-channels-20261026'
assert not OUT.exists();OUT.mkdir(parents=True);bodies={}
def add(path,name):
    assert path.resolve().is_relative_to(ROOT) and path.is_file()
    body=path.read_bytes();assert name not in bodies or bodies[name]==body;bodies[name]=body
def tree(folder,prefix):
    base=ROOT/folder;assert base.is_dir()
    for path in sorted(base.rglob('*')):
        if path.is_file():add(path,prefix+'/'+path.relative_to(base).as_posix())
for folder,prefix in(
    ('.build/vorbis-xiph-channels-host-20261026-01','host'),
    ('.build/vorbis-xiph-channels-stack-20261026-01','stack'),
    ('.build/vorbis-xiph-channels-lint-20261026-01','lint'),
    ('.build/vorbis-xiph-channel-scratch-preceding-20261026-01','preceding'),
    ('.build/vorbis-xiph-channels-validation-20261026-01','receipts'),
    ('.build/vorbis-xiph-channels-audits-20261026-01','audit')):tree(folder,prefix)
host=json.loads((ROOT/'.build/vorbis-xiph-channels-host-20261026-01/report.json').read_bytes())
lint=json.loads((ROOT/'.build/vorbis-xiph-channels-lint-20261026-01/report.json').read_bytes())
stack=json.loads((ROOT/'.build/vorbis-xiph-channels-stack-20261026-01/report.json').read_bytes())
assert host['completed'] and host['passed'] and not host['target_executed']
assert lint['completed'] and lint['errors']==0 and lint['warnings']==316
assert stack['completed'] and not stack['target_runtime'] and not stack['SDK_build']
for name in('cyd-vorbis-format-command-01.py','prepare-xiph-channel-scratch-20261026-01.py',
             'stack-xiph-channels-20261026-01.py','lint-xiph-channels-20261026-01.py',
             'collect-xiph-channels-20261026-01.py'):
    add(ROOT/'.build'/name,'helpers/'+name)
for name in('test-vorbis-xiph-packets.py','test-vorbis-xiph-port-generation.py',
             'verify-vorbis-xiph-packets-checkpoint.py','verify-vorbis-xiph-channels-checkpoint.py'):
    add(ROOT/'tests'/name,'sources/tests/'+name)
manifest={'schema':'vorbis-xiph-channels-checkpoint-v1','files':{name:{'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body)}for name,body in sorted(bodies.items())}}
raw=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(OUT/'captures.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as archive:
    for name,body in sorted(bodies.items()):archive.writestr(name,body)
    archive.writestr('manifest.json',raw)
record=dict(sha256=hashlib.sha256((OUT/'captures.zip').read_bytes()).hexdigest(),bytes=(OUT/'captures.zip').stat().st_size,members=len(bodies)+1,manifest_sha256=hashlib.sha256(raw).hexdigest(),host_qualified=True,source_only_Xtensa_objects=True,native_runtime_qualified=False,deferred_DSP_gate_qualified=False,wide_amplitude_qualified=False)
(OUT/'archive.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record))
