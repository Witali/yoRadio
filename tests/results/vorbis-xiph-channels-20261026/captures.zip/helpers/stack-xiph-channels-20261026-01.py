"""Source-only Xtensa compiler stack comparison, not an SDK build or run."""
import hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
HOST=ROOT/'.build/vorbis-xiph-channels-host-20261026-01'
OLD=ROOT/'.build/vorbis-xiph-channel-scratch-preceding-20261026-01'
OUT=ROOT/'.build/vorbis-xiph-channels-stack-20261026-01'
TOOL=Path('C:/Work/yoRadio/.idf/tools-v6.0.2/tools/xtensa-esp-elf/esp-15.2.0_20251204/xtensa-esp-elf/bin/xtensa-esp32-elf-gcc.exe')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
host=json.loads((HOST/'report.json').read_bytes());assert host['completed'] and host['passed'] and not OUT.exists()
OUT.mkdir();(OUT/'objects').mkdir();(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
report=dict(completed=False,commands=[],inputs={},tool_sha256=sha(TOOL),target_runtime=False,SDK_build=False,production_build=False,physical_device=False,
    scope='Four source-only Xtensa objects. Same -O2 -fno-inline flags before/after isolate compiler own-function stack frames. No SDK app, link, emulator, target execution, whole-call-chain stack bound or physical high-water measurement.')
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(name,argv):
    row=dict(name=name,argv=list(map(str,argv)));report['commands'].append(row);child=None;start=time.monotonic()
    try:
        with(OUT/(name+'.stdout.log')).open('xb')as so,(OUT/(name+'.stderr.log')).open('xb')as se:
            child=subprocess.Popen(row['argv'],cwd=OUT,stdin=subprocess.DEVNULL,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
            row['pid']=child.pid;row['returncode']=child.wait(timeout=60)
    finally:
        if child is not None and child.poll()is None:
            subprocess.run(['taskkill.exe','/PID',str(child.pid),'/T','/F'],capture_output=True,timeout=15,creationflags=subprocess.CREATE_NO_WINDOW)
            if child.poll()is None:child.kill()
            child.wait(timeout=5);row['forced_stop']=True
        row['elapsed_seconds']=time.monotonic()-start
        for stream in('stdout','stderr'):row[stream+'_sha256']=sha(OUT/(name+'.'+stream+'.log'))
        save()
    assert row['returncode']==0 and not row.get('forced_stop'),name
run('compiler-version',[TOOL,'--version']);run('compiler-machine',[TOOL,'-dumpmachine'])
run('compiler-macros',[TOOL,'-dM','-E','-x','c','-'])
macros=(OUT/'compiler-macros.stdout.log').read_text()
assert '#define __SIZEOF_POINTER__ 4\n' in macros and '#define __SIZEOF_LONG__ 4\n' in macros and '#define __XTENSA__ 1\n' in macros
generated=HOST/'generated';port=HOST/'sources/components/native_vorbis_xiph_port'
includes=[generated/'base/upstream/libvorbis/include',generated/'base/upstream/libogg/include',generated/'base/platform',generated/'base/upstream/libvorbis/lib',generated/'ported']
common=[str(TOOL),'-std=gnu17','-O2','-fno-inline','-DHAVE_ALLOCA_H=1','-D_GNU_SOURCE=1','-fno-fast-math','-ffp-contract=off','-fstack-usage',*['-I'+str(p)for p in includes]]
report['functions']={}
for unit,edit,function in [('mapping0','mapping-inverse','mapping0_inverse'),('res0','residue01-inverse','_01inverse')]:
    current=(generated/'ported'/(unit+'.c')).read_bytes();after=(port/'edits'/(edit+'.after.c')).read_bytes();before=(OLD/(edit+'.after.c')).read_bytes()
    assert current.count(after)==1 and before!=after
    for version,body in [('before',current.replace(after,before,1)),('after',current)]:
        source=OUT/(version+'-'+unit+'.c');source.write_bytes(body);report['inputs'][str(source)]=sha(source)
        object_path=OUT/'objects'/(version+'-'+unit+'.o');run('compile-'+version+'-'+unit,[*common,'-c',str(source),'-o',str(object_path)])
        usage=object_path.with_suffix('.su');assert usage.is_file()
        records=[]
        for line in usage.read_text().splitlines():
            site,size,kind=line.split('\t');name=site.rsplit(':',1)[-1]
            if name==function:records.append(dict(function=name,own_frame_bytes=int(size),kind=kind))
        assert len(records)==1,(function,usage.read_text())
        report['functions'][version+'-'+unit]=dict(**records[0],source_sha256=sha(source),object_sha256=sha(object_path),usage_sha256=sha(usage))
        save()
    assert 'dynamic' in report['functions']['before-'+unit]['kind']
    assert report['functions']['after-'+unit]['kind']=='static'
assert all(sha(path)==digest for path,digest in report['inputs'].items()) and sha(TOOL)==report['tool_sha256']
report['completed']=True;save();print(json.dumps(dict(completed=True,functions=report['functions'],target_runtime=False)))
