"""Use the recorded SDK/tool locations for this new isolated floor-packet run."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
target = sys.argv[1]
assert target in ('esp32', 'esp32c3')
prior = json.loads((root / '.build/vorbis-setup-validation-20261025-01' / (target + '.json')).read_bytes())
argv = [value.replace('vorbis-setup', 'vorbis-floor-packet') for value in prior['argv']]
argv[argv.index('--cases') + 1] = '.build/vorbis-floor-packet-host-20261025-03/target-cases'
component = root / 'idf/components/native_vorbis_numeric'
parts = {
    'source': 'floor0.c', 'header': 'include/native_vorbis_floor0.h',
    'quant-source': 'quant.c', 'quant-header': 'include/native_vorbis_quant.h',
    'codebook-source': 'codebook.c', 'codebook-header': 'include/native_vorbis_codebook.h',
    'setup-source': 'setup.c', 'setup-header': 'include/native_vorbis_setup.h',
    'floor-packet-source': 'floor_packet.c', 'floor-packet-header': 'include/native_vorbis_floor_packet.h',
    'component': 'CMakeLists.txt',
}
cases = root / argv[argv.index('--cases') + 1]
paths = {name: component / path for name, path in parts.items()}
paths.update({'cases': cases / 'cases.json', 'cases-header': cases / 'cases.h'})
for name, path in paths.items():
    option = '--' + name + '-sha256'
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if option in argv:
        argv[argv.index(option) + 1] = digest
    else:
        argv.extend([option, digest])
validation = root / '.build/vorbis-floor-packet-validation-20261025-01'
(validation / (target + '.argv.json')).write_text(json.dumps(argv, indent=2) + '\n', encoding='utf-8')
wrapper = [sys.executable, '-B', '-X', 'utf8', str(root / '.build/cyd-vorbis-format-command-01.py'),
           '--record', str(validation / (target + '.json')), '--cwd', str(root), '--timeout', '1200', '--']
subprocess.run(wrapper + argv, cwd=root, check=True)
