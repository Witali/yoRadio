import hashlib
import json
import re
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[1]
out = root / '.build/cyd-vendor-public-gcc-20261030-03'
out.mkdir(exist_ok=False)
source = root / 'idf/esp32-cyd2usb-native/main/audio_service.c'
report = dict(scope='actual production audio_service.c translation unit only',
              linked_firmware=False, passed=False, profiles=[])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
try:
    for name in ('build-c3-transfer', 'build-custom-flac-network-settings-continuous',
                 'build-custom-flac-network-settings-legacy'):
        build = root / 'idf/esp32-cyd2usb-native' / name
        database = build / 'compile_commands.json'
        entries = [row for row in json.loads(database.read_bytes())
                   if Path(row['file']).resolve() == source]
        assert len(entries) == 1
        row = entries[0]
        command = row['command']
        assert 'xtensa-esp' in command and 'gcc.exe' in command and ' -c ' in command
        obj = out / (name + '.obj')
        command, changes = re.subn(r' -o (?:"[^"]+"|\S+) ', ' -o ' + obj.as_posix() + ' ', command)
        assert changes == 1
        result = subprocess.run(command, cwd=row['directory'], stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, timeout=120, creationflags=subprocess.CREATE_NO_WINDOW)
        (out / (name + '.log')).write_bytes(result.stdout)
        record = dict(profile=name, command=command, exit_status=result.returncode,
            source_sha256=sha(source), config_sha256=sha(build / 'config/sdkconfig.h'),
            database_sha256=sha(database), log_sha256=sha(out / (name + '.log')))
        report['profiles'].append(record)
        assert result.returncode == 0 and obj.is_file(), 'Actual GCC translation unit failed'
        record['object_sha256'] = sha(obj)
    report['passed'] = True
finally:
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(passed=report['passed'], profiles=len(report['profiles']))))
