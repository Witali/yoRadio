from pathlib import Path
import hashlib,importlib.util,json,os,re,shutil,subprocess,time
root=Path.cwd(); repo=root.parent.parent
out=root/'.build/vorbis-floor1-product-native-replay-20261026-01'
assert not out.exists();out.mkdir()
controller=root/'tests/run-vorbis-floor1-product-qemu.py'
spec=importlib.util.spec_from_file_location('trusted_native_floor1_replay',controller)
subject=importlib.util.module_from_spec(spec);spec.loader.exec_module(subject)
math=subject.load_math(); originals,cases=subject.native_cases(math)
sha=lambda b:hashlib.sha256(b).hexdigest()
table=math.table_from_upstream((root/'idf/components/native_vorbis_xiph/upstream/libvorbis/lib/floor1.c').read_bytes())
old_line="save(); print(json.dumps(dict(completed=True,passed=True,target=args.target,**report['measurements']))); return 0"
new_line="save(); print(json.dumps(dict(completed=True,target=args.target,**report['measurements']))); return 0"
current=controller.read_bytes();assert current.count(new_line.encode())==1
before=current.replace(new_line.encode(),old_line.encode())
result=dict(passed=False,child_commands_terminal0=True,original_outer_controllers_clean=False,
    retained_original_outer_terminal_status=1,retained_footer_error_type='TypeError',
    source_delta_scope='One console-summary expression only; no parser, fixture, model or component changes.',
    final_controller_sha256=sha(current),executed_controller_sha256=sha(before),profiles={},commands=[])
def save():
 (out/'report.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(name,argv):
 row=dict(name=name,argv=[('runtime-executable-path-redacted' if re.search(r'(?i)[/\\]Users[/\\]',str(x)) else str(x)) for x in argv]);result['commands'].append(row);save()
 started=time.monotonic()
 with (out/(name+'.stdout.log')).open('xb') as so,(out/(name+'.stderr.log')).open('xb') as se:
  child=subprocess.Popen(list(map(str,argv)),stdin=subprocess.DEVNULL,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
  row['pid']=child.pid;save()
  try:row['exit_status']=child.wait(timeout=60)
  finally:
   if child.poll() is None:child.kill();child.wait(timeout=5);row['forced_stop']=True
 row['elapsed_seconds']=time.monotonic()-started
 for stream in ('stdout','stderr'):row[stream+'_sha256']=sha((out/(name+'.'+stream+'.log')).read_bytes())
 save();assert row['exit_status']==0 and not row.get('forced_stop')
 return (out/(name+'.stdout.log')).read_text('utf-8',errors='replace')
for target,stem in [('esp32','vorbis-floor1-product-native-esp32-20261026-02'),('esp32c3','vorbis-floor1-product-native-esp32c3-20261026-01')]:
 p=root/'.build'/stem; report=json.loads((p/'report.json').read_bytes())
 assert report['completed'] and report['passed'] and report['target_executed'] and report['numerical_qualified']
 assert report['error_type']=='TypeError' and 'multiple values' in report['error']
 assert (p/'sources/controller.py').read_bytes()==before
 assert [r['name'] for r in report['commands']]==['sdk-head','sdk-clean','build','symbols','merge','qemu']
 for command in report['commands']:
  assert command['state']=='complete' and command['exit_status']==0
  for stream in ('stdout','stderr'):assert sha((p/(command['name']+'.'+stream+'.log')).read_bytes())==command[stream+'_sha256']
 assert json.loads((p/'cases.json').read_bytes())['cases']==cases
 assert (p/'cases.h').read_bytes()==subject.header(cases)
 for name,pin in report['inputs'].items():
  assert sha((p/pin['snapshot']).read_bytes())==pin['sha256']
  if name!=str(controller):assert sha(Path(name).read_bytes())==pin['sha256']
 observed=subject.validate_log((p/'qemu.stdout.log').read_text('utf-8',errors='replace')+'\n'+(p/'qemu.stderr.log').read_text('utf-8',errors='replace'),cases,originals,math,table,target,report['cases_sha256'])
 assert observed==json.loads((p/'measurement.json').read_bytes())
 assert {k:v for k,v in observed.items() if k!='rows'}==report['measurements']
 sdk=repo/('.idf/v6.0.2' if target=='esp32' else '.idf/v6.1-9a97f6c54ec6')
 git=Path(shutil.which('git.exe') or shutil.which('git'))
 assert run(target+'-sdk-head-after',[git,'-c','core.longpaths=true','-C',sdk,'rev-parse','HEAD']).strip()==subject.SDK_HEAD[target]
 assert not run(target+'-sdk-clean-after',[git,'-c','core.longpaths=true','-C',sdk,'status','--porcelain','--untracked-files=no']).strip()
 description=json.loads((p/'build/project_description.json').read_bytes());compiler=Path(description['c_compiler'])
 ninja_paths=re.findall(r'^CMAKE_MAKE_PROGRAM:FILEPATH=(.+)$',(p/'build/CMakeCache.txt').read_text(),re.M);assert len(ninja_paths)==1
 ninja=Path(ninja_paths[0].strip())
 run(target+'-compiler-version',[compiler,'--version']);run(target+'-compiler-machine',[compiler,'-dumpmachine'])
 deps=run(target+'-dependencies',[ninja,'-C',p/'build','-t','deps',*[x['output'] for x in report['compile_rows'].values()]])
 for source in (p/'project/main/main.c',p/'project/main/host-fixture.c',p/'project/main/cases.h',p/'sources/components/native_vorbis_floor1_product/floor1_product.c',p/'sources/components/native_vorbis_floor1_product/floor1_table.h',p/'sources/components/native_vorbis_floor1_product/include/native_vorbis_floor1_product.h'):
  assert str(source).replace('\\','/').casefold() in deps.replace('\\','/').casefold()
 actual_tools={}
 for alias,record in report['tools'].items():
  tool=Path(shutil.which(alias+'.exe')) if record['personal_path_redacted'] else Path(record['path'])
  assert sha(tool.read_bytes())==record['sha256'];actual_tools[alias]=dict(sha256=record['sha256'],personal_path_redacted=record['personal_path_redacted'])
 for alias,path in [('compiler',compiler),('ninja',ninja)]:actual_tools[alias]=dict(sha256=sha(path.read_bytes()))
 config=(p/'sdkconfig').read_text()
 watchdog={key:re.findall('^'+key+r'=(.+)$',config,re.M) for key in ('CONFIG_ESP_TASK_WDT_EN','CONFIG_ESP_TASK_WDT_INIT','CONFIG_ESP_TASK_WDT_TIMEOUT_S','CONFIG_ESP_TASK_WDT_CHECK_IDLE_TASK_CPU0','CONFIG_ESP_TASK_WDT_CHECK_IDLE_TASK_CPU1')}
 assert watchdog['CONFIG_ESP_TASK_WDT_EN']==['y'] and watchdog['CONFIG_ESP_TASK_WDT_INIT']==['y'] and watchdog['CONFIG_ESP_TASK_WDT_CHECK_IDLE_TASK_CPU0']==['y']
 if target=='esp32':assert watchdog['CONFIG_ESP_TASK_WDT_CHECK_IDLE_TASK_CPU1']==['y']
 summary=dict(completed=True,target=target,**report['measurements']);assert json.loads(json.dumps(summary))['passed'] is True
 result['profiles'][target]=dict(source_report_sha256=sha((p/'report.json').read_bytes()),measurement_sha256=sha((p/'measurement.json').read_bytes()),
  measurements=report['measurements'],actual_tool_hashes_verified=actual_tools,watchdog=watchdog,
  original_controller_cli_exit=1,actual_native_children_exit=0,pure_replay_passed=True,summary_regression_passed=True)
 save()
assert result['profiles']['esp32']['measurements']['exact_limb_sha256']==result['profiles']['esp32c3']['measurements']['exact_limb_sha256']
result['passed']=True;save()
print(json.dumps({'passed':True,'profiles':{k:v['measurements'] for k,v in result['profiles'].items()},'original_controller_cli_exit':1,'summary_only_fixed':True,'commands_terminal0':len(result['commands'])}))
