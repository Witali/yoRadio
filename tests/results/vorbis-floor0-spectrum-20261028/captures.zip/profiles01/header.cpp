#include "native_vorbis_floor0_spectrum.h"
extern "C" auto floor0_prepare_probe() -> decltype(&native_vorbis_frame_floor0_prepare) { return &native_vorbis_frame_floor0_prepare; }
extern "C" auto floor0_materialize_probe() -> decltype(&native_vorbis_frame_floor0_materialize) { return &native_vorbis_frame_floor0_materialize; }
