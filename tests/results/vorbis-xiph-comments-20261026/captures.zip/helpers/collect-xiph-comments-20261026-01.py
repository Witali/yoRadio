"""Collect independent metadata API evidence without decoder qualification."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'tests/results/vorbis-xiph-comments-20261026'
assert not OUT.exists();OUT.mkdir(parents=True);bodies={}
def add(path,name):
    assert path.resolve().is_relative_to(ROOT)and path.is_file()
    body=path.read_bytes();assert name not in bodies or bodies[name]==body;bodies[name]=body
def tree(folder,prefix):
    base=ROOT/folder
    for path in sorted(base.rglob('*')):
        if path.is_file():add(path,prefix+'/'+path.relative_to(base).as_posix())
for folder,prefix in(
    ('.build/vorbis-xiph-comments-host-20261026-01','host-first'),
    ('.build/vorbis-xiph-comments-host-20261026-02','host'),
    ('.build/vorbis-xiph-comments-baseline-20261026-01','baseline'),
    ('.build/vorbis-xiph-comments-validation-20261026-01','receipts'),
    ('.build/vorbis-xiph-comments-lint-20261026-01','lint')):tree(folder,prefix)
folder='.build/vorbis-xiph-comments-esp32-20261026-01';base=ROOT/folder
native=json.loads((base/'report.json').read_text())
assert native['completed']and native['metadata_qualified']and not native['decoder_executed']and not native['dsp_gate_qualified']
for path in base.iterdir():
    if path.is_file():add(path,'native/'+path.name)
for sub in('sources','project'):tree(folder+'/'+sub,'native/'+sub)
for name,digest in native['build_outputs'].items():
    path=base/name;assert hashlib.sha256(path.read_bytes()).hexdigest()==digest;add(path,'native/'+name)
for name in('cyd-vorbis-format-command-01.py','extend-xiph-comments-20261026-01.py',
             'witness-xiph-comments-20261026-01.py','lint-xiph-comments-20261026-01.py',
             'prepare-xiph-comments-publication-20261026-01.py','collect-xiph-comments-20261026-01.py'):
    add(ROOT/'.build'/name,'helpers/'+name)
for name in('test-vorbis-xiph-comments.py','run-vorbis-xiph-comments-qemu.py',
             'test-vorbis-xiph-port-generation.py','verify-vorbis-xiph-comments-checkpoint.py'):
    add(ROOT/'tests'/name,'sources/tests/'+name)
manifest={'schema':'vorbis-xiph-comments-checkpoint-v1','files':{n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}for n,b in sorted(bodies.items())}}
raw=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(OUT/'captures.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as archive:
    for name,body in sorted(bodies.items()):archive.writestr(name,body)
    archive.writestr('manifest.json',raw)
record={'sha256':hashlib.sha256((OUT/'captures.zip').read_bytes()).hexdigest(),'bytes':(OUT/'captures.zip').stat().st_size,'members':len(bodies)+1,'manifest_sha256':hashlib.sha256(raw).hexdigest()}
(OUT/'archive.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record))
