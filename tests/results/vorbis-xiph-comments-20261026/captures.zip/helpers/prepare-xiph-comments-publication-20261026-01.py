from pathlib import Path
ROOT=Path(__file__).resolve().parent
text=(ROOT/'lint-xiph-headers-20261026-01.py').read_text().replace('vorbis-xiph-headers','vorbis-xiph-comments').replace('==29','==25').replace('29 actual','25 actual')
path=ROOT/'lint-xiph-comments-20261026-01.py';assert not path.exists()
compile(text,str(path),'exec');path.write_text(text,encoding='utf-8',newline='\n')
