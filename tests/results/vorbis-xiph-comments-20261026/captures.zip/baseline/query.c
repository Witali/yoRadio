#include <assert.h>
#include "vorbis/codec.h"
#include "vorbis_xiph_alloc.h"
int main(void){
  vorbis_comment value;vorbis_comment_init(&value);xiph_port_test_reset(0);
  vorbis_comment_add_tag(&value,"TITLE","metadata");assert(value.comments==1);
  xiph_port_test_reset(1);
  int count=vorbis_comment_query_count(&value,"title");
  assert(count==1 && xiph_port_test_attempts()==0);
  vorbis_comment_clear(&value);return 0;
}
