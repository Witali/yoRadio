#include "audio_service.h"
#include "audio_completion.h"
#include "decoder_pcm.h"
#include "decoder_resources.h"
#include "decoder_registration.h"

#include <stdatomic.h>
#include <stdlib.h>
#include <string.h>

#include "audio_level_led.h"
#include "native_aac_decoder.h"
#include "board_config.h"
#include "esp_audio_dec_default.h"
#include "esp_audio_simple_dec.h"
#include "esp_audio_simple_dec_default.h"
#include "esp_check.h"
#include "esp_crt_bundle.h"
#include "esp_http_client.h"
#include "stream_http_reader.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#ifdef YORADIO_CODEC_BENCHMARK
#include "esp_partition.h"
#endif
#include "esp_timer.h"
#include "freertos/queue.h"
#include "freertos/ringbuf.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#ifdef CONFIG_YORADIO_FLAC_DECODER_CUSTOM
#include "custom_flac_adapter.h"
#endif
#if defined(CONFIG_YORADIO_AAC_DECODER_HELIX) || \
    defined(CONFIG_YORADIO_MP3_DECODER_HELIX) || \
    defined(CONFIG_YORADIO_MP3_DECODER_MINIMP3)
#define YORADIO_CUSTOM_LEGACY_DECODER 1
#include "custom_legacy_adapter.h"
#endif
#include "native_audio_output.h"
#include "pipeline_profile.h"
#ifdef CONFIG_YORADIO_PIPELINE_PROFILE
#include "native_i2s_generator.h"
#endif
#include "rx_buffer_diagnostic.h"
#include "heap_fragment_probe.h"
#include "icy_title.h"
#include "network_service.h"

#include "runtime_settings.h"
#define STREAM_CHUNK_SIZE 2048
#define STREAM_READ_TIMEOUT_MS 250
#define PCM_RING_SIZE (8 * 1024)
#ifdef CONFIG_YORADIO_DIRECT_DMA_PCM
// Three 512-frame stereo packets, including lease/ring headers, fit in the
// unchanged 8 KiB queue. Larger packets can block the producer during prefill.
#define PCM_PACKET_DATA_SIZE 2048
#else
#define PCM_PACKET_DATA_SIZE 3584
#endif
#define MAX_HTTP_REDIRECTS 5
#define DECODE_STATS_INTERVAL_US 5000000LL
#define BITRATE_UPDATE_INTERVAL_US 1000000LL
#define STREAM_BITRATE_INTERVAL_US 5000000LL
#define STREAM_RETRY_INITIAL_MS 1000U
#define STREAM_RETRY_MAX_MS 30000U
#define STREAM_RETRY_POLL_MS 100U
enum {
    AUDIO_STREAM_PRIORITY = 5,
    AUDIO_DECODE_PRIORITY = 7,
#ifdef CONFIG_YORADIO_OUTPUT_TASK_FIRST
    AUDIO_OUTPUT_PRIORITY = AUDIO_DECODE_PRIORITY + 1,
#else
    AUDIO_OUTPUT_PRIORITY = AUDIO_DECODE_PRIORITY - 1,
#endif
};
#ifdef YORADIO_CODEC_BENCHMARK
#define CODEC_FIXTURE_MAGIC 0x59434658UL
#endif

typedef struct {
    uint32_t generation;
    native_codec_t requested_codec;
#ifdef YORADIO_CODEC_BENCHMARK
    uint32_t fixture_size;
#endif
    char url[512];
} play_command_t;

// Owned by stream_task. Reuse its current command/URL between attempts;
// retain no HTTP/TLS allocation while waiting.
typedef struct {
    int64_t due_us;
    int64_t deadline_us;
    uint32_t delay_ms;
    bool pending;
    uint8_t timeout_sec;
} stream_retry_t;

typedef struct {
    uint32_t generation;
    native_codec_t codec;
    uint16_t data_size;
    uint8_t end_of_stream;
    uint8_t data[];
} encoded_packet_t;

typedef struct {
    uint32_t generation;
    uint32_t sample_rate;
    uint8_t bits_per_sample;
    uint8_t channels;
    uint16_t data_size;
    uint32_t end_of_stream; // Keep the following PCM payload word-aligned.
#ifdef CONFIG_YORADIO_DIRECT_DMA_PCM
    native_audio_pcm_lease_t lease;
#endif
    uint8_t data[];
} pcm_packet_t;

typedef struct {
    uint32_t generation;
    native_codec_t codec;
    int64_t window_started_us;
    uint64_t decode_us;
    uint64_t audio_us;
    uint32_t calls;
    uint32_t max_call_us;
    uint32_t input_bytes;
    uint32_t pcm_bytes;
#ifdef CONFIG_YORADIO_PIPELINE_PROFILE
    pipeline_wait_t input_empty, pcm_full;
#endif
} decode_stats_t;

typedef struct {
    int64_t started_us;
    uint64_t audio_bytes;
} stream_bitrate_meter_t;

#ifdef YORADIO_CODEC_BENCHMARK
typedef struct {
    uint32_t magic;
    uint32_t codec;
    uint32_t size;
    uint32_t reserved;
} codec_fixture_header_t;

static esp_err_t benchmark_autostart(void);
#endif

static const char *const TAG = "audio";
static native_state_t *s_state;
static QueueHandle_t s_commands;
static RingbufHandle_t s_encoded;
static RingbufHandle_t s_pcm;
static size_t s_encoded_usable_size;
static atomic_uint s_generation;
static atomic_uint s_decoder_target_codec;
static atomic_uint s_decoder_released_generation;
static portMUX_TYPE s_generation_lock = portMUX_INITIALIZER_UNLOCKED;
static char s_last_url[sizeof(((play_command_t *)0)->url)];
static native_codec_t s_last_codec;
// Decoder callbacks run only in decoder_task. These fields rate-limit VBR
// updates without requiring another lock on the single-core C3.
static uint32_t s_published_bitrate_bps;
static int64_t s_bitrate_updated_us;
static atomic_bool s_measured_bitrate_ready;
// One stream task owns the bounded incremental metadata parser.
static icy_title_parser_t s_icy_title;
_Static_assert(ICY_TITLE_CAPACITY == sizeof(((native_state_t *)0)->title),
               "ICY parsing must preserve the full published title capacity");
static void log_runtime_memory(const char *stage);

static void dispose_http_client(esp_http_client_handle_t client) {
    if (!client) return;
    esp_http_client_close(client);
    esp_http_client_cleanup(client);
}

static native_codec_t codec_from_content_type(const char *content_type) {
    if (!content_type) return NATIVE_CODEC_AUTO;
    if (strstr(content_type, "mpeg") || strstr(content_type, "mp3")) {
        return NATIVE_CODEC_MP3;
    }
    if (strstr(content_type, "aac") || strstr(content_type, "aacp")) {
        return NATIVE_CODEC_AAC;
    }
    if (strstr(content_type, "flac")) return NATIVE_CODEC_FLAC;
    if (strstr(content_type, "ogg") || strstr(content_type, "opus")) {
        return NATIVE_CODEC_OGG;
    }
    return NATIVE_CODEC_AUTO;
}

static bool codec_uses_custom_legacy(native_codec_t codec) {
#ifdef CONFIG_YORADIO_AAC_DECODER_HELIX
    if (codec == NATIVE_CODEC_AAC) return true;
#endif
#if defined(CONFIG_YORADIO_MP3_DECODER_HELIX) || \
    defined(CONFIG_YORADIO_MP3_DECODER_MINIMP3)
    if (codec == NATIVE_CODEC_MP3) return true;
#endif
    return false;
}

static uint32_t advance_generation(native_codec_t target_codec) {
    portENTER_CRITICAL(&s_generation_lock);
    uint32_t generation = atomic_load(&s_generation) + 1U;
    // Publish the target first. Once the decoder observes the new generation,
    // it can release an incompatible arena before the stream allocates TLS.
    atomic_store(&s_decoder_target_codec, (unsigned)target_codec);
    atomic_store(&s_generation, generation);
    portEXIT_CRITICAL(&s_generation_lock);
    native_state_begin_stream(s_state, generation);
    return generation;
}

static native_codec_t codec_from_signature(const uint8_t *data, size_t size) {
    if (size >= 4 && memcmp(data, "fLaC", 4) == 0) return NATIVE_CODEC_FLAC;
    if (size >= 4 && memcmp(data, "OggS", 4) == 0) return NATIVE_CODEC_OGG;
    if (size >= 3 && memcmp(data, "ID3", 3) == 0) return NATIVE_CODEC_MP3;
    if (size >= 2 && data[0] == 0xff && (data[1] & 0xf6) == 0xf0) {
        return NATIVE_CODEC_AAC;
    }
    if (size >= 2 && data[0] == 0xff && (data[1] & 0xe0) == 0xe0) {
        return NATIVE_CODEC_MP3;
    }
    return NATIVE_CODEC_MP3;
}

static esp_audio_simple_dec_type_t simple_decoder_type(native_codec_t codec) {
    switch (codec) {
        case NATIVE_CODEC_AAC:
            return ESP_AUDIO_SIMPLE_DEC_TYPE_AAC;
        case NATIVE_CODEC_FLAC:
            return ESP_AUDIO_SIMPLE_DEC_TYPE_FLAC;
        case NATIVE_CODEC_OGG:
            return ESP_AUDIO_SIMPLE_DEC_TYPE_OGG;
        case NATIVE_CODEC_MP3:
        default:
            return ESP_AUDIO_SIMPLE_DEC_TYPE_MP3;
    }
}

static const char *codec_name(native_codec_t codec) {
    switch (codec) {
        case NATIVE_CODEC_AAC: return "AAC";
        case NATIVE_CODEC_FLAC: return "FLAC";
        case NATIVE_CODEC_OGG: return "OGG";
        case NATIVE_CODEC_MP3: return "MP3";
        default: return "auto";
    }
}

#ifdef YORADIO_CODEC_BENCHMARK
static void benchmark_log_memory(const char *stage, native_codec_t codec,
                                 size_t heap_before, size_t codec_payload) {
    size_t heap_now = heap_caps_get_free_size(MALLOC_CAP_8BIT);
    size_t heap_delta = heap_before > heap_now ? heap_before - heap_now : 0;
    ESP_LOGI(TAG,
             "MEM %s %s: heap_before %u, heap_now %u, heap_delta %u, "
             "largest %u, minimum %u, codec_payload %u",
             codec_name(codec), stage, (unsigned)heap_before,
             (unsigned)heap_now, (unsigned)heap_delta,
             (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_8BIT),
             (unsigned)heap_caps_get_minimum_free_size(MALLOC_CAP_8BIT),
             (unsigned)codec_payload);
}
#endif

static void decode_stats_reset(decode_stats_t *stats, uint32_t generation,
                               native_codec_t codec, int64_t now_us) {
    *stats = (decode_stats_t){
        .generation = generation,
        .codec = codec,
        .window_started_us = now_us,
    };
}

static void decode_stats_add_audio(decode_stats_t *stats,
                                   const esp_audio_simple_dec_info_t *info,
                                   size_t pcm_bytes) {
    size_t sample_bytes = (info->bits_per_sample + 7U) / 8U;
    size_t frame_bytes = sample_bytes * info->channel;
    if (!frame_bytes || !info->sample_rate) return;
    uint64_t frames = pcm_bytes / frame_bytes;
    stats->audio_us += frames * 1000000ULL / info->sample_rate;
    stats->pcm_bytes += (uint32_t)pcm_bytes;
}

static void decode_stats_report(decode_stats_t *stats, int64_t now_us) {
    int64_t window_us = now_us - stats->window_started_us;
    if (window_us < DECODE_STATS_INTERVAL_US || !stats->calls) return;

    uint32_t load_tenths = stats->audio_us
                               ? (uint32_t)(stats->decode_us * 1000ULL /
                                            stats->audio_us)
                               : 0;
    uint32_t speed_hundredths = stats->decode_us
                                    ? (uint32_t)(stats->audio_us * 100ULL /
                                                 stats->decode_us)
                                    : 0;
    ESP_LOGI(TAG,
             "PERF %s: window %llu ms, audio %llu ms, decode %llu ms "
             "(%lu.%lu%%, x%lu.%02lu), calls %lu, max %lu us, in %lu, "
             "pcm %lu",
             codec_name(stats->codec),
             (unsigned long long)(window_us / 1000),
             (unsigned long long)(stats->audio_us / 1000),
             (unsigned long long)(stats->decode_us / 1000),
             (unsigned long)(load_tenths / 10U),
             (unsigned long)(load_tenths % 10U),
             (unsigned long)(speed_hundredths / 100U),
             (unsigned long)(speed_hundredths % 100U),
             (unsigned long)stats->calls,
             (unsigned long)stats->max_call_us,
             (unsigned long)stats->input_bytes,
             (unsigned long)stats->pcm_bytes);
#ifdef CONFIG_YORADIO_PIPELINE_PROFILE
    ESP_LOGI(TAG,
        "PERF FLOW_DEC: gen=%lu codec=%s window_us=%llu "
        "input_us=%llu input_n=%lu input_timeouts=%lu input_max=%lu "
        "pcm_us=%llu pcm_n=%lu pcm_timeouts=%lu pcm_max=%lu",
        (unsigned long)stats->generation, codec_name(stats->codec),
        (unsigned long long)window_us,
        (unsigned long long)stats->input_empty.us,
        (unsigned long)stats->input_empty.count,
        (unsigned long)stats->input_empty.timeouts,
        (unsigned long)stats->input_empty.max_us,
        (unsigned long long)stats->pcm_full.us,
        (unsigned long)stats->pcm_full.count,
        (unsigned long)stats->pcm_full.timeouts,
        (unsigned long)stats->pcm_full.max_us);
#endif
    decode_stats_reset(stats, stats->generation, stats->codec, now_us);
}

static void state_set_audio(uint32_t generation, bool running,
                             const char *format) {
    native_state_set_audio(s_state, generation, running, format);
}

static bool http_status_is_redirect(int status) {
    return status == 301 || status == 302 || status == 303 || status == 307 ||
           status == 308;
}

static bool retryable_transport_error(esp_err_t result) {
    return result == ESP_ERR_HTTP_CONNECT ||
           result == ESP_ERR_HTTP_WRITE_DATA ||
           result == ESP_ERR_HTTP_EAGAIN || result == ESP_ERR_TIMEOUT;
}

static bool retryable_http_status(int status) {
    // Request timeout, rate limit and server errors can be temporary. Client
    // errors (including authentication/not-found) require a corrected request.
    return status == 408 || status == 429 || (status >= 500 && status <= 599);
}

static int connection_remaining_ms(int64_t deadline_us) {
    int64_t remaining_us = deadline_us - esp_timer_get_time();
    return remaining_us > 0 ? (int)((remaining_us + 999) / 1000) : 0;
}

static esp_err_t open_stream(esp_http_client_handle_t client,
                             const char *requested_url, int64_t deadline_us,
                             bool *retryable) {
    *retryable = false;
    for (unsigned redirect = 0; redirect <= MAX_HTTP_REDIRECTS; ++redirect) {
        int remaining_ms = connection_remaining_ms(deadline_us);
        if (!remaining_ms) return ESP_ERR_TIMEOUT;
        esp_http_client_set_timeout_ms(client, remaining_ms);
        ESP_LOGI(TAG, "Opening stream%s: %s",
                 redirect ? " after redirect" : "", requested_url);
        esp_err_t result = esp_http_client_open(client, 0);
        if (result != ESP_OK) {
            *retryable = retryable_transport_error(result);
            ESP_LOGE(TAG, "Stream transport open failed: %s (errno %d)",
                     esp_err_to_name(result), esp_http_client_get_errno(client));
            return result;
        }

        remaining_ms = connection_remaining_ms(deadline_us);
        if (!remaining_ms) return ESP_ERR_TIMEOUT;
        esp_http_client_set_timeout_ms(client, remaining_ms);
        int64_t headers = esp_http_client_fetch_headers(client);
        if (!connection_remaining_ms(deadline_us)) return ESP_ERR_TIMEOUT;
        int status = esp_http_client_get_status_code(client);
        if (headers < 0) {
            *retryable = true;
            ESP_LOGE(TAG,
                     "Stream response headers failed: status %d, errno %d",
                     status, esp_http_client_get_errno(client));
            esp_http_client_close(client);
            return ESP_ERR_HTTP_FETCH_HEADER;
        }
        ESP_LOGI(TAG, "Stream response: HTTP %d, length %lld", status,
                 (long long)headers);

        if (status >= 200 && status < 300) return ESP_OK;
        if (!http_status_is_redirect(status) || redirect == MAX_HTTP_REDIRECTS) {
            *retryable = retryable_http_status(status);
            esp_http_client_close(client);
            return http_status_is_redirect(status) ? ESP_ERR_HTTP_MAX_REDIRECT
                                                   : ESP_FAIL;
        }
        result = esp_http_client_set_redirection(client);
        esp_http_client_close(client);
        if (result != ESP_OK) {
            ESP_LOGE(TAG, "Stream redirect failed: %s",
                     esp_err_to_name(result));
            return result;
        }
    }
    return ESP_ERR_HTTP_MAX_REDIRECT;
}

static bool send_encoded(uint32_t generation, native_codec_t codec,
                         const uint8_t *data, size_t size, uint8_t eos) {
    size_t packet_size = sizeof(encoded_packet_t) + size;
    encoded_packet_t *packet = NULL;
    while (xRingbufferSendAcquire(s_encoded, (void **)&packet, packet_size,
                                  pdMS_TO_TICKS(250)) != pdTRUE) {
        // A slow decoder must apply TCP backpressure, not terminate the
        // station. Short waits still let a station change cancel promptly.
        if (atomic_load(&s_generation) != generation) return false;
    }
    packet->generation = generation;
    packet->codec = codec;
    packet->data_size = (uint16_t)size;
    packet->end_of_stream = eos;
    if (size) memcpy(packet->data, data, size);
    return xRingbufferSendComplete(s_encoded, packet) == pdTRUE;
}

static bool send_stream_audio(uint32_t generation, native_codec_t *codec,
                              const uint8_t *data, size_t size,
                              bool *first_chunk) {
    if (*first_chunk) {
        *first_chunk = false;
        if (*codec == NATIVE_CODEC_AUTO) {
            *codec = codec_from_signature(data, size);
        }
        state_set_audio(generation, true, codec_name(*codec));
    }
    return send_encoded(generation, *codec, data, size, false);
}

static void stream_bitrate_add(uint32_t generation,
                               stream_bitrate_meter_t *meter,
                               size_t audio_bytes) {
    if (!meter || !audio_bytes) return;
    int64_t now_us = esp_timer_get_time();
    if (!meter->started_us) meter->started_us = now_us;
    meter->audio_bytes += audio_bytes;
    int64_t elapsed_us = now_us - meter->started_us;
    if (elapsed_us < STREAM_BITRATE_INTERVAL_US) return;

    uint64_t bitrate = meter->audio_bytes * 8000000ULL /
                       (uint64_t)elapsed_us;
    if (bitrate && bitrate <= UINT32_MAX &&
        generation == atomic_load(&s_generation)) {
        atomic_store(&s_measured_bitrate_ready, true);
        native_state_set_bitrate(s_state, generation,
                                 ((uint32_t)bitrate + 500U) / 1000U);
        ESP_LOGI(TAG, "Measured stream bitrate: %llu bit/s",
                 (unsigned long long)bitrate);
    }
    meter->started_us = now_us;
    meter->audio_bytes = 0;
}

static void reset_decoder_bitrate_tracking(void) {
    s_published_bitrate_bps = 0;
    s_bitrate_updated_us = 0;
}

static void state_set_decoder_bitrate(uint32_t generation, uint32_t bitrate_bps) {
    if (!bitrate_bps || atomic_load(&s_measured_bitrate_ready)) return;
    if (bitrate_bps == s_published_bitrate_bps) return;
    int64_t now_us = esp_timer_get_time();
    if (s_bitrate_updated_us &&
        now_us - s_bitrate_updated_us < BITRATE_UPDATE_INTERVAL_US) {
        return;
    }
    s_published_bitrate_bps = bitrate_bps;
    s_bitrate_updated_us = now_us;
    native_state_set_bitrate(s_state, generation, (bitrate_bps + 500U) / 1000U);
    ESP_LOGI(TAG, "Decoder bitrate: %lu bit/s",
             (unsigned long)bitrate_bps);
}

static void publish_icy_title(uint32_t generation, const char *title) {
    if (!title) return;
    if (generation != atomic_load(&s_generation)) return;
    native_state_set_title(s_state, title);
    // A stop or station change can race the title publication between the
    // generation check and the state lock. Remove that last stale update too.
    if (generation != atomic_load(&s_generation)) {
        native_state_set_title(s_state, "");
        return;
    }
    ESP_LOGI(TAG, "Stream title: %s", title);
}

#ifdef YORADIO_CODEC_BENCHMARK
static void play_flash_fixture(const play_command_t *command,
                               uint8_t *buffer) {
    const esp_partition_t *partition = esp_partition_find_first(
        ESP_PARTITION_TYPE_DATA, (esp_partition_subtype_t)0x40,
        "codec_test");
    if (!partition || !command->fixture_size ||
        command->fixture_size > partition->size) {
        ESP_LOGE(TAG, "Invalid codec fixture size %lu",
                 (unsigned long)command->fixture_size);
        state_set_audio(command->generation, false, "invalid flash fixture");
        return;
    }

    ESP_LOGI(TAG, "Reading %lu-byte %s fixture from codec_test flash",
             (unsigned long)command->fixture_size,
             codec_name(command->requested_codec));
    native_codec_t codec = command->requested_codec;
    bool first_chunk = true;
    uint32_t offset = 0;
    while (offset < command->fixture_size &&
           atomic_load(&s_generation) == command->generation) {
        size_t chunk = command->fixture_size - offset;
        if (chunk > STREAM_CHUNK_SIZE) chunk = STREAM_CHUNK_SIZE;
        esp_err_t result = esp_partition_read(
            partition, sizeof(codec_fixture_header_t) + offset, buffer, chunk);
        if (result != ESP_OK) {
            ESP_LOGE(TAG, "Codec fixture read failed at %lu: %s",
                     (unsigned long)offset, esp_err_to_name(result));
            state_set_audio(command->generation, false, "flash read failed");
            break;
        }
        if (!send_stream_audio(command->generation, &codec, buffer, chunk,
                               &first_chunk)) {
            ESP_LOGW(TAG, "Compressed codec fixture buffer stalled");
            break;
        }
        offset += (uint32_t)chunk;
    }
    send_encoded(command->generation, codec, NULL, 0, AUDIO_END_EOF);
    ESP_LOGI(TAG, "Codec fixture complete: %lu/%lu bytes",
             (unsigned long)offset, (unsigned long)command->fixture_size);
}
#endif

static void begin_stream_deadline(stream_retry_t *retry) {
    uint8_t timeout_sec = runtime_settings_get_station_timeout_sec();
    *retry = (stream_retry_t){
        .deadline_us = esp_timer_get_time() +
            (int64_t)timeout_sec * 1000000,
        .timeout_sec = timeout_sec,
    };
}

static void station_unavailable(uint32_t generation) {
    if (generation != atomic_load(&s_generation)) return;
    state_set_audio(generation, false, AUDIO_STATUS_STATION_UNAVAILABLE);
    network_service_set_streaming(false);
}

static void schedule_stream_retry(stream_retry_t *retry, uint32_t generation) {
    if (generation != atomic_load(&s_generation) ||
        !runtime_settings_get_watchdog()) return;
    if (!connection_remaining_ms(retry->deadline_us)) {
        station_unavailable(generation);
        return;
    }
    uint32_t delay_ms = retry->delay_ms ? retry->delay_ms * 2U
                                      : STREAM_RETRY_INITIAL_MS;
    if (delay_ms > STREAM_RETRY_MAX_MS) delay_ms = STREAM_RETRY_MAX_MS;
    retry->delay_ms = delay_ms;
    retry->due_us = esp_timer_get_time() + (int64_t)delay_ms * 1000;
    if (retry->due_us > retry->deadline_us) retry->due_us = retry->deadline_us;
    retry->pending = true;
    ESP_LOGW(TAG, "Retry stream connection in %lu ms", (unsigned long)delay_ms);
}

static void receive_stream_command(play_command_t *command,
                                   stream_retry_t *retry) {
    for (;;) {
        if (!retry->pending) {
            xQueueReceive(s_commands, command, portMAX_DELAY);
            begin_stream_deadline(retry);
            return;
        }
        if (command->generation != atomic_load(&s_generation) ||
            !runtime_settings_get_watchdog()) {
            *retry = (stream_retry_t){0};
            continue;
        }
        int64_t remaining_us = retry->due_us - esp_timer_get_time();
        if (remaining_us <= 0) {
            retry->pending = false;
            if (!connection_remaining_ms(retry->deadline_us)) {
                station_unavailable(command->generation);
                continue;
            }
            return;
        }
        uint32_t wait_ms = (uint32_t)((remaining_us + 999) / 1000);
        if (wait_ms > STREAM_RETRY_POLL_MS) wait_ms = STREAM_RETRY_POLL_MS;
        // A new Play wakes the queue immediately. Stop/watchdog changes have
        // no queue item, so check them at bounded intervals while backing off.
        if (xQueueReceive(s_commands, command, pdMS_TO_TICKS(wait_ms)) == pdTRUE) {
            begin_stream_deadline(retry);
            return;
        }
    }
}

static void stream_task(void *argument) {
    (void)argument;
    uint8_t *buffer = malloc(STREAM_CHUNK_SIZE);
    if (!buffer) {
        ESP_LOGE(TAG, "No memory for stream input buffer");
        vTaskDelete(NULL);
    }
    play_command_t command;
    stream_retry_t retry = {0};
    while (true) {
        receive_stream_command(&command, &retry);
#ifdef YORADIO_CODEC_BENCHMARK
        if (command.fixture_size) {
            play_flash_fixture(&command, buffer);
            continue;
        }
#endif

        // A decoder can retain considerably more RAM than a TLS session.
        // Wait until the decoder task has released the previous station before
        // allocating the next HTTP/TLS transport.
        while (atomic_load(&s_generation) == command.generation &&
               atomic_load(&s_decoder_released_generation) !=
                   command.generation &&
               connection_remaining_ms(retry.deadline_us)) {
            vTaskDelay(pdMS_TO_TICKS(1));
        }
        if (atomic_load(&s_generation) != command.generation) continue;
        if (!connection_remaining_ms(retry.deadline_us)) {
            station_unavailable(command.generation);
            continue;
        }

        network_service_set_streaming(true);
        state_set_audio(command.generation, false, "connecting");

        esp_http_client_config_t config = {
            .url = command.url,
            .timeout_ms = connection_remaining_ms(retry.deadline_us),
            .buffer_size = STREAM_CHUNK_SIZE,
            .buffer_size_tx = 4096,
            .crt_bundle_attach = esp_crt_bundle_attach,
            .disable_auto_redirect = false,
            .max_redirection_count = MAX_HTTP_REDIRECTS,
            .keep_alive_enable = true,
            .user_agent = "yoRadio-native/1",
        };
        esp_http_client_handle_t client = esp_http_client_init(&config);
        if (!client) {
            if (atomic_load(&s_generation) == command.generation) {
                state_set_audio(command.generation, false, "HTTP allocation failed");
                network_service_set_streaming(false);
            }
            continue;
        }
        esp_http_client_set_header(client, "Icy-MetaData", "1");
        // One response per connection (RFC 9112 section 9.3). TCP keepalive
        // probes above are independent of HTTP connection reuse.
        esp_http_client_set_header(client, "Connection", "close");
        bool retryable;
        esp_err_t result = open_stream(client, command.url, retry.deadline_us,
                                       &retryable);
        if (result != ESP_OK) {
            ESP_LOGE(TAG, "Stream connection failed for %s: %s", command.url,
                     esp_err_to_name(result));
            if (atomic_load(&s_generation) == command.generation) {
                state_set_audio(command.generation, false, "connection failed");
                network_service_set_streaming(false);
            }
            dispose_http_client(client);
            if (retryable) schedule_stream_retry(&retry, command.generation);
            if (!retry.pending) station_unavailable(command.generation);
            continue;
        }
        const int64_t availability_timeout_us = (int64_t)retry.timeout_sec * 1000000;
        retry = (stream_retry_t){0};
        if (strncmp(command.url, "https://", 8) == 0) {
            log_runtime_memory("after TLS handshake");
        }
        // Keep the long timeout for TCP/TLS setup, then poll the stream often
        // enough that Stop can be handled without closing an HTTP client from
        // a different task (esp_http_client handles are not thread-safe).
        esp_http_client_set_timeout_ms(client, STREAM_READ_TIMEOUT_MS);
        if (atomic_load(&s_generation) != command.generation) {
            dispose_http_client(client);
            continue;
        }
        // Match the original yoRadio player state: a successfully opened
        // HTTP/ICY stream is playing even before its first PCM frame arrives.
        state_set_audio(command.generation, true, "connected");
        native_codec_t codec = command.requested_codec;
        if (codec == NATIVE_CODEC_AUTO) {
            char *content_type = NULL;
            if (esp_http_client_get_response_header(
                    client, "Content-Type", &content_type) == ESP_OK) {
                codec = codec_from_content_type(content_type);
            }
        }
        size_t metadata_interval = 0;
        char *metadata_interval_text = NULL;
        if (esp_http_client_get_response_header(
                client, "icy-metaint", &metadata_interval_text) == ESP_OK &&
            metadata_interval_text) {
            metadata_interval = strtoul(metadata_interval_text, NULL, 10);
            ESP_LOGI(TAG, "ICY metadata interval: %u",
                     (unsigned)metadata_interval);
        }
        char *icy_bitrate_text = NULL;
        if (esp_http_client_get_response_header(
                client, "icy-br", &icy_bitrate_text) == ESP_OK &&
            icy_bitrate_text) {
            unsigned long icy_bitrate =
                strtoul(icy_bitrate_text, NULL, 10);
            if (icy_bitrate > 0 && icy_bitrate <= UINT32_MAX) {
                native_state_set_bitrate(s_state, command.generation, (uint32_t)icy_bitrate);
                ESP_LOGI(TAG, "ICY bitrate: %lu kbit/s", icy_bitrate);
            }
        }
        size_t audio_until_metadata = metadata_interval;
        size_t metadata_remaining = 0;
        bool first_chunk = true;
        bool stream_stalled = false;
        bool stream_read_failed = false;
        bool stream_unavailable = false;
        int64_t last_stream_data_us = esp_timer_get_time();
        stream_bitrate_meter_t bitrate_meter = {
            .started_us = esp_timer_get_time(),
        };
        stream_http_reader_t reader = {0};
        while (atomic_load(&s_generation) == command.generation) {
            int received = stream_http_read(&reader, client, (char *)buffer,
                                            STREAM_CHUNK_SIZE);
            // Stop/station change may happen while the socket read is blocked.
            // Never pass data returned by that obsolete read to ICY or audio.
            if (atomic_load(&s_generation) != command.generation) break;
            if (received == -ESP_ERR_HTTP_EAGAIN) {
                if (runtime_settings_get_watchdog() &&
                    esp_timer_get_time() - last_stream_data_us >=
                        availability_timeout_us) {
                    stream_unavailable = true;
                    break;
                }
                continue;
            }
            if (received < 0) {
                log_runtime_memory("at stream read failure");
                ESP_LOGW(TAG, "Stream read failed");
                stream_read_failed = true;
                break;
            }
            if (received == 0) {
                if (esp_http_client_is_complete_data_received(client)) break;
                if (runtime_settings_get_watchdog() &&
                    esp_timer_get_time() - last_stream_data_us >=
                        availability_timeout_us) {
                    ESP_LOGW(TAG, "Stream watchdog timeout");
                    stream_unavailable = true;
                    break;
                }
                vTaskDelay(pdMS_TO_TICKS(10));
                continue;
            }
            size_t offset = 0;
            last_stream_data_us = esp_timer_get_time();
            while (offset < (size_t)received) {
                if (!metadata_interval) {
                    if (!send_stream_audio(command.generation, &codec,
                                           buffer + offset,
                                           (size_t)received - offset,
                                           &first_chunk)) {
                        stream_stalled = true;
                        break;
                    }
                    stream_bitrate_add(command.generation, &bitrate_meter,
                                       (size_t)received - offset);
                    offset = (size_t)received;
                } else if (audio_until_metadata) {
                    size_t available = (size_t)received - offset;
                    size_t chunk = available < audio_until_metadata
                                       ? available
                                       : audio_until_metadata;
                    if (!send_stream_audio(command.generation, &codec,
                                           buffer + offset, chunk,
                                           &first_chunk)) {
                        stream_stalled = true;
                        break;
                    }
                    stream_bitrate_add(command.generation, &bitrate_meter,
                                       chunk);
                    offset += chunk;
                    audio_until_metadata -= chunk;
                } else if (!metadata_remaining) {
                    metadata_remaining = (size_t)buffer[offset++] * ICY_METADATA_BLOCK_BYTES;
                    icy_title_begin(&s_icy_title);
                    if (!metadata_remaining) {
                        audio_until_metadata = metadata_interval;
                    }
                } else {
                    size_t available = (size_t)received - offset;
                    size_t chunk = available < metadata_remaining
                                       ? available
                                       : metadata_remaining;
                    icy_title_feed(&s_icy_title, buffer + offset, chunk);
                    metadata_remaining -= chunk;
                    offset += chunk;
                    if (!metadata_remaining) {
                        publish_icy_title(command.generation,
                                          icy_title_finish(&s_icy_title));
                        audio_until_metadata = metadata_interval;
                    }
                }
            }
            if (stream_stalled) {
                ESP_LOGW(TAG, "Compressed audio buffer stalled");
                break;
            }
        }
        uint8_t end_reason = stream_stalled ? AUDIO_END_BUFFER_STALLED
                             : stream_unavailable ? AUDIO_END_UNAVAILABLE
                             : stream_read_failed ? AUDIO_END_READ_FAILED
                                                  : AUDIO_END_EOF;
        send_encoded(command.generation, codec, NULL, 0, end_reason);
        dispose_http_client(client);
        if (atomic_load(&s_generation) == command.generation) {
            // The decoder still owns buffered input. Its last format callback
            // must precede the terminal state, including delayed HE-AAC PCM.
            // output_task publishes completion after the PCM queue drains.
            network_service_set_streaming(false);
        }
    }
}

static void log_runtime_memory(const char *stage) {
    ESP_LOGI(TAG,
             "Memory %s: free=%u largest=%u minimum=%u task_stack_hwm=%u",
             stage,
             (unsigned)heap_caps_get_free_size(MALLOC_CAP_8BIT),
             (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_8BIT),
             (unsigned)heap_caps_get_minimum_free_size(MALLOC_CAP_8BIT),
             (unsigned)uxTaskGetStackHighWaterMark(NULL));
}

static bool send_pcm(decode_stats_t *stats, uint32_t generation,
                     const esp_audio_simple_dec_info_t *info,
                     const uint8_t *data, size_t size) {
    (void)stats;
    size_t frame_bytes = (size_t)info->channel * info->bits_per_sample / 8U;
    if (!frame_bytes || frame_bytes > PCM_PACKET_DATA_SIZE ||
        size % frame_bytes) return false;
    while (size) {
        if (generation != atomic_load(&s_generation)) return false;
        size_t chunk = size > PCM_PACKET_DATA_SIZE ? PCM_PACKET_DATA_SIZE
                                                   : size;
        chunk -= chunk % frame_bytes;
        size_t packet_size = sizeof(pcm_packet_t) + chunk;
        pcm_packet_t *packet = NULL;
        while (pipeline_acquire(s_pcm, (void **)&packet, packet_size,
                                 pdMS_TO_TICKS(250), &stats->pcm_full) != pdTRUE) {
            if (atomic_load(&s_generation) != generation) return false;
        }
        packet->generation = generation;
        packet->sample_rate = info->sample_rate;
        packet->bits_per_sample = info->bits_per_sample;
        packet->channels = info->channel;
        packet->end_of_stream = AUDIO_CONTINUE;
        packet->data_size = (uint16_t)chunk;
        memcpy(packet->data, data, chunk);
        if (xRingbufferSendComplete(s_pcm, packet) != pdTRUE) return false;
        data += chunk;
        size -= chunk;
    }
    return true;
}

static bool send_pcm_end(uint32_t generation, uint8_t reason) {
    pcm_packet_t *packet = NULL;
    for (;;) {
        if (generation != atomic_load(&s_generation)) return false;
        if (xRingbufferSendAcquire(s_pcm, (void **)&packet, sizeof(*packet),
                                  pdMS_TO_TICKS(250)) == pdTRUE) break;
    }
    memset(packet, 0, sizeof(*packet));
    packet->generation = generation;
    packet->end_of_stream = reason;
    return xRingbufferSendComplete(s_pcm, packet) == pdTRUE;
}

static void return_decoded_packet(encoded_packet_t *packet,
                                  uint32_t failed_generation) {
    if (packet->end_of_stream && packet->generation != failed_generation) {
        send_pcm_end(packet->generation, packet->end_of_stream);
    }
    vRingbufferReturnItem(s_encoded, packet);
}

static void finish_pcm_stream(const pcm_packet_t *packet) {
    // native_state checks the generation under its lock: an old completion
    // cannot stop a new Play, even if that command raced this queue read.
    state_set_audio(packet->generation, false,
                    audio_completion_status(packet->end_of_stream));
}

static bool update_stream_info(uint32_t generation, const char *codec,
                                const esp_audio_simple_dec_info_t *latest,
                                esp_audio_simple_dec_info_t *current,
                                bool *ready, uint32_t source_rate,
                                uint8_t source_channels, bool core_channels,
                                bool format_is_pcm) {
    if (generation != atomic_load(&s_generation) || !latest->sample_rate ||
        !latest->channel || !latest->bits_per_sample) return false;
    *current = *latest;
    *ready = true;
    native_stream_info_t info = {
        .codec = codec,
        .sample_rate_hz = source_rate ? source_rate : latest->sample_rate,
        .channels = source_channels ? source_channels : latest->channel,
        .bits_per_sample = latest->bits_per_sample,
        .pcm_sample_rate_hz = latest->sample_rate,
        .pcm_channels = latest->channel,
        .channels_are_core = core_channels,
        .format_is_pcm = format_is_pcm,
    };
    native_state_set_stream_info(s_state, generation, &info);
    return true;
}

#ifdef CONFIG_YORADIO_FLAC_DECODER_CUSTOM
typedef struct {
    uint32_t generation;
    decode_stats_t *stats;
    esp_audio_simple_dec_info_t *stream_info;
    bool *stream_info_ready;
} custom_flac_output_context_t;

static bool custom_flac_output(void *user, const custom_flac_info_t *info,
                                 const uint8_t *pcm, size_t pcm_size) {
    custom_flac_output_context_t *context = user;
    const esp_audio_simple_dec_info_t latest = {
        .sample_rate = info->sample_rate,
        .bits_per_sample = info->bits_per_sample,
        .channel = info->channels,
        .bitrate = info->bitrate,
    };
    if (!update_stream_info(context->generation, "FLAC", &latest,
                            context->stream_info, context->stream_info_ready,
                            0, 0, false, false)) return false;
    state_set_decoder_bitrate(context->generation, info->bitrate);
    // Display source depth; size/time the callback's actual signed-16 PCM.
    esp_audio_simple_dec_info_t pcm_info = *context->stream_info;
    pcm_info.bits_per_sample = info->pcm_bits_per_sample;
    decode_stats_add_audio(context->stats, &pcm_info, pcm_size);
    return send_pcm(context->stats, context->generation, &pcm_info, pcm, pcm_size);
}
#endif

#ifdef YORADIO_CUSTOM_LEGACY_DECODER
typedef struct {
    uint32_t generation;
    decode_stats_t *stats;
    esp_audio_simple_dec_info_t *stream_info;
    bool *stream_info_ready;
} custom_legacy_output_context_t;

static bool custom_legacy_output(void *user, const custom_legacy_info_t *info,
                                 const uint8_t *pcm, size_t pcm_size) {
    custom_legacy_output_context_t *context = user;
    const esp_audio_simple_dec_info_t latest = {
        .sample_rate = info->sample_rate,
        .bits_per_sample = info->bits_per_sample,
        .channel = info->channels,
        .bitrate = info->bitrate,
    };
    const char *label = codec_name(context->stats->codec);
    if (context->stats->codec == NATIVE_CODEC_AAC) {
        if (info->aac_sbr) label = "HE-AAC";
        else if (info->aac_profile_known && info->aac_profile == 1)
            label = "AAC-LC";
    }
    if (!update_stream_info(context->generation, label, &latest,
                            context->stream_info, context->stream_info_ready,
                            info->stream_sample_rate, info->stream_channels,
                            info->channels_are_core, false)) return false;
    state_set_decoder_bitrate(context->generation, info->bitrate);
    decode_stats_add_audio(context->stats, context->stream_info, pcm_size);
    return send_pcm(context->stats, context->generation, context->stream_info, pcm, pcm_size);
}
#endif

static void decoder_task(void *argument) {
    (void)argument;
    esp_audio_err_t registration_result = decoder_register_codecs();
    uint8_t *output = NULL;
    size_t output_size = 0;
    esp_audio_simple_dec_handle_t decoder = NULL;
    native_aac_decoder_t *aac_decoder = NULL;
#ifdef CONFIG_YORADIO_FLAC_DECODER_CUSTOM
    custom_flac_decoder_t *flac_decoder = NULL;
#endif
#ifdef YORADIO_CUSTOM_LEGACY_DECODER
    custom_legacy_decoder_t *legacy_decoder = NULL;
#endif
    uint32_t generation = 0;
    uint32_t failed_generation = 0;
    native_codec_t codec = NATIVE_CODEC_AUTO;
    decode_stats_t stats = {0};
    esp_audio_simple_dec_info_t stream_info = {0};
    bool stream_info_ready = false;
    bool first_frame_memory_logged = false;
#ifdef YORADIO_CODEC_BENCHMARK
    size_t decoder_heap_before = 0;
    bool first_frame_memory_reported = false;
#endif

    while (true) {
        rx_buffer_diagnostic_poll();
        uint32_t current_generation = atomic_load(&s_generation);
        if (generation != current_generation) {
#ifdef YORADIO_CUSTOM_LEGACY_DECODER
            bool had_legacy_decoder = legacy_decoder != NULL;
#endif
            native_codec_t target_codec = (native_codec_t)atomic_load(
                &s_decoder_target_codec);
            if (decoder) esp_audio_simple_dec_close(decoder);
            decoder = NULL;
            native_aac_decoder_destroy(aac_decoder);
            aac_decoder = NULL;
#ifdef CONFIG_YORADIO_FLAC_DECODER_CUSTOM
            if (flac_decoder) custom_flac_decoder_destroy(flac_decoder);
            flac_decoder = NULL;
#endif
#ifdef YORADIO_CUSTOM_LEGACY_DECODER
            if (legacy_decoder) custom_legacy_decoder_destroy(legacy_decoder);
            legacy_decoder = NULL;
            // Keep the arena for another custom MP3/AAC decoder. Otherwise
            // return it before acknowledging release, so HTTP/TLS and the
            // official decoder never overlap the old custom workspace.
            if (had_legacy_decoder &&
                !codec_uses_custom_legacy(target_codec) &&
                !custom_legacy_decoder_discard_arena()) {
                ESP_LOGE(TAG, "Old codec arena is still in use");
                state_set_audio(generation, false, "DECODER BUSY");
            }
#endif
            // The simple decoder is already closed. Its reusable PCM buffer
            // is useful for another official decoder, but not for a custom
            // one. An unknown target is released conservatively.
            if (target_codec == NATIVE_CODEC_AUTO ||
                codec_uses_custom_legacy(target_codec)) {
                free(output);
                output = NULL;
                output_size = 0;
            }
            // Preserve the Espressif PCM workspace only when the next decoder
            // is explicitly known to be compatible. AUTO is released before
            // TLS because its type can be learned only from the stream.
            generation = current_generation;
            failed_generation = 0;
            codec = NATIVE_CODEC_AUTO;
            memset(&stream_info, 0, sizeof(stream_info));
            stream_info_ready = false;
            first_frame_memory_logged = false;
            atomic_store(&s_decoder_released_generation,
                         current_generation);
        }
        if (failed_generation && failed_generation == generation) {
            decoder_resources_release(&decoder, &aac_decoder, &output, &output_size);
        }
        size_t item_size = 0;
        heap_fragment_probe_poll(!decoder && !aac_decoder && !output
#ifdef CONFIG_YORADIO_FLAC_DECODER_CUSTOM
                                 && !flac_decoder
#endif
#ifdef YORADIO_CUSTOM_LEGACY_DECODER
                                 && !legacy_decoder
#endif
        );
        encoded_packet_t *packet = pipeline_receive(
            s_encoded, &item_size, pdMS_TO_TICKS(20), &stats.input_empty);
        if (!packet) continue;
        if (packet->generation != atomic_load(&s_generation)) {
            vRingbufferReturnItem(s_encoded, packet);
            continue;
        }
        if (packet->generation == failed_generation) {
            vRingbufferReturnItem(s_encoded, packet);
            continue;
        }
        if (packet->codec == NATIVE_CODEC_AUTO && packet->end_of_stream) {
            // Empty HTTP body: there was no first chunk to identify a codec.
            return_decoded_packet(packet, failed_generation);
            continue;
        }
        if (registration_result != ESP_AUDIO_ERR_OK) {
            registration_result = decoder_register_codecs();
            if (registration_result != ESP_AUDIO_ERR_OK) {
                ESP_LOGE(TAG, "Decoder registration failed: %d", registration_result);
                state_set_audio(packet->generation, false, "DECODER INIT ERROR");
                failed_generation = packet->generation;
                return_decoded_packet(packet, failed_generation);
                continue;
            }
        }
        if (packet->generation != generation || packet->codec != codec) {
            if (decoder) esp_audio_simple_dec_close(decoder);
            decoder = NULL;
            native_aac_decoder_destroy(aac_decoder);
            aac_decoder = NULL;
#ifdef CONFIG_YORADIO_FLAC_DECODER_CUSTOM
            if (flac_decoder) custom_flac_decoder_destroy(flac_decoder);
            flac_decoder = NULL;
#endif
#ifdef YORADIO_CUSTOM_LEGACY_DECODER
            if (legacy_decoder) custom_legacy_decoder_destroy(legacy_decoder);
            legacy_decoder = NULL;
#endif
            generation = packet->generation;
            codec = packet->codec;
            stream_info_ready = false;
            first_frame_memory_logged = false;
            reset_decoder_bitrate_tracking();
            decode_stats_reset(&stats, generation, codec, esp_timer_get_time());
#ifdef YORADIO_CODEC_BENCHMARK
            decoder_heap_before =
                heap_caps_get_free_size(MALLOC_CAP_8BIT);
            first_frame_memory_reported = false;
#endif
#ifdef CONFIG_YORADIO_FLAC_DECODER_CUSTOM
            if (codec == NATIVE_CODEC_FLAC) {
                free(output);
                output = NULL;
                output_size = 0;
                flac_decoder = custom_flac_decoder_create();
                if (!flac_decoder) {
                    ESP_LOGE(TAG, "Custom FLAC decoder allocation failed");
                    state_set_audio(generation, false, "NO MEMORY");
                    failed_generation = generation;
                }
#ifdef YORADIO_CODEC_BENCHMARK
                if (flac_decoder) {
                    benchmark_log_memory(
                        "open", codec, decoder_heap_before,
                        custom_flac_decoder_memory_used(flac_decoder));
                }
#endif
            } else
#endif
#ifdef YORADIO_CUSTOM_LEGACY_DECODER
            if (
#ifdef CONFIG_YORADIO_AAC_DECODER_HELIX
                codec == NATIVE_CODEC_AAC ||
#endif
#if defined(CONFIG_YORADIO_MP3_DECODER_HELIX) || defined(CONFIG_YORADIO_MP3_DECODER_MINIMP3)
                codec == NATIVE_CODEC_MP3 ||
#endif
                false) {
                free(output);
                output = NULL;
                output_size = 0;
                legacy_decoder = custom_legacy_decoder_create(
                    codec == NATIVE_CODEC_AAC ? CUSTOM_LEGACY_AAC
                                              : CUSTOM_LEGACY_MP3);
                if (!legacy_decoder) {
                    ESP_LOGE(TAG, "Custom %s decoder allocation failed",
                             codec_name(codec));
                    state_set_audio(generation, false, "NO MEMORY");
                    failed_generation = generation;
                }
#ifdef YORADIO_CODEC_BENCHMARK
                if (legacy_decoder) {
                    benchmark_log_memory(
                        "open", codec, decoder_heap_before,
                        custom_legacy_decoder_memory_used(legacy_decoder));
                }
#endif
            } else
#endif
            {
#ifdef YORADIO_CUSTOM_LEGACY_DECODER
                // A same-family decoder reuses the released arena. An
                // Espressif decoder cannot use it, so return the old custom
                // arena to the heap only when crossing decoder families.
                if (!custom_legacy_decoder_discard_arena()) {
                    ESP_LOGE(TAG, "Old codec arena is still in use");
                    state_set_audio(generation, false, "decoder release failed");
                    failed_generation = generation;
                    vRingbufferReturnItem(s_encoded, packet);
                    continue;
                }
#endif
#ifdef CONFIG_YORADIO_AAC_EARLY_SBR_RESERVE
                if (codec == NATIVE_CODEC_AAC) {
                    aac_decoder = native_aac_decoder_create();
                    if (!aac_decoder) {
                        state_set_audio(generation, false, "NO MEMORY");
                        failed_generation = generation;
                        vRingbufferReturnItem(s_encoded, packet);
                        continue;
                    }
                }
#endif
                if (!decoder_pcm_prepare(&output, &output_size,
                                         codec == NATIVE_CODEC_AAC)) {
#ifdef CONFIG_YORADIO_AAC_EARLY_SBR_RESERVE
                    native_aac_decoder_destroy(aac_decoder);
                    aac_decoder = NULL;
#endif
                    ESP_LOGE(TAG, "%s PCM buffer allocation failed",
                             codec_name(codec));
                    state_set_audio(generation, false, "NO MEMORY");
                    failed_generation = generation;
                    vRingbufferReturnItem(s_encoded, packet);
                    continue;
                }
                esp_audio_simple_dec_cfg_t cfg = {
                    .dec_type = simple_decoder_type(codec),
                    .dec_cfg = NULL,
                    .cfg_size = 0,
                    .use_frame_dec = false,
                };
                esp_audio_err_t open_result;
#ifdef CONFIG_YORADIO_AAC_DECODER_ESPRESSIF
                if (codec == NATIVE_CODEC_AAC) {
                    if (!aac_decoder) aac_decoder = native_aac_decoder_create();
                    open_result = aac_decoder ? ESP_AUDIO_ERR_OK : ESP_AUDIO_ERR_MEM_LACK;
                } else
#endif
                open_result = esp_audio_simple_dec_open(&cfg, &decoder);
                if (open_result != ESP_AUDIO_ERR_OK) {
                    ESP_LOGE(TAG, "%s decoder open failed: %d",
                             codec_name(codec), open_result);
                    state_set_audio(generation,
                        false,
                        open_result == ESP_AUDIO_ERR_MEM_LACK
                            ? "NO MEMORY" : "DECODER ERROR");
                    failed_generation = generation;
                    decoder_resources_release(&decoder, &aac_decoder, &output, &output_size);
                }
#ifdef YORADIO_CODEC_BENCHMARK
                if (open_result == ESP_AUDIO_ERR_OK) {
                    benchmark_log_memory("open", codec, decoder_heap_before,
                                         0);
                }
#endif
            }
        }
#ifdef CONFIG_YORADIO_FLAC_DECODER_CUSTOM
        if (codec == NATIVE_CODEC_FLAC) {
            if (flac_decoder) {
                custom_flac_feed_stats_t feed_stats = {0};
                custom_flac_output_context_t context = {
                    .generation = generation,
                    .stats = &stats,
                    .stream_info = &stream_info,
                    .stream_info_ready = &stream_info_ready,
                };
                int result = custom_flac_decoder_feed(
                    flac_decoder, packet->data, packet->data_size,
                    packet->end_of_stream, custom_flac_output, &context,
                    &feed_stats);
                stats.decode_us += feed_stats.decode_us;
                stats.calls += feed_stats.decode_calls;
                if (feed_stats.max_call_us > stats.max_call_us) {
                    stats.max_call_us = feed_stats.max_call_us;
                }
                stats.input_bytes += feed_stats.input_bytes;
#ifdef YORADIO_CODEC_BENCHMARK
                if (!first_frame_memory_reported && stream_info_ready) {
                    benchmark_log_memory(
                        "first-frame", codec, decoder_heap_before,
                        custom_flac_decoder_memory_used(flac_decoder));
                    first_frame_memory_reported = true;
                }
#endif
                if (!first_frame_memory_logged && stream_info_ready) {
                    log_runtime_memory("after first FLAC frame");
                    first_frame_memory_logged = true;
                }
                decode_stats_report(&stats, esp_timer_get_time());
                if (result < 0 && generation == atomic_load(&s_generation)) {
                    ESP_LOGW(TAG, "Custom FLAC decode error: %d", result);
                    state_set_audio(generation, false,
                                    result == -5 || result == -6 ? "NO MEMORY" : "decode failed");
                    failed_generation = generation;
                }
            }
            // send_pcm copied every callback's data into the output queue.
            // The custom workspace is no longer needed after feed has drained
            // EOF, or when this generation has failed. Stop must not be needed
            // to return the FLAC channel/input allocations to the heap.
            if (packet->end_of_stream || failed_generation == generation) {
                custom_flac_decoder_destroy(flac_decoder);
                flac_decoder = NULL;
            }
            return_decoded_packet(packet, failed_generation);
            continue;
        }
#endif
#ifdef YORADIO_CUSTOM_LEGACY_DECODER
        if (
#ifdef CONFIG_YORADIO_AAC_DECODER_HELIX
            codec == NATIVE_CODEC_AAC ||
#endif
#if defined(CONFIG_YORADIO_MP3_DECODER_HELIX) || defined(CONFIG_YORADIO_MP3_DECODER_MINIMP3)
            codec == NATIVE_CODEC_MP3 ||
#endif
            false) {
            if (legacy_decoder) {
                custom_legacy_feed_stats_t feed_stats = {0};
                custom_legacy_output_context_t context = {
                    .generation = generation,
                    .stats = &stats,
                    .stream_info = &stream_info,
                    .stream_info_ready = &stream_info_ready,
                };
                int result = custom_legacy_decoder_feed(
                    legacy_decoder, packet->data, packet->data_size,
                    packet->end_of_stream, custom_legacy_output, &context,
                    &feed_stats);
                stats.decode_us += feed_stats.decode_us;
                stats.calls += feed_stats.decode_calls;
                if (feed_stats.max_call_us > stats.max_call_us) {
                    stats.max_call_us = feed_stats.max_call_us;
                }
                stats.input_bytes += feed_stats.input_bytes;
#ifdef YORADIO_CODEC_BENCHMARK
                if (!first_frame_memory_reported && stream_info_ready) {
                    benchmark_log_memory(
                        "first-frame", codec, decoder_heap_before,
                        custom_legacy_decoder_memory_used(legacy_decoder));
                    first_frame_memory_reported = true;
                }
#endif
                if (!first_frame_memory_logged && stream_info_ready) {
                    log_runtime_memory("after first legacy frame");
                    first_frame_memory_logged = true;
                }
                decode_stats_report(&stats, esp_timer_get_time());
                if (result < 0 && generation == atomic_load(&s_generation)) {
                    ESP_LOGW(TAG, "Custom %s decode error: %d",
                             codec_name(codec), result);
                    state_set_audio(generation, false, "decode failed");
                    failed_generation = generation;
                }
            }
            if (packet->end_of_stream || failed_generation == generation) {
                custom_legacy_decoder_destroy(legacy_decoder);
                legacy_decoder = NULL;
                // Destroy releases the owner; discard returns the reusable
                // arena itself. Queued PCM contains independent copies.
                if (!custom_legacy_decoder_discard_arena()) {
                    ESP_LOGE(TAG, "Completed codec arena is still in use");
                    state_set_audio(generation, false, "decoder release failed");
                    failed_generation = generation;
                }
            }
            return_decoded_packet(packet, failed_generation);
            continue;
        }
#endif
        if (!decoder && !aac_decoder) {
            vRingbufferReturnItem(s_encoded, packet);
            continue;
        }
        esp_audio_simple_dec_raw_t raw = {
            .buffer = packet->data,
            .len = packet->data_size,
            .eos = packet->end_of_stream,
        };
        bool retry_pcm = false;
        while (raw.len || raw.eos || retry_pcm) {
            retry_pcm = false;
            esp_audio_simple_dec_out_t frame = {
                .buffer = output,
                .len = output_size,
            };
            raw.consumed = 0;
            int64_t decode_started_us = esp_timer_get_time();
            esp_audio_err_t result = aac_decoder
                ? native_aac_decoder_process(aac_decoder, &raw, &frame)
                : esp_audio_simple_dec_process(decoder, &raw, &frame);
            uint32_t decode_call_us =
                (uint32_t)(esp_timer_get_time() - decode_started_us);
            stats.decode_us += decode_call_us;
            ++stats.calls;
            if (decode_call_us > stats.max_call_us) {
                stats.max_call_us = decode_call_us;
            }
            // PCM backpressure normally blocks this task every few frames.
            // Keep a bounded fallback yield for malformed streams that keep
            // consuming input without producing PCM.
            if ((stats.calls & 31U) == 0U) vTaskDelay(1);
            if (generation != atomic_load(&s_generation)) break;
            if (result == ESP_AUDIO_ERR_BUFF_NOT_ENOUGH) {
                if (aac_decoder) {
                    stats.input_bytes += raw.consumed;
                    raw.buffer += raw.consumed;
                    raw.len -= raw.consumed;
                }
                if (frame.needed_size <= output_size ||
                    !decoder_pcm_resize(&output, &output_size,
                                        frame.needed_size)) {
                    state_set_audio(generation, false, "PCM allocation failed");
                    failed_generation = generation;
                    break;
                }
                retry_pcm = true;
                continue;
            }
            if (result != ESP_AUDIO_ERR_OK) {
                ESP_LOGW(TAG, "%s decode error: %d", codec_name(codec),
                         result);
                state_set_audio(generation, false, "decode failed");
                failed_generation = generation;
                break;
            }
            if (raw.consumed > raw.len) {
                ESP_LOGE(TAG, "%s decoder consumed invalid input size %lu/%lu",
                         codec_name(codec), (unsigned long)raw.consumed,
                         (unsigned long)raw.len);
                state_set_audio(generation, false, "decoder input error");
                failed_generation = generation;
                break;
            }
            stats.input_bytes += (uint32_t)raw.consumed;
            raw.buffer += raw.consumed;
            raw.len -= raw.consumed;
            if (frame.decoded_size) {
                esp_audio_simple_dec_info_t latest_info = {0};
                esp_audio_err_t info_result = aac_decoder
                    ? native_aac_decoder_get_info(aac_decoder, &latest_info)
                    : esp_audio_simple_dec_get_info(decoder, &latest_info);
                if (info_result == ESP_AUDIO_ERR_OK) {
                    bool format_is_pcm = codec == NATIVE_CODEC_AAC;
                    const char *label = aac_decoder
                        ? native_aac_decoder_label(aac_decoder, &latest_info,
                                                   &format_is_pcm)
                        : codec_name(codec);
                    stream_info_ready = update_stream_info(
                        generation, label, &latest_info,
                        &stream_info, &stream_info_ready, 0,
                        aac_decoder && !format_is_pcm ? native_aac_decoder_source_channels(aac_decoder) : 0, false,
                        format_is_pcm);
                    state_set_decoder_bitrate(generation, latest_info.bitrate);
                } else {
                    // Never send a frame with another frame's stale layout.
                    stream_info_ready = false;
                }
                if (stream_info_ready) {
#ifdef YORADIO_CODEC_BENCHMARK
                    if (!first_frame_memory_reported) {
                        benchmark_log_memory("first-frame", codec,
                                             decoder_heap_before, 0);
                        first_frame_memory_reported = true;
                    }
#endif
                    if (!first_frame_memory_logged) {
                        log_runtime_memory("after first decoded frame");
                        first_frame_memory_logged = true;
                    }
                    decode_stats_add_audio(&stats, &stream_info,
                                           frame.decoded_size);
                    if (!send_pcm(&stats, generation, &stream_info, output,
                                  frame.decoded_size)) {
                        ESP_LOGW(TAG, "PCM buffer stalled");
                        break;
                    }
                }
            }
            decode_stats_report(&stats, esp_timer_get_time());
            if (!raw.consumed && !frame.decoded_size && !raw.eos) {
                ESP_LOGE(TAG, "%s decoder made no input progress",
                         codec_name(codec));
                state_set_audio(generation, false, "decoder stalled");
                failed_generation = generation;
                break;
            }
            // EOF can drain several cached Ogg packets. Keep the decoder and
            // its PCM workspace alive until a successful call yields no PCM.
            if (raw.eos ? (!raw.len && !frame.decoded_size) : raw.len == 0) break;
        }
        if (packet->end_of_stream || failed_generation == generation) {
            decoder_resources_release(&decoder, &aac_decoder, &output, &output_size);
        }
        return_decoded_packet(packet, failed_generation);
    }
}

#ifdef CONFIG_YORADIO_DEEP_SLEEP_CLOCK
static TaskHandle_t s_output_task;
static SemaphoreHandle_t s_output_suspended;
static atomic_bool s_suspend_output;
static esp_err_t s_suspend_result;

esp_err_t audio_service_suspend_output(void) {
    if (!s_output_suspended || !s_output_task) return ESP_ERR_INVALID_STATE;
    atomic_store(&s_suspend_output, true);
    xSemaphoreTake(s_output_suspended, portMAX_DELAY);
    return s_suspend_result;
}

esp_err_t audio_service_resume_output(void) {
    xTaskNotifyGive(s_output_task);
    xSemaphoreTake(s_output_suspended, portMAX_DELAY);
    return s_suspend_result;
}
#endif

#ifdef CONFIG_YORADIO_DIRECT_DMA_PCM
static void release_pcm_lease(native_audio_pcm_lease_t *lease) {
    pcm_packet_t *packet = (pcm_packet_t *)((uint8_t *)lease - offsetof(pcm_packet_t, lease));
    vRingbufferReturnItem(s_pcm, packet);
}
#endif

#ifdef CONFIG_YORADIO_PIPELINE_PROFILE
typedef struct {
    int64_t start_us;
    pipeline_wait_t empty, submit;
    uint32_t overruns;
} output_flow_t;

static void output_flow_reset(output_flow_t *flow, bool active) {
    *flow = (output_flow_t){
        .start_us = active ? esp_timer_get_time() : 0,
        .overruns = native_audio_output_dma_overruns(),
    };
    native_i2s_take_wait_profile();
}

static void output_flow_report(output_flow_t *flow, uint32_t generation) {
    int64_t now = esp_timer_get_time();
    if (!flow->start_us || now - flow->start_us < DECODE_STATS_INTERVAL_US) return;
    pipeline_wait_t dma = native_i2s_take_wait_profile();
    uint32_t overruns = native_audio_output_dma_overruns();
    ESP_LOGI(TAG,
        "PERF FLOW_OUT: gen=%lu window_us=%llu "
        "empty_us=%llu empty_n=%lu empty_timeouts=%lu empty_max=%lu "
        "submit_us=%llu submit_n=%lu submit_max=%lu "
        "dma_us=%llu dma_n=%lu dma_timeouts=%lu dma_max=%lu overruns=%lu",
        (unsigned long)generation, (unsigned long long)(now - flow->start_us),
        (unsigned long long)flow->empty.us, (unsigned long)flow->empty.count,
        (unsigned long)flow->empty.timeouts, (unsigned long)flow->empty.max_us,
        (unsigned long long)flow->submit.us, (unsigned long)flow->submit.count,
        (unsigned long)flow->submit.max_us, (unsigned long long)dma.us,
        (unsigned long)dma.count, (unsigned long)dma.timeouts,
        (unsigned long)dma.max_us, (unsigned long)(overruns - flow->overruns));
    // Do not erase a completion interrupt occurring while the log is written.
    *flow = (output_flow_t){.start_us = now, .overruns = overruns};
}
#endif

static void output_task(void *argument) {
    (void)argument;
#ifdef CONFIG_YORADIO_DEEP_SLEEP_CLOCK
    s_output_task = xTaskGetCurrentTaskHandle();
#endif
    uint32_t sample_rate = 0;
#ifdef CONFIG_YORADIO_PIPELINE_PROFILE
    output_flow_t flow = {0};
#endif
#ifdef CONFIG_YORADIO_DIRECT_DMA_PCM
    uint32_t generation = atomic_load(&s_generation);
#endif
    while (true) {
#ifdef CONFIG_YORADIO_DIRECT_DMA_PCM
        uint32_t current_generation = atomic_load(&s_generation);
        if (generation != current_generation) {
            native_audio_output_discard_pcm();
            generation = current_generation;
#ifdef CONFIG_YORADIO_PIPELINE_PROFILE
            output_flow_reset(&flow, false);
#endif
        }
#endif
#ifdef CONFIG_YORADIO_DEEP_SLEEP_CLOCK
        if (atomic_exchange(&s_suspend_output, false)) {
            s_suspend_result = native_audio_output_suspend();
            xSemaphoreGive(s_output_suspended);
            if (s_suspend_result == ESP_OK) {
                ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
                // Reserve I2S again before the sleep gate admits a new Play.
                // Otherwise TLS/decoder allocations could take its DMA memory.
                s_suspend_result = native_audio_output_configure(
                    sample_rate ? sample_rate : 48000U);
                sample_rate = 0;
                xSemaphoreGive(s_output_suspended);
            }
        }
#endif
        size_t item_size = 0;
        pcm_packet_t *packet = pipeline_receive(s_pcm, &item_size,
                                                 pdMS_TO_TICKS(5), &flow.empty);
        if (!packet) {
            native_audio_output_idle();
#ifdef CONFIG_YORADIO_PIPELINE_PROFILE
            output_flow_report(&flow, generation);
#endif
            continue;
        }
#ifdef CONFIG_YORADIO_DIRECT_DMA_PCM
        current_generation = atomic_load(&s_generation);
        if (generation != current_generation) {
            native_audio_output_discard_pcm();
            generation = current_generation;
#ifdef CONFIG_YORADIO_PIPELINE_PROFILE
            output_flow_reset(&flow, false);
#endif
        }
#endif
        if (packet->generation != atomic_load(&s_generation)) {
            vRingbufferReturnItem(s_pcm, packet);
            continue;
        }
        if (packet->end_of_stream) {
#ifdef CONFIG_YORADIO_DIRECT_DMA_PCM
            esp_err_t flush_result = native_audio_output_flush_pcm();
            if (flush_result != ESP_OK) ESP_LOGW(TAG, "PCM tail flush failed: %s", esp_err_to_name(flush_result));
#endif
            finish_pcm_stream(packet);
            vRingbufferReturnItem(s_pcm, packet);
#ifdef CONFIG_YORADIO_PIPELINE_PROFILE
            output_flow_reset(&flow, false);
#endif
            continue;
        }
        if (packet->sample_rate != sample_rate) {
            esp_err_t result =
                native_audio_output_configure(packet->sample_rate);
            if (result != ESP_OK) {
                ESP_LOGE(TAG, "%s %lu Hz setup failed: %s",
                         native_audio_output_name(),
                         (unsigned long)packet->sample_rate,
                         esp_err_to_name(result));
                vRingbufferReturnItem(s_pcm, packet);
                continue;
            }
            sample_rate = packet->sample_rate;
        }
#ifdef CONFIG_YORADIO_PIPELINE_PROFILE
        if (!flow.start_us) output_flow_reset(&flow, true);
        int64_t submit_start = esp_timer_get_time();
#endif
#ifdef CONFIG_YORADIO_DIRECT_DMA_PCM
        // Ownership transfers even on a write error. The final source tail is
        // retained until another packet completes a DMA block, EOF, or Stop.
        esp_err_t result = native_audio_output_submit_pcm(
            &packet->lease, packet->data, packet->data_size,
            packet->bits_per_sample, packet->channels, release_pcm_lease);
#else
        esp_err_t result = native_audio_output_write_pcm(
            packet->data, packet->data_size, packet->bits_per_sample,
            packet->channels);
        vRingbufferReturnItem(s_pcm, packet);
#endif
#ifdef CONFIG_YORADIO_PIPELINE_PROFILE
        pipeline_wait_record(&flow.submit,
            (uint32_t)(esp_timer_get_time() - submit_start), false);
        output_flow_report(&flow, generation);
#endif
        if (result != ESP_OK) {
            ESP_LOGW(TAG, "%s write failed: %s", native_audio_output_name(),
                     esp_err_to_name(result));
        }
    }
}

esp_err_t audio_service_start(native_state_t *state) {
    s_state = state;
#ifdef CONFIG_YORADIO_DEEP_SLEEP_CLOCK
    s_output_suspended = xSemaphoreCreateBinary();
    if (!s_output_suspended) return ESP_ERR_NO_MEM;
#endif
    ESP_RETURN_ON_ERROR(native_audio_output_init(), TAG,
                        "initialize audio output");
    ESP_RETURN_ON_ERROR(audio_level_led_init(), TAG,
                        "initialize audio level LED");
    atomic_init(&s_generation, 0);
    atomic_init(&s_decoder_target_codec, NATIVE_CODEC_AUTO);
    atomic_init(&s_decoder_released_generation, 0);
    atomic_init(&s_measured_bitrate_ready, false);
    s_last_url[0] = '\0';
    s_last_codec = NATIVE_CODEC_AUTO;
    size_t encoded_ring_size =
        (size_t)runtime_settings_get_audio_buffer_blocks() * 1600U;
    s_commands = xQueueCreate(1, sizeof(play_command_t));
    s_encoded = xRingbufferCreate(encoded_ring_size, RINGBUF_TYPE_NOSPLIT);
    s_pcm = xRingbufferCreate(PCM_RING_SIZE, RINGBUF_TYPE_NOSPLIT);
    if (!s_commands || !s_encoded || !s_pcm) {
        return ESP_ERR_NO_MEM;
    }
    s_encoded_usable_size = xRingbufferGetCurFreeSize(s_encoded);
    // The historical ordering favored uninterrupted decode-call timing. With
    // OUTPUT_TASK_FIRST, a ready DMA block preempts long decode calls instead.
    // Compare decoder task CPU separately from elapsed call time: the latter
    // legitimately includes output preemption. Output yields through its PCM
    // and DMA queue waits; Wi-Fi/TCP retain their higher system priorities.
    if (xTaskCreate(stream_task, "radio_stream",
                    BOARD_TASK_STACK_RADIO_STREAM, NULL, AUDIO_STREAM_PRIORITY, NULL) !=
            pdPASS ||
        xTaskCreate(decoder_task, "audio_decode",
                    BOARD_TASK_STACK_AUDIO_DECODER, NULL, AUDIO_DECODE_PRIORITY, NULL) !=
            pdPASS ||
        xTaskCreate(output_task, "audio_output",
                    BOARD_TASK_STACK_AUDIO_OUTPUT, NULL, AUDIO_OUTPUT_PRIORITY, NULL) !=
            pdPASS) {
        return ESP_ERR_NO_MEM;
    }
    ESP_LOGI(TAG,
             "Pipeline ready: %s, %u-byte compressed + %u-byte PCM, free heap %u",
             native_audio_output_name(),
             (unsigned)encoded_ring_size, (unsigned)PCM_RING_SIZE,
             (unsigned)heap_caps_get_free_size(MALLOC_CAP_8BIT));
#ifdef CONFIG_YORADIO_PIPELINE_PROFILE
    ESP_LOGI(TAG, "PERF FLOW_CONFIG: stream_priority=%u decode_priority=%u output_priority=%u",
             AUDIO_STREAM_PRIORITY, AUDIO_DECODE_PRIORITY, AUDIO_OUTPUT_PRIORITY);
#endif
#ifdef YORADIO_CODEC_BENCHMARK
    ESP_RETURN_ON_ERROR(benchmark_autostart(), TAG,
                        "start codec flash fixture");
#endif
    return ESP_OK;
}

esp_err_t audio_service_play(const char *url, native_codec_t codec) {
    if (!url || !url[0] || strlen(url) >= sizeof(((play_command_t *)0)->url)) {
        return ESP_ERR_INVALID_ARG;
    }
    // Power-save changes are best effort: a transient Wi-Fi driver error must
    // not reject an otherwise valid Play command.
    network_service_set_streaming(true);
    play_command_t command = {
        .generation = advance_generation(codec),
        .requested_codec = codec,
    };
    strlcpy(command.url, url, sizeof(command.url));
    strlcpy(s_last_url, url, sizeof(s_last_url));
    s_last_codec = codec;
    atomic_store(&s_measured_bitrate_ready, false);
    native_state_set_station(s_state, url);
    // Clear a previous station's playing state before the command is queued.
    // The stream task switches it back after open_stream() succeeds.
    state_set_audio(command.generation, false, "connecting");
    if (xQueueOverwrite(s_commands, &command) == pdTRUE) return ESP_OK;
    if (atomic_load(&s_generation) == command.generation) {
        network_service_set_streaming(false);
    }
    return ESP_FAIL;
}

#ifdef YORADIO_CODEC_BENCHMARK
static esp_err_t audio_service_play_fixture(size_t size,
                                            native_codec_t codec) {
    const esp_partition_t *partition = esp_partition_find_first(
        ESP_PARTITION_TYPE_DATA, (esp_partition_subtype_t)0x40,
        "codec_test");
    if (!partition || !size ||
        size > partition->size - sizeof(codec_fixture_header_t) ||
        codec == NATIVE_CODEC_AUTO) {
        return ESP_ERR_INVALID_ARG;
    }
    play_command_t command = {
        .generation = advance_generation(codec),
        .requested_codec = codec,
        .fixture_size = (uint32_t)size,
    };
    s_last_url[0] = '\0';
    s_last_codec = NATIVE_CODEC_AUTO;
    atomic_store(&s_measured_bitrate_ready, false);
    native_state_set_station(s_state, "flash:codec_test benchmark");
    return xQueueOverwrite(s_commands, &command) == pdTRUE ? ESP_OK
                                                            : ESP_FAIL;
}

static esp_err_t benchmark_autostart(void) {
    const esp_partition_t *partition = esp_partition_find_first(
        ESP_PARTITION_TYPE_DATA, (esp_partition_subtype_t)0x40,
        "codec_test");
    if (!partition) return ESP_ERR_NOT_FOUND;
    codec_fixture_header_t header = {0};
    ESP_RETURN_ON_ERROR(esp_partition_read(partition, 0, &header,
                                            sizeof(header)), TAG,
                        "read codec fixture header");
    if (header.magic != CODEC_FIXTURE_MAGIC ||
        header.codec <= NATIVE_CODEC_AUTO ||
        header.codec > NATIVE_CODEC_OGG || !header.size ||
        header.size > partition->size - sizeof(header)) {
        ESP_LOGE(TAG,
                 "Invalid codec fixture header: magic %08lx codec %lu size %lu",
                 (unsigned long)header.magic, (unsigned long)header.codec,
                 (unsigned long)header.size);
        return ESP_ERR_INVALID_ARG;
    }
    ESP_LOGI(TAG, "Autostarting %s codec fixture from local flash",
             codec_name((native_codec_t)header.codec));
    return audio_service_play_fixture(header.size,
                                      (native_codec_t)header.codec);
}
#endif

esp_err_t audio_service_resume(void) {
    if (!s_last_url[0]) return ESP_ERR_INVALID_STATE;
    char url[sizeof(s_last_url)];
    native_state_t state;
    native_state_snapshot(s_state, &state);
    strlcpy(url, s_last_url, sizeof(url));
    esp_err_t result = audio_service_play(url, s_last_codec);
    if (result == ESP_OK) native_state_set_station(s_state, state.station);
    return result;
}

void audio_service_stop(void) {
    uint32_t generation = advance_generation(NATIVE_CODEC_AUTO);
    network_service_set_streaming(false);
    native_state_set_title(s_state, "");
    state_set_audio(generation, false, "stopped");
}

uint8_t audio_service_buffer_fill_percent(void) {
    if (!s_encoded || !s_encoded_usable_size) return 0;
    size_t free_size = xRingbufferGetCurFreeSize(s_encoded);
    if (free_size >= s_encoded_usable_size) return 0;
    size_t used_size = s_encoded_usable_size - free_size;
    unsigned percent =
        (unsigned)((used_size * 100U) / s_encoded_usable_size);
    return (uint8_t)(percent > 100U ? 100U : percent);
}
