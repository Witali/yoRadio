import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
port=ROOT/'idf/components/native_vorbis_xiph_port'
base=ROOT/'idf/components/native_vorbis_xiph'
source=(base/'upstream/libvorbis/lib/info.c').read_bytes()
def fragment(name,begin,end,transform):
    a=source.index(begin);b=source.index(end,a)
    before=source[a:b].rstrip(b'\r\n')+b'\r\n'
    after=transform(before.decode().replace('\r\n','\n'))
    (port/('edits/'+name+'.before.c')).write_bytes(before)
    (port/('edits/'+name+'.after.c')).write_bytes(after.encode())
def comments(body):
    body=body.replace('  int i;','  int i;\n  int failure=OV_EBADHEADER;',1)
    body=body.replace('  vc->vendor=_ogg_calloc(vendorlen+1,1);','  vc->vendor=_ogg_calloc(vendorlen+1,1);\n  if(!vc->vendor)goto oom_out;')
    body=body.replace('  vc->user_comments=_ogg_calloc(vc->comments+1,sizeof(*vc->user_comments));','  vc->user_comments=_ogg_calloc(vc->comments+1,sizeof(*vc->user_comments));\n  if(!vc->user_comments)goto oom_out;')
    body=body.replace('  vc->comment_lengths=_ogg_calloc(vc->comments+1, sizeof(*vc->comment_lengths));','  vc->comment_lengths=_ogg_calloc(vc->comments+1, sizeof(*vc->comment_lengths));\n  if(!vc->comment_lengths)goto oom_out;')
    body=body.replace('    vc->user_comments[i]=_ogg_calloc(len+1,1);','    vc->user_comments[i]=_ogg_calloc(len+1,1);\n    if(!vc->user_comments[i])goto oom_out;')
    body=body.replace(' err_out:\n  vorbis_comment_clear(vc);\n  return(OV_EBADHEADER);',' oom_out:\n  failure=OV_EFAULT;\n err_out:\n  vorbis_comment_clear(vc);\n  return(failure);')
    return body
def books(body):
    body='#include "native_vorbis_xiph_header_error.h"\n\n'+body
    body=body.replace('  int i;', '''  int i,failure=0;
  static vorbis_info_floor *(*const floor_unpack[])(vorbis_info *,oggpack_buffer *,int *)={
    native_xiph_floor0_unpack,native_xiph_floor1_unpack
  };
  static vorbis_info_residue *(*const residue_unpack[])(vorbis_info *,oggpack_buffer *,int *)={
    native_xiph_residue_unpack,native_xiph_residue_unpack,native_xiph_residue_unpack
  };
  static vorbis_info_mapping *(*const mapping_unpack[])(vorbis_info *,oggpack_buffer *,int *)={
    native_xiph_mapping_unpack
  };
  _Static_assert(sizeof(floor_unpack)/sizeof(*floor_unpack)==VI_FLOORB,"pinned floor registry");
  _Static_assert(sizeof(residue_unpack)/sizeof(*residue_unpack)==VI_RESB,"pinned residue registry");
  _Static_assert(sizeof(mapping_unpack)/sizeof(*mapping_unpack)==VI_MAPB,"pinned mapping registry");''',1)
    body=body.replace('vorbis_staticbook_unpack(opb)','native_xiph_staticbook_unpack(opb,&failure)')
    body=body.replace('_floor_P[ci->floor_type[i]]->unpack(vi,opb)','floor_unpack[ci->floor_type[i]](vi,opb,&failure)')
    body=body.replace('_residue_P[ci->residue_type[i]]->unpack(vi,opb)','residue_unpack[ci->residue_type[i]](vi,opb,&failure)')
    body=body.replace('_mapping_P[ci->map_type[i]]->unpack(vi,opb)','mapping_unpack[ci->map_type[i]](vi,opb,&failure)')
    body=body.replace('    ci->mode_param[i]=_ogg_calloc(1,sizeof(*ci->mode_param[i]));','    ci->mode_param[i]=_ogg_calloc(1,sizeof(*ci->mode_param[i]));\n    if(!ci->mode_param[i]){failure=OV_EFAULT;goto err_out;}')
    body=body.replace('  return(OV_EBADHEADER);','  return(failure?failure:OV_EBADHEADER);')
    return body
fragment('info-comments',b'static int _vorbis_unpack_comment(',b'/* all of the real encoding',comments)
fragment('info-books',b'static int _vorbis_unpack_books(',b'/* Is this packet',books)
include=port/'include';include.mkdir(exist_ok=True)
(include/'native_vorbis_xiph_header_error.h').write_text('''/* Private checked entry points for the source-built Xiph port.
   Public codec.h and original registry callback signatures remain unchanged.
   Each caller initializes its own failure=0; only a required allocation
   refusal sets OV_EFAULT. Malformed input leaves that status unchanged. */
#ifndef NATIVE_VORBIS_XIPH_HEADER_ERROR_H
#define NATIVE_VORBIS_XIPH_HEADER_ERROR_H
#include <ogg/ogg.h>
#include "vorbis/codec.h"
#include "codec_internal.h"
static_codebook *native_xiph_staticbook_unpack(oggpack_buffer *,int *);
vorbis_info_floor *native_xiph_floor0_unpack(vorbis_info *,oggpack_buffer *,int *);
vorbis_info_floor *native_xiph_floor1_unpack(vorbis_info *,oggpack_buffer *,int *);
vorbis_info_residue *native_xiph_residue_unpack(vorbis_info *,oggpack_buffer *,int *);
vorbis_info_mapping *native_xiph_mapping_unpack(vorbis_info *,oggpack_buffer *,int *);
#endif
''',encoding='utf-8',newline='\n')
path=port/'edits.json';changes=json.loads(path.read_bytes());assert len(changes['edits'])==9
for name,unit in(('codebook-unpack','codebook'),('floor0-unpack','floor0'),('floor1-unpack','floor1'),('residue-unpack','res0'),('mapping-unpack','mapping0'),('info-comments','info'),('info-books','info')):
    changes['edits'].append(dict(source='upstream/libvorbis/lib/'+unit+'.c',before='edits/'+name+'.before.c',after='edits/'+name+'.after.c'))
path.write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8',newline='\n')
path=port/'prepare.py';text=path.read_text().replace("len(changes['edits']) == 9, 'nine exact reviewed edits'","len(changes['edits']) == 16, 'sixteen exact reviewed edits'")
text=text.replace("'upstream/libogg/src/bitwise.c', 'upstream/libvorbis/lib/codebook.c'},", "'upstream/libogg/src/bitwise.c', 'upstream/libvorbis/lib/codebook.c',\n                           'upstream/libvorbis/lib/floor0.c', 'upstream/libvorbis/lib/floor1.c',\n                           'upstream/libvorbis/lib/res0.c', 'upstream/libvorbis/lib/mapping0.c',\n                           'upstream/libvorbis/lib/info.c'},")
text=text.replace('only the four reviewed translation units change','only the nine reviewed translation units change')
text=text.replace("    units = [dict(original=name,", "    generated['ported/native_vorbis_xiph_header_error.h'] = edits['include/native_vorbis_xiph_header_error.h']\n    units = [dict(original=name,")
path.write_text(text,encoding='utf-8',newline='\n')
path=port/'CMakeLists.txt';text=path.read_text().replace('if(unit STREQUAL "block" OR unit STREQUAL "sharedbook" OR unit STREQUAL "codebook")','if(unit IN_LIST xiph_ported_units)')
text=text.replace('set(xiph_sources)','set(xiph_ported_units block sharedbook codebook floor0 floor1 res0 mapping0 info)\nset(xiph_sources)')
text=text.replace('"${xiph_base}/*" "${CMAKE_CURRENT_LIST_DIR}/edits/*")','"${xiph_base}/*" "${CMAKE_CURRENT_LIST_DIR}/edits/*"\n    "${CMAKE_CURRENT_LIST_DIR}/include/*")')
text=text.replace('PRIV_INCLUDE_DIRS "${xiph_generated}/base/upstream/libvorbis/lib")','PRIV_INCLUDE_DIRS "${xiph_generated}/base/upstream/libvorbis/lib" "${xiph_generated}/ported")')
path.write_text(text,encoding='utf-8',newline='\n')
path=port/'README.md';text=path.read_text().replace('only four modified translation units','only nine modified translation units and one owned private header')
text=text.replace('Neither production application selects this component.', '''Seven further exact edits check every allocation in header book/floor/
residue/mapping/comment/mode parsing. Explicit checked variants report
OV_EFAULT for required allocation failures; malformed headers keep their
existing status. The original pointer-returning callback signatures remain
as thin wrappers. The public header parser uses a local status and checked
dispatch tables bound to the pinned registry sizes at compile time. There is
no shared mutable error state, TLS, errno inference, public ABI change, or
modified baseline header. Legal zero-size NULL allocations are preserved.
The generated private header declares only these checked entry points.

Neither production application selects this component.''')
text=text.replace('other block, DSP,\nheader, floor and residue allocations still require qualification. Channel-sized mapping/residue scratch and unchecked allocations elsewhere','other block, DSP,\npacket floor and residue allocations still require qualification. Channel-sized mapping/residue scratch and unchecked allocations elsewhere')
path.write_text(text,encoding='utf-8',newline='\n')
path=port/'port-manifest.json';manifest=json.loads(path.read_bytes());manifest['files']={p.relative_to(port).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(port.rglob('*'))if p.is_file()and p!=path}
path.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(port=hashlib.sha256(path.read_bytes()).hexdigest(),generator=hashlib.sha256((port/'prepare.py').read_bytes()).hexdigest(),entries=len(manifest['files']))))
