import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
port=ROOT/'idf/components/native_vorbis_xiph_port'
original=(ROOT/'idf/components/native_vorbis_xiph/upstream/libvorbis/lib/info.c').read_bytes()
saved=ROOT/'.build/vorbis-xiph-header-marker-first-20261026-01';assert not saved.exists();saved.mkdir()
for name in('port-manifest.json','edits/info-comments.before.c','edits/info-books.before.c'):
    (saved/Path(name).name).write_bytes((port/name).read_bytes())
for name in('info-comments','info-books'):
    path=port/('edits/'+name+'.before.c');body=path.read_bytes();assert original.count(body)==0
    fixed=body.rstrip(b'\r\n')+b'\n';assert original.count(fixed)==1;path.write_bytes(fixed)
path=port/'port-manifest.json';manifest=json.loads(path.read_bytes());manifest['files']={p.relative_to(port).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(port.rglob('*'))if p.is_file()and p!=path}
path.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
print(hashlib.sha256(path.read_bytes()).hexdigest())
