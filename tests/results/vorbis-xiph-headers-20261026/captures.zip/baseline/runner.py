"""Exercise the new OOM fixture with the original unchecked info unit."""
import hashlib,json,os,subprocess,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
HOST=ROOT/'.build/vorbis-xiph-headers-host-20261026-01'
OUT=ROOT/'.build/vorbis-xiph-headers-baseline-20261026-01'
assert not OUT.exists();OUT.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
linux=lambda p:'/mnt/'+Path(p).resolve().as_posix()[0].lower()+Path(p).resolve().as_posix()[2:]
original=json.loads((HOST/'report.json').read_text())
assert original['passed'] and original['porting']['compiled_units'][10]['original']=='upstream/libvorbis/lib/info.c'
(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
(OUT/'supervisor.py').write_bytes((HOST/'supervisor.py').read_bytes())
(OUT/'info.c').write_bytes((HOST/'generated/base/upstream/libvorbis/lib/info.c').read_bytes())
report={'completed':False,'expected_regression':False,'host_report_sha256':sha(HOST/'report.json'),'source_sha256':sha(OUT/'info.c'),'commands':[]}
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(name,argv,success=True):
    nonce=uuid.uuid4().hex;request=OUT/(name+'.request.json');receipt=OUT/(name+'.receipt.json')
    request.write_text(json.dumps(dict(nonce=nonce,argv=argv,timeout=60,receipt=linux(receipt),stop=linux(OUT/(name+'.stop')))),encoding='utf-8')
    row={'name':name,'argv':argv,'nonce':nonce,'request_sha256':sha(request)};report['commands'].append(row);save();child=None
    try:
        with(OUT/(name+'.stdout.log')).open('xb')as so,(OUT/(name+'.stderr.log')).open('xb')as se:
            child=subprocess.Popen(['wsl.exe','--exec','python3',linux(OUT/'supervisor.py'),linux(request)],stdout=so,stderr=se,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
            row['transport_pid']=child.pid;row['transport_exit']=child.wait(timeout=80)
    finally:
        if child is not None and child.poll()is None:
            (OUT/(name+'.stop')).write_text(nonce)
            try:child.wait(timeout=15)
            except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
            row['forced_stop']=True
        row['supervisor']=json.loads(receipt.read_text())if receipt.exists()else{}
        for stream in('stdout','stderr'):row[stream+'_sha256']=sha(OUT/(name+'.'+stream+'.log'))
        save()
    evidence=row['supervisor'];assert not row.get('forced_stop') and evidence['nonce']==nonce and evidence['request_sha256']==row['request_sha256'] and evidence['final'] and evidence['child_reaped'] and evidence['group_gone'] and evidence['state']=='terminal'
    assert evidence['child_returncode']==0 if success else evidence['child_returncode']!=0
    return row
rows={r['name']:r['child_argv']for r in original['commands']}
argv=list(rows['compile-library-10']);argv[argv.index('-c')+1]=linux(OUT/'info.c');argv[argv.index('-o')+1]=linux(OUT/'info.o');run('compile',argv)
argv=[linux(OUT/'info.o')if x==linux(HOST/'objects/library-10.o')else x for x in rows['link']];argv[argv.index('-o')+1]=linux(OUT/'baseline-tests');run('link',argv)
argv=['python3','-c','import os,resource,sys; resource.setrlimit(resource.RLIMIT_CORE,(0,0)); os.execve(sys.argv[1],sys.argv[1:],dict(os.environ,ASAN_OPTIONS="detect_leaks=1:abort_on_error=1:allocator_may_return_null=1",UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1"))',linux(OUT/'baseline-tests'),linux(OUT/'unexpected-pcm.bin')]
run('execute',argv,False)
error=(OUT/'execute.stderr.log').read_text();assert '/info.c:'in error and ('runtime error:'in error or 'AddressSanitizer'in error)
assert not (OUT/'unexpected-pcm.bin').exists()
report.update(completed=True,expected_regression=True,reason='Original header parser dereferences a refused allocation; the unchanged fixture catches it under sanitizers.',binary_sha256=sha(OUT/'baseline-tests'))
save();print(json.dumps({k:report[k]for k in('completed','expected_regression','reason')}))
