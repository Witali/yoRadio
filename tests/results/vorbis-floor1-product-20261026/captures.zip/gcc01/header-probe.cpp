#include "native_vorbis_floor1_product.h"
#include <type_traits>
static_assert(sizeof(void*) == 4 && sizeof(long) == 4 && sizeof(size_t) == 4);
static_assert(sizeof(native_vorbis_affine_t) == 16);
using scale_type = native_vorbis_numeric_status_t (*)(const native_vorbis_residue_layout_t*, const uint32_t*, size_t, uint32_t, const uint8_t*, size_t, uint32_t*, size_t, native_vorbis_floor1_product_t*);
static_assert(std::is_same_v<decltype(&native_vorbis_floor1_scale), scale_type>);
extern "C" int floor1_product_header_probe(void) { return sizeof(native_vorbis_floor1_product_t); }
