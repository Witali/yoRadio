"""Source-only ILP32 C/C++ compatibility and own-stack records for LX6 and C3."""
import argparse, hashlib, json, subprocess, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--prepared', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
args = parser.parse_args()
prepared, out = args.prepared.resolve(), args.output.resolve()
assert prepared.is_relative_to(ROOT / '.build') and out.is_relative_to(ROOT / '.build') and not out.exists()
host = json.loads((prepared / 'report.json').read_bytes())
assert host['source_snapshot_only'] and host['host_assertions'] == 0
out.mkdir(parents=True)
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
components = prepared / 'sources/components'
includes = [components / name / 'include' for name in
    ('native_vorbis_numeric', 'native_vorbis_setup_owner', 'native_vorbis_packet_frame', 'native_vorbis_floor1_product')]
source = components / 'native_vorbis_floor1_product/floor1_product.c'
probe = out / 'header-probe.cpp'
probe.write_text('''#include "native_vorbis_floor1_product.h"
#include <type_traits>
static_assert(sizeof(void*) == 4 && sizeof(long) == 4 && sizeof(size_t) == 4);
static_assert(sizeof(native_vorbis_affine_t) == 16);
using scale_type = native_vorbis_numeric_status_t (*)(const native_vorbis_residue_layout_t*, const uint32_t*, size_t, uint32_t, const uint8_t*, size_t, uint32_t*, size_t, native_vorbis_floor1_product_t*);
static_assert(std::is_same_v<decltype(&native_vorbis_floor1_scale), scale_type>);
extern "C" int floor1_product_header_probe(void) { return sizeof(native_vorbis_floor1_product_t); }
''', encoding='ascii', newline='\n')
profiles = {
    'esp32-lx6': (ROOT.parent.parent / '.idf/tools-v6.0.2/tools/xtensa-esp-elf/esp-15.2.0_20251204/xtensa-esp-elf/bin/xtensa-esp32-elf-gcc.exe', []),
    'esp32-c3': (ROOT.parent.parent / '.idf/tools-v6.1/tools/riscv32-esp-elf/esp-15.2.0_20251204/riscv32-esp-elf/bin/riscv32-esp-elf-gcc.exe', ['-march=rv32imc', '-mabi=ilp32'])}
report = dict(completed=False, commands=[], profiles={}, inputs={str(source):sha(source), str(probe):sha(probe)},
    source_snapshot_report_sha256=sha(prepared / 'report.json'), source_only=True, SDK_build=False,
    target_executed=False, production_build=False, whole_call_chain_stack_qualified=False)
def save():
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
def run(name, argv):
    row = dict(name=name, argv=list(map(str,argv)))
    report['commands'].append(row)
    save()
    child, started = None, time.monotonic()
    try:
        with (out / (name + '.stdout.log')).open('xb') as stdout, (out / (name + '.stderr.log')).open('xb') as stderr:
            child = subprocess.Popen(row['argv'], cwd=out, stdin=subprocess.DEVNULL,
                stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
            row['pid'] = child.pid
            row['returncode'] = child.wait(timeout=60)
    finally:
        if child is not None and child.poll() is None:
            child.kill()
            child.wait(timeout=5)
            row['forced_stop'] = True
        row['elapsed_seconds'] = time.monotonic()-started
        for stream in ('stdout','stderr'):
            row[stream+'_sha256'] = sha(out / (name+'.'+stream+'.log'))
        save()
    assert row['returncode'] == 0 and not row.get('forced_stop')
for name, (compiler, flags) in profiles.items():
    folder = out / name
    folder.mkdir()
    report['profiles'][name] = dict(compiler_sha256=sha(compiler), flags=flags, objects={})
    run(name+'-version', [compiler,'--version'])
    run(name+'-machine', [compiler,'-dumpmachine'])
    run(name+'-macros', [compiler,*flags,'-dM','-E','-x','c','-'])
    macros = (out / (name+'-macros.stdout.log')).read_text()
    assert '#define __SIZEOF_POINTER__ 4\n' in macros and '#define __SIZEOF_LONG__ 4\n' in macros
    assert ('#define __XTENSA__ 1\n' in macros) if name == 'esp32-lx6' else ('#define __riscv_xlen 32\n' in macros)
    common = [str(compiler),*flags,'-O2','-fno-inline','-UNDEBUG','-fno-fast-math',
        '-ffp-contract=off','-fstack-usage','-Wall','-Wextra','-Werror',*['-I'+str(path) for path in includes]]
    for stem, unit, language in (('product',source,'gnu17'),('header',probe,'c++17')):
        obj = folder / (stem+'.o')
        run(name+'-'+stem,[*common,'-std='+language,'-c',str(unit),'-o',str(obj)])
        body = obj.read_bytes()
        assert body[:6] == b'\x7fELF\x01\x01' and int.from_bytes(body[16:18],'little') == 1
        records = []
        for line in obj.with_suffix('.su').read_text().splitlines():
            site, count, kind = line.split('\t')
            records.append(dict(function=site.rsplit(':',1)[-1], own_frame_bytes=int(count), kind=kind))
        assert records and all(row['kind']=='static' for row in records)
        report['profiles'][name]['objects'][stem] = dict(sha256=sha(obj), machine=int.from_bytes(body[18:20],'little'),
            stack_sha256=sha(obj.with_suffix('.su')), own_function_frames=records)
        save()
assert all(sha(path)==digest for path,digest in report['inputs'].items())
report['completed'] = True
save()
print(json.dumps(dict(completed=True, profiles=report['profiles'], target_executed=False)))
