/mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-floor1-frame-host-20261026-02/objects/05.o: \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-floor1-frame-host-20261026-02/sources/components/native_vorbis_numeric/residue.c \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-floor1-frame-host-20261026-02/sources/components/native_vorbis_numeric/include/native_vorbis_residue.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-floor1-frame-host-20261026-02/sources/components/native_vorbis_numeric/include/native_vorbis_setup.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-floor1-frame-host-20261026-02/sources/components/native_vorbis_numeric/include/native_vorbis_codebook.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-floor1-frame-host-20261026-02/sources/components/native_vorbis_numeric/include/native_vorbis_quant.h \
 /mnt/c/Work/yoRadio/.worktree/esp32-cyd-c3-review/.build/vorbis-floor1-frame-host-20261026-02/sources/components/native_vorbis_numeric/include/native_vorbis_floor0.h
