import hashlib,importlib.util,json,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[1];h=lambda b:hashlib.sha256(b).hexdigest()
source=R/'tests/test-vorbis-pcm-pair.py'
spec=importlib.util.spec_from_file_location('root_pcm_pair_reader',source);reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
final=R/'.build/vorbis-pcm-pair-host-20261028-04';report=json.loads((final/'report.json').read_bytes())
capture=(final/'capture.bin').read_bytes();model=reader.rows();measured=reader.compare(capture,model)
damaged=reader.corruption_controls(capture,model);anchors=reader.fraction_anchors()
assert report['passed'] and report['completed'] and measured==report['measurement']
assert damaged==report['corruption_controls'] and anchors==report['fraction_anchors']
for name,pin in report['inputs'].items():
    assert h((R/name).read_bytes())==pin['sha256']==h((final/pin['snapshot']).read_bytes())
for row in report['commands']:
    s=row['supervisor'];assert row['transport_exit']==0 and s['state']=='terminal' and s['child_returncode']==0 and s['child_reaped'] and s['group_gone']
out=R/'tests/results/vorbis-pcm-pair-20261028';out.mkdir(exist_ok=False)
entries={};groups=[(f'host{i:02}',R/f'.build/vorbis-pcm-pair-host-20261028-{i:02}') for i in range(1,5)]
groups += [(f'profiles{i:02}',R/f'.build/vorbis-pcm-pair-profiles-20261028-{i:02}') for i in range(1,3)]
for label,folder in groups:
    for path in sorted(folder.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:continue
        rel=path.relative_to(folder)
        if label.startswith('host') and (rel.parts[0]=='objects' or path.name=='pcm-pair'):continue
        entries[label+'/'+rel.as_posix()]=path.read_bytes()
    for suffix in ['.outer.json','.outer.stdout.log','.outer.stderr.log']:
        path=folder.with_name(folder.name+suffix)
        if path.is_file():entries['outer/'+label+suffix]=path.read_bytes()
entries['tools/profile.py']=(R/'.build/vorbis-pcm-pair-profiles-20261028.py').read_bytes()
entries['tools/package.py']=Path(__file__).read_bytes()
archive=out/'captures.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,body in sorted(entries.items()):
        info=zipfile.ZipInfo(name,(2026,10,28,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,body)
manifest=dict(archive_sha256=h(archive.read_bytes()),archive_bytes=archive.stat().st_size,final_group='host04',
    files=[dict(path=name,bytes=len(body),sha256=h(body)) for name,body in sorted(entries.items())])
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
replay=dict(passed=True,members=len(entries),reader_sha256=h(source.read_bytes()),measurements=measured,
    fraction_anchors=anchors,corruption_controls=damaged,archived_code_executed=False,files_extracted=False,
    commands_reexecuted=0,native_executed=False)
(out/'replay.json').write_text(json.dumps(replay,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(passed=True,members=len(entries),archive_bytes=archive.stat().st_size,
    uncompressed_bytes=sum(map(len,entries.values())),archive_sha256=manifest['archive_sha256'],
    manifest_sha256=h((out/'manifest.json').read_bytes()),measurements=measured)))
