#include "native_vorbis_pcm.h"
extern "C" auto pcm_api_probe() -> decltype(&native_vorbis_pcm_s16_pair) { return &native_vorbis_pcm_s16_pair; }
