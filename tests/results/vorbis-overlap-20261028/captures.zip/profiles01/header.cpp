#include "native_vorbis_overlap.h"
extern "C" auto overlap_api_probe() -> decltype(&native_vorbis_overlap_push) { return &native_vorbis_overlap_push; }
