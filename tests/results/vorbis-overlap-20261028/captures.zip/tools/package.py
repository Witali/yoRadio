import hashlib,importlib.util,json,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[1]
h=lambda b:hashlib.sha256(b).hexdigest()
path=R/'tests/test-vorbis-overlap.py'
spec=importlib.util.spec_from_file_location('root_overlap_replay',path);reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
final=R/'.build/vorbis-overlap-host-20261028-03';report=json.loads((final/'report.json').read_bytes())
body=(final/'capture.bin').read_bytes();measured=reader.inspect_capture(body);damaged=reader.corruption_controls(body)
assert report['completed'] and report['passed'] and measured==report['measurements'] and damaged==report['corruption_controls']
for name,digest in report['sources'].items():assert h((final/'sources'/name).read_bytes())==digest
for name in ['overlap.c','include/native_vorbis_overlap.h']:
    assert (R/'idf/components/native_vorbis_overlap'/name).read_bytes()==(final/'sources/components/native_vorbis_overlap'/name).read_bytes()
for row in report['commands']:
    s=row['supervisor'];assert row['transport_exit']==0 and s['state']=='terminal' and s['child_returncode']==0 and s['child_reaped'] and s['group_gone']
out=R/'tests/results/vorbis-overlap-20261028';out.mkdir(exist_ok=False)
entries={}
groups=[(f'host{i:02}',R/f'.build/vorbis-overlap-host-20261028-{i:02}') for i in range(1,4)]
groups += [('profiles01',R/'.build/vorbis-overlap-profiles-20261028-01'),('fixture-lint01',R/'.build/vorbis-overlap-fixture-lint-20261028-01')]
for label,folder in groups:
    assert folder.is_dir()
    for source in sorted(folder.rglob('*')):
        if not source.is_file() or '__pycache__' in source.parts:continue
        relative=source.relative_to(folder)
        if label.startswith('host') and (relative.parts[0]=='objects' or source.name=='overlap'):continue
        entries[label+'/'+relative.as_posix()]=source.read_bytes()
    for suffix in ['.outer.json','.outer.stdout.log','.outer.stderr.log']:
        source=folder.with_name(folder.name+suffix)
        if source.is_file():entries['outer/'+label+suffix]=source.read_bytes()
for name in ['profile-vorbis-overlap-20261028.py','lint-vorbis-overlap-fixture-20261028-01.py']:
    source=R/'.build'/name
    if source.is_file():entries['tools/'+name]=source.read_bytes()
entries['tools/package.py']=Path(__file__).read_bytes()
archive=out/'captures.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,body in sorted(entries.items()):
        info=zipfile.ZipInfo(name,(2026,10,28,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,body)
manifest=dict(archive_sha256=h(archive.read_bytes()),archive_bytes=archive.stat().st_size,final_group='host03',
    files=[dict(path=name,bytes=len(body),sha256=h(body)) for name,body in sorted(entries.items())])
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
replay=dict(passed=True,members=len(entries),reader_sha256=h(path.read_bytes()),measurements=measured,
    corruption_controls=damaged,archived_code_executed=False,files_extracted=False,commands_reexecuted=0,
    native_executed=False,full_range_PCM_qualified=False)
(out/'replay.json').write_text(json.dumps(replay,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(passed=True,members=len(entries),archive_bytes=archive.stat().st_size,
    uncompressed_bytes=sum(map(len,entries.values())),archive_sha256=manifest['archive_sha256'],
    manifest_sha256=h((out/'manifest.json').read_bytes()),measurements=measured)))
