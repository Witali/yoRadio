import hashlib,json,os,re,shutil,struct,subprocess,time
from pathlib import Path
R=Path(__file__).resolve().parents[1]
O=R/'.build/vorbis-overlap-profiles-20261028-01';O.mkdir(exist_ok=False)
S=O/'sources';S.mkdir()
components=['native_vorbis_numeric','native_vorbis_packet_frame','native_vorbis_floor1_product',
    'native_vorbis_transform','native_vorbis_window','native_vorbis_overlap']
for name in components:shutil.copytree(R/'idf/components'/name,S/name)
incs=['-I'+str(S/name/'include') for name in components]
h=lambda b:hashlib.sha256(b).hexdigest()
report=dict(completed=False,passed=False,commands=[],objects=[],lint=[],sources={
    p.relative_to(S).as_posix():h(p.read_bytes()) for p in S.rglob('*') if p.is_file()})
def save():(O/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(name,argv):
    row=dict(name=name,argv=list(map(str,argv)));report['commands'].append(row);save();start=time.monotonic()
    with (O/(name+'.stdout.log')).open('xb') as so,(O/(name+'.stderr.log')).open('xb') as se:
        child=subprocess.Popen(argv,cwd=R,stdin=subprocess.DEVNULL,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid']=child.pid
        try:row['returncode']=child.wait(timeout=45)
        except BaseException:
            subprocess.run(['taskkill.exe','/PID',str(child.pid),'/T','/F'],capture_output=True,timeout=10,creationflags=subprocess.CREATE_NO_WINDOW)
            child.wait(timeout=10);raise
    row.update(elapsed_seconds=time.monotonic()-start,stdout_sha256=h((O/(name+'.stdout.log')).read_bytes()),
        stderr_sha256=h((O/(name+'.stderr.log')).read_bytes()));save()
    assert row['returncode']==0,name
    return (O/(name+'.stdout.log')).read_text('utf-8',errors='replace')+(O/(name+'.stderr.log')).read_text('utf-8',errors='replace')
try:
    probe=O/'header.cpp';probe.write_text('#include "native_vorbis_overlap.h"\nextern "C" auto overlap_api_probe() -> decltype(&native_vorbis_overlap_push) { return &native_vorbis_overlap_push; }\n',encoding='utf-8',newline='\n')
    T=Path('C:/Work/yoRadio/.idf')
    profiles=[('lx6',T/'tools-v6.0.2/tools/xtensa-esp-elf/esp-15.2.0_20251204/xtensa-esp-elf/bin/xtensa-esp32-elf-gcc.exe',[]),
        ('rv32',T/'tools-v6.1/tools/riscv32-esp-elf/esp-15.2.0_20251204/riscv32-esp-elf/bin/riscv32-esp-elf-gcc.exe',['-march=rv32imc','-mabi=ilp32'])]
    for name,gcc,extra in profiles:
        run(name+'-version',[str(gcc),'--version'])
        for unit,source,language in [('overlap',S/'native_vorbis_overlap/overlap.c','c'),('header',probe,'c++')]:
            compiler=gcc if language=='c' else gcc.with_name(gcc.name.replace('-gcc.exe','-g++.exe'))
            obj=O/(name+'-'+unit+'.o')
            run(name+'-'+unit,[str(compiler),*extra,'-O2','-fno-inline','-fno-fast-math','-ffp-contract=off',
                '-fstack-usage','-Wall','-Wextra','-Werror','-std=gnu17' if language=='c' else '-std=gnu++17',
                *incs,'-c',str(source),'-o',str(obj)])
            body=obj.read_bytes();assert body[:5]==b'\x7fELF\x01'
            report['objects'].append(dict(name=obj.name,sha256=h(body),machine=struct.unpack_from('<H',body,18)[0]))
    tidy=T/'tools-v6.0.2/tools/esp-clang/esp-20.1.1_20250829/esp-clang/bin/clang-tidy.exe'
    config=O/'clang-tidy.yaml';config.write_bytes((R/'.clang-tidy').read_bytes())
    text=run('lint-overlap',[str(tidy),str(S/'native_vorbis_overlap/overlap.c'),'--config-file='+str(config),
        '--header-filter=.*','--export-fixes='+str(O/'overlap.yaml'),'--','--target=xtensa-esp-elf','-mcpu=esp32',
        '-std=gnu17','-O2','-UNDEBUG','-fno-fast-math','-ffp-contract=off','-nostdinc','-isystem',
        str(tidy.parent.parent/'lib/clang/20/include'),'-isystem',
        str(T/'tools-v6.0.2/tools/xtensa-esp-elf/esp-15.2.0_20251204/xtensa-esp-elf/picolibc/include'),*incs])
    report['lint']=[dict(unit='overlap',warnings=len(re.findall(r': warning:',text)),errors=len(re.findall(r': error:',text)))]
    assert not report['lint'][0]['errors']
    report['stack_records']={p.name:p.read_text('utf-8') for p in O.glob('*.su')}
    for name,digest in report['sources'].items():assert h((S/name).read_bytes())==digest
    report.update(completed=True,passed=True);save()
    print(json.dumps(dict(passed=True,commands=len(report['commands']),objects=report['objects'],lint=report['lint'],stack_records=report['stack_records'])))
except BaseException as e:report['error']=repr(e);save();raise
