#include "native_vorbis_bigfloat.h"
static_assert(LIMB_BITS == 32, "MCU limb width must be 32");
static_assert(sizeof(void *) == 4, "MCU pointer width must be 32");
static_assert(sizeof(limb_t) == 4, "MCU limb storage must be 32");
native_vorbis_bigfloat_status_t profile_header_smoke(
    native_vorbis_bigfloat_context_t *context, bf_t *destination) {
    return native_vorbis_bigfloat_set_u64(context, destination, 0);
}
