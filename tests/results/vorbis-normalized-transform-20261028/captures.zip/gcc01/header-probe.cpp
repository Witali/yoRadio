#include "native_vorbis_transform.h"
#include <type_traits>
static_assert(sizeof(void*) == 4 && sizeof(long) == 4 && sizeof(size_t) == 4);
static_assert(sizeof(native_vorbis_affine_t) == 16);
using transform_type = native_vorbis_numeric_status_t (*)(const native_vorbis_imdct_plan_t*, const native_vorbis_floor1_product_t*, size_t, double*, size_t, native_vorbis_transform_block_t*);
static_assert(std::is_same_v<decltype(&native_vorbis_imdct_transform), transform_type>);
using binary64_type = native_vorbis_numeric_status_t (*)(const native_vorbis_imdct_plan_t*, const native_vorbis_transform_block_t*, size_t, double*, size_t, native_vorbis_transform_block_t*);
static_assert(std::is_same_v<decltype(&native_vorbis_imdct_transform_binary64), binary64_type>);
static_assert(std::is_same_v<decltype(native_vorbis_transform_block_t{}.exponent), int64_t>);
extern "C" int transform_header_probe(void) { return sizeof(native_vorbis_transform_block_t); }
