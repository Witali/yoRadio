from pathlib import Path
import datetime as dt,gzip,hashlib,json
root=Path.cwd();parity=root/'Small_TV/qemu/parity';full=Path('C:/Work/yoRadio/.build/small-tv-functional/jpeg-selector-complete-full-20261019');run=root/'.build/jpeg-selector-h10-20261019'
read=lambda f:json.loads(f.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
freeze=read(parity/'jpeg-selector-complete-full-start-20261019.json')
for row in freeze['tests']:assert sha((root/row['file']).read_bytes())==row['sha256'],row['file']
for row in freeze['extra_inputs']:
    base=root if row['root']=='yoRadio' else Path(freeze['qemu_root'])
    assert sha((base/row['file']).read_bytes())==row['sha256'],row['file']
assert len(freeze['tests'])+len(freeze['extra_inputs'])==581
os_record=read(parity/'b50d-stopped-os-20261020.json');analysis=read(parity/'b50d-h10-interrupted-analysis-20261020.json')
assert os_record['all_original_identities_absent'] and not os_record['observed_processes']
assert analysis['inputs_verified']==32 and analysis['complete_cycles_audited']==179 and analysis['pending_events']==5
assert analysis['checks']['start_record_matches'] and not analysis['checks']['workload_complete'] and not analysis['h10_checks_passed']
assert not (full/'controller-exit.json').exists() and not (full/'report.json').exists()
for name in ('b50d-stopped-os-20261020.json','b50d-h10-interrupted-analysis-20261020.json'):
    f=parity/name;f.write_text(json.dumps(read(f),indent=2)+'\n',encoding='utf-8',newline='\n')
raw=parity/'b50d-interrupted-20261020-raw';raw.mkdir(exist_ok=False);artifacts=[]
def archive(path,label):
    data=path.read_bytes();target=raw/(label+'.gz');packed=gzip.compress(data,mtime=0);target.write_bytes(packed)
    artifacts.append(dict(file=target.relative_to(parity).as_posix(),sha256=sha(packed),raw_sha256=sha(data),raw_bytes=len(data)))
reports=[]
for f in sorted(full.rglob('report.json')):
    record=read(f);reports.append(dict(file=f.relative_to(full).as_posix(),passed=record.get('passed'),status=record.get('status')))
    archive(f,'full-'+f.relative_to(full).as_posix().replace('/','__'))
assert len(reports)==32 and all(v['passed'] is True for v in reports)
for f in sorted(full.glob('*.json')):archive(f,'full-root-'+f.name)
for f in sorted(full.glob('*.log')):archive(f,'full-root-'+f.name)
for name in ('events.jsonl','report.json','uptime-guard.json','vm/session.json','vm/uart.log','vm/qemu.log'):
    archive(run/name,'runtime-'+name.replace('/','__'))
archive(Path(str(run)+'-supervisor')/'supervisor.json','runtime-supervisor.json')
archive(Path(str(run)+'-launch.json'),'runtime-launch.json')
for name in ('jpeg-selector-complete-full-start-20261019.json','jpeg-selector-h10-start-20261019.json',
             'jpeg-selector-h10-audit-start-20261019.json','jpeg-selector-baseline-launch-checkpoint-20261019.json',
             'b50d-stopped-os-20261020.json','b50d-h10-interrupted-analysis-20261020.json'):
    archive(parity/name,name)
archive(Path(__file__),'capture-script.py')
record=dict(schema_version=1,captured_utc=dt.datetime.now(dt.timezone.utc).isoformat(),all_functionality_verified=False,
    status='stopped_without_terminal_evidence',app_sha256=freeze['app_sha256'],native_elf_sha256=freeze['elf_sha256'],qemu_sha256=freeze['qemu_sha256'],
    full=dict(complete=False,inputs_verified=581,partial_passed_subreports=reports,terminal_controller_missing=True,final_report_missing=True),
    runtime=dict(complete=False,h10_checks_passed=False,inputs_verified=32,periodic_report_cycles=read(run/'report.json')['completed_cycles'],
                 complete_journal_cycles=179,pending_events=5,elapsed_guest_seconds=analysis['elapsed_guest_seconds_observed'],terminal_guard_missing=True),
    interruption_cause='unknown',os_identities_absent=True,host_reboot_between_run_and_capture=False,
    evidence=artifacts,scope='Interrupted B50D/D64 full and H10 prefixes only. No full/24h/physical/firmware-failure acceptance. Stale running records retained unchanged.')
(parity/'b50d-interrupted-20261020.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print('B50D preserved: 581 full inputs, 32 passing partial subreports; 179 complete runtime cycles +5pending; raw files',len(artifacts))
