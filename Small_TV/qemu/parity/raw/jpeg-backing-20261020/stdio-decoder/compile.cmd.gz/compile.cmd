@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
cd /d "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-backing-20261020\stdio-decoder"
where cl > compiler-path.txt
cl /nologo /std:c11 /O2 /W4 /WX /MT /DJPEG_STATIC /D_CRT_SECURE_NO_WARNINGS /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\codec" /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\app\include" /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-coefficients-20261020\nor-final\source\src" /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-coefficients-20261020\nor-final\library" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\codec\jpeg_decoder.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\codec\jpeg_memory.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\app\media\color_convert.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\tests\jpeg_decoder\driver.c" /Fe"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-backing-20261020\stdio-decoder\jpeg_decoder_test.exe" /link "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-coefficients-20261020\nor-final\library\jpeg-static.lib"
exit /b %errorlevel%
