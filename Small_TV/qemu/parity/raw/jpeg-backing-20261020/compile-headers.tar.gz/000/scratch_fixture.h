/* Real validated allocation; physical flash contents are a host model. */
#define SCRATCH_LOGICAL_BYTES 460800u
static const jpeg_nor_extent_t scratch_extents[]={
    {0x187000u,462848u},
};
#define SCRATCH_EXTENT_COUNT ((unsigned)(sizeof(scratch_extents)/sizeof(scratch_extents[0])))
