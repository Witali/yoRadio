@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
cd /d "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-backing-20261020\native-final"
where cl > compiler-path.txt
cl /nologo /std:c11 /O2 /W4 /WX /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-backing-20261020\native-final" /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\codec" /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\storage" /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\tests\jpeg_scratch" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\codec\jpeg_backing.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\codec\jpeg_coefficients.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\storage\jpeg_scratch.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\storage\jpeg_nor.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\tests\jpeg_backing\native_test.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\tests\jpeg_scratch\nor_model.c" /Fe"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-backing-20261020\native-final\backing_test.exe"
exit /b %errorlevel%
