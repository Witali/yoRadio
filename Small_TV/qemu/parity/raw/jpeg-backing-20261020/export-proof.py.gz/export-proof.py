"""Archive exact completed decoder/NOR evidence, keeping raw failed stages."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
PARITY=ROOT/'Small_TV/qemu/parity';DEST=PARITY/'raw/jpeg-backing-20261020'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=[]


def add_data(name,data):
    """Retain exact uncompressed hashes as well as deterministic gzip hashes."""
    path=DEST/(name+'.gz');assert not path.exists(),path;path.parent.mkdir(parents=True,exist_ok=True)
    packed=gzip.compress(data,compresslevel=9,mtime=0);path.write_bytes(packed)
    raw.append(dict(file=path.relative_to(PARITY).as_posix(),sha256=sha(packed),bytes=len(packed),uncompressed_sha256=sha(data),uncompressed_bytes=len(data)))


def add(path,name=None):
    """Do not alter original logs or binaries while publishing evidence."""
    add_data(name or path.relative_to(BASE).as_posix(),path.read_bytes())


contract=read(BASE/'decoder-contract-checked/report.json');stdio=read(BASE/'stdio-contract/report.json')
native=read(BASE/'native-final/report.json');mutants=read(BASE/'mutations-final/report.json');target=read(BASE/'qemu-final/report.json')
assert all(x['passed'] for x in (contract,stdio,native,mutants,target))
assert {k:len(contract[k]) for k in ('positive','limits','negative','faults','stops','transitions')}==dict(positive=61,limits=7,negative=10,faults=827,stops=48,transitions=12)
assert len(stdio['faults'])==1197 and len(mutants['cases'])==6 and native['checks']==15273
assert len(target['boots'])==2 and all(b['owners_stopped'] for b in target['boots'])
probe_owners=read(BASE/'probe-owners.json');assert probe_owners['all_stopped'] and len(probe_owners['owned_pids'])==4 and not probe_owners['alive']
assert all(next(r for r in b['events'] if r['event']=='complete')['cases']==7 for b in target['boots'])
assert 'Ran 16 tests' in (BASE/'existing-gates.log').read_text(encoding='utf-8-sig')
compile_inputs={}
for folder in ('native-final','host-decoder-bounded','stdio-decoder','target'):
    for name,h in read(BASE/folder/'inputs.json').items():
        assert sha(Path(name).read_bytes())==h,name;compile_inputs[name]=h
for report in (contract,mutants):
    assert report['inputs_unchanged']
    assert all(sha(Path(p).read_bytes())==h for p,h in report['inputs_sha256'].items())
assert target['frozen_inputs_unchanged'] and target['build_inputs_unchanged']
plan=read(BASE/'target/resources/plan.json')
for boot in target['boots']:
    before,after=[(BASE/'qemu-final/flash-images'/(boot[k]+'.bin')).read_bytes() for k in ('initial_flash_sha256','final_flash_sha256')]
    assert sha(before)==boot['initial_flash_sha256'] and sha(after)==boot['final_flash_sha256']
    assert len(before)==len(after)==0x400000
    changed=[i for i,(a,b) in enumerate(zip(before,after)) if a!=b]
    assert len(changed)==boot['changed_bytes']
    assert all(any(r['offset']<=i<r['offset']+r['bytes'] for r in plan['backing']['extents']) for i in changed)
assert sha((BASE/'target/small_tv_jpeg_decoder_probe.elf').read_bytes())==target['elf_sha256']
archive=ROOT/'firmware/development/small-tv-jpeg-decoder-probe';manifest=read(archive/'manifest.json')
assert all(sha((archive/r['file']).read_bytes())==r['sha256'] for r in manifest['images'])
main=ROOT/'firmware/development/small-tv-esp32c2-reconstructed/app.bin'
old_probe=ROOT/'firmware/development/small-tv-storage-probe/app.bin'
assert sha(main.read_bytes())=='3e030c1cc5f7b456fefc9985c397daf8340c33d1bb2805965b076147a07cd7e1'
assert sha(old_probe.read_bytes())=='6cb297718cb657bb91443cbaf8a345b0ab2091d60b55a1669a08b4d12b5ac944'
owners=read(BASE/'h10-owners.json');times={22184:'09:27:35.206623',32636:'09:27:35.684696',20772:'09:27:35.711979',32580:'09:27:41.510965',18268:'09:28:10.414044',14972:'09:28:10.447191'}
assert {r['ProcessId'] for r in owners}==set(times)
assert all(datetime.fromisoformat(r['CreationDate']).astimezone(timezone.utc)==datetime.fromisoformat('2026-10-20T'+times[r['ProcessId']]+'+00:00') for r in owners)
assert not (BASE/'sdk-status.txt').read_text(encoding='utf-8-sig').strip()
frozen_root=Path('C:/Work/yoRadio/.worktree/small-tv-jpeg-selectors/.build/jpeg-selector-qemu-complete-20261019')
frozen=read(frozen_root/'frozen-inputs.json');assert len(frozen['files'])==46
assert all(sha((frozen_root/r['file']).read_bytes())==r['sha256'] for r in frozen['files'])
sources={Path(p) for p in compile_inputs if Path(p).is_relative_to(ROOT/'Small_TV/src')}
sources.update(p for p in (ROOT/'Small_TV/src/tests/jpeg_backing').rglob('*') if p.is_file())
source_sha={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted(sources)}
DEST.mkdir(parents=True,exist_ok=False)
for p in sorted(sources):add(p,'source/'+p.relative_to(ROOT).as_posix())
for folder in ('native-final','host-decoder-bounded','stdio-decoder','mutations-final'):
    for p in sorted((BASE/folder).rglob('*')):
        if p.is_file() and p.suffix in ('.json','.log','.cmd','.c','.h','.txt'):add(p)
for folder in ('decoder-contract-checked','stdio-contract','qemu-final'):
    add(BASE/folder/'report.json')
for p in sorted(BASE.glob('*.log')):add(p)
for name in ('inputs.json','size.txt','symbols.txt','sdkconfig','sdkconfig.defaults','compile_commands.json','CMakeCache.txt','small_tv_jpeg_decoder_probe.map','resources/jpeg_layout.h','resources/probe_fixture.h','resources/plan.json','small_tv_jpeg_decoder_probe.elf'):
    add(BASE/'target'/name)
for p in sorted((BASE/'target').rglob('*.su')):add(p)
for name in ('uart-0.log','uart-1.log','session-0.json','session-1.json','vm/qemu.log','vm/prepared.json','vm/session.json'):
    add(BASE/'qemu-final'/name)
for p in sorted((BASE/'qemu-final/flash-images').glob('*.bin')):add(p)
for name in ('report.json','uart-0.log','session-0.json','vm/session.json','vm/uart.log','vm/qemu.log'):
    add(BASE/'qemu'/name,'history/qemu-observer/'+name)
for folder in ('decoder-contract','decoder-contract-resources','decoder-contract-final','decoder-contract-pinned','mutations','native','host-decoder'):
    for name in ('report.json','build.json','inputs.json'):
        p=BASE/folder/name
        if p.exists():add(p,'history/'+folder+'/'+name)
    for p in sorted((BASE/folder).rglob('mutant.c')) if (BASE/folder).exists() else []:add(p,'history/'+p.relative_to(BASE).as_posix())
for name in ('h10-owners.json','probe-owners.json','sdk-status.txt','export-proof.py','qemu-observer-before-fix.py','native-test-before-first-use-stop.c','save-history.py'):add(BASE/name)
add(archive/'manifest.json','production-probe/manifest.json')
add(frozen_root/'frozen-inputs.json','old-h10-frozen-inputs.json')
headers=io.BytesIO()
with tarfile.open(fileobj=headers,mode='w') as bundle:
    for i,(name,h) in enumerate(sorted(compile_inputs.items())):
        p=Path(name)
        if p.suffix=='.h' and not p.is_relative_to(ROOT/'Small_TV/src'):
            data=p.read_bytes();info=tarfile.TarInfo(f'{i:03d}/'+p.name);info.size=len(data);bundle.addfile(info,io.BytesIO(data))
add_data('compile-headers.tar',headers.getvalue())
for name in ('LICENSE.md','README.ijg'):add(ROOT/'Small_TV/src/tests/jpeg_library_probe/licenses'/name,'upstream-licenses/'+name)
report=dict(schema_version=1,passed=True,all_functionality_verified=False,
    scope='Actual portable JPEG decoder + coefficient NOR adapter, host strict physical model and standalone ESP32-C2/ESP-IDF/QEMU execution. Native UI/HTTP/source/journal/durable RGB565 cache/workflow and total UI/Wi-Fi RAM, real hardware/endurance/final acceptance remain unverified.',
    source_sha256=source_sha,compile_inputs_sha256=compile_inputs,
    host_counts={k:len(contract[k]) for k in ('positive','limits','negative','faults','stops','transitions')},
    native=native,negative_controls=mutants['cases'],stdio_regression_counts={k:len(stdio[k]) for k in ('positive','limits','negative','faults','transitions')},
    host_traffic=contract['traffic'],target=target,probe_manifest=manifest,probe_owners=probe_owners,
    main_production=dict(unchanged=True,decoder='TJpgd',app_sha256=sha(main.read_bytes())),old_transport_probe=dict(unchanged=True,app_sha256=sha(old_probe.read_bytes())),
    existing_gates=dict(artifact=6,correspondence=10),sdk_tracked_clean=True,
    old_h10=dict(owners=owners,frozen_payloads=46,manifest_included=True,QMP_RSP_interaction=False),
    failed_test_expectations=['Rare4x4 12bit hits65536pool first,8bit hits524288backing; both before physical I/O. Correct measured causes asserted.','RAM-checkpoint mutant initially survived: added stopped first-use-sector write test. All6 final mutants rejected.','Initial host global-stop wrapper checked only logical calls; corrected test transport to check every physical pre/post call.','First target observer wrongly required changed bytes on replay. Actual second target passed all7 cases and produced identical physical bytes. Observer corrected to require initial changes/positive SDK traffic and compare every protected byte; fresh two-process run retained separately.'],
    required_remaining=['native source/upload privacy/journal/hash/durable RGB565 cache workflow with matching assets and photo/settings preservation',
        'UI integration, actual shared Wi-Fi/LCD heap/stack/time, error HTTP response and reset/power-loss tests',
        'independent network/LCD/full/24h/hardware acceptance and remaining factory/network/electrical audit'],raw_artifacts=raw)
path=PARITY/'jpeg-backing-validation-20261020.json';assert not path.exists();path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
for r in raw:
    data=(PARITY/r['file']).read_bytes();assert sha(data)==r['sha256'] and sha(gzip.decompress(data))==r['uncompressed_sha256']
print('Saved decoder/NOR proof:',len(source_sha),'sources,',len(raw),'raw artifacts;',sum(r['bytes'] for r in raw),'compressed bytes')
