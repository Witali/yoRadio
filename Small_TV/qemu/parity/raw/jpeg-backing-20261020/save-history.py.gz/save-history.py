"""Recover exact earlier observer/test sources by reversing the recorded edits."""
import hashlib
import json
from pathlib import Path

BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
path=ROOT/'Small_TV/src/tests/jpeg_backing/qemu_probe.py';text=path.read_text()
start=text.index('            # Preserve observations before assertions, including failed observers.\n')
end=text.index('            if previous is not None:assert previous==before\n',start)
text=text[:start]+text[end:]
start=text.index('            # FIXED_TEST: replaying identical coefficients may leave identical\n')
end=text.index("            rows=result['events'];complete=next",start)
text=text[:start]+"            assert changed and all(any(r['offset']<=i<r['offset']+r['bytes'] for r in ranges) for i in changed)\n"+text[end:]
text=text.replace("            assert next(r for r in cases if r['case']=='full-cmyk12')['program_bytes']>0\n",'')
text=text.replace("            result.update(passed=True,changed_bytes=len(changed));previous=after\n", "            result.update(changed_bytes=len(changed),initial_flash_sha256=sha(before),final_flash_sha256=sha(after))\n            report['boots'].append(result);previous=after\n            shutil.copyfile(args.output/'vm/uart.log',args.output/f'uart-{number}.log')\n            shutil.copyfile(args.output/'vm/session.json',args.output/f'session-{number}.json')\n")
data=text.encode();expected=json.loads((BASE/'qemu/report.json').read_text())['inputs_sha256'][str(path)]
assert hashlib.sha256(data).hexdigest()==expected
(BASE/'qemu-observer-before-fix.py').write_bytes(data)
path=ROOT/'Small_TV/src/tests/jpeg_backing/native_test.c';text=path.read_text()
start=text.index('    /* A stopped job must not clear even a previously untouched dirty sector. */\n')
end=text.index('\n}',start);text=text[:start]+text[end+1:]
data=text.encode();expected=json.loads((BASE/'native/inputs.json').read_text())[str(path)]
assert hashlib.sha256(data).hexdigest()==expected
(BASE/'native-test-before-first-use-stop.c').write_bytes(data)
print('Exact before-fix observer and pre-gap unit source hashes verified')
