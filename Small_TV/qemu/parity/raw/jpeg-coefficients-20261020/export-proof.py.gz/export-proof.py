import gzip,hashlib,io,json,tarfile
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
PARITY=ROOT/'Small_TV/qemu/parity'
DEST=PARITY/'raw/jpeg-coefficients-20261020'
DEST.mkdir(parents=True,exist_ok=False)
raw=[]
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))

def add_bytes(name,data):
    packed=gzip.compress(data,compresslevel=9,mtime=0);p=DEST/(name+'.gz')
    p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),p;p.write_bytes(packed)
    raw.append(dict(file=p.relative_to(PARITY).as_posix(),sha256=sha(packed),bytes=len(packed),
                    uncompressed_sha256=sha(data),uncompressed_bytes=len(data)))

def add(p,name=None):
    add_bytes(name or p.relative_to(BASE).as_posix(),p.read_bytes())

builds=[read(BASE/n/'build.json') for n in ('reference','nor-final')]
source_paths=set()
for b in builds:
    assert sha(Path(b['executable']).read_bytes())==b['executable_sha256']
    for name,h in b['probe_inputs'].items():
        p=(ROOT/'Small_TV/src/tests/jpeg_library_probe'/name).resolve()
        assert sha(p.read_bytes())==h,p;source_paths.add(p)
    assert all(sha(Path(p).read_bytes())==h for p,h in b['backing_fixture_inputs'].items())
native=read(BASE/'native/report.json');mutants=read(BASE/'mutations/report.json')
integration=read(BASE/'integration-mutants/report.json');traffic=read(BASE/'traffic-final/report.json')
qual=read(BASE/'qualification-final/report.json');tables=read(BASE/'tables-final/report.json')
independent=read(BASE/'independent-final/report.json');logical=read(BASE/'logical-final/report.json')
physical=read(BASE/'physical-final/report.json');rv32=read(BASE/'rv32/report.json')
artifacts=read(BASE/'artifacts.json')
assert native['passed'] and native['checks']==19726488
assert mutants['passed'] and len(mutants['cases'])==7
assert integration['passed'] and len(integration['cases'])==4
assert traffic['passed'] and len(traffic['cases'])==18
assert qual['status']=='host_qualification_passed' and len(qual['lossless_cases'])==924
assert tables['status']==independent['status']=='passed' and len(independent['cases'])==18
assert logical['status']=='host_fault_reuse_passed' and logical['fault_cases']==1227
assert physical['passed'] and physical['fault_cases']==1573 and physical['inputs_unchanged']
assert rv32['passed'] and rv32['inputs_unchanged'] and artifacts['passed'] and artifacts['cases']==6
for name in ('native/inputs.json','mutations/report.json','physical-final/report.json','rv32/report.json'):
    record=read(BASE/name);pins=record.get('inputs_sha256',record)
    for path,h in pins.items():
        assert sha(Path(path).read_bytes())==h,path
        p=Path(path)
        if p.is_relative_to(ROOT/'Small_TV/src'):source_paths.add(p)
for p in (ROOT/'Small_TV/src/tests/jpeg_coefficients').iterdir():
    if p.is_file():source_paths.add(p)
for n in ('qualify.py','flash_tables_contract.py','independent.py','fault_contract.py'):
    source_paths.add(ROOT/'Small_TV/src/tests/jpeg_library_probe'/n)
assert sha((ROOT/'Small_TV/src/tests/jpeg_coefficients/traffic_contract.py').read_bytes())==traffic['runner_sha256']
source_sha={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted(source_paths)}
for p in sorted(source_paths):add(p,'source/'+p.relative_to(ROOT).as_posix())
for folder in ('native','mutations','integration-mutants','rv32'):
    for p in sorted((BASE/folder).rglob('*')):
        if p.is_file() and p.suffix in ('.json','.txt','.c','.su','.log','.cmd','.o'):add(p)
for folder in ('reference','nor-final'):
    for name in ('build.json','probe/CMakeCache.txt','probe/build.ninja','library/CMakeCache.txt'):
        add(BASE/folder/name)
for folder in ('traffic-final','qualification-final','tables-final','independent-final','logical-final','physical-final'):
    add(BASE/folder/'report.json')
# Preserve successful earlier stages as history with their exact backing snapshot.
for name in ('nor/build.json','traffic/report.json','traffic-v2/report.json',
             'before-fresh-sectors.c','traffic-before-flat-controls.py'):
    add(BASE/name,'stages/'+name)
for p in sorted(BASE.glob('*.log')):add(p)
for name in ('artifacts.json','h10-owners.json','sdk-status.txt','measure-rv32.py','export-proof.py'):
    add(BASE/name)
add(ROOT/'.build/jpeg-coefficients-native.log','native-driver.log')
fixture_stream=io.BytesIO();fixtures=[]
with tarfile.open(fileobj=fixture_stream,mode='w') as archive:
    for folder in ('traffic-final','qualification-final','tables-final','independent-final','logical-final','physical-final'):
        for p in sorted((BASE/folder/'fixtures').glob('*.jpg')):
            data=p.read_bytes();name=p.relative_to(BASE).as_posix();info=tarfile.TarInfo(name);info.size=len(data)
            archive.addfile(info,io.BytesIO(data));fixtures.append(dict(file=name,sha256=sha(data),bytes=len(data)))
add_bytes('fixtures.tar',fixture_stream.getvalue())
frozen_root=Path('C:/Work/yoRadio/.worktree/small-tv-jpeg-selectors/.build/jpeg-selector-qemu-complete-20261019')
frozen=read(frozen_root/'frozen-inputs.json');assert len(frozen['files'])==46
assert all(sha((frozen_root/f['file']).read_bytes())==f['sha256'] for f in frozen['files'])
add(frozen_root/'frozen-inputs.json','h10-frozen-inputs.json')
owners=read(BASE/'h10-owners.json')
times={22184:'09:27:35.206623',32636:'09:27:35.684696',20772:'09:27:35.711979',
       32580:'09:27:41.510965',18268:'09:28:10.414044',14972:'09:28:10.447191'}
assert {x['ProcessId'] for x in owners}==set(times)
assert all(datetime.fromisoformat(x['CreationDate']).astimezone(timezone.utc)==
           datetime.fromisoformat('2026-10-20T'+times[x['ProcessId']]+'+00:00') for x in owners)
assert not (BASE/'sdk-status.txt').read_text(encoding='utf-8-sig').strip()
main=ROOT/'firmware/development/small-tv-esp32c2-reconstructed/app.bin'
probe=ROOT/'firmware/development/small-tv-storage-probe/app.bin'
assert sha(main.read_bytes())=='3e030c1cc5f7b456fefc9985c397daf8340c33d1bb2805965b076147a07cd7e1'
assert sha(probe.read_bytes())=='6cb297718cb657bb91443cbaf8a345b0ab2091d60b55a1669a08b4d12b5ac944'
assert 'Ran 10 tests' in (BASE/'correspondence.log').read_text(encoding='utf-8-sig')
example=next(x for x in traffic['cases'] if x['name']=='rich-cmyk-progressive-12')
assert example['raw']['first']['nor_program_bytes']==3780608 and example['packed']['first']['nor_program_bytes']==2582784
flat=next(x for x in traffic['cases'] if x['name']=='flat-cmyk-progressive-12')
report=dict(schema_version=1,passed=True,all_functionality_verified=False,
    scope='Reversible coefficient representation and first-use temporary-sector initialization, actual host libjpeg/NOR. Not enabled in native UI; no target codec execution/final link/whole RAM/stack/timing or final acceptance.',
    source_sha256=source_sha,codec_builds=builds,host=native,
    negative_controls=dict(converter=mutants['cases'],integration=integration['cases']),
    traffic_cases=traffic['cases'],example=example,flat_tradeoff=flat,
    qualification=dict(resource_cases=len(qual['resource_cases']),lossless_cases=len(qual['lossless_cases']),
        negative_cases=len(qual['negative_cases']),optional_controls=len(qual['optional_mode_controls']),
        budget_cases=len(qual['budget_sweep']),rich12_cases=48,truncated12_cases=12,table_entries=38912,
        independent_images=18,pillow_version=independent['pillow_version']),
    logical_faults=dict(cases=1227,damaged_input_recoveries=36,format_transitions=12),
    physical_faults=dict(cases=1573,small_exhaustive_callbacks=1345,full_size_sampled_cases=4,
        sampled_calls_each=57,same_object_recovery=True,partial_physical_data_retained=True,
        arbitrary_silent_read_integrity_claimed=False),rv32=rv32,
    host_backing_memory=dict(conversion_buffer_bytes=256,sector_bitmap_bytes=15,nor_cache_bytes=4096,
        whole_app_memory_measured=False),main_production=dict(unchanged=True,decoder='TJpgd',artifacts=artifacts),
    target_probe=dict(unchanged=True,app_sha256=sha(probe.read_bytes()),new_codec_executed=False),
    correspondence_controls=10,sdk_tracked_clean=True,old_h10=dict(owners=owners,frozen_payloads=46,
        frozen_manifest_included=True,interaction='Read-only file/process identity checks; no QMP/RSP'),
    required_remaining=['precise unsupported/invalid/resource/I/O error contract and resource preflight',
        'expanded legal sampling/capacity bounds; no universal JPEG fit claim',
        'actual native source/upload/journal/physical hashes/RGB565 cache/codec integration',
        'matching assets deployment preserving all photos/settings',
        'full target link/heap/task stack/time, HTTP/reset/LCD/network/full/24h/hardware',
        'remaining full factory-image audit, network lifecycle and electrical plan items'],
    fixtures=fixtures,raw_artifacts=raw)
path=PARITY/'jpeg-coefficients-validation-20261020.json';assert not path.exists()
path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
for x in raw:
    data=(PARITY/x['file']).read_bytes()
    assert sha(data)==x['sha256'] and sha(gzip.decompress(data))==x['uncompressed_sha256']
print('Saved coefficient proof:',len(source_sha),'source pins,',len(raw),'raw files,',len(fixtures),'fixtures,',sum(x['bytes'] for x in raw),'compressed bytes')
