@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
cd /d "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-coefficients-20261020\native"
where cl > compiler-path.txt
cl /nologo /std:c11 /O2 /W4 /WX /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\codec" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\tests\jpeg_coefficients\native_test.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\codec\jpeg_coefficients.c" /Fe"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-coefficients-20261020\native\jpeg_coefficients_test.exe"
exit /b %errorlevel%
