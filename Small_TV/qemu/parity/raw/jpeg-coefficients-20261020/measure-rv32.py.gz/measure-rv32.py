import hashlib,json,re,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'Small_TV/src/tests/jpeg_library_probe'))
from rv32_footprint import elf_sections
output=Path(__file__).resolve().parent/'rv32'
output.mkdir(exist_ok=False)
tool=Path('C:/Work/yoRadio/.idf/tools-v6.1/tools/riscv32-esp-elf/esp-15.2.0_20251204/riscv32-esp-elf')
gcc=tool/'bin/riscv32-esp-elf-gcc.exe';specs=tool/'riscv32-esp-elf/lib/picolibc.specs'
source=root/'Small_TV/src/codec/jpeg_coefficients.c'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={str(p):sha(p) for p in (source,source.with_suffix('.h'),gcc,specs,Path(__file__))}
command=[str(gcc),'-march=rv32imc_zicsr_zifencei','-mabi=ilp32','-mtune=esp-base','-Os',
    '-std=c11','-Wall','-Wextra','-Werror','-ffunction-sections','-fdata-sections','-fstack-usage',
    '-fno-jump-tables','-fno-tree-switch-conversion','-D__PICOLIBC_ERRNO_FUNCTION=__errno',
    '-specs='+specs.as_posix(),'-c',str(source),'-o',str(output/'coefficients.o')]
r=subprocess.run(command,capture_output=True,timeout=60)
(output/'compile.log').write_bytes(r.stdout+r.stderr)
assert r.returncode==0,r.stderr
frames={}
for line in (output/'coefficients.su').read_text().splitlines():
    m=re.search(r':\d+:\d+:([^:]+)\t(\d+)\t(.+)$',line);assert m and m[3]=='static',line
    frames[m[1]]=int(m[2])
assert all(sha(Path(p))==h for p,h in inputs.items())
report=dict(passed=True,runtime_tested=False,inputs_unchanged=True,inputs_sha256=inputs,
            command=command,sizes=elf_sections(output/'coefficients.o'),single_frames=frames,
            max_single_frame=max(frames.values()),object_sha256=sha(output/'coefficients.o'))
(output/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print('RV32 packing:',report['sizes']['code_bytes'],'code bytes; frame',report['max_single_frame'])
