/* Generated from the validated current native image, never a guessed FF scan. */
static const jpeg_nor_extent_t plan_allowed[] = {
    {0x187000u, 495616u},
    {0x290000u, 126976u},
    {0x2c9000u, 98304u},
    {0x2fb000u, 98304u},
    {0x340000u, 20480u},
    {0x35b000u, 114688u},
    {0x3ca000u, 118784u},
};
static const jpeg_nor_extent_t plan_extents_0[] = {
    {0x187000u, 462848u},
};
static const jpeg_nor_extent_t plan_extents_1[] = {
    {0x1f8000u, 8192u},
};
static const jpeg_nor_extent_t plan_extents_2[] = {
    {0x1fa000u, 24576u},
    {0x290000u, 94208u},
};
static const jpeg_nor_extent_t plan_extents_3[] = {
    {0x2a7000u, 32768u},
    {0x2c9000u, 86016u},
};
static const jpeg_nor_extent_t plan_extents_4[] = {
    {0x2de000u, 12288u},
    {0x2fb000u, 98304u},
    {0x340000u, 8192u},
};
static const jpeg_nor_extent_t plan_extents_5[] = {
    {0x342000u, 12288u},
    {0x35b000u, 106496u},
};
static const jpeg_nor_extent_t plan_extents_6[] = {
    {0x375000u, 8192u},
    {0x3ca000u, 110592u},
};
static const struct {const jpeg_nor_extent_t *extents; unsigned count; uint32_t logical_bytes;} plan_stores[] = {
    {plan_extents_0, 1u, 460800u},
    {plan_extents_1, 1u, 8192u},
    {plan_extents_2, 2u, 115200u},
    {plan_extents_3, 2u, 115200u},
    {plan_extents_4, 3u, 115200u},
    {plan_extents_5, 2u, 115200u},
    {plan_extents_6, 2u, 115200u},
};
