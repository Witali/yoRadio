#include "jpeg_nor.h"
const unsigned jpeg_nor_handle_bytes = sizeof(jpeg_nor_t);
const unsigned jpeg_nor_sector_bytes = JPEG_NOR_SECTOR_BYTES;