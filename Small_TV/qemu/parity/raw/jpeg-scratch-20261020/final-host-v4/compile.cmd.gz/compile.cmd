@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
cd /d "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-scratch-20261020\final-host-v4"
where cl > compiler-path.txt
cl /nologo /std:c11 /O2 /W4 /WX /D_CRT_SECURE_NO_WARNINGS /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-scratch-20261020\final-host-v4" /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\storage" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\tests\jpeg_scratch\native_test.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\tests\jpeg_scratch\nor_model.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\storage\jpeg_scratch.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\storage\jpeg_nor.c" /Fe"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-scratch-20261020\final-host-v4\jpeg_scratch_test.exe"
exit /b %errorlevel%
