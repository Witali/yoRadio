#include "jpeg_scratch.h"
const unsigned char scratch_handle_bytes[sizeof(jpeg_scratch_t)]={0};
const unsigned char file_token_bytes[sizeof(jpeg_scratch_file_t)]={0};
const unsigned char file_region_bytes[sizeof(jpeg_scratch_region_t)]={0};
