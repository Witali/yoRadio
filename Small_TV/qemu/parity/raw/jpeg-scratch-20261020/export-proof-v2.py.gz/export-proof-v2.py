import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / '.build/jpeg-scratch-20261020'
PARITY = ROOT / 'Small_TV/qemu/parity'
DEST = PARITY / 'raw/jpeg-scratch-20261020'
DEST.mkdir(parents=True, exist_ok=True)
records = []


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def add_bytes(label, data):
    path = DEST / (label + '.gz')
    path.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(data, compresslevel=9, mtime=0)
    if path.exists():
        assert path.read_bytes() == packed, path
    else:
        path.write_bytes(packed)
    records.append(dict(file=path.relative_to(PARITY).as_posix(), sha256=digest(packed), bytes=len(packed),
                        uncompressed_sha256=digest(data), uncompressed_bytes=len(data)))


def add(path, label=None):
    add_bytes(label or path.relative_to(BASE).as_posix(), path.read_bytes())


native = read(BASE / 'final-host-v4/report.json')
assert native['passed'] and native['checks'] == 16432 and native['random_operations'] == 5000 and native['fault_cases'] == 134
native_products = read(BASE / 'final-host-v4/products.json')
assert native_products['inputs_unchanged']
assert digest((BASE / 'final-host-v4/jpeg_scratch_test.exe').read_bytes()) == native_products['executable_sha256']
inputs = read(BASE / 'final-host-v4/inputs.json')
assert all(digest(Path(p).read_bytes()) == h for p, h in inputs.items())
builds = [read(BASE / x / 'build.json') for x in ('reference-v2', 'nor-v2')]
source_paths = set()
for b in builds:
    assert digest(Path(b['executable']).read_bytes()) == b['executable_sha256']
    for name, h in b['probe_inputs'].items():
        p = (ROOT / 'Small_TV/src/tests/jpeg_library_probe' / name).resolve()
        assert digest(p.read_bytes()) == h, p
        source_paths.add(p)
    assert all(digest(Path(p).read_bytes()) == h for p, h in b['backing_fixture_inputs'].items())
assert builds[0]['backing_backend'] == 'stdio' and builds[1]['backing_backend'] == 'shared-nor-model'
qualification = read(BASE / 'qualification/report.json')
tables = read(BASE / 'tables/report.json')
independent = read(BASE / 'independent/report.json')
logical = read(BASE / 'logical-faults/report.json')
physical = read(BASE / 'physical-faults/report.json')
mutants = read(BASE / 'mutations/report.json')
rv32 = read(BASE / 'rv32/report.json')
artifacts = read(BASE / 'artifact-report.json')
assert qualification['status'] == 'host_qualification_passed'
assert tables['status'] == independent['status'] == 'passed'
assert logical['status'] == 'host_fault_reuse_passed' and logical['fault_cases'] == 1227
assert physical['passed'] and physical['inputs_unchanged'] and physical['fault_cases'] == 2238
assert mutants['passed'] and mutants['inputs_unchanged'] and len(mutants['cases']) == 13
assert rv32['passed'] and rv32['inputs_unchanged']
assert artifacts['passed'] and artifacts['cases'] == 6
correspondence = (BASE / 'correspondence.log').read_text(encoding='utf-8-sig')
assert 'Ran 10 tests' in correspondence and 'OK' in correspondence
for paths in (inputs, mutants['inputs_sha256'], physical['inputs_sha256'], rv32['inputs_sha256']):
    for name, h in paths.items():
        p = Path(name)
        assert digest(p.read_bytes()) == h, p
        if p.is_relative_to(ROOT / 'Small_TV/src'):
            source_paths.add(p)
for p in (ROOT / 'Small_TV/src/tests/jpeg_scratch').iterdir():
    if p.is_file():
        source_paths.add(p)
source_paths |= {ROOT / 'Small_TV/src/tests/jpeg_library_probe' / n for n in
                 ('qualify.py', 'independent.py', 'flash_tables_contract.py', 'fault_contract.py')}
source_sha = {p.relative_to(ROOT).as_posix(): digest(p.read_bytes()) for p in sorted(source_paths)}
for p in sorted(source_paths):
    add(p, 'source/' + p.relative_to(ROOT).as_posix())

for folder in ('final-host-v4', 'rv32', 'mutations'):
    for p in sorted((BASE / folder).rglob('*')):
        if p.is_file() and p.suffix in ('.json', '.txt', '.h', '.c', '.su', '.log', '.cmd', '.o'):
            add(p)
for folder in ('reference-v2', 'nor-v2'):
    for name in ('build.json', 'probe/CMakeCache.txt', 'probe/build.ninja', 'library/CMakeCache.txt',
                 'source/src/jmemmgr.c', 'source/src/jmemsys.h'):
        add(BASE / folder / name)
for folder in ('qualification', 'tables', 'independent', 'logical-faults', 'physical-faults'):
    add(BASE / folder / 'report.json')
for p in sorted(BASE.glob('*.log')):
    add(p)
for name in ('artifact-report.json', 'old-h10-processes.json', 'sdk-status.txt',
             'before-counter-order.c', 'before-probe-include-fix.cmake'):
    add(BASE / name)
add(ROOT / '.build/jpeg-scratch-first.log', 'first-native-failure.log')
add_bytes('export-proof.py', gzip.decompress((DEST / 'export-proof.py.gz').read_bytes()))
add(Path(__file__), 'export-proof-v2.py')

# One deterministic tar retains every generated fixture without thousands of Git entries.
fixture_bytes = io.BytesIO()
fixture_entries = []
with tarfile.open(fileobj=fixture_bytes, mode='w') as tar:
    for folder in ('qualification', 'tables', 'independent', 'logical-faults', 'physical-faults'):
        for p in sorted((BASE / folder / 'fixtures').glob('*.jpg')):
            data = p.read_bytes()
            name = p.relative_to(BASE).as_posix()
            info = tarfile.TarInfo(name)
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
            fixture_entries.append(dict(file=name, sha256=digest(data), bytes=len(data)))
add_bytes('fixtures.tar', fixture_bytes.getvalue())

frozen_root = Path('C:/Work/yoRadio/.worktree/small-tv-jpeg-selectors/.build/jpeg-selector-qemu-complete-20261019')
frozen = read(frozen_root / 'frozen-inputs.json')
assert len(frozen['files']) == 46  # 46 pinned payloads plus the manifest itself
assert all(digest((frozen_root / p['file']).read_bytes()) == p['sha256'] for p in frozen['files'])
add(frozen_root / 'frozen-inputs.json', 'old-h10-frozen-inputs.json')
owners = read(BASE / 'old-h10-processes.json')
expected = {22184:'2026-10-20T09:27:35.206623+00:00', 32636:'2026-10-20T09:27:35.684696+00:00',
            20772:'2026-10-20T09:27:35.711979+00:00', 32580:'2026-10-20T09:27:41.510965+00:00',
            18268:'2026-10-20T09:28:10.414044+00:00', 14972:'2026-10-20T09:28:10.447191+00:00'}
assert {o['ProcessId'] for o in owners} == set(expected)
assert all(datetime.fromisoformat(o['CreationDate']).astimezone(timezone.utc) ==
           datetime.fromisoformat(expected[o['ProcessId']]) for o in owners)
assert not (BASE / 'sdk-status.txt').read_text(encoding='utf-8-sig').strip()
main = ROOT / 'firmware/development/small-tv-esp32c2-reconstructed/app.bin'
probe = ROOT / 'firmware/development/small-tv-storage-probe/app.bin'
assert digest(main.read_bytes()) == '3e030c1cc5f7b456fefc9985c397daf8340c33d1bb2805965b076147a07cd7e1'
assert digest(probe.read_bytes()) == '6cb297718cb657bb91443cbaf8a345b0ab2091d60b55a1669a08b4d12b5ac944'

traffic = [{**dict(name=c['name']), **{k:c['control']['result']['first'][k] for k in
            ('nor_calls','nor_read_bytes','nor_program_bytes','nor_erases','scratch_peak_bytes','library_pool_peak')}}
           for c in physical['cases']]
proof = dict(schema_version=1, passed=True, all_functionality_verified=False,
    scope='Portable shared scratch allocator plus actual libjpeg/NOR host bridge and physical fault recovery. Not native UI/target codec execution, production limits, full application link/memory/stack/time or final HTTP/LCD/full/24h/hardware acceptance.',
    source_sha256=source_sha, upstream_commit=builds[0]['upstream_commit'],
    upstream_archive_sha256=builds[0]['source_archive_sha256'],
    codec_builds=builds, host=native, host_products=native_products,
    negative_controls=dict(passed=True,cases=mutants['cases']),
    qualification=dict(resource_cases=len(qualification['resource_cases']),lossless_cases=len(qualification['lossless_cases']),
        negative_cases=len(qualification['negative_cases']),optional_controls=len(qualification['optional_mode_controls']),
        budget_cases=len(qualification['budget_sweep']),tables_status=tables['status'],
        independent_images=len(independent['cases']),pillow_version=independent['pillow_version']),
    logical_faults=dict(cases=logical['fault_cases'],damaged_input_recoveries=len(logical['damaged_input_recoveries']),
                        format_transitions=len(logical['format_transitions'])),
    physical_faults=dict(cases=physical['fault_cases'],first_small_image_callbacks_exhaustive=2010,
                        full_size_fixtures=4,sampled_callbacks_each=57,partial_io_errors=True,
                        same_object_recovery=True,physical_contents_preserved=True,
                        arbitrary_silent_read_integrity_claimed=False),
    traffic=traffic, rv32=rv32, main_production=dict(app_sha256=digest(main.read_bytes()),decoder='TJpgd',unchanged=True,artifacts=artifacts),
    target_transport_probe=dict(app_sha256=digest(probe.read_bytes()),unchanged=True,new_scratch_executed=False),
    correspondence_controls=10, fixtures=fixture_entries,
    early_failures=['native test order after monotonic ID exhaustion','NOR probe missing common hook include',
                    'Pillow missing from SDK Python; independent gate uses unchanged bundled runtime',
                    'artifact runner invoked without required --output'],
    old_h10=dict(original_owners=owners,frozen_files_verified=47,observation='Read-only process identity and file checks; no QMP/RSP interaction'),
    sdk_tracked_clean=True,
    required_remaining=['expanded legal sampling and coefficient allocation capacity beyond fixture maximum460800',
                        'production call/byte/erase/time budgets using actual target timing and full required modes',
                        'source/upload journal invalidation, physical source/frame hashes and persistent RGB565 cache',
                        'matching assets build/deployment preserving all photos/settings',
                        'bounded native codec integration, target execution/full link/heap/task stack/time',
                        'HTTP/reset persistence, independent LCD/network, full regression/24h and hardware gates',
                        'remaining network lifecycle, factory full-image audit and electrical/hardware plan items'],
    raw_artifacts=records)
path = PARITY / 'jpeg-scratch-validation-20261020.json'
assert not path.exists()
path.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
for item in records:
    data=(PARITY/item['file']).read_bytes()
    assert digest(data)==item['sha256'] and digest(gzip.decompress(data))==item['uncompressed_sha256']
print('Saved proof:',len(records),'raw artifacts,',len(fixture_entries),'fixtures,',len(source_sha),'source pins;',sum(r['bytes'] for r in records),'compressed bytes')
