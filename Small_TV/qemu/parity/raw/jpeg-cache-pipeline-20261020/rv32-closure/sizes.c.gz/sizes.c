#include "jpeg_cache.h"
const uint32_t jpeg_cache_sizes[]={sizeof(jpeg_cache_t),sizeof(jpeg_cache_layout_t),sizeof(jpeg_cache_devices_t),sizeof(jpeg_journal_t),sizeof(jpeg_nor_t)};
