"""Publish exact persistent cache evidence and the reproduced/fixed source bug."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
PARITY=ROOT/'Small_TV/qemu/parity';DEST=PARITY/'raw/jpeg-cache-pipeline-20261020'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
unit=read(BASE/'native-final/report.json');contract=read(BASE/'contract-closure/report.json')
mutants=read(BASE/'mutations/report.json');generator=read(BASE/'generator-contract-closure/report.json');rv=read(BASE/'rv32-closure/report.json')
assert all(r['passed'] for r in (unit,contract,mutants,generator,rv))
assert (unit['physical_fault_cases'],unit['hash_fault_cases'],unit['stop_cases'])==(12120,946,2424)
assert {k:len(contract[k]) for k in ('positive','limits','negative','faults','stops')}==dict(positive=59,limits=5,negative=6,faults=268,stops=18)
assert len(mutants['cases'])==9 and len(generator['rejections'])==10 and len(generator['sampling_generator_compatibility'])==2
assert rv['retained_sizes']==dict(code=9016,readonly=16,writable=0,bss=0) and rv['context_sizes']['cache_handle']==5600
assert 'Ran 16 tests' in (BASE/'existing-gates.log').read_text(encoding='utf-8-sig')
compile_inputs={}
for folder in ('native-final','decoder-closure','generator-flat'):
    for name,h in read(BASE/folder/'inputs.json').items():
        assert sha(Path(name).read_bytes())==h,name;compile_inputs[name]=h
for r in (mutants,generator,rv):
    assert r['inputs_unchanged']
    for name,h in r['inputs_sha256'].items():assert sha(Path(name).read_bytes())==h,name
    compile_inputs.update(r['inputs_sha256'])
assert contract['inputs_unchanged'] and all(sha(Path(p).read_bytes())==h for p,h in contract['inputs_sha256'].items())
before=read(BASE/'silent-before-proof/report.json');assert before['incorrect_cache_publication_found']
bad=next(r for r in before['cases'] if r['result']['first']['ready'] and r['result']['first_sha256']!=before['expected_rgb565_sha256'])
assert bad['ordinal']==378 and bad['result']['first_sha256']==bad['result']['cold_sha256']
before_inputs=read(BASE/'decoder-silent-before/inputs.json')
overrides={'storage/jpeg_cache.c':'before-bug-cache.c','storage/jpeg_cache.h':'before-bug-cache.h','tests/jpeg_cache/native_test.c':'before-bug-native-test.c','tests/jpeg_cache/decoder_driver.c':'before-bug-driver.c'}
for name,h in before_inputs.items():
    p=Path(name)
    if p.is_relative_to(ROOT/'Small_TV/src'):
        relative=p.relative_to(ROOT/'Small_TV/src').as_posix()
        if relative in overrides:p=BASE/overrides[relative]
    assert sha(p.read_bytes())==h,name
before_build=read(BASE/'decoder-silent-before/build.json');assert sha(Path(before_build['executable']).read_bytes())==before_build['executable_sha256']
main=ROOT/'firmware/development/small-tv-esp32c2-reconstructed/app.bin'
assert sha(main.read_bytes())=='3e030c1cc5f7b456fefc9985c397daf8340c33d1bb2805965b076147a07cd7e1'
probe=ROOT/'firmware/development/small-tv-jpeg-decoder-probe/app.bin'
assert sha(probe.read_bytes())=='0f637039a537b0eca0f2bb5761c6e939d190489bc91823fee9c4c7e09aa45ad8'
owners=read(BASE/'h10-owners.json');times={22184:'09:27:35.206623',32636:'09:27:35.684696',20772:'09:27:35.711979',32580:'09:27:41.510965',18268:'09:28:10.414044',14972:'09:28:10.447191'}
assert {r['ProcessId'] for r in owners}==set(times)
assert all(datetime.fromisoformat(r['CreationDate']).astimezone(timezone.utc)==datetime.fromisoformat('2026-10-20T'+times[r['ProcessId']]+'+00:00') for r in owners)
assert not (BASE/'sdk-status.txt').read_text(encoding='utf-8-sig').strip()
frozen_root=Path('C:/Work/yoRadio/.worktree/small-tv-jpeg-selectors/.build/jpeg-selector-qemu-complete-20261019')
frozen=read(frozen_root/'frozen-inputs.json');assert len(frozen['files'])==46
assert all(sha((frozen_root/r['file']).read_bytes())==r['sha256'] for r in frozen['files'])
sources={Path(p) for p in compile_inputs if Path(p).is_relative_to(ROOT/'Small_TV/src')}
sources.update(p for p in (ROOT/'Small_TV/src/tests/jpeg_cache').rglob('*') if p.is_file())
sources.add(ROOT/'Small_TV/src/tests/color_convert_contract.py')
source_sha={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted(sources)}
DEST.mkdir(parents=True,exist_ok=False);raw=[]
def add_data(name,data):
    path=DEST/(name+'.gz');assert not path.exists(),name;path.parent.mkdir(parents=True,exist_ok=True)
    packed=gzip.compress(data,compresslevel=9,mtime=0);path.write_bytes(packed)
    raw.append(dict(file=path.relative_to(PARITY).as_posix(),sha256=sha(packed),bytes=len(packed),uncompressed_sha256=sha(data),uncompressed_bytes=len(data)))
def add(p,name=None):add_data(name or p.relative_to(BASE).as_posix(),p.read_bytes())
for p in sorted(sources):add(p,'source/'+p.relative_to(ROOT).as_posix())
for folder in ('native-final','decoder-closure','generator-flat','mutations','generator-contract-closure','rv32-closure'):
    for p in sorted((BASE/folder).rglob('*')):
        if p.is_file() and p.suffix in ('.json','.txt','.log','.c','.h','.su','.cmd','.o','.bin','.jpg'):add(p)
add(BASE/'contract-closure/report.json');add(BASE/'contract-closure/cold.rgb')
for p in sorted(BASE.glob('*.log')):
    if p.name!='export-proof.log':add(p)
for p in sorted(BASE.glob('*.c')):add(p,'history-sources/'+p.name)
for p in sorted(BASE.glob('*.h')):add(p,'history-sources/'+p.name)
for p in sorted(BASE.glob('*.py')):add(p)
for folder in ('native-first','native-layout','native-full','decoder-first','decoder-final','decoder-capacity','decoder-silent-before','decoder-verified','decoder-contract','decoder-contract-capacity','decoder-contract-flat','decoder-contract-verified','generator-contract','generator-contract-final','rv32-first','rv32-final'):
    for name in ('inputs.json','build.json','report.json','compile.log','link.log','resources/jpeg_cache_layout.h','resources/jpeg_layout.h'):
        p=BASE/folder/name
        if p.exists():add(p,'history/'+folder+'/'+name)
for name in ('report.json','first.rgb','cold.rgb'):add(BASE/'silent-before-proof'/name)
for name in ('h10-owners.json','sdk-status.txt'):add(BASE/name)
add(frozen_root/'frozen-inputs.json','old-h10-frozen-inputs.json')
headers=io.BytesIO()
with tarfile.open(fileobj=headers,mode='w') as archive:
    for i,(name,h) in enumerate(sorted(compile_inputs.items())):
        p=Path(name)
        if p.suffix=='.h' and not p.is_relative_to(ROOT/'Small_TV/src'):
            data=p.read_bytes();info=tarfile.TarInfo(f'{i:03d}/'+p.name);info.size=len(data);archive.addfile(info,io.BytesIO(data))
add_data('compile-headers.tar',headers.getvalue())
fixtures=[];bundle=io.BytesIO()
with tarfile.open(fileobj=bundle,mode='w') as archive:
    for p in sorted((BASE/'contract-closure/fixtures').glob('*.jpg')):
        data=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(data);archive.addfile(info,io.BytesIO(data))
        fixtures.append(dict(name=p.name,sha256=sha(data),bytes=len(data)))
add_data('fixtures.tar',bundle.getvalue())
report=dict(schema_version=1,passed=True,all_functionality_verified=False,
    scope='Actual persistent source/SHA/rows/cache/NOR/journal and full JPEG decoder workflow on host, strict physical/cut model, independent pixels and cold readonly hits. RV32 ET_REL only; new cache target execution/native UI/privacy/HTTP/deployment/whole shared heap/stack/time and final acceptance remain open.',
    source_sha256=source_sha,compile_inputs_sha256=compile_inputs,native=unit,
    host_counts={k:len(contract[k]) for k in ('positive','limits','negative','faults','stops')},
    traffic=contract['traffic'],resource_cases=contract['limits'],negative_cases=contract['negative'],
    pre_fix_source_bug=dict(confirmed=True,physical_callback=378,first_ready=bad['result']['first']['ready'],wrong_sha256=bad['result']['first_sha256'],cold_wrong_sha256=bad['result']['cold_sha256'],expected_sha256=before['expected_rgb565_sha256'],build=before_build),
    mutation_controls=mutants['cases'],generator=generator,rv32=rv,
    main_production=dict(app_sha256=sha(main.read_bytes()),decoder='TJpgd',unchanged=True,new_cache_enabled=False),
    target_decoder_probe=dict(app_sha256=sha(probe.read_bytes()),unchanged=True,new_cache_executed=False),
    sdk_tracked_clean=True,old_h10=dict(owners=owners,frozen_payloads=46,manifest_included=True,QMP_RSP_interaction=False),
    existing_gates=dict(artifact=6,correspondence=10),new_QEMU_processes=0,physical_device_actions=False,
    required_remaining=['native media owner/worker preserving source serialization and UI/HTTP responsiveness','target cache runtime/final vendor/build and photo/settings-preserving matching deployment','privacy/parser/typed HTTP errors/settings publication and reset/power-loss workflow','whole shared heap/stack/time and independent LCD/network/full/24h/hardware plus remaining factory/network/electrical audit'],fixtures=fixtures,raw_artifacts=raw)
path=PARITY/'jpeg-cache-pipeline-validation-20261020.json';assert not path.exists();path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
for r in raw:
    data=(PARITY/r['file']).read_bytes();assert sha(data)==r['sha256'] and sha(gzip.decompress(data))==r['uncompressed_sha256']
print('Saved persistent cache proof:',len(source_sha),'sources,',len(raw),'raw artifacts,',len(fixtures),'JPEG fixtures;',sum(r['bytes'] for r in raw),'compressed bytes')
