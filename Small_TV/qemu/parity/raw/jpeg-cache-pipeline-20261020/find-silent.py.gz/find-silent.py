"""Probe a real silent source read fault, rather than assuming double hashing suffices."""
import hashlib,json,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
OUT=BASE/'silent-before-proof';OUT.mkdir(exist_ok=False)
build=json.loads((BASE/'decoder-silent-before/build.json').read_text());exe=build['executable']
image=ROOT/'.build/jpeg-decoder-20261020/contract-classified/fixtures/full-cmyk12.jpg'
gold=next(x['rgb565_sha256'] for x in json.loads((BASE/'decoder-contract-flat/report.json').read_text())['positive'] if x['name']=='rich-cmyk-progressive-12.jpg')
first,cold=OUT/'first.rgb',OUT/'cold.rgb'
def run(fault=None):
    command=[exe,str(image),str(first),str(cold)]+([] if fault is None else ['silent',str(fault)])
    result=subprocess.run(command,capture_output=True,timeout=30);assert result.returncode==0,(result.returncode,result.stderr)
    row=json.loads(result.stdout);row['first_sha256']=hashlib.sha256(first.read_bytes()).hexdigest();row['cold_sha256']=hashlib.sha256(cold.read_bytes()).hexdigest();return row
control=run();assert control['first_sha256']==control['cold_sha256']==gold
report=dict(control=control,expected_rgb565_sha256=gold,cases=[],incorrect_cache_publication_found=False)
for ordinal in control['first_input_calls']:
    row=run(ordinal);report['cases'].append(dict(ordinal=ordinal,result=row))
    if row['first']['ready'] and row['first']['cache_result']==0 and row['first_sha256']!=gold:
        report['incorrect_cache_publication_found']=True
        print('CONFIRMED bad source read published:',ordinal,'cold cache matches damaged decode:',row['cold_sha256']==row['first_sha256'],flush=True)
        break
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
assert report['incorrect_cache_publication_found']
