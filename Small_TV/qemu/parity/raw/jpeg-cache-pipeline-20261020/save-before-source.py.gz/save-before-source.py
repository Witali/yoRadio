"""Recover byte-exact inputs for the reproduced pre-fix publication bug."""
import hashlib,json
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];SRC=ROOT/'Small_TV/src'
pins=json.loads((BASE/'decoder-silent-before/inputs.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(name,relative,data):
    assert sha(data)==pins[str(SRC/relative)],relative
    (BASE/name).write_bytes(data)
save('before-bug-cache.c','storage/jpeg_cache.c',(BASE/'cache_before_verified_source.c').read_bytes())
h=(SRC/'storage/jpeg_cache.h').read_text().replace('/* Exact bounded persistent input during begin/commit. Fresh256-byte readbacks\n * verify each returned buffer; budget these reads as well as the original read. */','/* Exact bounded persistent input callback for the decoder during begin/commit. */')
save('before-bug-cache.h','storage/jpeg_cache.h',h.encode())
t=(SRC/'tests/jpeg_cache/native_test.c').read_text()
replacements=[
('    uint64_t hash_bytes,hash_frame_bytes;\n    bool require_physical_hash;\n',''),
('    if(live_hash && role==1)model.hash_frame_bytes+=bytes;\n',''),
('    (void)context;CHECK(!live_hash && BCryptCreateHash(algorithm,&live_hash,NULL,0,NULL,0,0)>=0);\n    model.hash_bytes=0;model.hash_frame_bytes=0;model.require_physical_hash=!cache.journal.pending || cache.writing;\n    return hash_fault() ? -90:0;',
 '    (void)context;CHECK(!live_hash && BCryptCreateHash(algorithm,&live_hash,NULL,0,NULL,0,0)>=0);return hash_fault() ? -90:0;'),
('    (void)context;CHECK(live_hash && bytes<=ULONG_MAX && BCryptHashData(live_hash,(PUCHAR)data,(ULONG)bytes,0)>=0);\n    model.hash_bytes+=bytes;return hash_fault() ? -91:0;',
 '    (void)context;CHECK(live_hash && bytes<=ULONG_MAX && BCryptHashData(live_hash,(PUCHAR)data,(ULONG)bytes,0)>=0);return hash_fault() ? -91:0;'),
('    (void)context;CHECK(live_hash && BCryptFinishHash(live_hash,digest,32,0)>=0);\n    if(model.require_physical_hash && model.hash_bytes==115200u)CHECK(model.hash_frame_bytes==115200u);\n    return hash_fault() ? -92:0;',
 '    (void)context;CHECK(live_hash && BCryptFinishHash(live_hash,digest,32,0)>=0);return hash_fault() ? -92:0;'),
('    CHECK(jpeg_cache_lookup(&cache,0,1023)==JPEG_CACHE_MISS && !model.programs && !model.erases);\n    calls=model.calls;CHECK(jpeg_cache_read_row(&cache,0,row,240)==JPEG_CACHE_STATE && model.calls==calls);abort_cache();',
 '    CHECK(jpeg_cache_lookup(&cache,0,1023)==JPEG_CACHE_MISS && !model.programs && !model.erases);abort_cache();')]
for old,new in replacements:
    assert t.count(old)==1,old;t=t.replace(old,new)
save('before-bug-native-test.c','tests/jpeg_cache/native_test.c',t.encode())
save('before-bug-driver.c','tests/jpeg_cache/decoder_driver.c',(SRC/'tests/jpeg_cache/decoder_driver.c').read_bytes())
print('Verified exact pre-bug cache/header/model/driver snapshots against BEFORE-compilation inputs')
