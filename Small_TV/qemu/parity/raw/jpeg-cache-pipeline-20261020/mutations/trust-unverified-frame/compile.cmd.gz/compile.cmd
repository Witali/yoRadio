@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
cd /d "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-cache-20261020\mutations\trust-unverified-frame"
where cl > compiler-path.txt
cl /nologo /std:c11 /O2 /W3 /MT /DJPEG_STATIC /D_CRT_SECURE_NO_WARNINGS /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-cache-20261020\decoder-closure\resources" /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\storage" /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\codec" /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\app\include" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-cache-20261020\mutations\trust-unverified-frame\mutant.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\storage\jpeg_nor.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\storage\jpeg_journal.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\tests\jpeg_cache\native_test.c" /Fe"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-cache-20261020\mutations\trust-unverified-frame\mutant.exe" /link bcrypt.lib
exit /b %errorlevel%
