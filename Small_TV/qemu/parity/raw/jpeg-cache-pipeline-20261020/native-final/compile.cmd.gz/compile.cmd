@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
cd /d "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-cache-20261020\native-final"
where cl > compiler-path.txt
cl /nologo /std:c11 /O2 /W4 /WX /MT /D_CRT_SECURE_NO_WARNINGS /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-cache-20261020\native-final" /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\storage" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\storage\jpeg_cache.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\storage\jpeg_nor.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\storage\jpeg_journal.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\tests\jpeg_cache\native_test.c" /Fe"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-cache-20261020\native-final\jpeg_cache_test.exe" /link bcrypt.lib
exit /b %errorlevel%
