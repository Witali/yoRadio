"""Measure actual RV32 cache/storage objects, not a target execution or UI fit."""
import hashlib,json,struct,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];PROJECT=ROOT/'Small_TV/src'
OUT=BASE/'rv32-final';OUT.mkdir(exist_ok=False)
BIN=Path('C:/Work/yoRadio/.idf/tools-v6.1/tools/riscv32-esp-elf/esp-15.2.0_20251204/riscv32-esp-elf/bin')
specs=BIN.parent/'riscv32-esp-elf/lib/picolibc.specs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tool=lambda n:str(BIN/('riscv32-esp-elf-'+n+'.exe'))
flags=['-march=rv32imc_zicsr_zifencei','-mabi=ilp32','-mtune=esp-base','-Os','-std=c11','-Wall','-Wextra','-Werror','-ffunction-sections','-fdata-sections','-fstack-usage','-D__PICOLIBC_ERRNO_FUNCTION=__errno','-specs='+str(specs),'-I',str(PROJECT/'storage')]
paths=[PROJECT/'storage'/n for n in ('jpeg_cache.c','jpeg_cache.h','jpeg_guard.h','jpeg_journal.c','jpeg_journal.h','jpeg_nor.c','jpeg_nor.h')]+[Path(__file__),Path(tool('gcc')),specs]
pins={str(p):sha(p) for p in paths};commands=[]
def run(cmd,name):
    commands.append(cmd);r=subprocess.run(cmd,capture_output=True,timeout=60);(OUT/name).write_bytes(r.stdout+r.stderr);assert r.returncode==0,(cmd,r.returncode,r.stderr);return r.stdout
objects=[]
for name in ('jpeg_cache','jpeg_journal','jpeg_nor'):
    obj=OUT/(name+'.o');objects.append(str(obj));run([tool('gcc')]+flags+['-c',str(PROJECT/'storage'/(name+'.c')),'-o',str(obj)],name+'.log')
roots=['jpeg_cache_'+n for n in ('open','invalidate','lookup','begin','write_row','read_source','commit','read_row','abort')]
linked=OUT/'cache-storage.o'
run([tool('gcc')]+flags+['-r','-nostdlib','-Wl,--gc-sections,-e,'+roots[0]]+['-Wl,-u,'+n for n in roots[1:]]+objects+['-o',str(linked)],'link.log')
symbols=run([tool('nm'),'-S',str(linked)],'symbols.txt').decode();assert all(any(line.split()[-1]==n for line in symbols.splitlines()) for n in roots)
unresolved=run([tool('nm'),'-u',str(linked)],'unresolved.txt').decode().splitlines();assert all(not x.split()[-1].startswith('jpeg_') for x in unresolved)
run([tool('size'),'-A',str(linked)],'sections.txt')
measure=OUT/'sizes.c';measure.write_text('#include "jpeg_cache.h"\nconst uint32_t jpeg_cache_sizes[]={sizeof(jpeg_cache_t),sizeof(jpeg_cache_layout_t),sizeof(jpeg_cache_devices_t),sizeof(jpeg_journal_t),sizeof(jpeg_nor_t)};\n',encoding='utf-8',newline='\n')
run([tool('gcc')]+flags+['-c',str(measure),'-o',str(OUT/'sizes.o')],'sizes.log')
run([tool('objcopy'),'--dump-section','.rodata.jpeg_cache_sizes='+str(OUT/'sizes.bin'),str(OUT/'sizes.o')],'dump-sizes.log')
sizes=dict(zip(('cache_handle','layout','devices','journal','nor'),struct.unpack('<5I',(OUT/'sizes.bin').read_bytes())))
data=linked.read_bytes();h=struct.unpack_from('<16sHHIIIIIHHHHHH',data);assert h[0][:6]==b'\x7fELF\x01\x01' and h[1:3]==(1,243)
sections=[struct.unpack_from('<10I',data,h[6]+i*h[11]) for i in range(h[12])]
totals=dict(code=0,readonly=0,writable=0,bss=0)
for s in sections:
    if s[2]&2:totals['code' if s[2]&4 else 'bss' if s[2]&1 and s[1]==8 else 'writable' if s[2]&1 else 'readonly']+=s[5]
assert totals['writable']==totals['bss']==0
frames=[]
for p in OUT.glob('*.su'):
    for line in p.read_text().splitlines():
        identifier,size,kind=line.rsplit('\t',2);frames.append(dict(function=identifier,bytes=int(size),kind=kind))
assert all(sha(Path(p))==v for p,v in pins.items())
record=dict(passed=True,inputs_unchanged=True,inputs_sha256=pins,commands=commands,retained_sizes=totals,context_sizes=sizes,largest_frames=sorted(frames,key=lambda x:x['bytes'],reverse=True)[:20],unresolved=unresolved,object_sha256=sha(linked),scope='Actual RV32IMC ILP32 relocatable cache/NOR/journal link with every public cache root. No SDK/libc final link, target execution, aggregate call-chain stack or UI/Wi-Fi RAM fit.')
(OUT/'report.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print('PASS RV32 cache:',sizes,totals,'maximum individual frame',max(x['bytes'] for x in frames))
