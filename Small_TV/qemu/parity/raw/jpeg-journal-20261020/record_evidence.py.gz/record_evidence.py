"""Record bounded journal evidence; not production/whole-JPEG/hardware acceptance."""
import gzip
import hashlib
import json
from pathlib import Path
from elftools.elf.elffile import ELFFile

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'.build/jpeg-journal-20261020'
PARITY=ROOT/'Small_TV/qemu/parity'
RAW=PARITY/'raw/jpeg-journal-20261020'
PROJECT=ROOT/'Small_TV/src'


def sha(data):
    return hashlib.sha256(data).hexdigest()


host=json.loads((RUN/'final-compact/report.json').read_text())
wire=json.loads((RUN/'final-compact/wire-report.json').read_text())
negative=json.loads((RUN/'compact-mutations/report.json').read_text())
old_negative=json.loads((RUN/'mutations/report.json').read_text())
old_host=json.loads((RUN/'final/report.json').read_text())
plan=json.loads((RUN/'final-compact/plan.json').read_text())
integrity=json.loads((RUN/'production-integrity.json').read_text())
assert host['passed'] and host['power_io_fault_cases']==33400 and host['corruption_cases']==769
assert host['boot_faults']==6 and host['rejected_cases']==14
assert host['update_callbacks_128']==4270 and host['update_callbacks_256']==2410
assert 5*(4270+2410)==host['power_io_fault_cases']
assert negative['passed'] and negative['inputs_unchanged'] and len(negative['cases'])==12
assert not negative['full_power_cut_matrix_run'] and wire['passed'] and wire['snapshots']==4
assert integrity['passed'] and integrity['cases']==6 and old_host==host
assert (RUN/'quick/journal_fixture.h').read_bytes()==(RUN/'final-compact/journal_fixture.h').read_bytes()
for pins in (negative['inputs_sha256'],plan['test_inputs_sha256']):
    for path,digest in pins.items():assert sha(Path(path).read_bytes())==digest,path

source=PROJECT/'storage/jpeg_journal.c'
current=source.read_text()
begin=current.index('static bool valid_footer(')
end=current.index('static jpeg_journal_result_t load_bank(',begin)
pre=current[:begin]+current[end:]
pre=pre.replace('    uint8_t footer[JPEG_NOR_MAX_PAGE_BYTES];\n    *valid = false;',
                '    uint8_t footer[JPEG_NOR_MAX_PAGE_BYTES], expected[JPEG_NOR_MAX_PAGE_BYTES];\n    *valid = false;')
pre=pre.replace('    *valid = valid_footer(journal,footer);',
                '    make_footer(journal,expected);\n    *valid = !memcmp(footer,expected,journal->device.page_bytes);')
assert sha(pre.encode())==old_negative['inputs_sha256'][str(source.resolve())]
(RUN/'precompact-jpeg_journal.c').write_text(pre,encoding='utf-8',newline='\n')

with (RUN/'rv32-compact/jpeg_journal.o').open('rb') as stream:
    elf=ELFFile(stream)
    assert elf['e_type']=='ET_REL' and elf['e_machine']=='EM_RISCV'
    code=sum(s['sh_size'] for s in elf.iter_sections() if s['sh_flags']&4)
    writable=sum(s['sh_size'] for s in elf.iter_sections() if s['sh_flags']&1)
    rodata=sum(s['sh_size'] for s in elf.iter_sections() if s['sh_flags']&2 and not s['sh_flags']&5)
assert code==2976 and rodata==24 and writable==0
with (RUN/'rv32-compact/abi_probe.o').open('rb') as stream:
    elf=ELFFile(stream);abi={}
    for symbol in elf.get_section_by_name('.symtab').iter_symbols():
        if symbol.name.startswith('jpeg_journal_') and symbol.name.endswith('_bytes'):
            section=elf.get_section(symbol['st_shndx']);offset=symbol['st_value']-section['sh_addr']
            abi[symbol.name]=int.from_bytes(section.data()[offset:offset+4],'little')
assert abi==dict(jpeg_journal_handle_bytes=1032,jpeg_journal_config_bytes=80,jpeg_journal_entry_bytes=72,jpeg_journal_body_bytes=512)
frames={line.split('\t')[0].rsplit(':',1)[-1]:int(line.split('\t')[1])
        for line in (RUN/'rv32-compact/jpeg_journal.su').read_text().splitlines()}
old_frames={line.split('\t')[0].rsplit(':',1)[-1]:int(line.split('\t')[1])
            for line in (RUN/'rv32/jpeg_journal.su').read_text().splitlines()}
assert max(frames.values())==448 and frames['jpeg_journal_open']==448 and old_frames['jpeg_journal_open']==704

sources=[PROJECT/name for name in ('storage/jpeg_journal.c','storage/jpeg_journal.h',
    'storage/jpeg_nor.c','storage/jpeg_nor.h','tests/jpeg_journal/native_test.c',
    'tests/jpeg_journal/prepare.py','tests/jpeg_journal/run.ps1','tests/jpeg_journal/mutation_contract.py',
    'tests/jpeg_journal/wire_contract.py','tools/jpeg_guard_layout.py','tools/jpeg_storage_layout.py',
    'app/include/board.h','partitions.csv')]
paths=[RUN/'final-compact.log',RUN/'compact-mutations.log',RUN/'wire.log',
       RUN/'production-integrity.json',RUN/'production-integrity.log',RUN/'h10-live-owners.json',
       RUN/'precompact-jpeg_journal.c',RUN/'mutations/report.json',RUN/'final/report.json',
       RUN/'rv32/jpeg_journal.o',RUN/'rv32/jpeg_journal.su',RUN/'rv32/abi_probe.c',Path(__file__)]
for folder in ('final-compact','compact-mutations','rv32-compact'):
    paths.extend(p for p in (RUN/folder).rglob('*') if p.is_file() and p.suffix in
                 ('.json','.log','.txt','.cmd','.c','.h','.exe','.o','.su','.bin'))
raw=[]
for path in sorted(set(paths)):
    relative=Path('record_evidence.py') if path==Path(__file__) else path.relative_to(RUN)
    destination=RAW/relative;destination=destination.with_name(destination.name+'.gz')
    assert not destination.exists(),destination
    data=path.read_bytes();packed=gzip.compress(data,mtime=0)
    destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed)
    assert gzip.decompress(packed)==data
    raw.append(dict(file=destination.relative_to(PARITY).as_posix(),sha256=sha(packed),bytes=len(packed),
                    uncompressed_sha256=sha(data),uncompressed_bytes=len(data)))

rv=Path('C:/Work/yoRadio/.idf/tools-v6.1/tools/riscv32-esp-elf/esp-15.2.0_20251204/riscv32-esp-elf')
compiler=Path((RUN/'final-compact/compiler-path.txt').read_text().splitlines()[0])
toolchain=[compiler,rv/'bin/riscv32-esp-elf-gcc.exe',rv/'libexec/gcc/riscv32-esp-elf/15.2.0/cc1.exe']
archive=ROOT/'firmware/development/small-tv-esp32c2-reconstructed'
report=dict(schema_version=1,passed=True,all_functionality_verified=False,
    scope='Portable two-bank cache metadata with actual NOR-core synthetic frames, host hard-cut/partial-I/O/corruption/state tests, independent wire oracle and RV32 object/ABI measurement. Not linked to production, not atomic HTTP/source upload or hardware power-loss acceptance.',
    source_sha256={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sources},
    compiler_sha256={str(p):sha(p.read_bytes()) for p in toolchain},
    host=host,wire=wire,negative_controls=negative,
    fault_modes=['partial-error','silent-partial-write-or-corrupt-read','cut-after-full-operation',
                 'cut-halfway','cut-before-operation'],
    invariants=['durable invalidation before data mutation','active bank preserved while committing other bank',
        'body verified before commit page','every ready recovery entry matches a complete frame',
        'all other four cache frames and all protected flash bytes preserved',
        'newest foreign layout/codec snapshot never falls back to older matching generation',
        'metadata fallback still requires full current physical frame SHA on every hit',
        'generation does not wrap; duplicate generation fails closed; redundant invalidation avoids erase'],
    layout_id=plan['layout_id'],synthetic_test_codec_id=plan['journal_test_codec_id'],
    rv32=dict(code_bytes=code,rodata_bytes=rodata,writable_bytes=writable,abi=abi,
              single_frames=frames,previous_open_frame=704,executed=False,production_linked=False,
              flags=['-std=c11','-Os','-Wall','-Wextra','-Werror','-ffunction-sections','-fdata-sections',
                     '-fstack-usage','-march=rv32imc_zicsr_zifencei','-mabi=ilp32','-c']),
    production=dict(changed=False,journal_linked=False,artifact_checks=integrity,
                    app_sha256=sha((archive/'app.bin').read_bytes())),
    old_h10='Six original owner identities confirmed live using readonly CIM; no VM/SDK/source/snapshot mutations.',
    required_remaining=['ESP-IDF authorized transport/SHA/budgets and shared scratch subfiles',
        'integrate journal invalidation before actual source upload and cache writes; full physical verifier',
        'matching stamped assets build preserving user photos/settings',
        'libjpeg bridge/final link/size/heap/stack/time/HTTP/LCD/full/24h/hardware gates'],raw_artifacts=raw)
assert report['production']['app_sha256']=='3e030c1cc5f7b456fefc9985c397daf8340c33d1bb2805965b076147a07cd7e1'
with (PARITY/'jpeg-cache-journal-validation-20261020.json').open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(json.dumps(report,indent=2)+'\n')
print('PASS',len(raw),'raw artifacts; RV32 code2976/rodata24/handle1032/maxframe448;33400faults')
