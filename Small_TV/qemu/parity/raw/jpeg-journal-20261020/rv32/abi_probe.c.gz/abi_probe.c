#include "jpeg_journal.h"
const unsigned jpeg_journal_handle_bytes = sizeof(jpeg_journal_t);
const unsigned jpeg_journal_config_bytes = sizeof(jpeg_journal_config_t);
const unsigned jpeg_journal_entry_bytes = sizeof(jpeg_journal_entry_t);
const unsigned jpeg_journal_body_bytes = JPEG_JOURNAL_BODY_BYTES;
