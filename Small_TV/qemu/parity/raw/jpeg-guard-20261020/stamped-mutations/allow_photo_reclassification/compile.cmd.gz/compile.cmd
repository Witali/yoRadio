@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
cd /d "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-guard-20261020\stamped-mutations\allow_photo_reclassification"
where cl > compiler-path.txt
cl /nologo /std:c11 /W3 /D_CRT_SECURE_NO_WARNINGS /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-guard-20261020\stamped-host" /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\storage" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\tests\jpeg_guard\native_test.c" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-guard-20261020\stamped-mutations\allow_photo_reclassification\mutant.c" /Fe"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-guard-20261020\stamped-mutations\allow_photo_reclassification\mutant.exe" /link bcrypt.lib
exit /b %errorlevel%
