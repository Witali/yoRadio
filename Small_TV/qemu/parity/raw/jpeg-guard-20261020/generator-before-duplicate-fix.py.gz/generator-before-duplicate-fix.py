"""Check generated ownership inputs, privacy boundaries and fail-closed CLI output."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT/'tools'))
from jpeg_guard_layout import make_header, partition_descriptors, c_bytes


def main():
    """Independently compare every generated resource with the packed manifest."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--assets-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    asset_path, manifest_path = args.assets_dir/'assets.bin', args.assets_dir/'assets-manifest.json'
    board_path, partitions_path = PROJECT/'app/include/board.h', PROJECT/'partitions.csv'
    assets, manifest = asset_path.read_bytes(), json.loads(manifest_path.read_text())
    board, partitions = board_path.read_text(), partitions_path.read_text()
    header, plan = make_header(assets, manifest, board, partitions)
    assert plan['layout_id'] == '4508149b7701de9fbd945b6f9fe7145b5f2dbe93de9760e56fe2437f51ad9ca6'
    assert header.count('static const jpeg_guard_resource_t ') == 1
    immutable = manifest['records'][5:]
    assert len(immutable) == 27
    for row in immutable:
        begin = int(row['offset'], 0)-0x200000
        assert hashlib.sha256(assets[begin:begin+row['size']]).hexdigest() == row['sha256']
        assert header.count(c_bytes(row['sha256'])) == 1
    for row in manifest['records'][:5]:
        assert c_bytes(row['sha256']) not in header
    assert partition_descriptors(partitions) == [
        dict(label='nvs', type=1, subtype=2, offset=0x9000, bytes=0x6000, flags=0),
        dict(label='phy_init', type=1, subtype=1, offset=0xf000, bytes=0x1000, flags=0),
        dict(label='factory', type=0, subtype=0, offset=0x10000, bytes=0x177000, flags=0),
        dict(label='assets', type=1, subtype=0x40, offset=0x200000, bytes=0x1e7000, flags=0)]
    rejected = []

    def reject(name, operation):
        """Reject unsupported descriptors without silently dropping a table field."""
        try:
            operation()
        except (ValueError, KeyError):
            rejected.append(name)
        else:
            raise AssertionError('Accepted invalid guard input: '+name)

    reject('encrypted-partition', lambda: partition_descriptors(partitions.replace('0x6000,','0x6000, encrypted')))
    reject('unknown-flags', lambda: partition_descriptors(partitions.replace('0x6000,','0x6000, 2')))
    reject('extra-column', lambda: partition_descriptors(partitions.replace('0x6000,','0x6000,,extra')))
    reject('unsupported-type', lambda: partition_descriptors(partitions.replace('nvs, data,','nvs, custom,')))
    reject('unencodable-subtype', lambda: partition_descriptors(partitions.replace('data, nvs,','data, 0x100,')))
    reject('unterminated-label', lambda: partition_descriptors(partitions.replace('nvs, data,','abcdefghijklmnop, data,')))
    reject('label-injection', lambda: partition_descriptors(partitions.replace('nvs, data,','bad"name, data,')))
    reject('partition-gap-owned', lambda: make_header(assets, manifest, board,
        partitions+'other,data,0x41,0x1f0000,0x1000,\n'))
    reject('stale-image', lambda: make_header(bytes([assets[0]^1])+assets[1:], manifest, board, partitions))
    changed = copy.deepcopy(manifest); changed['records'].pop()
    reject('missing-immutable', lambda: make_header(assets, changed, board, partitions))
    changed = copy.deepcopy(manifest); changed['records'][0]['offset'] = '0x290000'
    reject('photo-promoted-to-scratch', lambda: make_header(assets, changed, board, partitions))
    # Input record/table order is not an identity; descriptors sort by address.
    changed = copy.deepcopy(manifest); changed['records'].reverse()
    reordered, reordered_plan = make_header(assets, changed, board, partitions)
    assert reordered == header and reordered_plan['layout_id'] == plan['layout_id']
    command = [sys.executable, '-B', str(PROJECT/'tools/jpeg_guard_layout.py'),
               '--assets-dir', str(args.assets_dir), '--output', str(args.output)]
    created = subprocess.run(command, capture_output=True, timeout=30)
    assert created.returncode == 0, created.stderr
    assert (args.output/'jpeg_layout.h').read_text() == header
    before = {p.name: p.read_bytes() for p in args.output.iterdir()}
    repeated = subprocess.run(command, capture_output=True, timeout=30)
    assert repeated.returncode != 0
    assert {p.name: p.read_bytes() for p in args.output.iterdir()} == before
    inputs = [asset_path, manifest_path, board_path, partitions_path, Path(__file__),
              PROJECT/'tools/jpeg_guard_layout.py', PROJECT/'tools/jpeg_storage_layout.py']
    report = dict(passed=True, immutable_resources=27, rejected_inputs=rejected,
                  controls=['hash-each-immutable', 'exclude-five-photos', 'all-partition-fields',
                            'sorted-resource-order', 'matching-cli-header', 'refuse-existing-output'],
                  layout_id=plan['layout_id'],
                  inputs_sha256={str(p.resolve()): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs})
    (args.output/'report.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8', newline='\n')
    print('PASS guard generator:', len(rejected), 'rejected inputs, 6 controls')


if __name__ == '__main__':
    main()
