#include "jpeg_guard.h"
#include "jpeg_layout.h"
const unsigned jpeg_guard_layout_bytes = sizeof(jpeg_guard_layout_t);
const unsigned jpeg_guard_resource_bytes = sizeof(jpeg_guard_resource_t);
const unsigned jpeg_guard_partition_bytes = sizeof(jpeg_guard_partition_t);
/* Keep the complete generated const descriptor graph in this measurement. */
const jpeg_guard_layout_t *jpeg_guard_example_layout(void) { return &jpeg_layout; }
