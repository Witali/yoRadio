"""Preserve exact host/target transport evidence, including earlier harness failures."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
from elftools.elf.elffile import ELFFile

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'.build/jpeg-transport-20261020'
PROJECT=ROOT/'Small_TV/src'
PARITY=ROOT/'Small_TV/qemu/parity'
RAW=PARITY/'raw/jpeg-transport-20261020'
SDK=Path('C:/Work/yoRadio/.idf/v6.1-9a97f6c54ec6')
ARCHIVE=ROOT/'firmware/development/small-tv-storage-probe'


def sha(data):
    return hashlib.sha256(data).hexdigest()


host=json.loads((RUN/'final-host/report.json').read_text())
mutations=json.loads((RUN/'mutations/report.json').read_text())
qemu=json.loads((RUN/'final-qemu-frozen/report.json').read_text())
footprint=json.loads((RUN/'rv32-final/report.json').read_text())
integrity=json.loads((RUN/'production-integrity.json').read_text())
manifest=json.loads((ARCHIVE/'manifest.json').read_text())
assert host['passed'] and host['cases']==31
assert mutations['passed'] and mutations['inputs_unchanged'] and len(mutations['cases'])==14
assert qemu['passed'] and qemu['frozen_inputs_unchanged'] and len(qemu['cases'])==4
assert all(c['passed'] and c['owners_stopped'] and all(b['owners_stopped'] for b in c['boots']) for c in qemu['cases'])
assert sum(len(c['boots']) for c in qemu['cases'])==5
assert qemu['cases'][0]['changed_bytes']==35
assert integrity['passed'] and integrity['cases']==6 and manifest['inputs_unchanged_during_build']
assert manifest['source_sha256']==sha(json.dumps(manifest['source_files'],separators=(',',':')).encode())
for pins in (mutations['inputs_sha256'],qemu['inputs_sha256']):
    for path,digest in pins.items():assert sha(Path(path).read_bytes())==digest,path
for row in manifest['source_files']:
    path=RUN/'idf-final/resources'/row['file'][10:] if row['file'].startswith('generated/') else PROJECT/row['file']
    assert sha(path.read_bytes())==row['sha256'],path
for row in manifest['images']:
    data=(ARCHIVE/row['file']).read_bytes();assert sha(data)==row['sha256'] and len(data)==row['bytes']
elf=RUN/'idf-final/small_tv_storage_probe.elf'
assert sha(elf.read_bytes())==manifest['elf_sha256']==footprint['elf_sha256']
app=(ARCHIVE/'app.bin').read_bytes()
assert app[176:208]==bytes.fromhex(manifest['elf_sha256']) and sha(app)==qemu['app_sha256']
assert len(app)==135504
assert footprint['jpeg_transport']['code_bytes']==2324 and footprint['jpeg_espidf']['code_bytes']==1448
assert footprint['jpeg_transport']['max_single_frame']==240 and footprint['jpeg_espidf']['max_single_frame']==416
assert footprint['executed_probe_globals']==dict(storage=536,scratch_port=152,cache_port=152,scratch=4352,cache=4352)

api_files=[SDK/p for p in ('components/spi_flash/include/esp_flash.h',
    'components/esp_partition/include/esp_partition.h','components/esp_partition/partition.c',
    'components/bootloader_support/include/esp_flash_partitions.h',
    'components/bootloader_support/src/flash_partitions.c',
    'components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto.h')]
sdk_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SDK,text=True).strip()
sdk_dirty=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=SDK,text=True).strip()
mbedtls_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SDK/'components/mbedtls/mbedtls',text=True).strip()
assert sdk_revision=='9a97f6c54ec638111ce55cd36581b3c192f15207' and not sdk_dirty
sdk=dict(revision=sdk_revision,tracked_worktree_clean=not sdk_dirty,mbedtls_revision=mbedtls_revision,
         api_sha256={p.relative_to(SDK).as_posix():sha(p.read_bytes()) for p in api_files})
(RUN/'sdk-provenance.json').write_text(json.dumps(sdk,indent=2)+'\n',encoding='utf-8',newline='\n')
assert 'Invalid character escape' in (RUN/'idf-build.log').read_text(errors='replace')
assert 'Unknown network profile' in (RUN/'qemu.log').read_text()
assert "no attribute 'firmware'" in (RUN/'qemu-v2.log').read_text()
early=json.loads((RUN/'qemu/report.json').read_text())
assert sha((RUN/'qemu-before-offline-fix.py').read_bytes())==early['inputs_sha256'][str(PROJECT/'tests/jpeg_transport/qemu_probe.py')]
early=json.loads((RUN/'qemu-v2/report.json').read_text())
assert sha((RUN/'qemu-before-firmware-fix.py').read_bytes())==early['inputs_sha256'][str(PROJECT/'tests/jpeg_transport/qemu_probe.py')]
for name in ('qemu-v3','final-qemu'):
    old=json.loads((RUN/name/'report.json').read_text());assert old['passed']
    assert sum(len(c['boots']) for c in old['cases'])==5 and all(c['owners_stopped'] for c in old['cases'])

sources=[PROJECT/p for p in ('storage/jpeg_transport.c','storage/jpeg_transport.h','storage/jpeg_espidf.c','storage/jpeg_espidf.h',
    'storage/jpeg_guard.c','storage/jpeg_guard.h','storage/jpeg_nor.c','storage/jpeg_nor.h',
    'tests/jpeg_transport/prepare.py','tests/jpeg_transport/run.ps1','tests/jpeg_transport/native_test.c',
    'tests/jpeg_transport/mutation_contract.py','tests/jpeg_transport/qemu_probe.py','tests/jpeg_transport/build-idf.ps1',
    'tests/jpeg_transport/idf_probe/CMakeLists.txt','tests/jpeg_transport/idf_probe/main/CMakeLists.txt',
    'tests/jpeg_transport/idf_probe/main/probe.c','tools/jpeg_guard_layout.py','tools/jpeg_storage_layout.py',
    'app/include/board.h','sdkconfig.defaults','partitions.csv')]
paths=[RUN/'idf-build.log',RUN/'idf-final-build.log',RUN/'final-host.log',RUN/'mutations.log',RUN/'final-qemu-frozen.log',
    RUN/'qemu.log',RUN/'qemu-v2.log',RUN/'qemu/report.json',RUN/'qemu-v2/report.json',RUN/'qemu-v3/report.json',RUN/'final-qemu/report.json',
    RUN/'qemu-before-offline-fix.py',RUN/'qemu-before-firmware-fix.py',RUN/'build-idf-before-cmake-path-fix.ps1',
    RUN/'build-idf-before-input-freeze.ps1',RUN/'sdk-provenance.json',RUN/'h10-live-owners.json',
    RUN/'production-integrity.json',RUN/'production-integrity.log',elf,RUN/'idf-final/small_tv_storage_probe.map',
    RUN/'idf-final/compile_commands.json',RUN/'idf-final/resources/jpeg_layout.h',RUN/'idf-final/resources/probe_map.h',
    RUN/'idf-final/sdkconfig.defaults',RUN/'idf-final/resources/plan.json',Path(__file__),ROOT/'.build/measure_transport.py']
for folder in ('final-host','mutations','rv32-final'):
    paths.extend(p for p in (RUN/folder).rglob('*') if p.is_file() and p.suffix in ('.json','.log','.cmd','.txt','.c','.h','.exe','.o','.su'))
for p in (RUN/'final-qemu-frozen').rglob('*'):
    if p.is_file() and p.name in ('uart.log','uart-first.log','qemu.log','session.json','prepared.json','report.json'):
        paths.append(p)
paths.extend((RUN/'probe-v2'/name) for name in ('app.bin','app.elf','manifest.json'))
raw=[]
for path in sorted(set(paths)):
    if path==Path(__file__):relative=Path('record_evidence.py')
    elif path==ROOT/'.build/measure_transport.py':relative=Path('measure_transport.py')
    else:relative=path.relative_to(RUN)
    destination=RAW/relative;destination=destination.with_name(destination.name+'.gz')
    assert not destination.exists(),destination
    data=path.read_bytes();packed=gzip.compress(data,mtime=0)
    destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed)
    assert gzip.decompress(packed)==data
    raw.append(dict(file=destination.relative_to(PARITY).as_posix(),sha256=sha(packed),bytes=len(packed),
                    uncompressed_sha256=sha(data),uncompressed_bytes=len(data)))
archive_pins={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in ARCHIVE.iterdir() if p.is_file()}
report=dict(schema_version=1,passed=True,all_functionality_verified=False,
    scope='Shared revocable I/O/time-budgeted ports + real ESP-IDF flash/partition/PSA binding; host contracts/mutations and executed standalone RV32 probe. Not linked into main UI/TJpgd, not libjpeg/shared-subfiles/upload integration or hardware/final parity acceptance.',
    source_sha256={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sources},archive_sha256=archive_pins,
    sdk=sdk,host=host,negative_controls=mutations,target=qemu,rv32=footprint,
    probe=dict(app_sha256=sha(app),elf_sha256=sha(elf.read_bytes()),app_bytes=len(app),inputs_frozen_before_build=True,
               source_fingerprint=manifest['source_sha256'],final_owner_processes=5,earlier_successful_owner_processes=10,
               all_owned_processes_stopped=True),
    main_production=dict(changed=False,app_sha256=integrity['app_sha256'],codec='TJpgd',artifact_checks=integrity),
    early_failures=['CMake custom include Windows path escaping','unknown network profile before process launch',
                    'missing firmware argument before process launch'],
    old_h10='Six original owners readonly-confirmed; no SDK/source/frozen helper or H10 VM mutation.',
    required_remaining=['one shared scratch cache + byte-bounded subfiles and initialization tracking',
        'measure actual libjpeg NOR traffic/wear/time; select production limits including expanded subsampling bounds',
        'source/upload journal invalidation + physical source/frame hashes + matching assets integration preserving photos/settings',
        'full JPEG bridge/native link/heap/task stack/time/HTTP/LCD/full/24h/hardware acceptance'],raw_artifacts=raw)
assert report['main_production']['app_sha256']=='3e030c1cc5f7b456fefc9985c397daf8340c33d1bb2805965b076147a07cd7e1'
with (PARITY/'jpeg-transport-validation-20261020.json').open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(json.dumps(report,indent=2)+'\n')
print('PASS',len(raw),'raw artifacts;',len(sources),'source pins;5exact-build target processes;31host/14mutants')
