/* Two small target I/O scopes from the full validated native plan. */
#define PROBE_SCRATCH_ADDRESS 0x187000u
#define PROBE_CACHE_ADDRESS 0x1fa000u
static const jpeg_nor_extent_t probe_scratch[]={{PROBE_SCRATCH_ADDRESS,8192}};
static const jpeg_nor_extent_t probe_cache[]={{PROBE_CACHE_ADDRESS,4096}};
