"""Replay exact probe compiler flags into separate objects with stack diagnostics."""
import ctypes
from ctypes import wintypes
import hashlib
import json
from pathlib import Path
import subprocess
from elftools.elf.elffile import ELFFile

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'.build/jpeg-transport-20261020'
OUT=RUN/'rv32-final';OUT.mkdir(exist_ok=False)
shell=ctypes.WinDLL('shell32');kernel=ctypes.WinDLL('kernel32')
shell.CommandLineToArgvW.argtypes=[wintypes.LPCWSTR,ctypes.POINTER(ctypes.c_int)]
shell.CommandLineToArgvW.restype=ctypes.POINTER(wintypes.LPWSTR)
kernel.LocalFree.argtypes=[ctypes.c_void_p]
commands=json.loads((RUN/'idf-final/compile_commands.json').read_text())
report={}
for name in ('jpeg_transport','jpeg_espidf','jpeg_guard','jpeg_nor'):
    entry=next(e for e in commands if Path(e['file']).name==name+'.c')
    count=ctypes.c_int();argv=shell.CommandLineToArgvW(entry['command'],ctypes.byref(count))
    args=[argv[i] for i in range(count.value)];kernel.LocalFree(argv)
    clean=[];i=0
    while i<len(args):
        if args[i] in ('-o','-MT','-MF'):i+=2;continue
        if args[i] in ('-MD','-MMD','-MP'):i+=1;continue
        clean.append(args[i]);i+=1
    output=OUT/(name+'.o');clean+=['-fstack-usage','-o',str(output)]
    result=subprocess.run(clean,cwd=entry['directory'],capture_output=True)
    (OUT/(name+'.log')).write_bytes(result.stdout+result.stderr)
    assert result.returncode==0,result.stderr
    with output.open('rb') as stream:
        elf=ELFFile(stream)
        assert elf['e_type']=='ET_REL' and elf['e_machine']=='EM_RISCV'
        code=sum(s['sh_size'] for s in elf.iter_sections() if s['sh_flags']&4)
        writable=sum(s['sh_size'] for s in elf.iter_sections() if s['sh_flags']&1)
    frames={line.split('\t')[0].rsplit(':',1)[-1]:int(line.split('\t')[1])
            for line in (OUT/(name+'.su')).read_text().splitlines()}
    report[name]=dict(code_bytes=code,writable_bytes=writable,max_single_frame=max(frames.values()),
        single_frames=frames,command=clean,source_sha256=hashlib.sha256(Path(entry['file']).read_bytes()).hexdigest(),
        object_sha256=hashlib.sha256(output.read_bytes()).hexdigest())

elf_path=RUN/'idf-final/small_tv_storage_probe.elf'
with elf_path.open('rb') as stream:
    elf=ELFFile(stream)
    sizes={s.name:s['st_size'] for s in elf.get_section_by_name('.symtab').iter_symbols()
           if s.name in ('storage','scratch','cache','scratch_port','cache_port')}
report['executed_probe_globals']=sizes
report['elf_sha256']=hashlib.sha256(elf_path.read_bytes()).hexdigest()
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({key:{k:v for k,v in value.items() if k in ('code_bytes','writable_bytes','max_single_frame')}
                  for key,value in report.items() if isinstance(value,dict)}))
print('Target globals:',sizes)
