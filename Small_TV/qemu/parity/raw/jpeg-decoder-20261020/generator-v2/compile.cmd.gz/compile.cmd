@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b 1
cd /d "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-decoder-20261020\generator-v2"
cl /nologo /std:c11 /O2 /W4 /WX /MT /DJPEG_STATIC /D_CRT_SECURE_NO_WARNINGS /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-coefficients-20261020\reference/source/src" /I"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-coefficients-20261020\reference/library" "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\Small_TV\src\tests\jpeg_decoder\generate.c" /Fe"C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-decoder-20261020\generator-v2\generate.exe" /link "C:\Work\yoRadio\.worktree\small-tv-improvement-plan\.build\jpeg-coefficients-20261020\reference\library\jpeg-static.lib"
exit /b %errorlevel%
