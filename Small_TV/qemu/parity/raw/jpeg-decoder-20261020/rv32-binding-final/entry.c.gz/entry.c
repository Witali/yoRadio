#include "jpeg_decoder_internal.h"
const unsigned char native_context_bytes[sizeof(jpeg_decoder_t)]={0};
const char *native_decoder_entry(const jpeg_decoder_config_t *c,const jpeg_decode_request_t *r,jpeg_decode_diagnostic_t *d){jpeg_decoder_t *s=jpeg_decoder_create(c,d);if(s){jpeg_decoder_decode(s,r,d);jpeg_decoder_destroy(s);}return jpeg_decoder_status_name(d->status);}
