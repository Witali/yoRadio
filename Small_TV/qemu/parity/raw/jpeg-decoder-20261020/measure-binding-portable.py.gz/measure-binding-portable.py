import hashlib,json,re,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'Small_TV/src/tests/jpeg_library_probe'))
from rv32_footprint import elf_sections
out=BASE/'rv32-binding-v2';out.mkdir(exist_ok=False)
library=BASE/'rv32-library';tools=Path('C:/Work/yoRadio/.idf/tools-v6.1/tools/riscv32-esp-elf/esp-15.2.0_20251204/riscv32-esp-elf')
gcc=tools/'bin/riscv32-esp-elf-gcc.exe';ld=tools/'bin/riscv32-esp-elf-ld.exe';nm=tools/'bin/riscv32-esp-elf-nm.exe';specs=tools/'riscv32-esp-elf/lib/picolibc.specs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[ROOT/'Small_TV/src'/n for n in ('codec/jpeg_decoder.c','codec/jpeg_memory.c','codec/jpeg_decoder.h','codec/jpeg_decoder_internal.h','app/media/color_convert.c','app/include/color_convert.h')]
files+=list((library/'source/src').glob('*.h'))+list((library/'library').glob('*.h'))
files+=[library/'library/libjpeg.a',gcc,ld,nm,specs,Path(__file__)]
pins={str(p):sha(p) for p in files}
flags=['-march=rv32imc_zicsr_zifencei','-mabi=ilp32','-mtune=esp-base','-Os','-std=c11','-Wall','-Wextra','-Werror','-ffunction-sections','-fdata-sections','-fstack-usage','-fno-jump-tables','-fno-tree-switch-conversion','-D__PICOLIBC_ERRNO_FUNCTION=__errno','-DJPEG_STATIC','-specs='+specs.as_posix()]
flags+=['-I'+str(p) for p in (ROOT/'Small_TV/src/codec',ROOT/'Small_TV/src/app/include',library/'source/src',library/'library')]
entry=out/'entry.c';entry.write_text('#include "jpeg_decoder_internal.h"\nconst unsigned char native_context_bytes[sizeof(jpeg_decoder_t)]={0};\nconst char *native_decoder_entry(const jpeg_decoder_config_t *c,const jpeg_decode_request_t *r,jpeg_decode_diagnostic_t *d){jpeg_decoder_t *s=jpeg_decoder_create(c,d);if(s){jpeg_decoder_decode(s,r,d);jpeg_decoder_destroy(s);}return jpeg_decoder_status_name(d->status);}\n',encoding='utf-8',newline='\n')
commands=[];objects=[]
for name,source in [('decoder',files[0]),('memory',files[1]),('color',files[4]),('entry',entry)]:
    obj=out/(name+'.o');command=[str(gcc),*flags,'-c',str(source),'-o',str(obj)];commands.append(command)
    result=subprocess.run(command,capture_output=True,timeout=60);(out/(name+'.log')).write_bytes(result.stdout+result.stderr)
    if result.returncode:raise RuntimeError(result.stderr.decode(errors='replace'))
    objects.append(obj)
symbols=subprocess.check_output([str(nm),'--print-size','--defined-only',str(objects[-1])]);(out/'abi.txt').write_bytes(symbols)
context_size=next(int(line.split()[1],16) for line in symbols.decode().splitlines() if line.split()[-1]=='native_context_bytes')
linked=out/'native-decoder.o';command=[str(ld),'-r','--gc-sections','-e','native_decoder_entry','-Map='+str(out/'native.map'),*[str(p) for p in objects],str(library/'library/libjpeg.a'),'-o',str(linked)];commands.append(command)
result=subprocess.run(command,capture_output=True,timeout=60);(out/'link.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0,result.stderr
undefined=subprocess.check_output([str(nm),'-u',str(linked)]);(out/'undefined.txt').write_bytes(undefined)
frames={}
for path in out.glob('*.su'):
    frames[path.name]={}
    for line in path.read_text().splitlines():
        match=re.search(r':\d+:\d+:([^:]+)\t(\d+)\t(.+)$',line);assert match,line
        frames[path.name][match[1]]=dict(bytes=int(match[2]),kind=match[3])
assert all(sha(Path(p))==h for p,h in pins.items())
report=dict(passed=True,runtime_tested=False,inputs_unchanged=True,inputs_sha256=pins,commands=commands,context_bytes=context_size,
    retained_sizes=elf_sections(linked),module_sizes={p.stem:elf_sections(p) for p in objects[:-1]},binding_frames=frames,
    object_sha256=sha(linked),unresolved=undefined.decode().splitlines(),scope='Relocatable native decoder+RGB565+pinned RV32 JPEG link; excludes libc/libgcc/SDK/startup, complete call-chain stack, actual target execution, final app/link/heap/timing.')
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print('RV32 native binding:',report['retained_sizes']['code_bytes'],'code +',report['retained_sizes']['readonly_bytes'],'rodata; context',context_size)
