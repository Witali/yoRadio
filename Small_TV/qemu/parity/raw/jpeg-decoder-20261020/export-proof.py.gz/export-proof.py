import gzip,hashlib,io,json,tarfile
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
PARITY=ROOT/'Small_TV/qemu/parity';DEST=PARITY/'raw/jpeg-decoder-20261020';DEST.mkdir(parents=True,exist_ok=False)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=[]

def add_data(name,data):
    path=DEST/(name+'.gz');path.parent.mkdir(parents=True,exist_ok=True);assert not path.exists(),path
    packed=gzip.compress(data,compresslevel=9,mtime=0);path.write_bytes(packed)
    raw.append(dict(file=path.relative_to(PARITY).as_posix(),sha256=sha(packed),bytes=len(packed),
        uncompressed_sha256=sha(data),uncompressed_bytes=len(data)))

def add(path,name=None):
    add_data(name or path.relative_to(BASE).as_posix(),path.read_bytes())

contract=read(BASE/'contract-classified/report.json');mutants=read(BASE/'mutants/report.json')
rv32=read(BASE/'rv32-binding-final/report.json');library=read(BASE/'rv32-library/report.json')
host=read(BASE/'host-classified/build.json');generator=read(BASE/'generator-v2/build.json')
artifacts=read(BASE/'artifacts.json')
assert contract['passed'] and contract['inputs_unchanged']
assert {k:len(contract[k]) for k in ('positive','limits','negative','faults','transitions')}==dict(positive=63,limits=7,negative=10,faults=1197,transitions=12)
assert mutants['passed'] and mutants['inputs_unchanged'] and len(mutants['cases'])==6
assert rv32['passed'] and rv32['inputs_unchanged']
assert all(not line.split()[-1].startswith(('jpeg_','j12','j16','jinit_','color_')) for line in rv32['unresolved'])
assert library['status']=='rv32_cross_compile_passed' and library['upstream_commit']=='c85e6b905bf237038faa936dab160ebfc5da0344'
assert artifacts['passed'] and artifacts['cases']==6
assert 'Ran 10 tests' in (BASE/'correspondence.log').read_text(encoding='utf-8-sig')
source_paths=set();compile_inputs={}
for pins in (read(BASE/'host-classified/inputs.json'),read(BASE/'generator-v2/inputs.json'),rv32['inputs_sha256']):
    for name,h in pins.items():
        p=Path(name);assert sha(p.read_bytes())==h,p;compile_inputs[name]=h
        if p.is_relative_to(ROOT/'Small_TV/src'):source_paths.add(p)
for p in (ROOT/'Small_TV/src/tests/jpeg_decoder').iterdir():
    if p.is_file():source_paths.add(p)
for name in ('color_convert_contract.py','jpeg_library_probe/rv32_footprint.py','jpeg_library_probe/build.py'):
    source_paths.add(ROOT/'Small_TV/src/tests'/name)
assert sha(Path(host['executable']).read_bytes())==host['executable_sha256']
assert sha(Path(generator['executable']).read_bytes())==generator['executable_sha256']
assert sha((ROOT/'Small_TV/src/tests/jpeg_decoder/contract.py').read_bytes())==contract['runner_sha256']
source_sha={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted(source_paths)}
for p in sorted(source_paths):add(p,'source/'+p.relative_to(ROOT).as_posix())
for folder in ('host-classified','generator-v2','mutants','rv32-binding-final'):
    for p in sorted((BASE/folder).rglob('*')):
        if p.is_file() and p.suffix in ('.json','.txt','.c','.h','.su','.log','.cmd','.o','.map'):add(p)
add(BASE/'contract-classified/report.json')
add(BASE/'rv32-library/report.json')
for name in ('rv32-toolchain.cmake','decoder.map','sections.txt','elf-architecture.txt','compiler.txt','unresolved.txt','symbol-sizes.txt'):
    add(BASE/'rv32-library'/name)
for name in ('artifacts.json','h10-owners.json','sdk-status.txt','before-c11-internal.h','before-c11-decoder.c',
             'before-error-classification.c','generator-before-type-fix.c','measure-binding-first.py',
             'measure-binding-portable.py','contract-before-extra-headers.py','measure-binding.py','export-proof.py'):
    add(BASE/name)
for p in sorted(BASE.glob('*.log')):add(p)
add(ROOT/'.build/jpeg-decoder-first-build.log','first-host-build.log')
for folder in ('host-v2','host-final','host-portable','generator'):
    for name in ('inputs.json','build.json'):
        path=BASE/folder/name
        if path.exists():add(path,'history/'+folder+'/'+name)
for folder in ('contract','contract-final','contract-portable'):
    add(BASE/folder/'report.json','history/'+folder+'/report.json')
for folder in ('rv32-binding','rv32-binding-v2'):
    for name in ('decoder.log','report.json'):
        path=BASE/folder/name
        if path.exists():add(path,'history/'+folder+'/'+name)
# Archive exact native/private ABI header views, without redundant source trees or binaries.
headers=io.BytesIO()
with tarfile.open(fileobj=headers,mode='w') as archive:
    for i,(name,h) in enumerate(sorted(compile_inputs.items())):
        p=Path(name)
        if p.suffix=='.h' and not p.is_relative_to(ROOT/'Small_TV/src'):
            data=p.read_bytes();info=tarfile.TarInfo(f'{i:03d}/'+p.name);info.size=len(data);archive.addfile(info,io.BytesIO(data))
add_data('compile-headers.tar',headers.getvalue())
for name in ('LICENSE.md','README.ijg'):
    add(ROOT/'Small_TV/src/tests/jpeg_library_probe/licenses'/name,'upstream-licenses/'+name)
fixtures=[];images=io.BytesIO()
with tarfile.open(fileobj=images,mode='w') as archive:
    for p in sorted((BASE/'contract-classified/fixtures').glob('*.jpg')):
        data=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(data);archive.addfile(info,io.BytesIO(data))
        fixtures.append(dict(file=p.name,sha256=sha(data),bytes=len(data)))
add_data('fixtures.tar',images.getvalue())
frozen_root=Path('C:/Work/yoRadio/.worktree/small-tv-jpeg-selectors/.build/jpeg-selector-qemu-complete-20261019')
frozen=read(frozen_root/'frozen-inputs.json');assert len(frozen['files'])==46
assert all(sha((frozen_root/f['file']).read_bytes())==f['sha256'] for f in frozen['files'])
add(frozen_root/'frozen-inputs.json','old-h10-frozen-inputs.json')
owners=read(BASE/'h10-owners.json');times={22184:'09:27:35.206623',32636:'09:27:35.684696',20772:'09:27:35.711979',32580:'09:27:41.510965',18268:'09:28:10.414044',14972:'09:28:10.447191'}
assert {x['ProcessId'] for x in owners}==set(times)
assert all(datetime.fromisoformat(x['CreationDate']).astimezone(timezone.utc)==datetime.fromisoformat('2026-10-20T'+times[x['ProcessId']]+'+00:00') for x in owners)
assert not (BASE/'sdk-status.txt').read_text(encoding='utf-8-sig').strip()
main=ROOT/'firmware/development/small-tv-esp32c2-reconstructed/app.bin';probe=ROOT/'firmware/development/small-tv-storage-probe/app.bin'
assert sha(main.read_bytes())=='3e030c1cc5f7b456fefc9985c397daf8340c33d1bb2805965b076147a07cd7e1'
assert sha(probe.read_bytes())=='6cb297718cb657bb91443cbaf8a345b0ab2091d60b55a1669a08b4d12b5ac944'
report=dict(schema_version=1,passed=True,all_functionality_verified=False,
    scope='Real reusable portable JPEG decoder with bounded source/RGB565/backing callbacks, capped allocator, whole-array preflight and typed errors. Host stdio adapters and RV32 relocatable binding only; not target execution/UI/NOR/upload/privacy/cache workflow or final acceptance.',
    source_sha256=source_sha,compile_inputs_sha256=compile_inputs,host_build=host,generator_build=generator,
    host_counts={k:len(contract[k]) for k in ('positive','limits','negative','faults','transitions')},
    resource_cases=contract['limits'],negative_cases=contract['negative'],format_transitions=contract['transitions'],
    negative_controls=mutants['cases'],host_full_cmyk12=next(x['result']['first'] for x in contract['positive'] if x['name']=='full-cmyk12.jpg'),
    expanded_sampling_positive_limits=dict(library_pool=262144,backing_capacity=1048576,device_fit_claimed=False),
    rv32_binding=rv32,rv32_library=library,artifact_checks=artifacts,correspondence_controls=10,
    main_production=dict(app_sha256=sha(main.read_bytes()),decoder='TJpgd',unchanged=True),
    transport_probe=dict(app_sha256=sha(probe.read_bytes()),unchanged=True,new_decoder_executed=False),
    sdk_tracked_clean=True,old_h10=dict(owners=owners,frozen_payloads=46,manifest_included=True,QMP_RSP_interaction=False),
    early_failures=['test generator J12SAMPROW signedness','strictC11 private jinclude setenv declaration and misleading indentation'],
    required_remaining=['portable actual NOR/packed backing adapter for this new API','target execution/whole heap/task stack/time/final app link',
        'source/upload/journal/physical source+frame hashes/durable RGB565 cache workflow',
        'matching assets build/deployment preserving all photos/settings and native UI/error/privacy HTTP integration',
        'independent LCD/network/full/24h/hardware gates and remaining full factory-image/network/electrical audit'],
    fixtures=fixtures,raw_artifacts=raw)
path=PARITY/'jpeg-decoder-validation-20261020.json';assert not path.exists();path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
for r in raw:
    data=(PARITY/r['file']).read_bytes();assert sha(data)==r['sha256'] and sha(gzip.decompress(data))==r['uncompressed_sha256']
print('Saved decoder proof:',len(source_sha),'source pins,',len(raw),'raw files,',len(fixtures),'fixtures;',sum(r['bytes'] for r in raw),'compressed bytes')
