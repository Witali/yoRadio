from pathlib import Path
import gzip,hashlib,json,subprocess,sys
root=Path.cwd();project=root/'Small_TV/src';build=root/'.build/jpeg-main-20261020';parity=root/'Small_TV/qemu/parity'
rawroot=parity/'raw/jpeg-dependency-build-20261020';rawroot.mkdir(parents=True,exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest=json.loads((root/'firmware/development/small-tv-esp32c2-reconstructed/manifest.json').read_text())
selection=json.loads((build/'main/jpeg-library/selection.json').read_text());library=Path(selection['build_directory'])
sys.path.insert(0,str(project/'tools'));import audit_correspondence as audit
review=json.loads((project/'reference/correspondence.json').read_text());inventory=audit.audit(project,review)
(build/'inventory-final.json').write_text(json.dumps(inventory,indent=2)+'\n',encoding='utf-8',newline='\n')
source={('Small_TV/'+n):h for n,h in audit.inputs(project).items()}
extra=['tools/audit_correspondence.py','tests/correspondence_test.py','tests/jpeg_dependency_test.py','tests/jpeg_cache/generator_contract.py','tests/native_test.c','tests/run.ps1','tests/artifact_test.py','reference/correspondence.json']
extra += [p.relative_to(project).as_posix() for p in (project/'tests/stubs').rglob('*') if p.is_file()]
for name in extra:source['Small_TV/src/'+name]=sha((project/name).read_bytes())
raws=[]
def save(name,path):
    data=path.read_bytes();destination=rawroot/(name+'.gz');destination.parent.mkdir(parents=True,exist_ok=True);packed=gzip.compress(data,compresslevel=9,mtime=0);destination.write_bytes(packed)
    raws.append(dict(file=destination.relative_to(parity).as_posix(),sha256=sha(packed),uncompressed_sha256=sha(data),bytes=len(data)))
for name in ['build.log','build-retry.log','build-final.log','dependency-tests.log','dependency-tests-final.log','native-tests.log','native-tests-reviewed.log','correspondence-final.log','cache-layout.log','artifact-tests.log','artifact-tests.json','sdk-status.txt','h10-owners.json','defined-symbols.txt','sections.txt','elf-architecture.txt','link-evidence.json','inventory-final.json']:
    save(name,build/name)
for path in sorted((build/'main/log').glob('idf_py_*_output_*')):save('idf-logs/'+path.name,path)
for name in ['report.json','rv32-toolchain.cmake','library/CMakeCache.txt','library/build.ninja']:
    save('dependency/'+name,library/name)
save('qualification/old-build.ninja',root/'.build/jpeg-decoder-20261020/rv32-library/library/build.ninja')
save('native-report.json',root/'.build/small-tv-esp32c2/native-tests/report.json')
save('cache-layout-report.json',build/'cache-layout-contract/report.json')
save('main-manifest.json',root/'firmware/development/small-tv-esp32c2-reconstructed/manifest.json')
save('export-proof.py',Path(sys.argv[0])) if sys.argv[0]!='-' else None
native=json.loads((root/'.build/small-tv-esp32c2/native-tests/report.json').read_text());artifacts=json.loads((build/'artifact-tests.json').read_text());link=json.loads((build/'link-evidence.json').read_text())
assert native['passed'] and artifacts['passed'] and link['passed']
report=dict(schema_version=1,passed=True,scope='Offline dependency/main compile-link and scoped host contracts; UI/upload still TJpgd',all_functionality_verified=False,physical_hardware_tested=False,new_target_runtime_tested=False,new_vm_started=False,app_sha256=next(x['sha256'] for x in manifest['images'] if x['file']=='app.bin'),elf_sha256=manifest['elf_sha256'],source_sha256=manifest['source_sha256'],app_bytes=1170432,app_partition_free_bytes=365568,dependency_archive_sha256=selection['library_sha256'],dependency_archive_matches_qualified_target=True,dependency_tests=13,inventory_controls=12,native_checks=5806,cache_generator_rejections=10,artifact_checks=6,inventory=dict(factory=176,app=170,total=459),link_evidence=link,source_pins=source,raw_artifacts=raws,limitations=['Codec/cache not activated by UI or upload; no new complete application memory/stack/latency or runtime proof.','Old library also used Os in actual Ninja commands; the cache O3 entry was misleading. Byte identity is not a new optimization claim.','Assets remain unchanged; guard stamp/cache deployment and preservation of user source/settings still pending.','No hardware flash; protected old H10 and shared SDK were only observed read-only.'])
(parity/'jpeg-dependency-build-validation-20261020.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Proof saved:',len(raws),'raw files;',len(source),'source pins;',sum((parity/r['file']).stat().st_size for r in raws),'compressed bytes')
