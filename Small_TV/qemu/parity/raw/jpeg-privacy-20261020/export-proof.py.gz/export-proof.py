from pathlib import Path
import json,subprocess,hashlib,gzip,sys,re
root=Path.cwd();project=root/'Small_TV/src';build=root/'.build/jpeg-privacy-20261020';main=root/'.build/jpeg-main-20261020/main';parity=root/'Small_TV/qemu/parity';raw=parity/'raw/jpeg-privacy-20261020';raw.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tools=Path('C:/Work/yoRadio/.idf/tools-v6.1/tools/riscv32-esp-elf/esp-15.2.0_20251204/riscv32-esp-elf/bin')
elf=main/'small_tv_reconstructed.elf'
symbols=subprocess.check_output([str(tools/'riscv32-esp-elf-nm.exe'),'--defined-only',str(elf)])
(build/'defined-symbols.txt').write_bytes(symbols)
names={line.split()[-1].decode() for line in symbols.splitlines() if line.split()}
assert 'jpeg_privacy_check' in names and 'jd_decomp' in names and 'jpeg_decoder_decode' not in names
listing=subprocess.check_output([str(tools/'riscv32-esp-elf-objdump.exe'),'-d','--disassemble=photo_upload_finish',str(elf)])
assert b'<jpeg_privacy_check>' in listing and b'<media_validate_jpeg_unlocked>' in listing
(build/'upload-finish-disassembly.txt').write_bytes(listing)
manifest=json.loads((root/'firmware/development/small-tv-esp32c2-reconstructed/manifest.json').read_text());assert sha(elf)==manifest['elf_sha256']
sys.path.insert(0,str(project/'tools'));import audit_correspondence as a
review=json.loads((project/'reference/correspondence.json').read_text());inventory=a.audit(project,review)
(build/'inventory-final.json').write_text(json.dumps(inventory,indent=2)+'\n',encoding='utf-8',newline='\n')
source={'Small_TV/'+n:h for n,h in a.inputs(project).items()}
extras=['tests/jpeg_privacy/native_test.c','tests/jpeg_privacy/run.ps1','tests/jpeg_privacy/contract.py','tests/jpeg_privacy/mutation_contract.py','tests/run.ps1','tests/native_test.c','tests/artifact_test.py','tests/correspondence_test.py','tests/jpeg_cache/generator_contract.py','tools/audit_correspondence.py','reference/correspondence.json']
extras += [p.relative_to(project).as_posix() for p in (project/'tests/stubs').rglob('*') if p.is_file()]
for name in extras:source['Small_TV/src/'+name]=sha(project/name)
artifacts=[]
def save(name,path):
 data=path.read_bytes();packed=gzip.compress(data,compresslevel=9,mtime=0);dest=raw/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed)
 artifacts.append(dict(file=dest.relative_to(parity).as_posix(),sha256=hashlib.sha256(packed).hexdigest(),uncompressed_sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
for name in ['native-first.log','native-final.log','native-integration.log','native-final-integration.log','real-first.log','real-final.log','mutants-first.log','mutants-final.log','target-build.log','artifact-tests.json','artifact-tests.log','cache-identity.log','privacy.su','sections.txt','privacy.o','sdk-status.txt','h10-owners.json','defined-symbols.txt','upload-finish-disassembly.txt','inventory-final.json']:
 save(name,build/name)
for dirname in ('native-final','real-final','mutants-final','cache-identity'):
 for path in sorted((build/dirname).rglob('*')):
  if path.is_file() and path.suffix in ('.json','.log','.c','.jpg'):save(dirname+'/'+path.relative_to(build/dirname).as_posix(),path)
for path in sorted((main/'log').glob('idf_py_*_output_*')):save('idf-logs/'+path.name,path)
for name in ['report.json','privacy-report.json']:save('ordinary-native/'+name,root/'.build/small-tv-esp32c2/native-tests'/name)
save('main-manifest.json',root/'firmware/development/small-tv-esp32c2-reconstructed/manifest.json')
save('export-proof.py',Path(__file__))
unit=json.loads((build/'native-final/report.json').read_text(encoding='utf-8-sig'));real=json.loads((build/'real-final/report.json').read_text());mutants=json.loads((build/'mutants-final/report.json').read_text());artifact=json.loads((build/'artifact-tests.json').read_text());owners=json.loads((build/'h10-owners.json').read_text(encoding='utf-8-sig'))
assert unit['passed'] and real['passed'] and mutants['passed'] and artifact['passed'] and len(owners)==6
assert (build/'sdk-status.txt').read_text(encoding='utf-8-sig').strip()==''
record=dict(schema_version=1,passed=True,scope='Actual upload privacy integration, host contracts and RV32 build/link; not decoder or complete target runtime acceptance',all_functionality_verified=False,physical_hardware_tested=False,new_vm_started=False,new_target_runtime_tested=False,app_sha256=next(x['sha256'] for x in manifest['images'] if x['file']=='app.bin'),elf_sha256=manifest['elf_sha256'],source_sha256=manifest['source_sha256'],app_bytes=1171136,app_partition_free_bytes=364864,privacy_unit=unit,valid_jpeg_files=len(real['positive']),private_trailing_refusals=len(real['rejected']),compiled_unsafe_mutants=len(mutants['mutants']),ordinary_native_checks=5806,inventory=dict(factory=176,app=172,total=469),inventory_controls=12,cache_identity_rejections=10,artifact_checks=6,rv32=dict(code_bytes=1224,readonly_bytes=180,initialized_writable_bytes=0,zero_initialized_bytes=0,largest_function_frame_bytes=368),privacy_called_by_upload=True,new_decoder_called_by_ui=False,source_pins=source,raw_artifacts=artifacts,limitations=['Privacy grammar acceptance is not entropy/dimension/resource/codec acceptance.','TJpgd still decodes actual uploads/UI; progressive HTTP support and asynchronous worker remain pending.','Compiler stack frame does not prove complete HTTP task headroom.','No new VM, network/LCD/RF/hardware/full/24h acceptance claim.'])
(parity/'jpeg-privacy-validation-20261020.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Proof:',len(artifacts),'raw files;',len(source),'source pins;',sum((parity/x['file']).stat().st_size for x in artifacts),'bytes compressed')
