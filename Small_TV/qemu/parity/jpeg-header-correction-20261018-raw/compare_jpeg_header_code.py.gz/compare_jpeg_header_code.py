"""Preserve exact decoder disassemblies and independently compare JDEC layouts."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

BASE=Path('C:/Work/yoRadio')
BEFORE=BASE/'.worktree/small-tv-reset-display'
AFTER=BASE/'.worktree/small-tv-jpeg-headers'
OUT=BASE/'.build/jpeg-header-code-comparison-20261018'
OUT.mkdir(exist_ok=True)
assert not any(OUT.iterdir()), 'Preserve an existing completed/partial comparison'
DUMP=BASE/'.idf/tools-v6.1/tools/riscv32-esp-elf/esp-15.2.0_20251204/riscv32-esp-elf/bin/riscv32-esp-elf-objdump.exe'
sys.path.insert(0,str(AFTER/'.build/small-tv-parity/oracle-deps'))
from elftools.elf.elffile import ELFFile
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()

def layout(path):
    """Read structure sizes/member offsets from each actual linked native ELF."""
    with path.open('rb') as stream:
        elf=ELFFile(stream)
        for cu in elf.get_dwarf_info().iter_CUs():
            for die in cu.iter_DIEs():
                name=die.attributes.get('DW_AT_name')
                if die.tag!='DW_TAG_structure_type' or not name or name.value!=b'JDEC' or 'DW_AT_byte_size' not in die.attributes:
                    continue
                members={child.attributes['DW_AT_name'].value.decode():child.attributes['DW_AT_data_member_location'].value
                    for child in die.iter_children() if child.tag=='DW_TAG_member'}
                return dict(size=die.attributes['DW_AT_byte_size'].value,members=members)
    raise ValueError('No linked JDEC type')

records={}
for tag,root in (('before',BEFORE),('after',AFTER)):
    elf=root/'.build/small-tv-esp32c2/small_tv_reconstructed.elf'
    symbols=subprocess.check_output([str(DUMP),'-t',str(elf)])
    names=[]
    for line in symbols.decode().splitlines():
        if any(name in line.split()[-1:] for name in ('jd_prepare','create_qt_tbl')):
            names.append(line.split()[-1])
    assert 'jd_prepare' in names
    for name in names:
        data=subprocess.check_output([str(DUMP),'-d','--disassemble='+name,str(elf)])
        (OUT/(tag+'-'+name+'.asm')).write_bytes(data)
    records[tag]=dict(elf_sha256=sha(elf),layout=layout(elf),dumped_symbols=names)
old,new=records['before']['layout'],records['after']['layout']
assert all(new['members'][name]==offset for name,offset in old['members'].items())
assert set(new['members'])-set(old['members'])=={'component_id'}
assert new['members']['component_id']==old['size'] and new['size']==old['size']+4
record=dict(passed=True,scope='Exact native jd_prepare/quantizer disassembly and linked JDEC layout comparison. Pixel/machine/HTTP correctness is established by separate tests.',
    native=records,existing_member_offsets_unchanged=True,added_tail_bytes=3,rv32_struct_size_delta=4,
    factory_header_assembly_sha256=sha(AFTER/'Small_TV/src/reference/assembly/jpeg_header_prepare_at_42011c48.asm'),
    factory_quantizer_assembly_sha256=sha(AFTER/'Small_TV/src/reference/assembly/jpeg_quantization_tables_at_4201105c.asm'),
    objdump_sha256=sha(DUMP),evidence={path.name:sha(path) for path in OUT.glob('*.asm')})
(OUT/'report.json').write_text(json.dumps(record,indent=2)+'\n',newline='\n')
print(json.dumps(dict(passed=True,before_size=old['size'],after_size=new['size'],existing_offsets_unchanged=True)))
