"""Probe actual factory/native JPEG header paths through SDK input boundaries."""
from pathlib import Path
import hashlib
import json
import sys

ROOT=Path('C:/Work/yoRadio/.worktree/small-tv-reset-display')
sys.path.insert(0,str(ROOT/'.build/small-tv-parity/oracle-deps'))
sys.path.insert(0,str(ROOT/'Small_TV/src/tests'))
from control_oracle import verify_inputs
from jpeg_oracle import JpegMachine, patterned_panel
from jpeg_test_fixtures import gray_huffman_fixture

OUT=Path('C:/Work/yoRadio/.build/jpeg-header-before-20261018')
OUT.mkdir(exist_ok=False)
original=(ROOT/'Small_TV/full-flash.bin').read_bytes()
sha=lambda data:hashlib.sha256(data).hexdigest()
app=verify_inputs(ROOT,ROOT)
factory=JpegMachine('factory',original,dependency_root=ROOT)
native=JpegMachine('native',original,dependency_root=ROOT)
one=[1]+[0]*15
baseline=gray_huffman_fixture(one,[0],one,[0],width=8,height=8)
scan=baseline.index(b'\xff\xda')
old_length=int.from_bytes(baseline[scan+2:scan+4],'big')
payload=baseline[scan+4:scan+2+old_length]
cases=[('baseline',True,baseline)]
def segment(marker,payload):
    return b'\xff'+bytes([marker])+(len(payload)+2).to_bytes(2,'big')+payload
for name,valid,data in [('zero',True,b'\0\0'),('one',True,b'\0\1'),('maximum',True,b'\xff\xff'),
                        ('short',False,b'\0'),('extra',False,b'\0\0\0')]:
    cases.append(('dri-'+name,valid,baseline[:scan]+segment(0xdd,data)+baseline[scan:]))
for length in range(1,6):
    cases.append(('sos-short-'+str(length),False,
        baseline[:scan]+segment(0xda,payload[:length])+baseline[scan+2+old_length:]))
cases.append(('sos-extra',False,baseline[:scan]+segment(0xda,payload+b'\0')+baseline[scan+2+old_length:]))
for name,offset,value in [('spectral-start',3,1),('spectral-end',4,62),('approx-high',5,0x10),
                           ('approx-low',5,1),('wrong-component',1,2)]:
    changed=bytearray(payload);changed[offset]=value
    cases.append(('sos-'+name,False,baseline[:scan]+segment(0xda,changed)+baseline[scan+2+old_length:]))
for value in (0,17,255):
    data=bytearray(baseline)
    frame=data.index(b'\xff\xc0')
    data[frame+10]=value;data[scan+5]=value
    cases.append(('component-id-'+str(value),True,bytes(data)))
for offset in (0,63):
    data=bytearray(baseline);data[7+offset]=0
    cases.append(('zero-quantizer-'+str(offset),False,bytes(data)))
inputs=[ROOT/'Small_TV/full-flash.bin',ROOT/'.build/small-tv-esp32c2/small_tv_reconstructed.elf',
        ROOT/'firmware/development/small-tv-esp32c2-reconstructed/app.bin',
        ROOT/'Small_TV/src/third_party/tjpgd/tjpgd.c']
before={str(path):sha(path.read_bytes()) for path in inputs}
rows=[]
for name,valid,data in cases:
    asset=dict(width=8,height=8,source_length=len(data),flash_offset=hex(0x200000),native_offset=0x200000)
    factory.dump=original[:0x200000]+data+b'\xff'*512+original[0x200000+len(data)+512:]
    native.native_assets=data+b'\xff'*512+native.native_assets[len(data)+512:]
    row=dict(name=name,expected_valid=valid,fixture_sha256=sha(data),fixture_hex=data.hex())
    for label,machine in (('factory',factory),('native',native)):
        machine.panel=patterned_panel();initial=machine.panel.pixels[:]
        result=machine.draw(asset,length=len(data))
        row[label]=dict(result=result,decoder_started=machine.decompression_started,
                        changed_pixels=sum(a!=b for a,b in zip(initial,machine.panel.pixels)))
    native.panel=patterned_panel();initial=native.panel.pixels[:]
    result=native.validate(asset,8,8,length=len(data))
    row['validation']=dict(result=result,decoder_started=native.decompression_started,
        changed_pixels=sum(a!=b for a,b in zip(initial,native.panel.pixels)))
    rows.append(row)
    print(json.dumps({key:row[key] for key in ('name','expected_valid','factory','native','validation')}),flush=True)
report=dict(app_sha256=app,inputs_sha256=before,cases=rows,
 inputs_unchanged=all(sha(Path(path).read_bytes())==value for path,value in before.items()),
 scope='Header investigation through unchanged actual RV32 factory/native instructions; inputs supplied only at SDK reads. Invalid acceptance is recorded, not relabeled as a pass.')
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',newline='\n')
