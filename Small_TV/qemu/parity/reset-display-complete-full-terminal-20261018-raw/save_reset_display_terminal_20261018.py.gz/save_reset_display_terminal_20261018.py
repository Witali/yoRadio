"""Preserve terminal historical 0592/D64 full-suite evidence with frozen inputs."""
from pathlib import Path
import datetime as dt
import gzip
import hashlib
import json

BASE = Path('C:/Work/yoRadio')
ROOT = BASE / '.worktree/small-tv-reset-display'
PARITY = ROOT / 'Small_TV/qemu/parity'
RUN = BASE / '.build/small-tv-functional/reset-display-complete-full-20261018'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
freeze_path = PARITY / 'reset-display-complete-full-start-20261018.json'
freeze = read(freeze_path)
full = read(RUN / 'report.json')
terminal = read(RUN / 'controller-exit.json')
assert full['passed'] and not full['all_functionality_verified']
assert terminal['status'] == 'terminal_passed' and terminal['exit_code'] == 0
assert full['app_sha256'] == freeze['app_sha256']
assert full['source_sha256'] == freeze['source_sha256']
assert len(freeze['tests']) + len(freeze['extra_inputs']) == freeze['input_count'] == 561
for row in freeze['tests']:
    assert sha((ROOT / row['file']).read_bytes()) == row['sha256'], row['file']
for row in freeze['extra_inputs']:
    root = ROOT if row['root'] == 'yoRadio' else Path(freeze['qemu_root'])
    assert sha((root / row['file']).read_bytes()) == row['sha256'], row['file']
groups = [row['name'] for row in full['groups'] if row['status'] == 'passed']
assert len(groups) == 19 and not any(row['status'] == 'failed' for row in full['groups'])
qemu = read(RUN / 'qemu/report.json')
assert qemu['passed'] and qemu['inputs_unchanged'] and not qemu['errors']
published = PARITY / 'reset-display-complete-full-published-20261018.json'
verified = PARITY / 'reset-display-complete-full-artifacts-20261018.json'
checks = read(verified)
assert checks['app_sha256'] == freeze['app_sha256']
assert checks['source_sha256'] == freeze['source_sha256']
assert checks['asset_pack_matches_sanitized_exports']
assert checks['compiled_source_hashes_match_archive']
assert checks['partition_table_md5_valid'] and checks['original_flash_dump_unchanged']
raw = PARITY / 'reset-display-complete-full-terminal-20261018-raw'
raw.mkdir(exist_ok=False)
evidence = []
paths = [(freeze_path, 'frozen-start.json'), (RUN / 'controller-exit.json', 'controller-exit.json'),
         (Path(__file__), 'save_reset_display_terminal_20261018.py')]
paths += [(p, p.relative_to(RUN).as_posix().replace('/', '__')) for p in sorted(RUN.rglob('report.json'))]
paths += [(p, p.name) for p in sorted(RUN.glob('*.log'))]
for source, label in paths:
    data = source.read_bytes()
    target = raw / (label + '.gz')
    assert not target.exists()
    target.write_bytes(gzip.compress(data, mtime=0))
    evidence.append(dict(file=target.relative_to(PARITY).as_posix(), original_sha256=sha(data),
                         gzip_sha256=sha(target.read_bytes())))
record = dict(status='terminal_passed', passed=True, all_functionality_verified=False,
              captured_utc=dt.datetime.now(dt.timezone.utc).isoformat(), terminal=terminal,
              app_sha256=freeze['app_sha256'], elf_sha256=freeze['elf_sha256'],
              source_sha256=freeze['source_sha256'], qemu_sha256=freeze['qemu_sha256'],
              input_count=561, inputs_verified=True, passed_groups=groups,
              not_run=[row['name'] for row in full['groups'] if row['status'] == 'not_run'],
              published=dict(file=published.name, sha256=sha(published.read_bytes())),
              artifact_verification=dict(file=verified.name, sha256=sha(verified.read_bytes())),
              evidence=evidence,
              scope='Historical 0592/D64 full host/RV32/QEMU suite with independent reset subsystem results. '
                    'Not F1 acceptance, standalone new browser/cold-LCD gates, H10, physical hardware or CYD acceptance.')
target = PARITY / 'reset-display-complete-full-terminal-20261018.json'
assert not target.exists()
target.write_text(json.dumps(record, indent=2) + '\n', newline='\n')
print(json.dumps(dict(passed=True, groups=19, frozen_inputs=561, raw_files=len(evidence))))
