"""Preserve actual UI evidence and independently re-prepare immutable flash ranges."""
from pathlib import Path
from types import SimpleNamespace
import datetime as dt
import gzip
import hashlib
import json
import subprocess
import sys

BASE=Path('C:/Work/yoRadio')
ROOT=BASE/'.worktree/small-tv-browser-controls-verify'
PAIR=BASE/'.worktree/small-tv-jpeg-headers'
SNAP=PAIR/'.build/jpeg-header-qemu-complete-20261018'
RUN=ROOT/'.build/browser-controls-complete-20261018'
PARITY=ROOT/'Small_TV/qemu/parity'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
report=read(RUN/'report.json')
assert report['passed'] and all(report['checks'].values()) and len(report['checks'])==5
assert report['app_sha256']=='f1ada8b4da4338df3248ffb26a39a79e36bf5cf0e365eb2972b75c8721f7ea7b'
assert len(report['inputs_sha256'])==25
for path,value in report['inputs_sha256'].items():assert sha(Path(path).read_bytes())==value,path
assert len(report['stages']['mutate']['browser']['checks'])==236
assert len(report['stages']['cold']['browser']['checks'])==45
assert len(report['stages']['mutate']['browser']['posts'])==96
assert report['stages']['cold']['browser']['posts']==[]
assert report['stages']['mutate']['pid']!=report['stages']['cold']['pid']
for stage in ('mutate','cold'):
    item=report['stages'][stage];browser=item['browser']
    assert item['rom_boots']==1 and browser['passed']
    assert all(row['passed'] for row in browser['checks'])
    assert not browser['console'] and not browser['page_errors']
    uart=gzip.decompress((RUN/f'uart-controls-{stage}.log.gz').read_bytes())
    assert uart.count(b'ESP-ROM:esp32c2')==1
    assert not any(marker in uart for marker in (b'Guru Meditation',b'assert failed',b'abort() was called',b'watchdog got triggered'))
    assert {row['viewport']['width'] for row in browser['pages']}=={1280,390}
assert read(PARITY/'browser-controls-owned-vms-20261018.json')['all_absent']
sys.path[:0]=[str(SNAP/'tools'),str(ROOT/'Small_TV/src/tests')]
import small_tv_vm as vm
from browser_controls_qemu import matches_raw
fresh=BASE/'.build/browser-controls-independent-flash-20261018'
assert not fresh.exists()
args=SimpleNamespace(yoradio=str(ROOT),firmware='reconstructed',network='clock',persistent=True,
    rom_elf=str(BASE/'.idf/tools-v6.1/tools/esp-rom-elfs/20260528/esp32c2_rev200_rom.elf'),
    hardware_profile=str(ROOT/'Small_TV/qemu/profiles/small-tv-c2.json'))
vm.prepare(args,fresh)
before=(fresh/'flash.bin').read_bytes();after=(RUN/'vm/flash.bin').read_bytes()
assert len(before)==len(after)==0x400000
protected=[]
for low,high in ((0,0x9000),(0xf000,0x3e7000),(0x3e8000,0x400000)):
    assert before[low:high]==after[low:high]
    protected.append(dict(start=low,end=high,sha256=sha(after[low:high])))
expected=read(RUN/'expected-controls.json')
assert matches_raw(after[0x3e7000:0x3e7000+444],expected)
flash=dict(passed=True,protected_intervals=protected,raw_public_settings_match=True,
    raw_record_sha256=sha(after[0x3e7000:0x3e7000+444]),scope='Offline independent fresh preparation and protected byte comparison; no new VM, QMP or RSP client.')
(RUN/'independent-flash-check.json').write_text(json.dumps(flash,indent=2)+'\n',newline='\n')
git=lambda *a:subprocess.check_output(['git','-C',str(ROOT),*a],text=True).strip()
changed=git('diff','--name-only','1989bdcc','HEAD').splitlines()
assert set(changed)=={'Small_TV/src/WORK_LOG.md','Small_TV/src/WORKING_NOTES.md',
    'Small_TV/src/tests/README.md','Small_TV/src/tests/BROWSER_CONTROLS.md',
    'Small_TV/src/tests/browser_controls_qemu.py','Small_TV/src/tests/browser_controls_flow.mjs'}
sources={}
for name in ('browser_controls_qemu.py','browser_controls_flow.mjs'):
    path='Small_TV/src/tests/'+name
    data=(ROOT/path).read_bytes();canonical=subprocess.check_output(['git','-C',str(ROOT),'show','HEAD:'+path])
    assert data.replace(b'\r\n',b'\n')==canonical
    sources[path]=dict(worktree_sha256=sha(data),git_lf_sha256=sha(canonical))
raw=PARITY/'browser-controls-validation-20261018-raw';raw.mkdir(exist_ok=False)
artifacts=[]
def save(source,label,precompressed=False):
    data=source.read_bytes();payload=gzip.decompress(data) if precompressed else data
    target=raw/(label+'.gz');assert not target.exists();target.write_bytes(gzip.compress(payload,mtime=0))
    artifacts.append(dict(file=target.relative_to(PARITY).as_posix(),source_file_sha256=sha(data),
        payload_sha256=sha(payload),stored_sha256=sha(target.read_bytes()),source_was_gzip=precompressed))
for name in ('report.json','browser-controls-mutate.json','browser-controls-cold.json','expected-controls.json',
             'node-controls-mutate.log','node-controls-cold.log','independent-flash-check.json'):
    save(RUN/name,name)
for stage in ('mutate','cold'):save(RUN/f'uart-controls-{stage}.log.gz',f'uart-{stage}.log',True)
for name in sources:save(ROOT/name,Path(name).name)
save(Path(__file__),'save_browser_controls_evidence.py')
screens=[]
for source in sorted(RUN.glob('*.png')):
    target=raw/source.name;target.write_bytes(source.read_bytes())
    screens.append(dict(file=target.relative_to(PARITY).as_posix(),sha256=sha(target.read_bytes())))
assert len(screens)==12
record=dict(status='desktop_mobile_controls_and_cold_persistence_passed',passed=True,all_functionality_verified=False,
    captured_utc=dt.datetime.now(dt.timezone.utc).isoformat(),test_commit=git('rev-parse','HEAD'),
    app_sha256=report['app_sha256'],native_elf_sha256=report['native_elf_sha256'],qemu_sha256=report['qemu_sha256'],
    source_sha256=read(ROOT/'firmware/development/small-tv-esp32c2-reconstructed/manifest.json')['source_sha256'],
    browser_version=report['stages']['cold']['browser']['browser_version'],ui_checks=281,storage_source_checks=5,
    ui_post_requests=96,cold_post_requests=0,observed_input_count=25,source_hashes=sources,
    ui_checks_by_stage={stage:len(report['stages'][stage]['browser']['checks']) for stage in ('mutate','cold')},
    vm_processes={stage:dict(pid=report['stages'][stage]['pid'],name=report['stages'][stage]['vm_name'],rom_boots=1) for stage in ('mutate','cold')},
    os_cleanup=read(PARITY/'browser-controls-owned-vms-20261018.json'),independent_flash=flash,
    evidence=artifacts,screenshots=screens,production_changed=False,
    scope='Standalone real Chrome desktop/mobile H03/H04 controls gate on exact F1/D64. No LCD/PWM, RF/WPA/captive portal, Internet weather, crop/upload, power interruption mid-write, software restart, full-suite or H10 acceptance is claimed.')
(PARITY/'browser-controls-validation-20261018.json').write_text(json.dumps(record,indent=2)+'\n',newline='\n')
print(json.dumps(dict(passed=True,ui_checks=281,storage_checks=5,raw_files=len(artifacts),screenshots=12,production_changed=False)))
