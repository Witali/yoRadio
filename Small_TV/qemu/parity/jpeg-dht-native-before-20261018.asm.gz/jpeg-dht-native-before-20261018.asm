
.build/jpeg-dht-before/app.elf:     file format elf32-littleriscv


Disassembly of section .iram0.text:

Disassembly of section .flash.text:

42012f50 <jd_prepare>:
42012f50:	715d                	addi	sp,sp,-80
42012f52:	c2a6                	sw	s1,68(sp)
42012f54:	c0ca                	sw	s2,64(sp)
42012f56:	84ae                	mv	s1,a1
42012f58:	8932                	mv	s2,a2
42012f5a:	4581                	li	a1,0
42012f5c:	07800613          	li	a2,120
42012f60:	c686                	sw	ra,76(sp)
42012f62:	c4a2                	sw	s0,72(sp)
42012f64:	c636                	sw	a3,12(sp)
42012f66:	842a                	mv	s0,a0
42012f68:	c43a                	sw	a4,8(sp)
42012f6a:	de4e                	sw	s3,60(sp)
42012f6c:	dc52                	sw	s4,56(sp)
42012f6e:	da56                	sw	s5,52(sp)
42012f70:	d85a                	sw	s6,48(sp)
42012f72:	d65e                	sw	s7,44(sp)
42012f74:	d462                	sw	s8,40(sp)
42012f76:	d266                	sw	s9,36(sp)
42012f78:	d06a                	sw	s10,32(sp)
42012f7a:	ce6e                	sw	s11,28(sp)
42012f7c:	fdfed097          	auipc	ra,0xfdfed
42012f80:	50c080e7          	jalr	1292(ra) # 40000488 <memset>
42012f84:	46b2                	lw	a3,12(sp)
42012f86:	4722                	lw	a4,8(sp)
42012f88:	07242423          	sw	s2,104(s0)
42012f8c:	d474                	sw	a3,108(s0)
42012f8e:	d824                	sw	s1,112(s0)
42012f90:	d878                	sw	a4,116(s0)
42012f92:	20000593          	li	a1,512
42012f96:	8522                	mv	a0,s0
42012f98:	e33ff0ef          	jal	42012dca <alloc_pool>
42012f9c:	c408                	sw	a0,8(s0)
42012f9e:	22050e63          	beqz	a0,420131da <jd_prepare+0x28a>
42012fa2:	6a41                	lui	s4,0x10
42012fa4:	892a                	mv	s2,a0
42012fa6:	4981                	li	s3,0
42012fa8:	4481                	li	s1,0
42012faa:	4b05                	li	s6,1
42012fac:	fd8a0a13          	addi	s4,s4,-40 # ffd8 <CSR_UINTSTATUS+0xf327>
42012fb0:	583c                	lw	a5,112(s0)
42012fb2:	4605                	li	a2,1
42012fb4:	85ca                	mv	a1,s2
42012fb6:	8522                	mv	a0,s0
42012fb8:	9782                	jalr	a5
42012fba:	c42a                	sw	a0,8(sp)
42012fbc:	0b651b63          	bne	a0,s6,42013072 <jd_prepare+0x122>
42012fc0:	00094783          	lbu	a5,0(s2)
42012fc4:	04a2                	slli	s1,s1,0x8
42012fc6:	0985                	addi	s3,s3,1
42012fc8:	8cdd                	or	s1,s1,a5
42012fca:	04c2                	slli	s1,s1,0x10
42012fcc:	80c1                	srli	s1,s1,0x10
42012fce:	ff4491e3          	bne	s1,s4,42012fb0 <jd_prepare+0x60>
42012fd2:	6a41                	lui	s4,0x10
42012fd4:	1a7d                	addi	s4,s4,-1 # ffff <CSR_UINTSTATUS+0xf34e>
42012fd6:	0ff00c13          	li	s8,255
42012fda:	4cc5                	li	s9,17
42012fdc:	583c                	lw	a5,112(s0)
42012fde:	4611                	li	a2,4
42012fe0:	85ca                	mv	a1,s2
42012fe2:	8522                	mv	a0,s0
42012fe4:	9782                	jalr	a5
42012fe6:	4791                	li	a5,4
42012fe8:	8d2a                	mv	s10,a0
42012fea:	08f51463          	bne	a0,a5,42013072 <jd_prepare+0x122>
42012fee:	00095703          	lhu	a4,0(s2)
42012ff2:	09470263          	beq	a4,s4,42013076 <jd_prepare+0x126>
42012ff6:	00875793          	srli	a5,a4,0x8
42012ffa:	0722                	slli	a4,a4,0x8
42012ffc:	97ba                	add	a5,a5,a4
42012ffe:	00295703          	lhu	a4,2(s2)
42013002:	07c2                	slli	a5,a5,0x10
42013004:	83c1                	srli	a5,a5,0x10
42013006:	00875493          	srli	s1,a4,0x8
4201300a:	0722                	slli	a4,a4,0x8
4201300c:	94ba                	add	s1,s1,a4
4201300e:	04c2                	slli	s1,s1,0x10
42013010:	80c1                	srli	s1,s1,0x10
42013012:	4709                	li	a4,2
42013014:	3e977963          	bgeu	a4,s1,42013406 <jd_prepare+0x4b6>
42013018:	0087d713          	srli	a4,a5,0x8
4201301c:	3f871563          	bne	a4,s8,42013406 <jd_prepare+0x4b6>
42013020:	14f9                	addi	s1,s1,-2
42013022:	0991                	addi	s3,s3,4
42013024:	0ff7f793          	zext.b	a5,a5
42013028:	0da00713          	li	a4,218
4201302c:	99a6                	add	s3,s3,s1
4201302e:	30e78e63          	beq	a5,a4,4201334a <jd_prepare+0x3fa>
42013032:	06f76663          	bltu	a4,a5,4201309e <jd_prepare+0x14e>
42013036:	f4078793          	addi	a5,a5,-192
4201303a:	07c2                	slli	a5,a5,0x10
4201303c:	83c1                	srli	a5,a5,0x10
4201303e:	4765                	li	a4,25
42013040:	02f76263          	bltu	a4,a5,42013064 <jd_prepare+0x114>
42013044:	4705                	li	a4,1
42013046:	0200fdb7          	lui	s11,0x200f
4201304a:	00f71733          	sll	a4,a4,a5
4201304e:	eeed8d93          	addi	s11,s11,-274 # 200eeee <CSR_UINTSTATUS+0x200e23d>
42013052:	01b77db3          	and	s11,a4,s11
42013056:	120d9663          	bnez	s11,42013182 <jd_prepare+0x232>
4201305a:	4691                	li	a3,4
4201305c:	14d78463          	beq	a5,a3,420131a4 <jd_prepare+0x254>
42013060:	8b05                	andi	a4,a4,1
42013062:	eb35                	bnez	a4,420130d6 <jd_prepare+0x186>
42013064:	583c                	lw	a5,112(s0)
42013066:	8626                	mv	a2,s1
42013068:	4581                	li	a1,0
4201306a:	8522                	mv	a0,s0
4201306c:	9782                	jalr	a5
4201306e:	f69507e3          	beq	a0,s1,42012fdc <jd_prepare+0x8c>
42013072:	4d09                	li	s10,2
42013074:	aa01                	j	42013184 <jd_prepare+0x234>
42013076:	583c                	lw	a5,112(s0)
42013078:	4605                	li	a2,1
4201307a:	00490593          	addi	a1,s2,4
4201307e:	8522                	mv	a0,s0
42013080:	9782                	jalr	a5
42013082:	4785                	li	a5,1
42013084:	fef517e3          	bne	a0,a5,42013072 <jd_prepare+0x122>
42013088:	00195703          	lhu	a4,1(s2)
4201308c:	00875793          	srli	a5,a4,0x8
42013090:	0722                	slli	a4,a4,0x8
42013092:	97ba                	add	a5,a5,a4
42013094:	07c2                	slli	a5,a5,0x10
42013096:	00395703          	lhu	a4,3(s2)
4201309a:	83c1                	srli	a5,a5,0x10
4201309c:	b7ad                	j	42013006 <jd_prepare+0xb6>
4201309e:	0db00713          	li	a4,219
420130a2:	20e78c63          	beq	a5,a4,420132ba <jd_prepare+0x36a>
420130a6:	0dd00713          	li	a4,221
420130aa:	fae79de3          	bne	a5,a4,42013064 <jd_prepare+0x114>
420130ae:	20000793          	li	a5,512
420130b2:	0c97e963          	bltu	a5,s1,42013184 <jd_prepare+0x234>
420130b6:	583c                	lw	a5,112(s0)
420130b8:	8626                	mv	a2,s1
420130ba:	85ca                	mv	a1,s2
420130bc:	8522                	mv	a0,s0
420130be:	9782                	jalr	a5
420130c0:	fa9519e3          	bne	a0,s1,42013072 <jd_prepare+0x122>
420130c4:	00095783          	lhu	a5,0(s2)
420130c8:	0087d713          	srli	a4,a5,0x8
420130cc:	07a2                	slli	a5,a5,0x8
420130ce:	97ba                	add	a5,a5,a4
420130d0:	00f41d23          	sh	a5,26(s0)
420130d4:	b721                	j	42012fdc <jd_prepare+0x8c>
420130d6:	20000793          	li	a5,512
420130da:	0a97e563          	bltu	a5,s1,42013184 <jd_prepare+0x234>
420130de:	583c                	lw	a5,112(s0)
420130e0:	8626                	mv	a2,s1
420130e2:	85ca                	mv	a1,s2
420130e4:	8522                	mv	a0,s0
420130e6:	9782                	jalr	a5
420130e8:	f89515e3          	bne	a0,s1,42013072 <jd_prepare+0x122>
420130ec:	4795                	li	a5,5
420130ee:	3097fc63          	bgeu	a5,s1,42013406 <jd_prepare+0x4b6>
420130f2:	00094703          	lbu	a4,0(s2)
420130f6:	47a1                	li	a5,8
420130f8:	08f71563          	bne	a4,a5,42013182 <jd_prepare+0x232>
420130fc:	00395783          	lhu	a5,3(s2)
42013100:	0087d713          	srli	a4,a5,0x8
42013104:	07a2                	slli	a5,a5,0x8
42013106:	97ba                	add	a5,a5,a4
42013108:	00f41e23          	sh	a5,28(s0)
4201310c:	00195783          	lhu	a5,1(s2)
42013110:	0087d713          	srli	a4,a5,0x8
42013114:	07a2                	slli	a5,a5,0x8
42013116:	97ba                	add	a5,a5,a4
42013118:	00f41f23          	sh	a5,30(s0)
4201311c:	00594683          	lbu	a3,5(s2)
42013120:	4785                	li	a5,1
42013122:	00d409a3          	sb	a3,19(s0)
42013126:	0fd6f713          	andi	a4,a3,253
4201312a:	04f71c63          	bne	a4,a5,42013182 <jd_prepare+0x232>
4201312e:	478d                	li	a5,3
42013130:	02f687b3          	mul	a5,a3,a5
42013134:	0799                	addi	a5,a5,6
42013136:	2c979863          	bne	a5,s1,42013406 <jd_prepare+0x4b6>
4201313a:	00794783          	lbu	a5,7(s2)
4201313e:	00790713          	addi	a4,s2,7
42013142:	fdf78613          	addi	a2,a5,-33
42013146:	00263613          	sltiu	a2,a2,2
4201314a:	e601                	bnez	a2,42013152 <jd_prepare+0x202>
4201314c:	fef78613          	addi	a2,a5,-17
42013150:	ea0d                	bnez	a2,42013182 <jd_prepare+0x232>
42013152:	0047d613          	srli	a2,a5,0x4
42013156:	8bbd                	andi	a5,a5,15
42013158:	00c40723          	sb	a2,14(s0)
4201315c:	00f407a3          	sb	a5,15(s0)
42013160:	460d                	li	a2,3
42013162:	00174783          	lbu	a5,1(a4)
42013166:	01b405b3          	add	a1,s0,s11
4201316a:	00f58823          	sb	a5,16(a1)
4201316e:	00f66a63          	bltu	a2,a5,42013182 <jd_prepare+0x232>
42013172:	0d85                	addi	s11,s11,1
42013174:	e6ddf4e3          	bgeu	s11,a3,42012fdc <jd_prepare+0x8c>
42013178:	00374783          	lbu	a5,3(a4)
4201317c:	070d                	addi	a4,a4,3
4201317e:	ff9782e3          	beq	a5,s9,42013162 <jd_prepare+0x212>
42013182:	4d21                	li	s10,8
42013184:	40b6                	lw	ra,76(sp)
42013186:	4426                	lw	s0,72(sp)
42013188:	4496                	lw	s1,68(sp)
4201318a:	4906                	lw	s2,64(sp)
4201318c:	59f2                	lw	s3,60(sp)
4201318e:	5a62                	lw	s4,56(sp)
42013190:	5ad2                	lw	s5,52(sp)
42013192:	5b42                	lw	s6,48(sp)
42013194:	5bb2                	lw	s7,44(sp)
42013196:	5c22                	lw	s8,40(sp)
42013198:	5c92                	lw	s9,36(sp)
4201319a:	4df2                	lw	s11,28(sp)
4201319c:	856a                	mv	a0,s10
4201319e:	5d02                	lw	s10,32(sp)
420131a0:	6161                	addi	sp,sp,80
420131a2:	8082                	ret
420131a4:	20000793          	li	a5,512
420131a8:	fc97eee3          	bltu	a5,s1,42013184 <jd_prepare+0x234>
420131ac:	583c                	lw	a5,112(s0)
420131ae:	8626                	mv	a2,s1
420131b0:	85ca                	mv	a1,s2
420131b2:	8522                	mv	a0,s0
420131b4:	9782                	jalr	a5
420131b6:	ea951ee3          	bne	a0,s1,42013072 <jd_prepare+0x122>
420131ba:	8d4a                	mv	s10,s2
420131bc:	4dc1                	li	s11,16
420131be:	249df463          	bgeu	s11,s1,42013406 <jd_prepare+0x4b6>
420131c2:	000d4a83          	lbu	s5,0(s10)
420131c6:	0eeaf713          	andi	a4,s5,238
420131ca:	22071e63          	bnez	a4,42013406 <jd_prepare+0x4b6>
420131ce:	45c1                	li	a1,16
420131d0:	8522                	mv	a0,s0
420131d2:	bf9ff0ef          	jal	42012dca <alloc_pool>
420131d6:	882a                	mv	a6,a0
420131d8:	e119                	bnez	a0,420131de <jd_prepare+0x28e>
420131da:	4d0d                	li	s10,3
420131dc:	b765                	j	42013184 <jd_prepare+0x234>
420131de:	00faf793          	andi	a5,s5,15
420131e2:	001d0b13          	addi	s6,s10,1
420131e6:	0786                	slli	a5,a5,0x1
420131e8:	004add13          	srli	s10,s5,0x4
420131ec:	97ea                	add	a5,a5,s10
420131ee:	078a                	slli	a5,a5,0x2
420131f0:	4622                	lw	a2,8(sp)
420131f2:	00f40bb3          	add	s7,s0,a5
420131f6:	02aba023          	sw	a0,32(s7)
420131fa:	4a81                	li	s5,0
420131fc:	4581                	li	a1,0
420131fe:	000b4503          	lbu	a0,0(s6)
42013202:	00b808b3          	add	a7,a6,a1
42013206:	0606                	slli	a2,a2,0x1
42013208:	00a88023          	sb	a0,0(a7)
4201320c:	1ea66d63          	bltu	a2,a0,42013406 <jd_prepare+0x4b6>
42013210:	0585                	addi	a1,a1,1
42013212:	0b05                	addi	s6,s6,1
42013214:	8e09                	sub	a2,a2,a0
42013216:	9aaa                	add	s5,s5,a0
42013218:	ffb593e3          	bne	a1,s11,420131fe <jd_prepare+0x2ae>
4201321c:	001a9593          	slli	a1,s5,0x1
42013220:	8522                	mv	a0,s0
42013222:	c642                	sw	a6,12(sp)
42013224:	ba7ff0ef          	jal	42012dca <alloc_pool>
42013228:	d94d                	beqz	a0,420131da <jd_prepare+0x28a>
4201322a:	4832                	lw	a6,12(sp)
4201322c:	fef48893          	addi	a7,s1,-17
42013230:	02aba823          	sw	a0,48(s7)
42013234:	4e01                	li	t3,0
42013236:	4301                	li	t1,0
42013238:	4601                	li	a2,0
4201323a:	4f41                	li	t5,16
4201323c:	006805b3          	add	a1,a6,t1
42013240:	0005ce83          	lbu	t4,0(a1)
42013244:	001e1593          	slli	a1,t3,0x1
42013248:	95aa                	add	a1,a1,a0
4201324a:	8fb2                	mv	t6,a2
4201324c:	84f6                	mv	s1,t4
4201324e:	e0a9                	bnez	s1,42013290 <jd_prepare+0x340>
42013250:	9676                	add	a2,a2,t4
42013252:	0606                	slli	a2,a2,0x1
42013254:	0642                	slli	a2,a2,0x10
42013256:	0305                	addi	t1,t1,1
42013258:	9e76                	add	t3,t3,t4
4201325a:	8241                	srli	a2,a2,0x10
4201325c:	ffe310e3          	bne	t1,t5,4201323c <jd_prepare+0x2ec>
42013260:	1b58e363          	bltu	a7,s5,42013406 <jd_prepare+0x4b6>
42013264:	85d6                	mv	a1,s5
42013266:	8522                	mv	a0,s0
42013268:	c646                	sw	a7,12(sp)
4201326a:	b61ff0ef          	jal	42012dca <alloc_pool>
4201326e:	d535                	beqz	a0,420131da <jd_prepare+0x28a>
42013270:	48b2                	lw	a7,12(sp)
42013272:	001d4d13          	xori	s10,s10,1
42013276:	04aba023          	sw	a0,64(s7)
4201327a:	001d7d13          	andi	s10,s10,1
4201327e:	009a9f63          	bne	s5,s1,4201329c <jd_prepare+0x34c>
42013282:	415884b3          	sub	s1,a7,s5
42013286:	d5588be3          	beq	a7,s5,42012fdc <jd_prepare+0x8c>
4201328a:	015b0d33          	add	s10,s6,s5
4201328e:	bf05                	j	420131be <jd_prepare+0x26e>
42013290:	01f59023          	sh	t6,0(a1)
42013294:	14fd                	addi	s1,s1,-1
42013296:	0589                	addi	a1,a1,2
42013298:	0f85                	addi	t6,t6,1
4201329a:	bf55                	j	4201324e <jd_prepare+0x2fe>
4201329c:	009b07b3          	add	a5,s6,s1
420132a0:	0007c783          	lbu	a5,0(a5)
420132a4:	00c7b613          	sltiu	a2,a5,12
420132a8:	e219                	bnez	a2,420132ae <jd_prepare+0x35e>
420132aa:	140d1e63          	bnez	s10,42013406 <jd_prepare+0x4b6>
420132ae:	00950633          	add	a2,a0,s1
420132b2:	00f60023          	sb	a5,0(a2)
420132b6:	0485                	addi	s1,s1,1
420132b8:	b7d9                	j	4201327e <jd_prepare+0x32e>
420132ba:	20000793          	li	a5,512
420132be:	ec97e3e3          	bltu	a5,s1,42013184 <jd_prepare+0x234>
420132c2:	583c                	lw	a5,112(s0)
420132c4:	8626                	mv	a2,s1
420132c6:	85ca                	mv	a1,s2
420132c8:	8522                	mv	a0,s0
420132ca:	9782                	jalr	a5
420132cc:	da9513e3          	bne	a0,s1,42013072 <jd_prepare+0x122>
420132d0:	8dca                	mv	s11,s2
420132d2:	04000813          	li	a6,64
420132d6:	488d                	li	a7,3
420132d8:	12987763          	bgeu	a6,s1,42013406 <jd_prepare+0x4b6>
420132dc:	000dcd03          	lbu	s10,0(s11)
420132e0:	13a8e363          	bltu	a7,s10,42013406 <jd_prepare+0x4b6>
420132e4:	10000593          	li	a1,256
420132e8:	8522                	mv	a0,s0
420132ea:	ae1ff0ef          	jal	42012dca <alloc_pool>
420132ee:	ee0506e3          	beqz	a0,420131da <jd_prepare+0x28a>
420132f2:	0d51                	addi	s10,s10,20
420132f4:	3c0eb7b7          	lui	a5,0x3c0eb
420132f8:	0d0a                	slli	s10,s10,0x2
420132fa:	9d22                	add	s10,s10,s0
420132fc:	29c78613          	addi	a2,a5,668 # 3c0eb29c <Ipsf>
42013300:	3c0eb7b7          	lui	a5,0x3c0eb
42013304:	fbf48493          	addi	s1,s1,-65
42013308:	00ad2023          	sw	a0,0(s10)
4201330c:	4701                	li	a4,0
4201330e:	31c78693          	addi	a3,a5,796 # 3c0eb31c <Zig>
42013312:	04000813          	li	a6,64
42013316:	488d                	li	a7,3
42013318:	00d707b3          	add	a5,a4,a3
4201331c:	0007c783          	lbu	a5,0(a5)
42013320:	00ed8333          	add	t1,s11,a4
42013324:	00134303          	lbu	t1,1(t1)
42013328:	00279593          	slli	a1,a5,0x2
4201332c:	0786                	slli	a5,a5,0x1
4201332e:	97b2                	add	a5,a5,a2
42013330:	0007d783          	lhu	a5,0(a5)
42013334:	95aa                	add	a1,a1,a0
42013336:	0705                	addi	a4,a4,1
42013338:	02f307b3          	mul	a5,t1,a5
4201333c:	c19c                	sw	a5,0(a1)
4201333e:	fd071de3          	bne	a4,a6,42013318 <jd_prepare+0x3c8>
42013342:	041d8d93          	addi	s11,s11,65
42013346:	f8c9                	bnez	s1,420132d8 <jd_prepare+0x388>
42013348:	b951                	j	42012fdc <jd_prepare+0x8c>
4201334a:	20000793          	li	a5,512
4201334e:	e297ebe3          	bltu	a5,s1,42013184 <jd_prepare+0x234>
42013352:	583c                	lw	a5,112(s0)
42013354:	8626                	mv	a2,s1
42013356:	85ca                	mv	a1,s2
42013358:	8522                	mv	a0,s0
4201335a:	9782                	jalr	a5
4201335c:	d0951be3          	bne	a0,s1,42013072 <jd_prepare+0x122>
42013360:	01c45783          	lhu	a5,28(s0)
42013364:	c3cd                	beqz	a5,42013406 <jd_prepare+0x4b6>
42013366:	01e45783          	lhu	a5,30(s0)
4201336a:	cfd1                	beqz	a5,42013406 <jd_prepare+0x4b6>
4201336c:	01344583          	lbu	a1,19(s0)
42013370:	00094783          	lbu	a5,0(s2)
42013374:	e0b797e3          	bne	a5,a1,42013182 <jd_prepare+0x232>
42013378:	00290613          	addi	a2,s2,2
4201337c:	4701                	li	a4,0
4201337e:	06b76563          	bltu	a4,a1,420133e8 <jd_prepare+0x498>
42013382:	00f44483          	lbu	s1,15(s0)
42013386:	00e44783          	lbu	a5,14(s0)
4201338a:	02f484b3          	mul	s1,s1,a5
4201338e:	cca5                	beqz	s1,42013406 <jd_prepare+0x4b6>
42013390:	00749593          	slli	a1,s1,0x7
42013394:	04058593          	addi	a1,a1,64
42013398:	10000793          	li	a5,256
4201339c:	00f5f363          	bgeu	a1,a5,420133a2 <jd_prepare+0x452>
420133a0:	85be                	mv	a1,a5
420133a2:	8522                	mv	a0,s0
420133a4:	a27ff0ef          	jal	42012dca <alloc_pool>
420133a8:	d028                	sw	a0,96(s0)
420133aa:	e20508e3          	beqz	a0,420131da <jd_prepare+0x28a>
420133ae:	00248593          	addi	a1,s1,2
420133b2:	059a                	slli	a1,a1,0x6
420133b4:	8522                	mv	a0,s0
420133b6:	a15ff0ef          	jal	42012dca <alloc_pool>
420133ba:	d068                	sw	a0,100(s0)
420133bc:	e0050fe3          	beqz	a0,420131da <jd_prepare+0x28a>
420133c0:	1ff9f993          	andi	s3,s3,511
420133c4:	00098c63          	beqz	s3,420133dc <jd_prepare+0x48c>
420133c8:	583c                	lw	a5,112(s0)
420133ca:	20000613          	li	a2,512
420133ce:	41360633          	sub	a2,a2,s3
420133d2:	013905b3          	add	a1,s2,s3
420133d6:	8522                	mv	a0,s0
420133d8:	9782                	jalr	a5
420133da:	c008                	sw	a0,0(s0)
420133dc:	19fd                	addi	s3,s3,-1
420133de:	99ca                	add	s3,s3,s2
420133e0:	01342223          	sw	s3,4(s0)
420133e4:	4d01                	li	s10,0
420133e6:	bb79                	j	42013184 <jd_prepare+0x234>
420133e8:	00064783          	lbu	a5,0(a2)
420133ec:	fef78693          	addi	a3,a5,-17
420133f0:	c299                	beqz	a3,420133f6 <jd_prepare+0x4a6>
420133f2:	d80798e3          	bnez	a5,42013182 <jd_prepare+0x232>
420133f6:	00e037b3          	snez	a5,a4
420133fa:	00478693          	addi	a3,a5,4
420133fe:	068e                	slli	a3,a3,0x3
42013400:	96a2                	add	a3,a3,s0
42013402:	4294                	lw	a3,0(a3)
42013404:	e299                	bnez	a3,4201340a <jd_prepare+0x4ba>
42013406:	4d19                	li	s10,6
42013408:	bbb5                	j	42013184 <jd_prepare+0x234>
4201340a:	078e                	slli	a5,a5,0x3
4201340c:	97a2                	add	a5,a5,s0
4201340e:	53dc                	lw	a5,36(a5)
42013410:	dbfd                	beqz	a5,42013406 <jd_prepare+0x4b6>
42013412:	00e407b3          	add	a5,s0,a4
42013416:	0107c783          	lbu	a5,16(a5)
4201341a:	0705                	addi	a4,a4,1
4201341c:	0609                	addi	a2,a2,2
4201341e:	07d1                	addi	a5,a5,20
42013420:	078a                	slli	a5,a5,0x2
42013422:	97a2                	add	a5,a5,s0
42013424:	439c                	lw	a5,0(a5)
42013426:	ffa1                	bnez	a5,4201337e <jd_prepare+0x42e>
42013428:	bff9                	j	42013406 <jd_prepare+0x4b6>
