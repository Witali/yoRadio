"""Archive literal before/after decoder and HTTP evidence without changing tests."""
from pathlib import Path
from copy import deepcopy
import base64
import datetime as dt
import gzip
import hashlib
import json
import subprocess
import sys

BASE = Path('C:/Work/yoRadio')
ROOT = BASE / '.worktree/small-tv-jpeg-selectors'
OLD = BASE / '.worktree/small-tv-jpeg-headers'
PARITY = ROOT / 'Small_TV/qemu/parity'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
sys.path.insert(0, str(ROOT / 'Small_TV/src/tests'))
from jpeg_selector_contract import validate_selector_evidence, validate_photo_selectors
from jpeg_selector_fixtures import cases, upload_cases

before = read(BASE / '.build/jpeg-selector-f1-before-final-20261018.json')
inputs = read(BASE / '.build/jpeg-selector-inputs-after-20261018.json')
after = inputs['selectors']
validate_selector_evidence(after, {key: inputs[key] for key in
    ('app_sha256', 'source_sha256', 'native_elf_sha256', 'factory_elf_sha256')}, inputs['selector_rejection_checks'])
assert inputs['passed'] and inputs['inputs_unchanged'] and before['inputs_unchanged']
assert not before['passed'] and sum(row['passed'] for row in before['cases']) == 34
assert [(r['name'], r['fixture_sha256']) for r in before['cases']] == [(r['name'], r['fixture_sha256']) for r in after['cases']]
for name, digest in after['inputs_sha256'].items():
    assert sha(Path(name).read_bytes()) == digest, name
for name, digest in before['inputs_sha256'].items():
    path = Path(name)
    if str(path).lower().startswith(str(ROOT).lower()) and ('firmware' in path.parts or path.name == 'small_tv_reconstructed.elf'):
        path = OLD / path.relative_to(ROOT)
    assert sha(path.read_bytes()) == digest, path
photo_before_dir = BASE / '.build/jpeg-selector-http-f1-before-20261018'
photo_after_dir = BASE / '.build/jpeg-selector-http-after-20261018'
pb, pa = read(photo_before_dir / 'report.json'), read(photo_after_dir / 'report.json')
assert not pb['passed'] and pb['inputs_unchanged']
assert pa['passed'] and pa['inputs_unchanged'] and len(pa['checks']) == 26 and all(pa['checks'].values())
assert pa['app_sha256'] == after['app_sha256'] and pa['native_elf_sha256'] == after['native_elf_sha256']
assert pb['test_inputs'] == pa['test_inputs'] and pb['helper_sha256'] == pa['helper_sha256']
assert pb['qemu_sha256'] == pa['qemu_sha256']
assert all(row['finish_status'] == 400 for row in pb['selector_uploads'].values())
validate_photo_selectors(pa)
negative = []
for name in ('missing-upload', 'wrong-valid-status', 'bad-download', 'wrong-fixture', 'invalid-published'):
    candidate = deepcopy(pa)
    if name == 'missing-upload': candidate['selector_uploads'].pop('rgb-mixed')
    elif name == 'wrong-valid-status': candidate['selector_uploads']['rgb-mixed']['finish_status'] = 400
    elif name == 'bad-download': candidate['selector_uploads']['gray-table1']['exact_download'] = False
    elif name == 'wrong-fixture': candidate['selector_uploads']['rgb-shared0']['fixture_sha256'] = '0' * 64
    else: candidate['selector_uploads']['missing-gray-table-01']['metadata'] = dict(exists=True, size=605)
    try: validate_photo_selectors(candidate)
    except (ValueError, KeyError): negative.append(dict(name=name, passed=True))
    else: raise ValueError('Consumer accepted ' + name)
public = read(BASE / '.build/jpeg-selector-public-after-20261018.json')
artifact = read(BASE / '.build/jpeg-selector-artifact-tests-20261018.json')
host = read(ROOT / '.build/small-tv-esp32c2/native-tests/report.json')
assert public['passed'] and len(public['cases']) == 107 and len(public['errors']) == 35 and len(public['placements']) == 7
assert artifact['passed'] and artifact['cases'] == 6 and not artifact['failures'] and not artifact['errors']
assert host['passed'] and host['checks'] == 5531
manifest = read(ROOT / 'firmware/development/small-tv-esp32c2-reconstructed/source-manifest.json')
old_manifest = read(OLD / 'firmware/development/small-tv-esp32c2-reconstructed/source-manifest.json')
old_rows = {row['file']: row['sha256'] for row in old_manifest['files']}
changed = [row['file'] for row in manifest['files'] if row['sha256'] != old_rows[row['file']]]
assert changed == ['third_party/tjpgd/tjpgd.c', 'third_party/tjpgd/tjpgd.h'] and len(old_rows) == 59
cleanup_path = PARITY / 'jpeg-selector-vm-cleanup-20261018.json'
cleanup = read(cleanup_path)
assert cleanup['owned_test_vms_absent']
raw = PARITY / 'jpeg-selector-correction-20261018-raw'
raw.mkdir(exist_ok=False)
evidence = []


def archive(source, label):
    """Preserve exact payloads and original/compressed identities, including failures."""
    data = source.read_bytes()
    payload = gzip.decompress(data) if source.suffix == '.gz' else data
    target = raw / (label.removesuffix('.gz') + '.gz')
    assert not target.exists(), target
    target.write_bytes(gzip.compress(payload, mtime=0))
    evidence.append(dict(file=target.relative_to(PARITY).as_posix(), original_file_sha256=sha(data),
                         payload_sha256=sha(payload), stored_sha256=sha(target.read_bytes())))


for name in ('jpeg-selector-f1-before-final-20261018.json', 'jpeg-selector-f1-before-final-20261018.log',
             'jpeg-selector-inputs-after-20261018.json', 'jpeg-selector-inputs-after-20261018.log',
             'jpeg-selector-public-after-20261018.json', 'jpeg-selector-public-after-20261018.log',
             'jpeg-selector-independent-pillow-20261018.json', 'jpeg-selector-upload-pillow-20261018.json',
             'jpeg-selector-artifact-tests-20261018.json', 'jpeg-selector-host-20261018.log',
             'jpeg-selector-http-f1-before-20261018.log', 'jpeg-selector-http-after-20261018.log'):
    archive(BASE / '.build' / name, name)
for label, folder in (('http-before', photo_before_dir), ('http-after', photo_after_dir)):
    for relative in ('report.json', 'vm/qemu.log', 'vm/uart.log', 'vm/session.json'):
        archive(folder / relative, label + '-' + relative.replace('/', '__'))
for source in sorted((BASE / '.build/jpeg-selector-code-20261018').iterdir()):
    archive(source, 'code-' + source.name)
archive(OLD / 'Small_TV/src/reference/assembly/jpeg_header_prepare_at_42011c48.asm', 'factory-prepare.asm')
archive(ROOT / '.build/small-tv-esp32c2/native-tests/report.json', 'native-report.json')
archive(cleanup_path, cleanup_path.name)
archive(Path(__file__), Path(__file__).name)
fixture_record = dict(small={name: dict(valid=valid, base64=base64.b64encode(data).decode()) for name, valid, data in cases()},
                      upload={name: dict(valid=valid, base64=base64.b64encode(data).decode()) for name, valid, data in upload_cases()})
fixture_path = BASE / '.build/jpeg-selector-exact-fixtures-20261018.json'
assert not fixture_path.exists()
fixture_path.write_text(json.dumps(fixture_record, indent=2) + '\n', newline='\n')
archive(fixture_path, 'exact-fixtures.json')
sources = {}
for name in ('third_party/tjpgd/tjpgd.c', 'third_party/tjpgd/tjpgd.h', 'tests/jpeg_selector_fixtures.py',
             'tests/jpeg_selector_oracle.py', 'tests/jpeg_selector_contract.py', 'tests/jpeg_inputs_oracle.py',
             'tests/photo_qemu.py', 'tests/publish-report.py', 'tools/verify_artifacts.py'):
    source = ROOT / 'Small_TV/src' / name
    sources[name] = sha(source.read_bytes())
    archive(source, 'tested-' + name.replace('/', '__'))
record = dict(passed=True, status='selector_correction_targeted_gates_passed', all_functionality_verified=False,
    captured_utc=dt.datetime.now(dt.timezone.utc).isoformat(), app_sha256=after['app_sha256'],
    native_elf_sha256=after['native_elf_sha256'], source_sha256=after['source_sha256'], qemu_sha256=pa['qemu_sha256'],
    changed_production_inputs=changed, before_cases_passed=34, after_cases_passed=168,
    valid_cases=136, invalid_cases=32, decoder_evidence_rejections=8, http_evidence_rejections=negative,
    public_jpegs=107, host_checks=5531, artifact_checks=6, sources=sources, evidence=evidence,
    before_http_terminal_passed=False, before_http_scope='All three valid selector JPEGs wrongly received400. Later cold-stage start_upload timed out with QEMU WSAEventSelect warning; that independent failure is retained, not accepted.',
    after_http_checks=26, new_full_pending=True, new_h10_pending=True,
    scope='Exact B50D/85FC native decoder and photo HTTP/storage correction on D64. Unchanged current F1 full/H10 remain separate. No full new-candidate, physical RF/LCD/PWM, CYD or hardware acceptance.')
(PARITY / 'jpeg-selector-correction-20261018.json').write_text(json.dumps(record, indent=2) + '\n', newline='\n')
print(json.dumps(dict(passed=True, before=34, after=168, raw_files=len(evidence), http_checks=26)))
