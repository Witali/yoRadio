
C:\Work\yoRadio\.worktree\small-tv-jpeg-selectors\.build\small-tv-esp32c2\small_tv_reconstructed.elf:     file format elf32-littleriscv


Disassembly of section .iram0.text:

Disassembly of section .flash.text:

42012f50 <jd_prepare>:
42012f50:	715d                	addi	sp,sp,-80
42012f52:	c2a6                	sw	s1,68(sp)
42012f54:	c0ca                	sw	s2,64(sp)
42012f56:	84ae                	mv	s1,a1
42012f58:	8932                	mv	s2,a2
42012f5a:	4581                	li	a1,0
42012f5c:	08000613          	li	a2,128
42012f60:	c686                	sw	ra,76(sp)
42012f62:	c4a2                	sw	s0,72(sp)
42012f64:	c636                	sw	a3,12(sp)
42012f66:	842a                	mv	s0,a0
42012f68:	c43a                	sw	a4,8(sp)
42012f6a:	de4e                	sw	s3,60(sp)
42012f6c:	dc52                	sw	s4,56(sp)
42012f6e:	da56                	sw	s5,52(sp)
42012f70:	d85a                	sw	s6,48(sp)
42012f72:	d65e                	sw	s7,44(sp)
42012f74:	d462                	sw	s8,40(sp)
42012f76:	d266                	sw	s9,36(sp)
42012f78:	d06a                	sw	s10,32(sp)
42012f7a:	ce6e                	sw	s11,28(sp)
42012f7c:	fdfed097          	auipc	ra,0xfdfed
42012f80:	50c080e7          	jalr	1292(ra) # 40000488 <memset>
42012f84:	46b2                	lw	a3,12(sp)
42012f86:	4722                	lw	a4,8(sp)
42012f88:	07242423          	sw	s2,104(s0)
42012f8c:	d474                	sw	a3,108(s0)
42012f8e:	d824                	sw	s1,112(s0)
42012f90:	d878                	sw	a4,116(s0)
42012f92:	20000593          	li	a1,512
42012f96:	8522                	mv	a0,s0
42012f98:	e33ff0ef          	jal	42012dca <alloc_pool>
42012f9c:	c408                	sw	a0,8(s0)
42012f9e:	26050063          	beqz	a0,420131fe <jd_prepare+0x2ae>
42012fa2:	6a41                	lui	s4,0x10
42012fa4:	84aa                	mv	s1,a0
42012fa6:	4981                	li	s3,0
42012fa8:	4901                	li	s2,0
42012faa:	4a85                	li	s5,1
42012fac:	fd8a0a13          	addi	s4,s4,-40 # ffd8 <CSR_UINTSTATUS+0xf327>
42012fb0:	583c                	lw	a5,112(s0)
42012fb2:	4605                	li	a2,1
42012fb4:	85a6                	mv	a1,s1
42012fb6:	8522                	mv	a0,s0
42012fb8:	9782                	jalr	a5
42012fba:	c42a                	sw	a0,8(sp)
42012fbc:	03550363          	beq	a0,s5,42012fe2 <jd_prepare+0x92>
42012fc0:	4d89                	li	s11,2
42012fc2:	40b6                	lw	ra,76(sp)
42012fc4:	4426                	lw	s0,72(sp)
42012fc6:	4496                	lw	s1,68(sp)
42012fc8:	4906                	lw	s2,64(sp)
42012fca:	59f2                	lw	s3,60(sp)
42012fcc:	5a62                	lw	s4,56(sp)
42012fce:	5ad2                	lw	s5,52(sp)
42012fd0:	5b42                	lw	s6,48(sp)
42012fd2:	5bb2                	lw	s7,44(sp)
42012fd4:	5c22                	lw	s8,40(sp)
42012fd6:	5c92                	lw	s9,36(sp)
42012fd8:	5d02                	lw	s10,32(sp)
42012fda:	856e                	mv	a0,s11
42012fdc:	4df2                	lw	s11,28(sp)
42012fde:	6161                	addi	sp,sp,80
42012fe0:	8082                	ret
42012fe2:	0004c783          	lbu	a5,0(s1)
42012fe6:	0922                	slli	s2,s2,0x8
42012fe8:	0985                	addi	s3,s3,1
42012fea:	00f96933          	or	s2,s2,a5
42012fee:	0942                	slli	s2,s2,0x10
42012ff0:	01095913          	srli	s2,s2,0x10
42012ff4:	fb491ee3          	bne	s2,s4,42012fb0 <jd_prepare+0x60>
42012ff8:	6ac1                	lui	s5,0x10
42012ffa:	1afd                	addi	s5,s5,-1 # ffff <CSR_UINTSTATUS+0xf34e>
42012ffc:	4a09                	li	s4,2
42012ffe:	0da00b13          	li	s6,218
42013002:	583c                	lw	a5,112(s0)
42013004:	4611                	li	a2,4
42013006:	85a6                	mv	a1,s1
42013008:	8522                	mv	a0,s0
4201300a:	9782                	jalr	a5
4201300c:	4791                	li	a5,4
4201300e:	8daa                	mv	s11,a0
42013010:	faf518e3          	bne	a0,a5,42012fc0 <jd_prepare+0x70>
42013014:	0004d703          	lhu	a4,0(s1)
42013018:	03570563          	beq	a4,s5,42013042 <jd_prepare+0xf2>
4201301c:	00875793          	srli	a5,a4,0x8
42013020:	0722                	slli	a4,a4,0x8
42013022:	97ba                	add	a5,a5,a4
42013024:	0024d703          	lhu	a4,2(s1)
42013028:	07c2                	slli	a5,a5,0x10
4201302a:	83c1                	srli	a5,a5,0x10
4201302c:	00875d13          	srli	s10,a4,0x8
42013030:	0722                	slli	a4,a4,0x8
42013032:	9d3a                	add	s10,s10,a4
42013034:	0d42                	slli	s10,s10,0x10
42013036:	010d5d13          	srli	s10,s10,0x10
4201303a:	03aa6863          	bltu	s4,s10,4201306a <jd_prepare+0x11a>
4201303e:	4d99                	li	s11,6
42013040:	b749                	j	42012fc2 <jd_prepare+0x72>
42013042:	583c                	lw	a5,112(s0)
42013044:	4605                	li	a2,1
42013046:	00448593          	addi	a1,s1,4
4201304a:	8522                	mv	a0,s0
4201304c:	9782                	jalr	a5
4201304e:	4785                	li	a5,1
42013050:	f6f518e3          	bne	a0,a5,42012fc0 <jd_prepare+0x70>
42013054:	0014d703          	lhu	a4,1(s1)
42013058:	00875793          	srli	a5,a4,0x8
4201305c:	0722                	slli	a4,a4,0x8
4201305e:	97ba                	add	a5,a5,a4
42013060:	07c2                	slli	a5,a5,0x10
42013062:	0034d703          	lhu	a4,3(s1)
42013066:	83c1                	srli	a5,a5,0x10
42013068:	b7d1                	j	4201302c <jd_prepare+0xdc>
4201306a:	0087d713          	srli	a4,a5,0x8
4201306e:	0ff00693          	li	a3,255
42013072:	fcd716e3          	bne	a4,a3,4201303e <jd_prepare+0xee>
42013076:	ffed0913          	addi	s2,s10,-2
4201307a:	0991                	addi	s3,s3,4
4201307c:	8ff5                	and	a5,a5,a3
4201307e:	99ca                	add	s3,s3,s2
42013080:	31678663          	beq	a5,s6,4201338c <jd_prepare+0x43c>
42013084:	04fb6163          	bltu	s6,a5,420130c6 <jd_prepare+0x176>
42013088:	f4078793          	addi	a5,a5,-192
4201308c:	07c2                	slli	a5,a5,0x10
4201308e:	83c1                	srli	a5,a5,0x10
42013090:	4765                	li	a4,25
42013092:	02f76263          	bltu	a4,a5,420130b6 <jd_prepare+0x166>
42013096:	4705                	li	a4,1
42013098:	0200fd37          	lui	s10,0x200f
4201309c:	00f71733          	sll	a4,a4,a5
420130a0:	eeed0d13          	addi	s10,s10,-274 # 200eeee <CSR_UINTSTATUS+0x200e23d>
420130a4:	01a77d33          	and	s10,a4,s10
420130a8:	100d1e63          	bnez	s10,420131c4 <jd_prepare+0x274>
420130ac:	4691                	li	a3,4
420130ae:	10d78d63          	beq	a5,a3,420131c8 <jd_prepare+0x278>
420130b2:	8b05                	andi	a4,a4,1
420130b4:	e339                	bnez	a4,420130fa <jd_prepare+0x1aa>
420130b6:	583c                	lw	a5,112(s0)
420130b8:	864a                	mv	a2,s2
420130ba:	4581                	li	a1,0
420130bc:	8522                	mv	a0,s0
420130be:	9782                	jalr	a5
420130c0:	f52501e3          	beq	a0,s2,42013002 <jd_prepare+0xb2>
420130c4:	bdf5                	j	42012fc0 <jd_prepare+0x70>
420130c6:	0db00713          	li	a4,219
420130ca:	22e78963          	beq	a5,a4,420132fc <jd_prepare+0x3ac>
420130ce:	0dd00713          	li	a4,221
420130d2:	fee792e3          	bne	a5,a4,420130b6 <jd_prepare+0x166>
420130d6:	f74914e3          	bne	s2,s4,4201303e <jd_prepare+0xee>
420130da:	583c                	lw	a5,112(s0)
420130dc:	8652                	mv	a2,s4
420130de:	85a6                	mv	a1,s1
420130e0:	8522                	mv	a0,s0
420130e2:	9782                	jalr	a5
420130e4:	ed451ee3          	bne	a0,s4,42012fc0 <jd_prepare+0x70>
420130e8:	0004d783          	lhu	a5,0(s1)
420130ec:	0087d713          	srli	a4,a5,0x8
420130f0:	07a2                	slli	a5,a5,0x8
420130f2:	97ba                	add	a5,a5,a4
420130f4:	00f41d23          	sh	a5,26(s0)
420130f8:	b729                	j	42013002 <jd_prepare+0xb2>
420130fa:	20000793          	li	a5,512
420130fe:	ed27e2e3          	bltu	a5,s2,42012fc2 <jd_prepare+0x72>
42013102:	583c                	lw	a5,112(s0)
42013104:	864a                	mv	a2,s2
42013106:	85a6                	mv	a1,s1
42013108:	8522                	mv	a0,s0
4201310a:	9782                	jalr	a5
4201310c:	eb251ae3          	bne	a0,s2,42012fc0 <jd_prepare+0x70>
42013110:	4795                	li	a5,5
42013112:	f327f6e3          	bgeu	a5,s2,4201303e <jd_prepare+0xee>
42013116:	0004c703          	lbu	a4,0(s1)
4201311a:	47a1                	li	a5,8
4201311c:	0af71463          	bne	a4,a5,420131c4 <jd_prepare+0x274>
42013120:	0034d783          	lhu	a5,3(s1)
42013124:	0087d713          	srli	a4,a5,0x8
42013128:	07a2                	slli	a5,a5,0x8
4201312a:	97ba                	add	a5,a5,a4
4201312c:	00f41e23          	sh	a5,28(s0)
42013130:	0014d783          	lhu	a5,1(s1)
42013134:	0087d713          	srli	a4,a5,0x8
42013138:	07a2                	slli	a5,a5,0x8
4201313a:	97ba                	add	a5,a5,a4
4201313c:	00f41f23          	sh	a5,30(s0)
42013140:	0054c583          	lbu	a1,5(s1)
42013144:	4785                	li	a5,1
42013146:	00b409a3          	sb	a1,19(s0)
4201314a:	0fd5f713          	andi	a4,a1,253
4201314e:	06f71b63          	bne	a4,a5,420131c4 <jd_prepare+0x274>
42013152:	478d                	li	a5,3
42013154:	02f587b3          	mul	a5,a1,a5
42013158:	0799                	addi	a5,a5,6
4201315a:	ef2792e3          	bne	a5,s2,4201303e <jd_prepare+0xee>
4201315e:	00648693          	addi	a3,s1,6
42013162:	8722                	mv	a4,s0
42013164:	0006c603          	lbu	a2,0(a3)
42013168:	87a2                	mv	a5,s0
4201316a:	06c70c23          	sb	a2,120(a4)
4201316e:	04e79263          	bne	a5,a4,420131b2 <jd_prepare+0x262>
42013172:	0016c783          	lbu	a5,1(a3)
42013176:	040d1463          	bnez	s10,420131be <jd_prepare+0x26e>
4201317a:	fdf78613          	addi	a2,a5,-33
4201317e:	00263613          	sltiu	a2,a2,2
42013182:	e601                	bnez	a2,4201318a <jd_prepare+0x23a>
42013184:	fef78613          	addi	a2,a5,-17
42013188:	ee15                	bnez	a2,420131c4 <jd_prepare+0x274>
4201318a:	0047d613          	srli	a2,a5,0x4
4201318e:	8bbd                	andi	a5,a5,15
42013190:	00c40723          	sb	a2,14(s0)
42013194:	00f407a3          	sb	a5,15(s0)
42013198:	0026c783          	lbu	a5,2(a3)
4201319c:	460d                	li	a2,3
4201319e:	00f70823          	sb	a5,16(a4)
420131a2:	02f66163          	bltu	a2,a5,420131c4 <jd_prepare+0x274>
420131a6:	0d05                	addi	s10,s10,1
420131a8:	96b2                	add	a3,a3,a2
420131aa:	0705                	addi	a4,a4,1
420131ac:	fabd6ce3          	bltu	s10,a1,42013164 <jd_prepare+0x214>
420131b0:	bd89                	j	42013002 <jd_prepare+0xb2>
420131b2:	0787c503          	lbu	a0,120(a5)
420131b6:	0785                	addi	a5,a5,1
420131b8:	fac51be3          	bne	a0,a2,4201316e <jd_prepare+0x21e>
420131bc:	b549                	j	4201303e <jd_prepare+0xee>
420131be:	4645                	li	a2,17
420131c0:	fcc78ce3          	beq	a5,a2,42013198 <jd_prepare+0x248>
420131c4:	4da1                	li	s11,8
420131c6:	bbf5                	j	42012fc2 <jd_prepare+0x72>
420131c8:	20000793          	li	a5,512
420131cc:	df27ebe3          	bltu	a5,s2,42012fc2 <jd_prepare+0x72>
420131d0:	583c                	lw	a5,112(s0)
420131d2:	864a                	mv	a2,s2
420131d4:	85a6                	mv	a1,s1
420131d6:	8522                	mv	a0,s0
420131d8:	9782                	jalr	a5
420131da:	df2513e3          	bne	a0,s2,42012fc0 <jd_prepare+0x70>
420131de:	8da6                	mv	s11,s1
420131e0:	4d41                	li	s10,16
420131e2:	e52d7ee3          	bgeu	s10,s2,4201303e <jd_prepare+0xee>
420131e6:	000dcb83          	lbu	s7,0(s11)
420131ea:	0eebf713          	andi	a4,s7,238
420131ee:	e40718e3          	bnez	a4,4201303e <jd_prepare+0xee>
420131f2:	45c1                	li	a1,16
420131f4:	8522                	mv	a0,s0
420131f6:	bd5ff0ef          	jal	42012dca <alloc_pool>
420131fa:	882a                	mv	a6,a0
420131fc:	e119                	bnez	a0,42013202 <jd_prepare+0x2b2>
420131fe:	4d8d                	li	s11,3
42013200:	b3c9                	j	42012fc2 <jd_prepare+0x72>
42013202:	00fbf793          	andi	a5,s7,15
42013206:	001d8c13          	addi	s8,s11,1
4201320a:	0786                	slli	a5,a5,0x1
4201320c:	004bdd93          	srli	s11,s7,0x4
42013210:	97ee                	add	a5,a5,s11
42013212:	078a                	slli	a5,a5,0x2
42013214:	4622                	lw	a2,8(sp)
42013216:	00f40cb3          	add	s9,s0,a5
4201321a:	02aca023          	sw	a0,32(s9)
4201321e:	4b81                	li	s7,0
42013220:	4581                	li	a1,0
42013222:	000c4503          	lbu	a0,0(s8)
42013226:	00b808b3          	add	a7,a6,a1
4201322a:	0606                	slli	a2,a2,0x1
4201322c:	00a88023          	sb	a0,0(a7)
42013230:	e0c577e3          	bgeu	a0,a2,4201303e <jd_prepare+0xee>
42013234:	0585                	addi	a1,a1,1
42013236:	0c05                	addi	s8,s8,1
42013238:	8e09                	sub	a2,a2,a0
4201323a:	9baa                	add	s7,s7,a0
4201323c:	ffa593e3          	bne	a1,s10,42013222 <jd_prepare+0x2d2>
42013240:	001b9593          	slli	a1,s7,0x1
42013244:	8522                	mv	a0,s0
42013246:	c642                	sw	a6,12(sp)
42013248:	b83ff0ef          	jal	42012dca <alloc_pool>
4201324c:	d94d                	beqz	a0,420131fe <jd_prepare+0x2ae>
4201324e:	4832                	lw	a6,12(sp)
42013250:	fef90893          	addi	a7,s2,-17
42013254:	02aca823          	sw	a0,48(s9)
42013258:	4e81                	li	t4,0
4201325a:	4301                	li	t1,0
4201325c:	4e01                	li	t3,0
4201325e:	4f41                	li	t5,16
42013260:	00680633          	add	a2,a6,t1
42013264:	00064603          	lbu	a2,0(a2)
42013268:	001e9593          	slli	a1,t4,0x1
4201326c:	95aa                	add	a1,a1,a0
4201326e:	8ff2                	mv	t6,t3
42013270:	8932                	mv	s2,a2
42013272:	04091263          	bnez	s2,420132b6 <jd_prepare+0x366>
42013276:	9eb2                	add	t4,t4,a2
42013278:	9672                	add	a2,a2,t3
4201327a:	0606                	slli	a2,a2,0x1
4201327c:	01061e13          	slli	t3,a2,0x10
42013280:	0305                	addi	t1,t1,1
42013282:	010e5e13          	srli	t3,t3,0x10
42013286:	fde31de3          	bne	t1,t5,42013260 <jd_prepare+0x310>
4201328a:	db78eae3          	bltu	a7,s7,4201303e <jd_prepare+0xee>
4201328e:	85de                	mv	a1,s7
42013290:	8522                	mv	a0,s0
42013292:	c646                	sw	a7,12(sp)
42013294:	b37ff0ef          	jal	42012dca <alloc_pool>
42013298:	d13d                	beqz	a0,420131fe <jd_prepare+0x2ae>
4201329a:	48b2                	lw	a7,12(sp)
4201329c:	04aca023          	sw	a0,64(s9)
420132a0:	4329                	li	t1,10
420132a2:	4e2d                	li	t3,11
420132a4:	012b9f63          	bne	s7,s2,420132c2 <jd_prepare+0x372>
420132a8:	41788933          	sub	s2,a7,s7
420132ac:	d5788be3          	beq	a7,s7,42013002 <jd_prepare+0xb2>
420132b0:	017c0db3          	add	s11,s8,s7
420132b4:	b73d                	j	420131e2 <jd_prepare+0x292>
420132b6:	01f59023          	sh	t6,0(a1)
420132ba:	197d                	addi	s2,s2,-1
420132bc:	0589                	addi	a1,a1,2
420132be:	0f85                	addi	t6,t6,1
420132c0:	bf4d                	j	42013272 <jd_prepare+0x322>
420132c2:	012c07b3          	add	a5,s8,s2
420132c6:	0007c783          	lbu	a5,0(a5)
420132ca:	000d9a63          	bnez	s11,420132de <jd_prepare+0x38e>
420132ce:	d6fe68e3          	bltu	t3,a5,4201303e <jd_prepare+0xee>
420132d2:	01250633          	add	a2,a0,s2
420132d6:	00f60023          	sb	a5,0(a2)
420132da:	0905                	addi	s2,s2,1
420132dc:	b7e1                	j	420132a4 <jd_prepare+0x354>
420132de:	00f7f813          	andi	a6,a5,15
420132e2:	d5036ee3          	bltu	t1,a6,4201303e <jd_prepare+0xee>
420132e6:	f1078593          	addi	a1,a5,-240
420132ea:	00f03633          	snez	a2,a5
420132ee:	00b035b3          	snez	a1,a1
420132f2:	8e6d                	and	a2,a2,a1
420132f4:	de79                	beqz	a2,420132d2 <jd_prepare+0x382>
420132f6:	fc081ee3          	bnez	a6,420132d2 <jd_prepare+0x382>
420132fa:	b391                	j	4201303e <jd_prepare+0xee>
420132fc:	20000793          	li	a5,512
42013300:	cd27e1e3          	bltu	a5,s2,42012fc2 <jd_prepare+0x72>
42013304:	583c                	lw	a5,112(s0)
42013306:	864a                	mv	a2,s2
42013308:	85a6                	mv	a1,s1
4201330a:	8522                	mv	a0,s0
4201330c:	9782                	jalr	a5
4201330e:	cb2519e3          	bne	a0,s2,42012fc0 <jd_prepare+0x70>
42013312:	8d26                	mv	s10,s1
42013314:	04000813          	li	a6,64
42013318:	488d                	li	a7,3
4201331a:	d32872e3          	bgeu	a6,s2,4201303e <jd_prepare+0xee>
4201331e:	000d4d83          	lbu	s11,0(s10)
42013322:	d1b8eee3          	bltu	a7,s11,4201303e <jd_prepare+0xee>
42013326:	10000593          	li	a1,256
4201332a:	8522                	mv	a0,s0
4201332c:	a9fff0ef          	jal	42012dca <alloc_pool>
42013330:	ec0507e3          	beqz	a0,420131fe <jd_prepare+0x2ae>
42013334:	0dd1                	addi	s11,s11,20
42013336:	0d8a                	slli	s11,s11,0x2
42013338:	9da2                	add	s11,s11,s0
4201333a:	3c0eb337          	lui	t1,0x3c0eb
4201333e:	3c0eb7b7          	lui	a5,0x3c0eb
42013342:	041d0e13          	addi	t3,s10,65
42013346:	00ada023          	sw	a0,0(s11)
4201334a:	31c30693          	addi	a3,t1,796 # 3c0eb31c <Zig>
4201334e:	0d05                	addi	s10,s10,1
42013350:	29c78713          	addi	a4,a5,668 # 3c0eb29c <Ipsf>
42013354:	04000813          	li	a6,64
42013358:	488d                	li	a7,3
4201335a:	000d4583          	lbu	a1,0(s10)
4201335e:	ce0580e3          	beqz	a1,4201303e <jd_prepare+0xee>
42013362:	0006c783          	lbu	a5,0(a3)
42013366:	0d05                	addi	s10,s10,1
42013368:	0685                	addi	a3,a3,1
4201336a:	00279613          	slli	a2,a5,0x2
4201336e:	0786                	slli	a5,a5,0x1
42013370:	97ba                	add	a5,a5,a4
42013372:	0007d783          	lhu	a5,0(a5)
42013376:	962a                	add	a2,a2,a0
42013378:	02b787b3          	mul	a5,a5,a1
4201337c:	c21c                	sw	a5,0(a2)
4201337e:	fdcd1ee3          	bne	s10,t3,4201335a <jd_prepare+0x40a>
42013382:	fbf90913          	addi	s2,s2,-65
42013386:	f8091ae3          	bnez	s2,4201331a <jd_prepare+0x3ca>
4201338a:	b9a5                	j	42013002 <jd_prepare+0xb2>
4201338c:	20000793          	li	a5,512
42013390:	c327e9e3          	bltu	a5,s2,42012fc2 <jd_prepare+0x72>
42013394:	01344a03          	lbu	s4,19(s0)
42013398:	0a09                	addi	s4,s4,2
4201339a:	0a06                	slli	s4,s4,0x1
4201339c:	cb2a11e3          	bne	s4,s2,4201303e <jd_prepare+0xee>
420133a0:	583c                	lw	a5,112(s0)
420133a2:	8652                	mv	a2,s4
420133a4:	85a6                	mv	a1,s1
420133a6:	8522                	mv	a0,s0
420133a8:	9782                	jalr	a5
420133aa:	c1451be3          	bne	a0,s4,42012fc0 <jd_prepare+0x70>
420133ae:	01c45783          	lhu	a5,28(s0)
420133b2:	c80786e3          	beqz	a5,4201303e <jd_prepare+0xee>
420133b6:	01e45783          	lhu	a5,30(s0)
420133ba:	c80782e3          	beqz	a5,4201303e <jd_prepare+0xee>
420133be:	01344783          	lbu	a5,19(s0)
420133c2:	0004c703          	lbu	a4,0(s1)
420133c6:	def71fe3          	bne	a4,a5,420131c4 <jd_prepare+0x274>
420133ca:	9d26                	add	s10,s10,s1
420133cc:	ffbd4703          	lbu	a4,-5(s10)
420133d0:	de071ae3          	bnez	a4,420131c4 <jd_prepare+0x274>
420133d4:	ffcd4683          	lbu	a3,-4(s10)
420133d8:	03f00713          	li	a4,63
420133dc:	dee694e3          	bne	a3,a4,420131c4 <jd_prepare+0x274>
420133e0:	ffdd4703          	lbu	a4,-3(s10)
420133e4:	de0710e3          	bnez	a4,420131c4 <jd_prepare+0x274>
420133e8:	86a2                	mv	a3,s0
420133ea:	00148593          	addi	a1,s1,1
420133ee:	00f40633          	add	a2,s0,a5
420133f2:	06c69663          	bne	a3,a2,4201345e <jd_prepare+0x50e>
420133f6:	00f44903          	lbu	s2,15(s0)
420133fa:	00e44783          	lbu	a5,14(s0)
420133fe:	02f90933          	mul	s2,s2,a5
42013402:	c2090ee3          	beqz	s2,4201303e <jd_prepare+0xee>
42013406:	00791593          	slli	a1,s2,0x7
4201340a:	04058593          	addi	a1,a1,64
4201340e:	10000793          	li	a5,256
42013412:	00f5f363          	bgeu	a1,a5,42013418 <jd_prepare+0x4c8>
42013416:	85be                	mv	a1,a5
42013418:	8522                	mv	a0,s0
4201341a:	9b1ff0ef          	jal	42012dca <alloc_pool>
4201341e:	d028                	sw	a0,96(s0)
42013420:	dc050fe3          	beqz	a0,420131fe <jd_prepare+0x2ae>
42013424:	00290593          	addi	a1,s2,2
42013428:	059a                	slli	a1,a1,0x6
4201342a:	8522                	mv	a0,s0
4201342c:	99fff0ef          	jal	42012dca <alloc_pool>
42013430:	d068                	sw	a0,100(s0)
42013432:	dc0506e3          	beqz	a0,420131fe <jd_prepare+0x2ae>
42013436:	1ff9f993          	andi	s3,s3,511
4201343a:	00098c63          	beqz	s3,42013452 <jd_prepare+0x502>
4201343e:	583c                	lw	a5,112(s0)
42013440:	20000613          	li	a2,512
42013444:	41360633          	sub	a2,a2,s3
42013448:	013485b3          	add	a1,s1,s3
4201344c:	8522                	mv	a0,s0
4201344e:	9782                	jalr	a5
42013450:	c008                	sw	a0,0(s0)
42013452:	19fd                	addi	s3,s3,-1
42013454:	99a6                	add	s3,s3,s1
42013456:	01342223          	sw	s3,4(s0)
4201345a:	4d81                	li	s11,0
4201345c:	b69d                	j	42012fc2 <jd_prepare+0x72>
4201345e:	0005c703          	lbu	a4,0(a1)
42013462:	0786c783          	lbu	a5,120(a3)
42013466:	8536                	mv	a0,a3
42013468:	bcf71be3          	bne	a4,a5,4201303e <jd_prepare+0xee>
4201346c:	0015c783          	lbu	a5,1(a1)
42013470:	0ee7f713          	andi	a4,a5,238
42013474:	d40718e3          	bnez	a4,420131c4 <jd_prepare+0x274>
42013478:	0047d713          	srli	a4,a5,0x4
4201347c:	0711                	addi	a4,a4,4
4201347e:	070e                	slli	a4,a4,0x3
42013480:	06f68da3          	sb	a5,123(a3)
42013484:	9722                	add	a4,a4,s0
42013486:	4318                	lw	a4,0(a4)
42013488:	ba070be3          	beqz	a4,4201303e <jd_prepare+0xee>
4201348c:	8bbd                	andi	a5,a5,15
4201348e:	078e                	slli	a5,a5,0x3
42013490:	97a2                	add	a5,a5,s0
42013492:	53dc                	lw	a5,36(a5)
42013494:	ba0785e3          	beqz	a5,4201303e <jd_prepare+0xee>
42013498:	01054783          	lbu	a5,16(a0)
4201349c:	0685                	addi	a3,a3,1
4201349e:	0589                	addi	a1,a1,2
420134a0:	07d1                	addi	a5,a5,20
420134a2:	078a                	slli	a5,a5,0x2
420134a4:	97a2                	add	a5,a5,s0
420134a6:	439c                	lw	a5,0(a5)
420134a8:	f7a9                	bnez	a5,420133f2 <jd_prepare+0x4a2>
420134aa:	be51                	j	4201303e <jd_prepare+0xee>
