
C:\Work\yoRadio\.worktree\small-tv-jpeg-headers\.build\small-tv-esp32c2\small_tv_reconstructed.elf:     file format elf32-littleriscv


Disassembly of section .iram0.text:

Disassembly of section .flash.text:

42012f50 <jd_prepare>:
42012f50:	715d                	addi	sp,sp,-80
42012f52:	c2a6                	sw	s1,68(sp)
42012f54:	c0ca                	sw	s2,64(sp)
42012f56:	84ae                	mv	s1,a1
42012f58:	8932                	mv	s2,a2
42012f5a:	4581                	li	a1,0
42012f5c:	07c00613          	li	a2,124
42012f60:	c686                	sw	ra,76(sp)
42012f62:	c4a2                	sw	s0,72(sp)
42012f64:	c636                	sw	a3,12(sp)
42012f66:	842a                	mv	s0,a0
42012f68:	c43a                	sw	a4,8(sp)
42012f6a:	de4e                	sw	s3,60(sp)
42012f6c:	dc52                	sw	s4,56(sp)
42012f6e:	da56                	sw	s5,52(sp)
42012f70:	d85a                	sw	s6,48(sp)
42012f72:	d65e                	sw	s7,44(sp)
42012f74:	d462                	sw	s8,40(sp)
42012f76:	d266                	sw	s9,36(sp)
42012f78:	d06a                	sw	s10,32(sp)
42012f7a:	ce6e                	sw	s11,28(sp)
42012f7c:	fdfed097          	auipc	ra,0xfdfed
42012f80:	50c080e7          	jalr	1292(ra) # 40000488 <memset>
42012f84:	46b2                	lw	a3,12(sp)
42012f86:	4722                	lw	a4,8(sp)
42012f88:	07242423          	sw	s2,104(s0)
42012f8c:	d474                	sw	a3,108(s0)
42012f8e:	d824                	sw	s1,112(s0)
42012f90:	d878                	sw	a4,116(s0)
42012f92:	20000593          	li	a1,512
42012f96:	8522                	mv	a0,s0
42012f98:	e33ff0ef          	jal	42012dca <alloc_pool>
42012f9c:	c408                	sw	a0,8(s0)
42012f9e:	24050f63          	beqz	a0,420131fc <jd_prepare+0x2ac>
42012fa2:	6a41                	lui	s4,0x10
42012fa4:	84aa                	mv	s1,a0
42012fa6:	4981                	li	s3,0
42012fa8:	4901                	li	s2,0
42012faa:	4a85                	li	s5,1
42012fac:	fd8a0a13          	addi	s4,s4,-40 # ffd8 <CSR_UINTSTATUS+0xf327>
42012fb0:	583c                	lw	a5,112(s0)
42012fb2:	4605                	li	a2,1
42012fb4:	85a6                	mv	a1,s1
42012fb6:	8522                	mv	a0,s0
42012fb8:	9782                	jalr	a5
42012fba:	c42a                	sw	a0,8(sp)
42012fbc:	0f551363          	bne	a0,s5,420130a2 <jd_prepare+0x152>
42012fc0:	0004c783          	lbu	a5,0(s1)
42012fc4:	0922                	slli	s2,s2,0x8
42012fc6:	0985                	addi	s3,s3,1
42012fc8:	00f96933          	or	s2,s2,a5
42012fcc:	0942                	slli	s2,s2,0x10
42012fce:	01095913          	srli	s2,s2,0x10
42012fd2:	fd491fe3          	bne	s2,s4,42012fb0 <jd_prepare+0x60>
42012fd6:	6ac1                	lui	s5,0x10
42012fd8:	1afd                	addi	s5,s5,-1 # ffff <CSR_UINTSTATUS+0xf34e>
42012fda:	4a09                	li	s4,2
42012fdc:	0da00b13          	li	s6,218
42012fe0:	583c                	lw	a5,112(s0)
42012fe2:	4611                	li	a2,4
42012fe4:	85a6                	mv	a1,s1
42012fe6:	8522                	mv	a0,s0
42012fe8:	9782                	jalr	a5
42012fea:	4791                	li	a5,4
42012fec:	8daa                	mv	s11,a0
42012fee:	0af51a63          	bne	a0,a5,420130a2 <jd_prepare+0x152>
42012ff2:	0004d703          	lhu	a4,0(s1)
42012ff6:	03570563          	beq	a4,s5,42013020 <jd_prepare+0xd0>
42012ffa:	00875793          	srli	a5,a4,0x8
42012ffe:	0722                	slli	a4,a4,0x8
42013000:	97ba                	add	a5,a5,a4
42013002:	0024d703          	lhu	a4,2(s1)
42013006:	07c2                	slli	a5,a5,0x10
42013008:	83c1                	srli	a5,a5,0x10
4201300a:	00875d13          	srli	s10,a4,0x8
4201300e:	0722                	slli	a4,a4,0x8
42013010:	9d3a                	add	s10,s10,a4
42013012:	0d42                	slli	s10,s10,0x10
42013014:	010d5d13          	srli	s10,s10,0x10
42013018:	03aa6863          	bltu	s4,s10,42013048 <jd_prepare+0xf8>
4201301c:	4d99                	li	s11,6
4201301e:	a261                	j	420131a6 <jd_prepare+0x256>
42013020:	583c                	lw	a5,112(s0)
42013022:	4605                	li	a2,1
42013024:	00448593          	addi	a1,s1,4
42013028:	8522                	mv	a0,s0
4201302a:	9782                	jalr	a5
4201302c:	4785                	li	a5,1
4201302e:	06f51a63          	bne	a0,a5,420130a2 <jd_prepare+0x152>
42013032:	0014d703          	lhu	a4,1(s1)
42013036:	00875793          	srli	a5,a4,0x8
4201303a:	0722                	slli	a4,a4,0x8
4201303c:	97ba                	add	a5,a5,a4
4201303e:	07c2                	slli	a5,a5,0x10
42013040:	0034d703          	lhu	a4,3(s1)
42013044:	83c1                	srli	a5,a5,0x10
42013046:	b7d1                	j	4201300a <jd_prepare+0xba>
42013048:	0087d713          	srli	a4,a5,0x8
4201304c:	0ff00693          	li	a3,255
42013050:	fcd716e3          	bne	a4,a3,4201301c <jd_prepare+0xcc>
42013054:	ffed0913          	addi	s2,s10,-2
42013058:	0991                	addi	s3,s3,4
4201305a:	8ff5                	and	a5,a5,a3
4201305c:	99ca                	add	s3,s3,s2
4201305e:	33678663          	beq	a5,s6,4201338a <jd_prepare+0x43a>
42013062:	04fb6263          	bltu	s6,a5,420130a6 <jd_prepare+0x156>
42013066:	f4078793          	addi	a5,a5,-192
4201306a:	07c2                	slli	a5,a5,0x10
4201306c:	83c1                	srli	a5,a5,0x10
4201306e:	4765                	li	a4,25
42013070:	02f76263          	bltu	a4,a5,42013094 <jd_prepare+0x144>
42013074:	4705                	li	a4,1
42013076:	0200fd37          	lui	s10,0x200f
4201307a:	00f71733          	sll	a4,a4,a5
4201307e:	eeed0d13          	addi	s10,s10,-274 # 200eeee <CSR_UINTSTATUS+0x200e23d>
42013082:	01a77d33          	and	s10,a4,s10
42013086:	100d1f63          	bnez	s10,420131a4 <jd_prepare+0x254>
4201308a:	4691                	li	a3,4
4201308c:	12d78d63          	beq	a5,a3,420131c6 <jd_prepare+0x276>
42013090:	8b05                	andi	a4,a4,1
42013092:	e721                	bnez	a4,420130da <jd_prepare+0x18a>
42013094:	583c                	lw	a5,112(s0)
42013096:	864a                	mv	a2,s2
42013098:	4581                	li	a1,0
4201309a:	8522                	mv	a0,s0
4201309c:	9782                	jalr	a5
4201309e:	f52501e3          	beq	a0,s2,42012fe0 <jd_prepare+0x90>
420130a2:	4d89                	li	s11,2
420130a4:	a209                	j	420131a6 <jd_prepare+0x256>
420130a6:	0db00713          	li	a4,219
420130aa:	24e78863          	beq	a5,a4,420132fa <jd_prepare+0x3aa>
420130ae:	0dd00713          	li	a4,221
420130b2:	fee791e3          	bne	a5,a4,42013094 <jd_prepare+0x144>
420130b6:	f74913e3          	bne	s2,s4,4201301c <jd_prepare+0xcc>
420130ba:	583c                	lw	a5,112(s0)
420130bc:	8652                	mv	a2,s4
420130be:	85a6                	mv	a1,s1
420130c0:	8522                	mv	a0,s0
420130c2:	9782                	jalr	a5
420130c4:	fd451fe3          	bne	a0,s4,420130a2 <jd_prepare+0x152>
420130c8:	0004d783          	lhu	a5,0(s1)
420130cc:	0087d713          	srli	a4,a5,0x8
420130d0:	07a2                	slli	a5,a5,0x8
420130d2:	97ba                	add	a5,a5,a4
420130d4:	00f41d23          	sh	a5,26(s0)
420130d8:	b721                	j	42012fe0 <jd_prepare+0x90>
420130da:	20000793          	li	a5,512
420130de:	0d27e463          	bltu	a5,s2,420131a6 <jd_prepare+0x256>
420130e2:	583c                	lw	a5,112(s0)
420130e4:	864a                	mv	a2,s2
420130e6:	85a6                	mv	a1,s1
420130e8:	8522                	mv	a0,s0
420130ea:	9782                	jalr	a5
420130ec:	fb251be3          	bne	a0,s2,420130a2 <jd_prepare+0x152>
420130f0:	4795                	li	a5,5
420130f2:	f327f5e3          	bgeu	a5,s2,4201301c <jd_prepare+0xcc>
420130f6:	0004c703          	lbu	a4,0(s1)
420130fa:	47a1                	li	a5,8
420130fc:	0af71463          	bne	a4,a5,420131a4 <jd_prepare+0x254>
42013100:	0034d783          	lhu	a5,3(s1)
42013104:	0087d713          	srli	a4,a5,0x8
42013108:	07a2                	slli	a5,a5,0x8
4201310a:	97ba                	add	a5,a5,a4
4201310c:	00f41e23          	sh	a5,28(s0)
42013110:	0014d783          	lhu	a5,1(s1)
42013114:	0087d713          	srli	a4,a5,0x8
42013118:	07a2                	slli	a5,a5,0x8
4201311a:	97ba                	add	a5,a5,a4
4201311c:	00f41f23          	sh	a5,30(s0)
42013120:	0054c583          	lbu	a1,5(s1)
42013124:	4785                	li	a5,1
42013126:	00b409a3          	sb	a1,19(s0)
4201312a:	0fd5f713          	andi	a4,a1,253
4201312e:	06f71b63          	bne	a4,a5,420131a4 <jd_prepare+0x254>
42013132:	478d                	li	a5,3
42013134:	02f587b3          	mul	a5,a1,a5
42013138:	0799                	addi	a5,a5,6
4201313a:	ef2791e3          	bne	a5,s2,4201301c <jd_prepare+0xcc>
4201313e:	00648693          	addi	a3,s1,6
42013142:	8722                	mv	a4,s0
42013144:	0006c603          	lbu	a2,0(a3)
42013148:	87a2                	mv	a5,s0
4201314a:	06c70c23          	sb	a2,120(a4)
4201314e:	04e79263          	bne	a5,a4,42013192 <jd_prepare+0x242>
42013152:	0016c783          	lbu	a5,1(a3)
42013156:	040d1463          	bnez	s10,4201319e <jd_prepare+0x24e>
4201315a:	fdf78613          	addi	a2,a5,-33
4201315e:	00263613          	sltiu	a2,a2,2
42013162:	e601                	bnez	a2,4201316a <jd_prepare+0x21a>
42013164:	fef78613          	addi	a2,a5,-17
42013168:	ee15                	bnez	a2,420131a4 <jd_prepare+0x254>
4201316a:	0047d613          	srli	a2,a5,0x4
4201316e:	8bbd                	andi	a5,a5,15
42013170:	00c40723          	sb	a2,14(s0)
42013174:	00f407a3          	sb	a5,15(s0)
42013178:	0026c783          	lbu	a5,2(a3)
4201317c:	460d                	li	a2,3
4201317e:	00f70823          	sb	a5,16(a4)
42013182:	02f66163          	bltu	a2,a5,420131a4 <jd_prepare+0x254>
42013186:	0d05                	addi	s10,s10,1
42013188:	96b2                	add	a3,a3,a2
4201318a:	0705                	addi	a4,a4,1
4201318c:	fabd6ce3          	bltu	s10,a1,42013144 <jd_prepare+0x1f4>
42013190:	bd81                	j	42012fe0 <jd_prepare+0x90>
42013192:	0787c503          	lbu	a0,120(a5)
42013196:	0785                	addi	a5,a5,1
42013198:	fac51be3          	bne	a0,a2,4201314e <jd_prepare+0x1fe>
4201319c:	b541                	j	4201301c <jd_prepare+0xcc>
4201319e:	4645                	li	a2,17
420131a0:	fcc78ce3          	beq	a5,a2,42013178 <jd_prepare+0x228>
420131a4:	4da1                	li	s11,8
420131a6:	40b6                	lw	ra,76(sp)
420131a8:	4426                	lw	s0,72(sp)
420131aa:	4496                	lw	s1,68(sp)
420131ac:	4906                	lw	s2,64(sp)
420131ae:	59f2                	lw	s3,60(sp)
420131b0:	5a62                	lw	s4,56(sp)
420131b2:	5ad2                	lw	s5,52(sp)
420131b4:	5b42                	lw	s6,48(sp)
420131b6:	5bb2                	lw	s7,44(sp)
420131b8:	5c22                	lw	s8,40(sp)
420131ba:	5c92                	lw	s9,36(sp)
420131bc:	5d02                	lw	s10,32(sp)
420131be:	856e                	mv	a0,s11
420131c0:	4df2                	lw	s11,28(sp)
420131c2:	6161                	addi	sp,sp,80
420131c4:	8082                	ret
420131c6:	20000793          	li	a5,512
420131ca:	fd27eee3          	bltu	a5,s2,420131a6 <jd_prepare+0x256>
420131ce:	583c                	lw	a5,112(s0)
420131d0:	864a                	mv	a2,s2
420131d2:	85a6                	mv	a1,s1
420131d4:	8522                	mv	a0,s0
420131d6:	9782                	jalr	a5
420131d8:	ed2515e3          	bne	a0,s2,420130a2 <jd_prepare+0x152>
420131dc:	8da6                	mv	s11,s1
420131de:	4d41                	li	s10,16
420131e0:	e32d7ee3          	bgeu	s10,s2,4201301c <jd_prepare+0xcc>
420131e4:	000dcb83          	lbu	s7,0(s11)
420131e8:	0eebf713          	andi	a4,s7,238
420131ec:	e20718e3          	bnez	a4,4201301c <jd_prepare+0xcc>
420131f0:	45c1                	li	a1,16
420131f2:	8522                	mv	a0,s0
420131f4:	bd7ff0ef          	jal	42012dca <alloc_pool>
420131f8:	882a                	mv	a6,a0
420131fa:	e119                	bnez	a0,42013200 <jd_prepare+0x2b0>
420131fc:	4d8d                	li	s11,3
420131fe:	b765                	j	420131a6 <jd_prepare+0x256>
42013200:	00fbf793          	andi	a5,s7,15
42013204:	001d8c13          	addi	s8,s11,1
42013208:	0786                	slli	a5,a5,0x1
4201320a:	004bdd93          	srli	s11,s7,0x4
4201320e:	97ee                	add	a5,a5,s11
42013210:	078a                	slli	a5,a5,0x2
42013212:	4622                	lw	a2,8(sp)
42013214:	00f40cb3          	add	s9,s0,a5
42013218:	02aca023          	sw	a0,32(s9)
4201321c:	4b81                	li	s7,0
4201321e:	4581                	li	a1,0
42013220:	000c4503          	lbu	a0,0(s8)
42013224:	00b808b3          	add	a7,a6,a1
42013228:	0606                	slli	a2,a2,0x1
4201322a:	00a88023          	sb	a0,0(a7)
4201322e:	dec577e3          	bgeu	a0,a2,4201301c <jd_prepare+0xcc>
42013232:	0585                	addi	a1,a1,1
42013234:	0c05                	addi	s8,s8,1
42013236:	8e09                	sub	a2,a2,a0
42013238:	9baa                	add	s7,s7,a0
4201323a:	ffa593e3          	bne	a1,s10,42013220 <jd_prepare+0x2d0>
4201323e:	001b9593          	slli	a1,s7,0x1
42013242:	8522                	mv	a0,s0
42013244:	c642                	sw	a6,12(sp)
42013246:	b85ff0ef          	jal	42012dca <alloc_pool>
4201324a:	d94d                	beqz	a0,420131fc <jd_prepare+0x2ac>
4201324c:	4832                	lw	a6,12(sp)
4201324e:	fef90893          	addi	a7,s2,-17
42013252:	02aca823          	sw	a0,48(s9)
42013256:	4e81                	li	t4,0
42013258:	4301                	li	t1,0
4201325a:	4e01                	li	t3,0
4201325c:	4f41                	li	t5,16
4201325e:	00680633          	add	a2,a6,t1
42013262:	00064603          	lbu	a2,0(a2)
42013266:	001e9593          	slli	a1,t4,0x1
4201326a:	95aa                	add	a1,a1,a0
4201326c:	8ff2                	mv	t6,t3
4201326e:	8932                	mv	s2,a2
42013270:	04091263          	bnez	s2,420132b4 <jd_prepare+0x364>
42013274:	9eb2                	add	t4,t4,a2
42013276:	9672                	add	a2,a2,t3
42013278:	0606                	slli	a2,a2,0x1
4201327a:	01061e13          	slli	t3,a2,0x10
4201327e:	0305                	addi	t1,t1,1
42013280:	010e5e13          	srli	t3,t3,0x10
42013284:	fde31de3          	bne	t1,t5,4201325e <jd_prepare+0x30e>
42013288:	d978eae3          	bltu	a7,s7,4201301c <jd_prepare+0xcc>
4201328c:	85de                	mv	a1,s7
4201328e:	8522                	mv	a0,s0
42013290:	c646                	sw	a7,12(sp)
42013292:	b39ff0ef          	jal	42012dca <alloc_pool>
42013296:	d13d                	beqz	a0,420131fc <jd_prepare+0x2ac>
42013298:	48b2                	lw	a7,12(sp)
4201329a:	04aca023          	sw	a0,64(s9)
4201329e:	4829                	li	a6,10
420132a0:	432d                	li	t1,11
420132a2:	012b9f63          	bne	s7,s2,420132c0 <jd_prepare+0x370>
420132a6:	41788933          	sub	s2,a7,s7
420132aa:	d3788be3          	beq	a7,s7,42012fe0 <jd_prepare+0x90>
420132ae:	017c0db3          	add	s11,s8,s7
420132b2:	b73d                	j	420131e0 <jd_prepare+0x290>
420132b4:	01f59023          	sh	t6,0(a1)
420132b8:	197d                	addi	s2,s2,-1
420132ba:	0589                	addi	a1,a1,2
420132bc:	0f85                	addi	t6,t6,1
420132be:	bf4d                	j	42013270 <jd_prepare+0x320>
420132c0:	012c07b3          	add	a5,s8,s2
420132c4:	0007c783          	lbu	a5,0(a5)
420132c8:	000d9a63          	bnez	s11,420132dc <jd_prepare+0x38c>
420132cc:	d4f368e3          	bltu	t1,a5,4201301c <jd_prepare+0xcc>
420132d0:	01250633          	add	a2,a0,s2
420132d4:	00f60023          	sb	a5,0(a2)
420132d8:	0905                	addi	s2,s2,1
420132da:	b7e1                	j	420132a2 <jd_prepare+0x352>
420132dc:	00f7f593          	andi	a1,a5,15
420132e0:	d2b86ee3          	bltu	a6,a1,4201301c <jd_prepare+0xcc>
420132e4:	f1078613          	addi	a2,a5,-240
420132e8:	00c03633          	snez	a2,a2
420132ec:	00f03e33          	snez	t3,a5
420132f0:	01c67633          	and	a2,a2,t3
420132f4:	de71                	beqz	a2,420132d0 <jd_prepare+0x380>
420132f6:	fde9                	bnez	a1,420132d0 <jd_prepare+0x380>
420132f8:	b315                	j	4201301c <jd_prepare+0xcc>
420132fa:	20000793          	li	a5,512
420132fe:	eb27e4e3          	bltu	a5,s2,420131a6 <jd_prepare+0x256>
42013302:	583c                	lw	a5,112(s0)
42013304:	864a                	mv	a2,s2
42013306:	85a6                	mv	a1,s1
42013308:	8522                	mv	a0,s0
4201330a:	9782                	jalr	a5
4201330c:	d9251be3          	bne	a0,s2,420130a2 <jd_prepare+0x152>
42013310:	8d26                	mv	s10,s1
42013312:	04000813          	li	a6,64
42013316:	488d                	li	a7,3
42013318:	d12872e3          	bgeu	a6,s2,4201301c <jd_prepare+0xcc>
4201331c:	000d4d83          	lbu	s11,0(s10)
42013320:	cfb8eee3          	bltu	a7,s11,4201301c <jd_prepare+0xcc>
42013324:	10000593          	li	a1,256
42013328:	8522                	mv	a0,s0
4201332a:	aa1ff0ef          	jal	42012dca <alloc_pool>
4201332e:	ec0507e3          	beqz	a0,420131fc <jd_prepare+0x2ac>
42013332:	0dd1                	addi	s11,s11,20
42013334:	0d8a                	slli	s11,s11,0x2
42013336:	9da2                	add	s11,s11,s0
42013338:	3c0eb337          	lui	t1,0x3c0eb
4201333c:	3c0eb7b7          	lui	a5,0x3c0eb
42013340:	041d0e13          	addi	t3,s10,65
42013344:	00ada023          	sw	a0,0(s11)
42013348:	31c30693          	addi	a3,t1,796 # 3c0eb31c <Zig>
4201334c:	0d05                	addi	s10,s10,1
4201334e:	29c78713          	addi	a4,a5,668 # 3c0eb29c <Ipsf>
42013352:	04000813          	li	a6,64
42013356:	488d                	li	a7,3
42013358:	000d4583          	lbu	a1,0(s10)
4201335c:	cc0580e3          	beqz	a1,4201301c <jd_prepare+0xcc>
42013360:	0006c783          	lbu	a5,0(a3)
42013364:	0d05                	addi	s10,s10,1
42013366:	0685                	addi	a3,a3,1
42013368:	00279613          	slli	a2,a5,0x2
4201336c:	0786                	slli	a5,a5,0x1
4201336e:	97ba                	add	a5,a5,a4
42013370:	0007d783          	lhu	a5,0(a5)
42013374:	962a                	add	a2,a2,a0
42013376:	02b787b3          	mul	a5,a5,a1
4201337a:	c21c                	sw	a5,0(a2)
4201337c:	fdcd1ee3          	bne	s10,t3,42013358 <jd_prepare+0x408>
42013380:	fbf90913          	addi	s2,s2,-65
42013384:	f8091ae3          	bnez	s2,42013318 <jd_prepare+0x3c8>
42013388:	b9a1                	j	42012fe0 <jd_prepare+0x90>
4201338a:	20000793          	li	a5,512
4201338e:	e127ece3          	bltu	a5,s2,420131a6 <jd_prepare+0x256>
42013392:	01344a03          	lbu	s4,19(s0)
42013396:	0a09                	addi	s4,s4,2
42013398:	0a06                	slli	s4,s4,0x1
4201339a:	c92a11e3          	bne	s4,s2,4201301c <jd_prepare+0xcc>
4201339e:	583c                	lw	a5,112(s0)
420133a0:	8652                	mv	a2,s4
420133a2:	85a6                	mv	a1,s1
420133a4:	8522                	mv	a0,s0
420133a6:	9782                	jalr	a5
420133a8:	cf451de3          	bne	a0,s4,420130a2 <jd_prepare+0x152>
420133ac:	01c45783          	lhu	a5,28(s0)
420133b0:	c60786e3          	beqz	a5,4201301c <jd_prepare+0xcc>
420133b4:	01e45783          	lhu	a5,30(s0)
420133b8:	c60782e3          	beqz	a5,4201301c <jd_prepare+0xcc>
420133bc:	01344503          	lbu	a0,19(s0)
420133c0:	0004c783          	lbu	a5,0(s1)
420133c4:	dea790e3          	bne	a5,a0,420131a4 <jd_prepare+0x254>
420133c8:	9d26                	add	s10,s10,s1
420133ca:	ffbd4783          	lbu	a5,-5(s10)
420133ce:	dc079be3          	bnez	a5,420131a4 <jd_prepare+0x254>
420133d2:	ffcd4703          	lbu	a4,-4(s10)
420133d6:	03f00793          	li	a5,63
420133da:	dcf715e3          	bne	a4,a5,420131a4 <jd_prepare+0x254>
420133de:	ffdd4783          	lbu	a5,-3(s10)
420133e2:	dc0791e3          	bnez	a5,420131a4 <jd_prepare+0x254>
420133e6:	01040593          	addi	a1,s0,16
420133ea:	00148613          	addi	a2,s1,1
420133ee:	4681                	li	a3,0
420133f0:	06a6e663          	bltu	a3,a0,4201345c <jd_prepare+0x50c>
420133f4:	00f44903          	lbu	s2,15(s0)
420133f8:	00e44783          	lbu	a5,14(s0)
420133fc:	02f90933          	mul	s2,s2,a5
42013400:	c0090ee3          	beqz	s2,4201301c <jd_prepare+0xcc>
42013404:	00791593          	slli	a1,s2,0x7
42013408:	04058593          	addi	a1,a1,64
4201340c:	10000793          	li	a5,256
42013410:	00f5f363          	bgeu	a1,a5,42013416 <jd_prepare+0x4c6>
42013414:	85be                	mv	a1,a5
42013416:	8522                	mv	a0,s0
42013418:	9b3ff0ef          	jal	42012dca <alloc_pool>
4201341c:	d028                	sw	a0,96(s0)
4201341e:	dc050fe3          	beqz	a0,420131fc <jd_prepare+0x2ac>
42013422:	00290593          	addi	a1,s2,2
42013426:	059a                	slli	a1,a1,0x6
42013428:	8522                	mv	a0,s0
4201342a:	9a1ff0ef          	jal	42012dca <alloc_pool>
4201342e:	d068                	sw	a0,100(s0)
42013430:	dc0506e3          	beqz	a0,420131fc <jd_prepare+0x2ac>
42013434:	1ff9f993          	andi	s3,s3,511
42013438:	00098c63          	beqz	s3,42013450 <jd_prepare+0x500>
4201343c:	583c                	lw	a5,112(s0)
4201343e:	20000613          	li	a2,512
42013442:	41360633          	sub	a2,a2,s3
42013446:	013485b3          	add	a1,s1,s3
4201344a:	8522                	mv	a0,s0
4201344c:	9782                	jalr	a5
4201344e:	c008                	sw	a0,0(s0)
42013450:	19fd                	addi	s3,s3,-1
42013452:	99a6                	add	s3,s3,s1
42013454:	01342223          	sw	s3,4(s0)
42013458:	4d81                	li	s11,0
4201345a:	b3b1                	j	420131a6 <jd_prepare+0x256>
4201345c:	00064703          	lbu	a4,0(a2)
42013460:	0685c783          	lbu	a5,104(a1)
42013464:	882e                	mv	a6,a1
42013466:	baf71be3          	bne	a4,a5,4201301c <jd_prepare+0xcc>
4201346a:	00164783          	lbu	a5,1(a2)
4201346e:	c781                	beqz	a5,42013476 <jd_prepare+0x526>
42013470:	17bd                	addi	a5,a5,-17
42013472:	d20799e3          	bnez	a5,420131a4 <jd_prepare+0x254>
42013476:	00d037b3          	snez	a5,a3
4201347a:	00478713          	addi	a4,a5,4
4201347e:	070e                	slli	a4,a4,0x3
42013480:	9722                	add	a4,a4,s0
42013482:	4318                	lw	a4,0(a4)
42013484:	b8070ce3          	beqz	a4,4201301c <jd_prepare+0xcc>
42013488:	078e                	slli	a5,a5,0x3
4201348a:	97a2                	add	a5,a5,s0
4201348c:	53dc                	lw	a5,36(a5)
4201348e:	b80787e3          	beqz	a5,4201301c <jd_prepare+0xcc>
42013492:	00084783          	lbu	a5,0(a6)
42013496:	0685                	addi	a3,a3,1
42013498:	0585                	addi	a1,a1,1
4201349a:	07d1                	addi	a5,a5,20
4201349c:	078a                	slli	a5,a5,0x2
4201349e:	97a2                	add	a5,a5,s0
420134a0:	439c                	lw	a5,0(a5)
420134a2:	0609                	addi	a2,a2,2
420134a4:	f7b1                	bnez	a5,420133f0 <jd_prepare+0x4a0>
420134a6:	be9d                	j	4201301c <jd_prepare+0xcc>
