
C:\Work\yoRadio\.worktree\small-tv-jpeg-headers\.build\small-tv-esp32c2\small_tv_reconstructed.elf:     file format elf32-littleriscv


Disassembly of section .iram0.text:

Disassembly of section .flash.text:
