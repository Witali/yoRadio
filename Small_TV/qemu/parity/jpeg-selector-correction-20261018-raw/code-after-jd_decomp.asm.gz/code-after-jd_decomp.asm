
C:\Work\yoRadio\.worktree\small-tv-jpeg-selectors\.build\small-tv-esp32c2\small_tv_reconstructed.elf:     file format elf32-littleriscv


Disassembly of section .iram0.text:

Disassembly of section .flash.text:

420134ac <jd_decomp>:
420134ac:	6a061a63          	bnez	a2,42013b60 <jd_decomp+0x6b4>
420134b0:	7119                	addi	sp,sp,-128
420134b2:	dca2                	sw	s0,120(sp)
420134b4:	daa6                	sw	s1,116(sp)
420134b6:	c6ee                	sw	s11,76(sp)
420134b8:	de86                	sw	ra,124(sp)
420134ba:	d8ca                	sw	s2,112(sp)
420134bc:	d6ce                	sw	s3,108(sp)
420134be:	d4d2                	sw	s4,104(sp)
420134c0:	d2d6                	sw	s5,100(sp)
420134c2:	d0da                	sw	s6,96(sp)
420134c4:	cede                	sw	s7,92(sp)
420134c6:	cce2                	sw	s8,88(sp)
420134c8:	cae6                	sw	s9,84(sp)
420134ca:	c8ea                	sw	s10,80(sp)
420134cc:	00e54783          	lbu	a5,14(a0)
420134d0:	d42e                	sw	a1,40(sp)
420134d2:	842a                	mv	s0,a0
420134d4:	078e                	slli	a5,a5,0x3
420134d6:	c83e                	sw	a5,16(sp)
420134d8:	00f54783          	lbu	a5,15(a0)
420134dc:	000506a3          	sb	zero,13(a0)
420134e0:	00052a23          	sw	zero,20(a0)
420134e4:	078e                	slli	a5,a5,0x3
420134e6:	ca3e                	sw	a5,20(sp)
420134e8:	3c0eb7b7          	lui	a5,0x3c0eb
420134ec:	31c78793          	addi	a5,a5,796 # 3c0eb31c <Zig>
420134f0:	00051c23          	sh	zero,24(a0)
420134f4:	c602                	sw	zero,12(sp)
420134f6:	4d81                	li	s11,0
420134f8:	4481                	li	s1,0
420134fa:	d23e                	sw	a5,36(sp)
420134fc:	01e45783          	lhu	a5,30(s0)
42013500:	64f4ee63          	bltu	s1,a5,42013b5c <jd_decomp+0x6b0>
42013504:	4501                	li	a0,0
42013506:	aa6d                	j	420136c0 <jd_decomp+0x214>
42013508:	01a45783          	lhu	a5,26(s0)
4201350c:	cb89                	beqz	a5,4201351e <jd_decomp+0x72>
4201350e:	15b78a63          	beq	a5,s11,42013662 <jd_decomp+0x1b6>
42013512:	001d8793          	addi	a5,s11,1
42013516:	01079d93          	slli	s11,a5,0x10
4201351a:	010ddd93          	srli	s11,s11,0x10
4201351e:	00f44783          	lbu	a5,15(s0)
42013522:	00e44b03          	lbu	s6,14(s0)
42013526:	06042983          	lw	s3,96(s0)
4201352a:	4a05                	li	s4,1
4201352c:	02fb0b33          	mul	s6,s6,a5
42013530:	507c                	lw	a5,100(s0)
42013532:	4a81                	li	s5,0
42013534:	cc3e                	sw	a5,24(sp)
42013536:	002b0793          	addi	a5,s6,2
4201353a:	d03e                	sw	a5,32(sp)
4201353c:	416a0a33          	sub	s4,s4,s6
42013540:	47e2                	lw	a5,24(sp)
42013542:	006a9d13          	slli	s10,s5,0x6
42013546:	9d3e                	add	s10,s10,a5
42013548:	1b6aeb63          	bltu	s5,s6,420136fe <jd_decomp+0x252>
4201354c:	1a0a0963          	beqz	s4,420136fe <jd_decomp+0x252>
42013550:	01344703          	lbu	a4,19(s0)
42013554:	478d                	li	a5,3
42013556:	8cd2                	mv	s9,s4
42013558:	1af70463          	beq	a4,a5,42013700 <jd_decomp+0x254>
4201355c:	04000613          	li	a2,64
42013560:	08000593          	li	a1,128
42013564:	856a                	mv	a0,s10
42013566:	fdfed097          	auipc	ra,0xfdfed
4201356a:	f22080e7          	jalr	-222(ra) # 40000488 <memset>
4201356e:	5782                	lw	a5,32(sp)
42013570:	0a85                	addi	s5,s5,1
42013572:	0a05                	addi	s4,s4,1
42013574:	fcfae6e3          	bltu	s5,a5,42013540 <jd_decomp+0x94>
42013578:	00e44f83          	lbu	t6,14(s0)
4201357c:	00f44b03          	lbu	s6,15(s0)
42013580:	01c45783          	lhu	a5,28(s0)
42013584:	003f9613          	slli	a2,t6,0x3
42013588:	00c90733          	add	a4,s2,a2
4201358c:	003b1293          	slli	t0,s6,0x3
42013590:	86b2                	mv	a3,a2
42013592:	00e7f463          	bgeu	a5,a4,4201359a <jd_decomp+0xee>
42013596:	412786b3          	sub	a3,a5,s2
4201359a:	01e45703          	lhu	a4,30(s0)
4201359e:	005487b3          	add	a5,s1,t0
420135a2:	8f16                	mv	t5,t0
420135a4:	00f77463          	bgeu	a4,a5,420135ac <jd_decomp+0x100>
420135a8:	40970f33          	sub	t5,a4,s1
420135ac:	fff90793          	addi	a5,s2,-1
420135b0:	97b6                	add	a5,a5,a3
420135b2:	02f11d23          	sh	a5,58(sp)
420135b6:	fff48793          	addi	a5,s1,-1
420135ba:	97fa                	add	a5,a5,t5
420135bc:	02f11f23          	sh	a5,62(sp)
420135c0:	47e1                	li	a5,24
420135c2:	02ff87b3          	mul	a5,t6,a5
420135c6:	06042383          	lw	t2,96(s0)
420135ca:	3c0eb337          	lui	t1,0x3c0eb
420135ce:	03211c23          	sh	s2,56(sp)
420135d2:	02911e23          	sh	s1,60(sp)
420135d6:	006f9993          	slli	s3,t6,0x6
420135da:	4801                	li	a6,0
420135dc:	4b89                	li	s7,2
420135de:	e9c30313          	addi	t1,t1,-356 # 3c0eae9c <Clip8>
420135e2:	59b00c13          	li	s8,1435
420135e6:	cc3e                	sw	a5,24(sp)
420135e8:	40000a13          	li	s4,1024
420135ec:	16000c93          	li	s9,352
420135f0:	2db00d13          	li	s10,731
420135f4:	46586063          	bltu	a6,t0,42013a54 <jd_decomp+0x5a8>
420135f8:	00d44783          	lbu	a5,13(s0)
420135fc:	00f65633          	srl	a2,a2,a5
42013600:	50c6eb63          	bltu	a3,a2,42013b16 <jd_decomp+0x66a>
42013604:	03e686b3          	mul	a3,a3,t5
42013608:	478d                	li	a5,3
4201360a:	502c                	lw	a1,96(s0)
4201360c:	852e                	mv	a0,a1
4201360e:	862e                	mv	a2,a1
42013610:	02f686b3          	mul	a3,a3,a5
42013614:	96ae                	add	a3,a3,a1
42013616:	00064703          	lbu	a4,0(a2)
4201361a:	00164783          	lbu	a5,1(a2)
4201361e:	0509                	addi	a0,a0,2
42013620:	0722                	slli	a4,a4,0x8
42013622:	00264803          	lbu	a6,2(a2)
42013626:	80077713          	andi	a4,a4,-2048
4201362a:	078e                	slli	a5,a5,0x3
4201362c:	00385813          	srli	a6,a6,0x3
42013630:	7e07f793          	andi	a5,a5,2016
42013634:	01076733          	or	a4,a4,a6
42013638:	8fd9                	or	a5,a5,a4
4201363a:	060d                	addi	a2,a2,3
4201363c:	fef51f23          	sh	a5,-2(a0)
42013640:	fcd61be3          	bne	a2,a3,42013616 <jd_decomp+0x16a>
42013644:	57a2                	lw	a5,40(sp)
42013646:	1830                	addi	a2,sp,56
42013648:	8522                	mv	a0,s0
4201364a:	9782                	jalr	a5
4201364c:	50050c63          	beqz	a0,42013b64 <jd_decomp+0x6b8>
42013650:	47c2                	lw	a5,16(sp)
42013652:	993e                	add	s2,s2,a5
42013654:	01c45783          	lhu	a5,28(s0)
42013658:	eaf968e3          	bltu	s2,a5,42013508 <jd_decomp+0x5c>
4201365c:	47d2                	lw	a5,20(sp)
4201365e:	94be                	add	s1,s1,a5
42013660:	bd71                	j	420134fc <jd_decomp+0x50>
42013662:	00442a03          	lw	s4,4(s0)
42013666:	4008                	lw	a0,0(s0)
42013668:	4d89                	li	s11,2
4201366a:	4981                	li	s3,0
4201366c:	4b05                	li	s6,1
4201366e:	ed11                	bnez	a0,4201368a <jd_decomp+0x1de>
42013670:	00842a03          	lw	s4,8(s0)
42013674:	583c                	lw	a5,112(s0)
42013676:	20000613          	li	a2,512
4201367a:	85d2                	mv	a1,s4
4201367c:	8522                	mv	a0,s0
4201367e:	9782                	jalr	a5
42013680:	e511                	bnez	a0,4201368c <jd_decomp+0x1e0>
42013682:	4509                	li	a0,2
42013684:	a835                	j	420136c0 <jd_decomp+0x214>
42013686:	4d85                	li	s11,1
42013688:	b7dd                	j	4201366e <jd_decomp+0x1c2>
4201368a:	0a05                	addi	s4,s4,1
4201368c:	000a4783          	lbu	a5,0(s4)
42013690:	09a2                	slli	s3,s3,0x8
42013692:	157d                	addi	a0,a0,-1
42013694:	00f9e7b3          	or	a5,s3,a5
42013698:	01079993          	slli	s3,a5,0x10
4201369c:	0109d993          	srli	s3,s3,0x10
420136a0:	ff6d93e3          	bne	s11,s6,42013686 <jd_decomp+0x1da>
420136a4:	fd87f793          	andi	a5,a5,-40
420136a8:	07c2                	slli	a5,a5,0x10
420136aa:	01442223          	sw	s4,4(s0)
420136ae:	c008                	sw	a0,0(s0)
420136b0:	00040623          	sb	zero,12(s0)
420136b4:	87c1                	srai	a5,a5,0x10
420136b6:	fd000713          	li	a4,-48
420136ba:	02e78263          	beq	a5,a4,420136de <jd_decomp+0x232>
420136be:	4519                	li	a0,6
420136c0:	50f6                	lw	ra,124(sp)
420136c2:	5466                	lw	s0,120(sp)
420136c4:	54d6                	lw	s1,116(sp)
420136c6:	5946                	lw	s2,112(sp)
420136c8:	59b6                	lw	s3,108(sp)
420136ca:	5a26                	lw	s4,104(sp)
420136cc:	5a96                	lw	s5,100(sp)
420136ce:	5b06                	lw	s6,96(sp)
420136d0:	4bf6                	lw	s7,92(sp)
420136d2:	4c66                	lw	s8,88(sp)
420136d4:	4cd6                	lw	s9,84(sp)
420136d6:	4d46                	lw	s10,80(sp)
420136d8:	4db6                	lw	s11,76(sp)
420136da:	6109                	addi	sp,sp,128
420136dc:	8082                	ret
420136de:	47b2                	lw	a5,12(sp)
420136e0:	0137c9b3          	xor	s3,a5,s3
420136e4:	0079f993          	andi	s3,s3,7
420136e8:	fc099be3          	bnez	s3,420136be <jd_decomp+0x212>
420136ec:	0785                	addi	a5,a5,1
420136ee:	07c2                	slli	a5,a5,0x10
420136f0:	83c1                	srli	a5,a5,0x10
420136f2:	c63e                	sw	a5,12(sp)
420136f4:	00042a23          	sw	zero,20(s0)
420136f8:	00041c23          	sh	zero,24(s0)
420136fc:	b50d                	j	4201351e <jd_decomp+0x72>
420136fe:	4c81                	li	s9,0
42013700:	01940bb3          	add	s7,s0,s9
42013704:	07bbc583          	lbu	a1,123(s7)
42013708:	4601                	li	a2,0
4201370a:	8522                	mv	a0,s0
4201370c:	8191                	srli	a1,a1,0x4
4201370e:	ed8ff0ef          	jal	42012de6 <huffext>
42013712:	8c2a                	mv	s8,a0
42013714:	00055563          	bgez	a0,4201371e <jd_decomp+0x272>
42013718:	40a00533          	neg	a0,a0
4201371c:	b755                	j	420136c0 <jd_decomp+0x214>
4201371e:	0c86                	slli	s9,s9,0x1
42013720:	9ca2                	add	s9,s9,s0
42013722:	014c9783          	lh	a5,20(s9)
42013726:	c915                	beqz	a0,4201375a <jd_decomp+0x2ae>
42013728:	85aa                	mv	a1,a0
4201372a:	8522                	mv	a0,s0
4201372c:	ce3e                	sw	a5,28(sp)
4201372e:	f8eff0ef          	jal	42012ebc <bitext>
42013732:	47f2                	lw	a5,28(sp)
42013734:	00055563          	bgez	a0,4201373e <jd_decomp+0x292>
42013738:	40a00533          	neg	a0,a0
4201373c:	b751                	j	420136c0 <jd_decomp+0x214>
4201373e:	1c7d                	addi	s8,s8,-1
42013740:	4705                	li	a4,1
42013742:	01871c33          	sll	s8,a4,s8
42013746:	018576b3          	and	a3,a0,s8
4201374a:	e689                	bnez	a3,42013754 <jd_decomp+0x2a8>
4201374c:	0c06                	slli	s8,s8,0x1
4201374e:	41870733          	sub	a4,a4,s8
42013752:	953a                	add	a0,a0,a4
42013754:	97aa                	add	a5,a5,a0
42013756:	00fc9a23          	sh	a5,20(s9)
4201375a:	010bc703          	lbu	a4,16(s7)
4201375e:	0fc00613          	li	a2,252
42013762:	4581                	li	a1,0
42013764:	0751                	addi	a4,a4,20
42013766:	070a                	slli	a4,a4,0x2
42013768:	9722                	add	a4,a4,s0
4201376a:	00072c03          	lw	s8,0(a4)
4201376e:	00498513          	addi	a0,s3,4
42013772:	000c2703          	lw	a4,0(s8)
42013776:	02e787b3          	mul	a5,a5,a4
4201377a:	87a1                	srai	a5,a5,0x8
4201377c:	00f9a023          	sw	a5,0(s3)
42013780:	fdfed097          	auipc	ra,0xfdfed
42013784:	d08080e7          	jalr	-760(ra) # 40000488 <memset>
42013788:	07bbcb83          	lbu	s7,123(s7)
4201378c:	00fbf793          	andi	a5,s7,15
42013790:	4b85                	li	s7,1
42013792:	ce3e                	sw	a5,28(sp)
42013794:	8cde                	mv	s9,s7
42013796:	45f2                	lw	a1,28(sp)
42013798:	4605                	li	a2,1
4201379a:	8522                	mv	a0,s0
4201379c:	e4aff0ef          	jal	42012de6 <huffext>
420137a0:	28050a63          	beqz	a0,42013a34 <jd_decomp+0x588>
420137a4:	f8054ae3          	bltz	a0,42013738 <jd_decomp+0x28c>
420137a8:	00455713          	srli	a4,a0,0x4
420137ac:	9bba                	add	s7,s7,a4
420137ae:	03f00793          	li	a5,63
420137b2:	f177e6e3          	bltu	a5,s7,420136be <jd_decomp+0x212>
420137b6:	00f57593          	andi	a1,a0,15
420137ba:	c1a1                	beqz	a1,420137fa <jd_decomp+0x34e>
420137bc:	8522                	mv	a0,s0
420137be:	d62e                	sw	a1,44(sp)
420137c0:	efcff0ef          	jal	42012ebc <bitext>
420137c4:	55b2                	lw	a1,44(sp)
420137c6:	f60549e3          	bltz	a0,42013738 <jd_decomp+0x28c>
420137ca:	15fd                	addi	a1,a1,-1
420137cc:	00bc95b3          	sll	a1,s9,a1
420137d0:	00b57733          	and	a4,a0,a1
420137d4:	e709                	bnez	a4,420137de <jd_decomp+0x332>
420137d6:	0586                	slli	a1,a1,0x1
420137d8:	40bc85b3          	sub	a1,s9,a1
420137dc:	952e                	add	a0,a0,a1
420137de:	5792                	lw	a5,36(sp)
420137e0:	01778733          	add	a4,a5,s7
420137e4:	00074703          	lbu	a4,0(a4)
420137e8:	070a                	slli	a4,a4,0x2
420137ea:	00e986b3          	add	a3,s3,a4
420137ee:	9762                	add	a4,a4,s8
420137f0:	4318                	lw	a4,0(a4)
420137f2:	02e50533          	mul	a0,a0,a4
420137f6:	8521                	srai	a0,a0,0x8
420137f8:	c288                	sw	a0,0(a3)
420137fa:	0b85                	addi	s7,s7,1
420137fc:	04000793          	li	a5,64
42013800:	f8fb9be3          	bne	s7,a5,42013796 <jd_decomp+0x2ea>
42013804:	6e85                	lui	t4,0x1
42013806:	6289                	lui	t0,0x2
42013808:	6f85                	lui	t6,0x1
4201380a:	6f0d                	lui	t5,0x3
4201380c:	02098393          	addi	t2,s3,32
42013810:	87ce                	mv	a5,s3
42013812:	6a0e8e93          	addi	t4,t4,1696 # 16a0 <CSR_UINTSTATUS+0x9ef>
42013816:	d9028293          	addi	t0,t0,-624 # 1d90 <CSR_UINTSTATUS+0x10df>
4201381a:	151f8f93          	addi	t6,t6,337 # 1151 <CSR_UINTSTATUS+0x4a0>
4201381e:	9cff0f13          	addi	t5,t5,-1585 # 29cf <CSR_UINTSTATUS+0x1d1e>
42013822:	0807a703          	lw	a4,128(a5)
42013826:	0c07a583          	lw	a1,192(a5)
4201382a:	4390                	lw	a2,0(a5)
4201382c:	43b4                	lw	a3,64(a5)
4201382e:	0207ab83          	lw	s7,32(a5)
42013832:	00e608b3          	add	a7,a2,a4
42013836:	8e19                	sub	a2,a2,a4
42013838:	40b68733          	sub	a4,a3,a1
4201383c:	03d70733          	mul	a4,a4,t4
42013840:	96ae                	add	a3,a3,a1
42013842:	0e07a503          	lw	a0,224(a5)
42013846:	53ac                	lw	a1,96(a5)
42013848:	00d88e33          	add	t3,a7,a3
4201384c:	40d888b3          	sub	a7,a7,a3
42013850:	8731                	srai	a4,a4,0xc
42013852:	8f15                	sub	a4,a4,a3
42013854:	00e60333          	add	t1,a2,a4
42013858:	8e19                	sub	a2,a2,a4
4201385a:	0a07a703          	lw	a4,160(a5)
4201385e:	40ab86b3          	sub	a3,s7,a0
42013862:	955e                	add	a0,a0,s7
42013864:	40b70bb3          	sub	s7,a4,a1
42013868:	972e                	add	a4,a4,a1
4201386a:	40e505b3          	sub	a1,a0,a4
4201386e:	953a                	add	a0,a0,a4
42013870:	01768733          	add	a4,a3,s7
42013874:	02570733          	mul	a4,a4,t0
42013878:	03f686b3          	mul	a3,a3,t6
4201387c:	8731                	srai	a4,a4,0xc
4201387e:	03eb8bb3          	mul	s7,s7,t5
42013882:	86b1                	srai	a3,a3,0xc
42013884:	40d706b3          	sub	a3,a4,a3
42013888:	03d585b3          	mul	a1,a1,t4
4201388c:	40cbdb93          	srai	s7,s7,0xc
42013890:	41770733          	sub	a4,a4,s7
42013894:	8f09                	sub	a4,a4,a0
42013896:	00ae0bb3          	add	s7,t3,a0
4201389a:	40ae0e33          	sub	t3,t3,a0
4201389e:	00e30533          	add	a0,t1,a4
420138a2:	40e30333          	sub	t1,t1,a4
420138a6:	0177a023          	sw	s7,0(a5)
420138aa:	0fc7a023          	sw	t3,224(a5)
420138ae:	85b1                	srai	a1,a1,0xc
420138b0:	8d99                	sub	a1,a1,a4
420138b2:	00b60733          	add	a4,a2,a1
420138b6:	8e8d                	sub	a3,a3,a1
420138b8:	c3b8                	sw	a4,64(a5)
420138ba:	8e0d                	sub	a2,a2,a1
420138bc:	00d88733          	add	a4,a7,a3
420138c0:	40d888b3          	sub	a7,a7,a3
420138c4:	d388                	sw	a0,32(a5)
420138c6:	0c67a023          	sw	t1,192(a5)
420138ca:	0ac7a023          	sw	a2,160(a5)
420138ce:	d3b8                	sw	a4,96(a5)
420138d0:	0917a023          	sw	a7,128(a5)
420138d4:	0791                	addi	a5,a5,4
420138d6:	f47796e3          	bne	a5,t2,42013822 <jd_decomp+0x376>
420138da:	6e85                	lui	t4,0x1
420138dc:	6289                	lui	t0,0x2
420138de:	6f85                	lui	t6,0x1
420138e0:	6f0d                	lui	t5,0x3
420138e2:	3c0eb537          	lui	a0,0x3c0eb
420138e6:	10098393          	addi	t2,s3,256
420138ea:	864e                	mv	a2,s3
420138ec:	6ba1                	lui	s7,0x8
420138ee:	6a0e8e93          	addi	t4,t4,1696 # 16a0 <CSR_UINTSTATUS+0x9ef>
420138f2:	d9028293          	addi	t0,t0,-624 # 1d90 <CSR_UINTSTATUS+0x10df>
420138f6:	151f8f93          	addi	t6,t6,337 # 1151 <CSR_UINTSTATUS+0x4a0>
420138fa:	9cff0f13          	addi	t5,t5,-1585 # 29cf <CSR_UINTSTATUS+0x1d1e>
420138fe:	e9c50513          	addi	a0,a0,-356 # 3c0eae9c <Clip8>
42013902:	421c                	lw	a5,0(a2)
42013904:	4a14                	lw	a3,16(a2)
42013906:	01862803          	lw	a6,24(a2)
4201390a:	460c                	lw	a1,8(a2)
4201390c:	97de                	add	a5,a5,s7
4201390e:	00d78733          	add	a4,a5,a3
42013912:	8f95                	sub	a5,a5,a3
42013914:	410586b3          	sub	a3,a1,a6
42013918:	03d686b3          	mul	a3,a3,t4
4201391c:	95c2                	add	a1,a1,a6
4201391e:	00462c03          	lw	s8,4(a2)
42013922:	00c62303          	lw	t1,12(a2)
42013926:	01c62e03          	lw	t3,28(a2)
4201392a:	00b708b3          	add	a7,a4,a1
4201392e:	8f0d                	sub	a4,a4,a1
42013930:	0d21                	addi	s10,s10,8
42013932:	86b1                	srai	a3,a3,0xc
42013934:	8e8d                	sub	a3,a3,a1
42013936:	00d78833          	add	a6,a5,a3
4201393a:	8f95                	sub	a5,a5,a3
4201393c:	4a54                	lw	a3,20(a2)
4201393e:	41cc05b3          	sub	a1,s8,t3
42013942:	9e62                	add	t3,t3,s8
42013944:	40668c33          	sub	s8,a3,t1
42013948:	969a                	add	a3,a3,t1
4201394a:	40de0333          	sub	t1,t3,a3
4201394e:	9e36                	add	t3,t3,a3
42013950:	018586b3          	add	a3,a1,s8
42013954:	025686b3          	mul	a3,a3,t0
42013958:	02060613          	addi	a2,a2,32
4201395c:	03f585b3          	mul	a1,a1,t6
42013960:	86b1                	srai	a3,a3,0xc
42013962:	03ec0c33          	mul	s8,s8,t5
42013966:	85b1                	srai	a1,a1,0xc
42013968:	40b685b3          	sub	a1,a3,a1
4201396c:	40cc5c13          	srai	s8,s8,0xc
42013970:	418686b3          	sub	a3,a3,s8
42013974:	03d30333          	mul	t1,t1,t4
42013978:	01c88c33          	add	s8,a7,t3
4201397c:	41c888b3          	sub	a7,a7,t3
42013980:	4088d893          	srai	a7,a7,0x8
42013984:	3ff8f893          	andi	a7,a7,1023
42013988:	98aa                	add	a7,a7,a0
4201398a:	0008c883          	lbu	a7,0(a7)
4201398e:	41c686b3          	sub	a3,a3,t3
42013992:	408c5c13          	srai	s8,s8,0x8
42013996:	ff1d0fa3          	sb	a7,-1(s10)
4201399a:	00d808b3          	add	a7,a6,a3
4201399e:	40d80833          	sub	a6,a6,a3
420139a2:	40885813          	srai	a6,a6,0x8
420139a6:	3ff87813          	andi	a6,a6,1023
420139aa:	40c35313          	srai	t1,t1,0xc
420139ae:	982a                	add	a6,a6,a0
420139b0:	40d30333          	sub	t1,t1,a3
420139b4:	00084683          	lbu	a3,0(a6)
420139b8:	406585b3          	sub	a1,a1,t1
420139bc:	4088d893          	srai	a7,a7,0x8
420139c0:	fedd0f23          	sb	a3,-2(s10)
420139c4:	006786b3          	add	a3,a5,t1
420139c8:	406787b3          	sub	a5,a5,t1
420139cc:	87a1                	srai	a5,a5,0x8
420139ce:	3ff7f793          	andi	a5,a5,1023
420139d2:	97aa                	add	a5,a5,a0
420139d4:	0007c783          	lbu	a5,0(a5)
420139d8:	86a1                	srai	a3,a3,0x8
420139da:	3ffc7c13          	andi	s8,s8,1023
420139de:	fefd0ea3          	sb	a5,-3(s10)
420139e2:	00b707b3          	add	a5,a4,a1
420139e6:	87a1                	srai	a5,a5,0x8
420139e8:	3ff7f793          	andi	a5,a5,1023
420139ec:	97aa                	add	a5,a5,a0
420139ee:	8f0d                	sub	a4,a4,a1
420139f0:	0007c783          	lbu	a5,0(a5)
420139f4:	8721                	srai	a4,a4,0x8
420139f6:	3ff8f893          	andi	a7,a7,1023
420139fa:	3ff6f693          	andi	a3,a3,1023
420139fe:	3ff77713          	andi	a4,a4,1023
42013a02:	9c2a                	add	s8,s8,a0
42013a04:	98aa                	add	a7,a7,a0
42013a06:	96aa                	add	a3,a3,a0
42013a08:	972a                	add	a4,a4,a0
42013a0a:	fefd0da3          	sb	a5,-5(s10)
42013a0e:	000c4c03          	lbu	s8,0(s8)
42013a12:	0008c883          	lbu	a7,0(a7)
42013a16:	0006c683          	lbu	a3,0(a3)
42013a1a:	00074783          	lbu	a5,0(a4)
42013a1e:	ff8d0c23          	sb	s8,-8(s10)
42013a22:	ff1d0ca3          	sb	a7,-7(s10)
42013a26:	fedd0d23          	sb	a3,-6(s10)
42013a2a:	fefd0e23          	sb	a5,-4(s10)
42013a2e:	ec761ae3          	bne	a2,t2,42013902 <jd_decomp+0x456>
42013a32:	be35                	j	4201356e <jd_decomp+0xc2>
42013a34:	4705                	li	a4,1
42013a36:	dceb97e3          	bne	s7,a4,42013804 <jd_decomp+0x358>
42013a3a:	0009a583          	lw	a1,0(s3)
42013a3e:	10000793          	li	a5,256
42013a42:	04000613          	li	a2,64
42013a46:	02f5c5b3          	div	a1,a1,a5
42013a4a:	f8058593          	addi	a1,a1,-128
42013a4e:	0ff5f593          	zext.b	a1,a1
42013a52:	be09                	j	42013564 <jd_decomp+0xb8>
42013a54:	506c                	lw	a1,100(s0)
42013a56:	01358733          	add	a4,a1,s3
42013a5a:	017b1d63          	bne	s6,s7,42013a74 <jd_decomp+0x5c8>
42013a5e:	00185713          	srli	a4,a6,0x1
42013a62:	02070713          	addi	a4,a4,32
42013a66:	070e                	slli	a4,a4,0x3
42013a68:	479d                	li	a5,7
42013a6a:	972e                	add	a4,a4,a1
42013a6c:	0107f463          	bgeu	a5,a6,42013a74 <jd_decomp+0x5c8>
42013a70:	04058593          	addi	a1,a1,64
42013a74:	00381793          	slli	a5,a6,0x3
42013a78:	95be                	add	a1,a1,a5
42013a7a:	8e9e                	mv	t4,t2
42013a7c:	4e01                	li	t3,0
42013a7e:	00ce6763          	bltu	t3,a2,42013a8c <jd_decomp+0x5e0>
42013a82:	47e2                	lw	a5,24(sp)
42013a84:	0805                	addi	a6,a6,1
42013a86:	09a1                	addi	s3,s3,8
42013a88:	93be                	add	t2,t2,a5
42013a8a:	b6ad                	j	420135f4 <jd_decomp+0x148>
42013a8c:	00074783          	lbu	a5,0(a4)
42013a90:	04074883          	lbu	a7,64(a4)
42013a94:	f8078793          	addi	a5,a5,-128
42013a98:	f8088893          	addi	a7,a7,-128
42013a9c:	077f9b63          	bne	t6,s7,42013b12 <jd_decomp+0x666>
42013aa0:	4521                	li	a0,8
42013aa2:	06ae1463          	bne	t3,a0,42013b0a <jd_decomp+0x65e>
42013aa6:	03858593          	addi	a1,a1,56
42013aaa:	03888533          	mul	a0,a7,s8
42013aae:	0005ca83          	lbu	s5,0(a1)
42013ab2:	0e8d                	addi	t4,t4,3
42013ab4:	0e05                	addi	t3,t3,1
42013ab6:	0585                	addi	a1,a1,1
42013ab8:	03454533          	div	a0,a0,s4
42013abc:	9556                	add	a0,a0,s5
42013abe:	3ff57513          	andi	a0,a0,1023
42013ac2:	951a                	add	a0,a0,t1
42013ac4:	00054503          	lbu	a0,0(a0)
42013ac8:	03a888b3          	mul	a7,a7,s10
42013acc:	feae8ea3          	sb	a0,-3(t4)
42013ad0:	03978533          	mul	a0,a5,s9
42013ad4:	9546                	add	a0,a0,a7
42013ad6:	03454533          	div	a0,a0,s4
42013ada:	40aa8533          	sub	a0,s5,a0
42013ade:	3ff57513          	andi	a0,a0,1023
42013ae2:	951a                	add	a0,a0,t1
42013ae4:	00054503          	lbu	a0,0(a0)
42013ae8:	feae8f23          	sb	a0,-2(t4)
42013aec:	71600513          	li	a0,1814
42013af0:	02a787b3          	mul	a5,a5,a0
42013af4:	0347c7b3          	div	a5,a5,s4
42013af8:	97d6                	add	a5,a5,s5
42013afa:	3ff7f793          	andi	a5,a5,1023
42013afe:	979a                	add	a5,a5,t1
42013b00:	0007c783          	lbu	a5,0(a5)
42013b04:	fefe8fa3          	sb	a5,-1(t4)
42013b08:	bf9d                	j	42013a7e <jd_decomp+0x5d2>
42013b0a:	001e7513          	andi	a0,t3,1
42013b0e:	972a                	add	a4,a4,a0
42013b10:	bf69                	j	42013aaa <jd_decomp+0x5fe>
42013b12:	0705                	addi	a4,a4,1
42013b14:	bf59                	j	42013aaa <jd_decomp+0x5fe>
42013b16:	458d                	li	a1,3
42013b18:	8e15                	sub	a2,a2,a3
42013b1a:	02b60633          	mul	a2,a2,a1
42013b1e:	503c                	lw	a5,96(s0)
42013b20:	4801                	li	a6,0
42013b22:	853e                	mv	a0,a5
42013b24:	02b685b3          	mul	a1,a3,a1
42013b28:	ad0f0ee3          	beq	t5,a6,42013604 <jd_decomp+0x158>
42013b2c:	00b788b3          	add	a7,a5,a1
42013b30:	872a                	mv	a4,a0
42013b32:	a839                	j	42013b50 <jd_decomp+0x6a4>
42013b34:	0007c303          	lbu	t1,0(a5)
42013b38:	078d                	addi	a5,a5,3
42013b3a:	070d                	addi	a4,a4,3
42013b3c:	fe670ea3          	sb	t1,-3(a4)
42013b40:	ffe7c303          	lbu	t1,-2(a5)
42013b44:	fe670f23          	sb	t1,-2(a4)
42013b48:	fff7c303          	lbu	t1,-1(a5)
42013b4c:	fe670fa3          	sb	t1,-1(a4)
42013b50:	ff1792e3          	bne	a5,a7,42013b34 <jd_decomp+0x688>
42013b54:	952e                	add	a0,a0,a1
42013b56:	97b2                	add	a5,a5,a2
42013b58:	0805                	addi	a6,a6,1
42013b5a:	b7f9                	j	42013b28 <jd_decomp+0x67c>
42013b5c:	4901                	li	s2,0
42013b5e:	bcdd                	j	42013654 <jd_decomp+0x1a8>
42013b60:	4515                	li	a0,5
42013b62:	8082                	ret
42013b64:	4505                	li	a0,1
42013b66:	bea9                	j	420136c0 <jd_decomp+0x214>
