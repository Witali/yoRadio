
C:\Work\yoRadio\.worktree\small-tv-jpeg-headers\.build\small-tv-esp32c2\small_tv_reconstructed.elf:     file format elf32-littleriscv


Disassembly of section .iram0.text:

Disassembly of section .flash.text:

420134a8 <jd_decomp>:
420134a8:	6a061863          	bnez	a2,42013b58 <jd_decomp+0x6b0>
420134ac:	7119                	addi	sp,sp,-128
420134ae:	dca2                	sw	s0,120(sp)
420134b0:	daa6                	sw	s1,116(sp)
420134b2:	c6ee                	sw	s11,76(sp)
420134b4:	de86                	sw	ra,124(sp)
420134b6:	d8ca                	sw	s2,112(sp)
420134b8:	d6ce                	sw	s3,108(sp)
420134ba:	d4d2                	sw	s4,104(sp)
420134bc:	d2d6                	sw	s5,100(sp)
420134be:	d0da                	sw	s6,96(sp)
420134c0:	cede                	sw	s7,92(sp)
420134c2:	cce2                	sw	s8,88(sp)
420134c4:	cae6                	sw	s9,84(sp)
420134c6:	c8ea                	sw	s10,80(sp)
420134c8:	00e54783          	lbu	a5,14(a0)
420134cc:	d42e                	sw	a1,40(sp)
420134ce:	842a                	mv	s0,a0
420134d0:	078e                	slli	a5,a5,0x3
420134d2:	c83e                	sw	a5,16(sp)
420134d4:	00f54783          	lbu	a5,15(a0)
420134d8:	000506a3          	sb	zero,13(a0)
420134dc:	00052a23          	sw	zero,20(a0)
420134e0:	078e                	slli	a5,a5,0x3
420134e2:	ca3e                	sw	a5,20(sp)
420134e4:	3c0eb7b7          	lui	a5,0x3c0eb
420134e8:	31c78793          	addi	a5,a5,796 # 3c0eb31c <Zig>
420134ec:	00051c23          	sh	zero,24(a0)
420134f0:	c602                	sw	zero,12(sp)
420134f2:	4d81                	li	s11,0
420134f4:	4481                	li	s1,0
420134f6:	d23e                	sw	a5,36(sp)
420134f8:	01e45783          	lhu	a5,30(s0)
420134fc:	64f4ec63          	bltu	s1,a5,42013b54 <jd_decomp+0x6ac>
42013500:	4501                	li	a0,0
42013502:	aa6d                	j	420136bc <jd_decomp+0x214>
42013504:	01a45783          	lhu	a5,26(s0)
42013508:	cb89                	beqz	a5,4201351a <jd_decomp+0x72>
4201350a:	15b78a63          	beq	a5,s11,4201365e <jd_decomp+0x1b6>
4201350e:	001d8793          	addi	a5,s11,1
42013512:	01079d93          	slli	s11,a5,0x10
42013516:	010ddd93          	srli	s11,s11,0x10
4201351a:	00f44783          	lbu	a5,15(s0)
4201351e:	00e44b03          	lbu	s6,14(s0)
42013522:	06042983          	lw	s3,96(s0)
42013526:	4a05                	li	s4,1
42013528:	02fb0b33          	mul	s6,s6,a5
4201352c:	507c                	lw	a5,100(s0)
4201352e:	4a81                	li	s5,0
42013530:	cc3e                	sw	a5,24(sp)
42013532:	002b0793          	addi	a5,s6,2
42013536:	d03e                	sw	a5,32(sp)
42013538:	416a0a33          	sub	s4,s4,s6
4201353c:	47e2                	lw	a5,24(sp)
4201353e:	006a9d13          	slli	s10,s5,0x6
42013542:	9d3e                	add	s10,s10,a5
42013544:	1b6aeb63          	bltu	s5,s6,420136fa <jd_decomp+0x252>
42013548:	1a0a0963          	beqz	s4,420136fa <jd_decomp+0x252>
4201354c:	01344683          	lbu	a3,19(s0)
42013550:	470d                	li	a4,3
42013552:	8bd2                	mv	s7,s4
42013554:	1ae68463          	beq	a3,a4,420136fc <jd_decomp+0x254>
42013558:	04000613          	li	a2,64
4201355c:	08000593          	li	a1,128
42013560:	856a                	mv	a0,s10
42013562:	fdfed097          	auipc	ra,0xfdfed
42013566:	f26080e7          	jalr	-218(ra) # 40000488 <memset>
4201356a:	5782                	lw	a5,32(sp)
4201356c:	0a85                	addi	s5,s5,1
4201356e:	0a05                	addi	s4,s4,1
42013570:	fcfae6e3          	bltu	s5,a5,4201353c <jd_decomp+0x94>
42013574:	00e44f83          	lbu	t6,14(s0)
42013578:	00f44b03          	lbu	s6,15(s0)
4201357c:	01c45783          	lhu	a5,28(s0)
42013580:	003f9613          	slli	a2,t6,0x3
42013584:	00c90733          	add	a4,s2,a2
42013588:	003b1293          	slli	t0,s6,0x3
4201358c:	86b2                	mv	a3,a2
4201358e:	00e7f463          	bgeu	a5,a4,42013596 <jd_decomp+0xee>
42013592:	412786b3          	sub	a3,a5,s2
42013596:	01e45703          	lhu	a4,30(s0)
4201359a:	005487b3          	add	a5,s1,t0
4201359e:	8f16                	mv	t5,t0
420135a0:	00f77463          	bgeu	a4,a5,420135a8 <jd_decomp+0x100>
420135a4:	40970f33          	sub	t5,a4,s1
420135a8:	fff90793          	addi	a5,s2,-1
420135ac:	97b6                	add	a5,a5,a3
420135ae:	02f11d23          	sh	a5,58(sp)
420135b2:	fff48793          	addi	a5,s1,-1
420135b6:	97fa                	add	a5,a5,t5
420135b8:	02f11f23          	sh	a5,62(sp)
420135bc:	47e1                	li	a5,24
420135be:	02ff87b3          	mul	a5,t6,a5
420135c2:	06042383          	lw	t2,96(s0)
420135c6:	3c0eb337          	lui	t1,0x3c0eb
420135ca:	03211c23          	sh	s2,56(sp)
420135ce:	02911e23          	sh	s1,60(sp)
420135d2:	006f9993          	slli	s3,t6,0x6
420135d6:	4801                	li	a6,0
420135d8:	4b89                	li	s7,2
420135da:	e9c30313          	addi	t1,t1,-356 # 3c0eae9c <Clip8>
420135de:	59b00c13          	li	s8,1435
420135e2:	cc3e                	sw	a5,24(sp)
420135e4:	40000a13          	li	s4,1024
420135e8:	16000c93          	li	s9,352
420135ec:	2db00d13          	li	s10,731
420135f0:	44586e63          	bltu	a6,t0,42013a4c <jd_decomp+0x5a4>
420135f4:	00d44783          	lbu	a5,13(s0)
420135f8:	00f65633          	srl	a2,a2,a5
420135fc:	50c6e963          	bltu	a3,a2,42013b0e <jd_decomp+0x666>
42013600:	03e686b3          	mul	a3,a3,t5
42013604:	478d                	li	a5,3
42013606:	502c                	lw	a1,96(s0)
42013608:	852e                	mv	a0,a1
4201360a:	862e                	mv	a2,a1
4201360c:	02f686b3          	mul	a3,a3,a5
42013610:	96ae                	add	a3,a3,a1
42013612:	00064703          	lbu	a4,0(a2)
42013616:	00164783          	lbu	a5,1(a2)
4201361a:	0509                	addi	a0,a0,2
4201361c:	0722                	slli	a4,a4,0x8
4201361e:	00264803          	lbu	a6,2(a2)
42013622:	80077713          	andi	a4,a4,-2048
42013626:	078e                	slli	a5,a5,0x3
42013628:	00385813          	srli	a6,a6,0x3
4201362c:	7e07f793          	andi	a5,a5,2016
42013630:	01076733          	or	a4,a4,a6
42013634:	8fd9                	or	a5,a5,a4
42013636:	060d                	addi	a2,a2,3
42013638:	fef51f23          	sh	a5,-2(a0)
4201363c:	fcd61be3          	bne	a2,a3,42013612 <jd_decomp+0x16a>
42013640:	57a2                	lw	a5,40(sp)
42013642:	1830                	addi	a2,sp,56
42013644:	8522                	mv	a0,s0
42013646:	9782                	jalr	a5
42013648:	50050a63          	beqz	a0,42013b5c <jd_decomp+0x6b4>
4201364c:	47c2                	lw	a5,16(sp)
4201364e:	993e                	add	s2,s2,a5
42013650:	01c45783          	lhu	a5,28(s0)
42013654:	eaf968e3          	bltu	s2,a5,42013504 <jd_decomp+0x5c>
42013658:	47d2                	lw	a5,20(sp)
4201365a:	94be                	add	s1,s1,a5
4201365c:	bd71                	j	420134f8 <jd_decomp+0x50>
4201365e:	00442a03          	lw	s4,4(s0)
42013662:	4008                	lw	a0,0(s0)
42013664:	4d89                	li	s11,2
42013666:	4981                	li	s3,0
42013668:	4b05                	li	s6,1
4201366a:	ed11                	bnez	a0,42013686 <jd_decomp+0x1de>
4201366c:	00842a03          	lw	s4,8(s0)
42013670:	583c                	lw	a5,112(s0)
42013672:	20000613          	li	a2,512
42013676:	85d2                	mv	a1,s4
42013678:	8522                	mv	a0,s0
4201367a:	9782                	jalr	a5
4201367c:	e511                	bnez	a0,42013688 <jd_decomp+0x1e0>
4201367e:	4509                	li	a0,2
42013680:	a835                	j	420136bc <jd_decomp+0x214>
42013682:	4d85                	li	s11,1
42013684:	b7dd                	j	4201366a <jd_decomp+0x1c2>
42013686:	0a05                	addi	s4,s4,1
42013688:	000a4783          	lbu	a5,0(s4)
4201368c:	09a2                	slli	s3,s3,0x8
4201368e:	157d                	addi	a0,a0,-1
42013690:	00f9e7b3          	or	a5,s3,a5
42013694:	01079993          	slli	s3,a5,0x10
42013698:	0109d993          	srli	s3,s3,0x10
4201369c:	ff6d93e3          	bne	s11,s6,42013682 <jd_decomp+0x1da>
420136a0:	fd87f793          	andi	a5,a5,-40
420136a4:	07c2                	slli	a5,a5,0x10
420136a6:	01442223          	sw	s4,4(s0)
420136aa:	c008                	sw	a0,0(s0)
420136ac:	00040623          	sb	zero,12(s0)
420136b0:	87c1                	srai	a5,a5,0x10
420136b2:	fd000713          	li	a4,-48
420136b6:	02e78263          	beq	a5,a4,420136da <jd_decomp+0x232>
420136ba:	4519                	li	a0,6
420136bc:	50f6                	lw	ra,124(sp)
420136be:	5466                	lw	s0,120(sp)
420136c0:	54d6                	lw	s1,116(sp)
420136c2:	5946                	lw	s2,112(sp)
420136c4:	59b6                	lw	s3,108(sp)
420136c6:	5a26                	lw	s4,104(sp)
420136c8:	5a96                	lw	s5,100(sp)
420136ca:	5b06                	lw	s6,96(sp)
420136cc:	4bf6                	lw	s7,92(sp)
420136ce:	4c66                	lw	s8,88(sp)
420136d0:	4cd6                	lw	s9,84(sp)
420136d2:	4d46                	lw	s10,80(sp)
420136d4:	4db6                	lw	s11,76(sp)
420136d6:	6109                	addi	sp,sp,128
420136d8:	8082                	ret
420136da:	47b2                	lw	a5,12(sp)
420136dc:	0137c9b3          	xor	s3,a5,s3
420136e0:	0079f993          	andi	s3,s3,7
420136e4:	fc099be3          	bnez	s3,420136ba <jd_decomp+0x212>
420136e8:	0785                	addi	a5,a5,1
420136ea:	07c2                	slli	a5,a5,0x10
420136ec:	83c1                	srli	a5,a5,0x10
420136ee:	c63e                	sw	a5,12(sp)
420136f0:	00042a23          	sw	zero,20(s0)
420136f4:	00041c23          	sh	zero,24(s0)
420136f8:	b50d                	j	4201351a <jd_decomp+0x72>
420136fa:	4b81                	li	s7,0
420136fc:	017037b3          	snez	a5,s7
42013700:	4601                	li	a2,0
42013702:	85be                	mv	a1,a5
42013704:	8522                	mv	a0,s0
42013706:	ce3e                	sw	a5,28(sp)
42013708:	edeff0ef          	jal	42012de6 <huffext>
4201370c:	8c2a                	mv	s8,a0
4201370e:	00055563          	bgez	a0,42013718 <jd_decomp+0x270>
42013712:	40a00533          	neg	a0,a0
42013716:	b75d                	j	420136bc <jd_decomp+0x214>
42013718:	001b9713          	slli	a4,s7,0x1
4201371c:	9722                	add	a4,a4,s0
4201371e:	01471c83          	lh	s9,20(a4)
42013722:	c915                	beqz	a0,42013756 <jd_decomp+0x2ae>
42013724:	85aa                	mv	a1,a0
42013726:	8522                	mv	a0,s0
42013728:	d63a                	sw	a4,44(sp)
4201372a:	f92ff0ef          	jal	42012ebc <bitext>
4201372e:	5732                	lw	a4,44(sp)
42013730:	00055563          	bgez	a0,4201373a <jd_decomp+0x292>
42013734:	40a00533          	neg	a0,a0
42013738:	b751                	j	420136bc <jd_decomp+0x214>
4201373a:	1c7d                	addi	s8,s8,-1
4201373c:	4685                	li	a3,1
4201373e:	01869c33          	sll	s8,a3,s8
42013742:	01857633          	and	a2,a0,s8
42013746:	e609                	bnez	a2,42013750 <jd_decomp+0x2a8>
42013748:	0c06                	slli	s8,s8,0x1
4201374a:	418686b3          	sub	a3,a3,s8
4201374e:	9536                	add	a0,a0,a3
42013750:	9caa                	add	s9,s9,a0
42013752:	01971a23          	sh	s9,20(a4)
42013756:	017407b3          	add	a5,s0,s7
4201375a:	0107c783          	lbu	a5,16(a5)
4201375e:	0fc00613          	li	a2,252
42013762:	4581                	li	a1,0
42013764:	07d1                	addi	a5,a5,20
42013766:	078a                	slli	a5,a5,0x2
42013768:	97a2                	add	a5,a5,s0
4201376a:	0007ac03          	lw	s8,0(a5)
4201376e:	00498513          	addi	a0,s3,4
42013772:	4b85                	li	s7,1
42013774:	000c2783          	lw	a5,0(s8)
42013778:	02fc8cb3          	mul	s9,s9,a5
4201377c:	408cdc93          	srai	s9,s9,0x8
42013780:	0199a023          	sw	s9,0(s3)
42013784:	fdfed097          	auipc	ra,0xfdfed
42013788:	d04080e7          	jalr	-764(ra) # 40000488 <memset>
4201378c:	8cde                	mv	s9,s7
4201378e:	45f2                	lw	a1,28(sp)
42013790:	4605                	li	a2,1
42013792:	8522                	mv	a0,s0
42013794:	e52ff0ef          	jal	42012de6 <huffext>
42013798:	28050a63          	beqz	a0,42013a2c <jd_decomp+0x584>
4201379c:	f8054ce3          	bltz	a0,42013734 <jd_decomp+0x28c>
420137a0:	00455713          	srli	a4,a0,0x4
420137a4:	9bba                	add	s7,s7,a4
420137a6:	03f00793          	li	a5,63
420137aa:	f177e8e3          	bltu	a5,s7,420136ba <jd_decomp+0x212>
420137ae:	00f57593          	andi	a1,a0,15
420137b2:	c1a1                	beqz	a1,420137f2 <jd_decomp+0x34a>
420137b4:	8522                	mv	a0,s0
420137b6:	d62e                	sw	a1,44(sp)
420137b8:	f04ff0ef          	jal	42012ebc <bitext>
420137bc:	55b2                	lw	a1,44(sp)
420137be:	f6054be3          	bltz	a0,42013734 <jd_decomp+0x28c>
420137c2:	15fd                	addi	a1,a1,-1
420137c4:	00bc95b3          	sll	a1,s9,a1
420137c8:	00b57733          	and	a4,a0,a1
420137cc:	e709                	bnez	a4,420137d6 <jd_decomp+0x32e>
420137ce:	0586                	slli	a1,a1,0x1
420137d0:	40bc85b3          	sub	a1,s9,a1
420137d4:	952e                	add	a0,a0,a1
420137d6:	5792                	lw	a5,36(sp)
420137d8:	01778733          	add	a4,a5,s7
420137dc:	00074703          	lbu	a4,0(a4)
420137e0:	070a                	slli	a4,a4,0x2
420137e2:	00e986b3          	add	a3,s3,a4
420137e6:	9762                	add	a4,a4,s8
420137e8:	4318                	lw	a4,0(a4)
420137ea:	02e50533          	mul	a0,a0,a4
420137ee:	8521                	srai	a0,a0,0x8
420137f0:	c288                	sw	a0,0(a3)
420137f2:	0b85                	addi	s7,s7,1
420137f4:	04000793          	li	a5,64
420137f8:	f8fb9be3          	bne	s7,a5,4201378e <jd_decomp+0x2e6>
420137fc:	6e85                	lui	t4,0x1
420137fe:	6289                	lui	t0,0x2
42013800:	6f85                	lui	t6,0x1
42013802:	6f0d                	lui	t5,0x3
42013804:	02098393          	addi	t2,s3,32
42013808:	87ce                	mv	a5,s3
4201380a:	6a0e8e93          	addi	t4,t4,1696 # 16a0 <CSR_UINTSTATUS+0x9ef>
4201380e:	d9028293          	addi	t0,t0,-624 # 1d90 <CSR_UINTSTATUS+0x10df>
42013812:	151f8f93          	addi	t6,t6,337 # 1151 <CSR_UINTSTATUS+0x4a0>
42013816:	9cff0f13          	addi	t5,t5,-1585 # 29cf <CSR_UINTSTATUS+0x1d1e>
4201381a:	0807a703          	lw	a4,128(a5)
4201381e:	0c07a583          	lw	a1,192(a5)
42013822:	4390                	lw	a2,0(a5)
42013824:	43b4                	lw	a3,64(a5)
42013826:	0207ab83          	lw	s7,32(a5)
4201382a:	00e608b3          	add	a7,a2,a4
4201382e:	8e19                	sub	a2,a2,a4
42013830:	40b68733          	sub	a4,a3,a1
42013834:	03d70733          	mul	a4,a4,t4
42013838:	96ae                	add	a3,a3,a1
4201383a:	0e07a503          	lw	a0,224(a5)
4201383e:	53ac                	lw	a1,96(a5)
42013840:	00d88e33          	add	t3,a7,a3
42013844:	40d888b3          	sub	a7,a7,a3
42013848:	8731                	srai	a4,a4,0xc
4201384a:	8f15                	sub	a4,a4,a3
4201384c:	00e60333          	add	t1,a2,a4
42013850:	8e19                	sub	a2,a2,a4
42013852:	0a07a703          	lw	a4,160(a5)
42013856:	40ab86b3          	sub	a3,s7,a0
4201385a:	955e                	add	a0,a0,s7
4201385c:	40b70bb3          	sub	s7,a4,a1
42013860:	972e                	add	a4,a4,a1
42013862:	40e505b3          	sub	a1,a0,a4
42013866:	953a                	add	a0,a0,a4
42013868:	01768733          	add	a4,a3,s7
4201386c:	02570733          	mul	a4,a4,t0
42013870:	03f686b3          	mul	a3,a3,t6
42013874:	8731                	srai	a4,a4,0xc
42013876:	03eb8bb3          	mul	s7,s7,t5
4201387a:	86b1                	srai	a3,a3,0xc
4201387c:	40d706b3          	sub	a3,a4,a3
42013880:	03d585b3          	mul	a1,a1,t4
42013884:	40cbdb93          	srai	s7,s7,0xc
42013888:	41770733          	sub	a4,a4,s7
4201388c:	8f09                	sub	a4,a4,a0
4201388e:	00ae0bb3          	add	s7,t3,a0
42013892:	40ae0e33          	sub	t3,t3,a0
42013896:	00e30533          	add	a0,t1,a4
4201389a:	40e30333          	sub	t1,t1,a4
4201389e:	0177a023          	sw	s7,0(a5)
420138a2:	0fc7a023          	sw	t3,224(a5)
420138a6:	85b1                	srai	a1,a1,0xc
420138a8:	8d99                	sub	a1,a1,a4
420138aa:	00b60733          	add	a4,a2,a1
420138ae:	8e8d                	sub	a3,a3,a1
420138b0:	c3b8                	sw	a4,64(a5)
420138b2:	8e0d                	sub	a2,a2,a1
420138b4:	00d88733          	add	a4,a7,a3
420138b8:	40d888b3          	sub	a7,a7,a3
420138bc:	d388                	sw	a0,32(a5)
420138be:	0c67a023          	sw	t1,192(a5)
420138c2:	0ac7a023          	sw	a2,160(a5)
420138c6:	d3b8                	sw	a4,96(a5)
420138c8:	0917a023          	sw	a7,128(a5)
420138cc:	0791                	addi	a5,a5,4
420138ce:	f47796e3          	bne	a5,t2,4201381a <jd_decomp+0x372>
420138d2:	6e85                	lui	t4,0x1
420138d4:	6289                	lui	t0,0x2
420138d6:	6f85                	lui	t6,0x1
420138d8:	6f0d                	lui	t5,0x3
420138da:	3c0eb537          	lui	a0,0x3c0eb
420138de:	10098393          	addi	t2,s3,256
420138e2:	864e                	mv	a2,s3
420138e4:	6ba1                	lui	s7,0x8
420138e6:	6a0e8e93          	addi	t4,t4,1696 # 16a0 <CSR_UINTSTATUS+0x9ef>
420138ea:	d9028293          	addi	t0,t0,-624 # 1d90 <CSR_UINTSTATUS+0x10df>
420138ee:	151f8f93          	addi	t6,t6,337 # 1151 <CSR_UINTSTATUS+0x4a0>
420138f2:	9cff0f13          	addi	t5,t5,-1585 # 29cf <CSR_UINTSTATUS+0x1d1e>
420138f6:	e9c50513          	addi	a0,a0,-356 # 3c0eae9c <Clip8>
420138fa:	421c                	lw	a5,0(a2)
420138fc:	4a14                	lw	a3,16(a2)
420138fe:	01862803          	lw	a6,24(a2)
42013902:	460c                	lw	a1,8(a2)
42013904:	97de                	add	a5,a5,s7
42013906:	00d78733          	add	a4,a5,a3
4201390a:	8f95                	sub	a5,a5,a3
4201390c:	410586b3          	sub	a3,a1,a6
42013910:	03d686b3          	mul	a3,a3,t4
42013914:	95c2                	add	a1,a1,a6
42013916:	00462c03          	lw	s8,4(a2)
4201391a:	00c62303          	lw	t1,12(a2)
4201391e:	01c62e03          	lw	t3,28(a2)
42013922:	00b708b3          	add	a7,a4,a1
42013926:	8f0d                	sub	a4,a4,a1
42013928:	0d21                	addi	s10,s10,8
4201392a:	86b1                	srai	a3,a3,0xc
4201392c:	8e8d                	sub	a3,a3,a1
4201392e:	00d78833          	add	a6,a5,a3
42013932:	8f95                	sub	a5,a5,a3
42013934:	4a54                	lw	a3,20(a2)
42013936:	41cc05b3          	sub	a1,s8,t3
4201393a:	9e62                	add	t3,t3,s8
4201393c:	40668c33          	sub	s8,a3,t1
42013940:	969a                	add	a3,a3,t1
42013942:	40de0333          	sub	t1,t3,a3
42013946:	9e36                	add	t3,t3,a3
42013948:	018586b3          	add	a3,a1,s8
4201394c:	025686b3          	mul	a3,a3,t0
42013950:	02060613          	addi	a2,a2,32
42013954:	03f585b3          	mul	a1,a1,t6
42013958:	86b1                	srai	a3,a3,0xc
4201395a:	03ec0c33          	mul	s8,s8,t5
4201395e:	85b1                	srai	a1,a1,0xc
42013960:	40b685b3          	sub	a1,a3,a1
42013964:	40cc5c13          	srai	s8,s8,0xc
42013968:	418686b3          	sub	a3,a3,s8
4201396c:	03d30333          	mul	t1,t1,t4
42013970:	01c88c33          	add	s8,a7,t3
42013974:	41c888b3          	sub	a7,a7,t3
42013978:	4088d893          	srai	a7,a7,0x8
4201397c:	3ff8f893          	andi	a7,a7,1023
42013980:	98aa                	add	a7,a7,a0
42013982:	0008c883          	lbu	a7,0(a7)
42013986:	41c686b3          	sub	a3,a3,t3
4201398a:	408c5c13          	srai	s8,s8,0x8
4201398e:	ff1d0fa3          	sb	a7,-1(s10)
42013992:	00d808b3          	add	a7,a6,a3
42013996:	40d80833          	sub	a6,a6,a3
4201399a:	40885813          	srai	a6,a6,0x8
4201399e:	3ff87813          	andi	a6,a6,1023
420139a2:	40c35313          	srai	t1,t1,0xc
420139a6:	982a                	add	a6,a6,a0
420139a8:	40d30333          	sub	t1,t1,a3
420139ac:	00084683          	lbu	a3,0(a6)
420139b0:	406585b3          	sub	a1,a1,t1
420139b4:	4088d893          	srai	a7,a7,0x8
420139b8:	fedd0f23          	sb	a3,-2(s10)
420139bc:	006786b3          	add	a3,a5,t1
420139c0:	406787b3          	sub	a5,a5,t1
420139c4:	87a1                	srai	a5,a5,0x8
420139c6:	3ff7f793          	andi	a5,a5,1023
420139ca:	97aa                	add	a5,a5,a0
420139cc:	0007c783          	lbu	a5,0(a5)
420139d0:	86a1                	srai	a3,a3,0x8
420139d2:	3ffc7c13          	andi	s8,s8,1023
420139d6:	fefd0ea3          	sb	a5,-3(s10)
420139da:	00b707b3          	add	a5,a4,a1
420139de:	87a1                	srai	a5,a5,0x8
420139e0:	3ff7f793          	andi	a5,a5,1023
420139e4:	97aa                	add	a5,a5,a0
420139e6:	8f0d                	sub	a4,a4,a1
420139e8:	0007c783          	lbu	a5,0(a5)
420139ec:	8721                	srai	a4,a4,0x8
420139ee:	3ff8f893          	andi	a7,a7,1023
420139f2:	3ff6f693          	andi	a3,a3,1023
420139f6:	3ff77713          	andi	a4,a4,1023
420139fa:	9c2a                	add	s8,s8,a0
420139fc:	98aa                	add	a7,a7,a0
420139fe:	96aa                	add	a3,a3,a0
42013a00:	972a                	add	a4,a4,a0
42013a02:	fefd0da3          	sb	a5,-5(s10)
42013a06:	000c4c03          	lbu	s8,0(s8)
42013a0a:	0008c883          	lbu	a7,0(a7)
42013a0e:	0006c683          	lbu	a3,0(a3)
42013a12:	00074783          	lbu	a5,0(a4)
42013a16:	ff8d0c23          	sb	s8,-8(s10)
42013a1a:	ff1d0ca3          	sb	a7,-7(s10)
42013a1e:	fedd0d23          	sb	a3,-6(s10)
42013a22:	fefd0e23          	sb	a5,-4(s10)
42013a26:	ec761ae3          	bne	a2,t2,420138fa <jd_decomp+0x452>
42013a2a:	b681                	j	4201356a <jd_decomp+0xc2>
42013a2c:	4705                	li	a4,1
42013a2e:	dceb97e3          	bne	s7,a4,420137fc <jd_decomp+0x354>
42013a32:	0009a583          	lw	a1,0(s3)
42013a36:	10000793          	li	a5,256
42013a3a:	04000613          	li	a2,64
42013a3e:	02f5c5b3          	div	a1,a1,a5
42013a42:	f8058593          	addi	a1,a1,-128
42013a46:	0ff5f593          	zext.b	a1,a1
42013a4a:	be19                	j	42013560 <jd_decomp+0xb8>
42013a4c:	506c                	lw	a1,100(s0)
42013a4e:	01358733          	add	a4,a1,s3
42013a52:	017b1d63          	bne	s6,s7,42013a6c <jd_decomp+0x5c4>
42013a56:	00185713          	srli	a4,a6,0x1
42013a5a:	02070713          	addi	a4,a4,32
42013a5e:	070e                	slli	a4,a4,0x3
42013a60:	479d                	li	a5,7
42013a62:	972e                	add	a4,a4,a1
42013a64:	0107f463          	bgeu	a5,a6,42013a6c <jd_decomp+0x5c4>
42013a68:	04058593          	addi	a1,a1,64
42013a6c:	00381793          	slli	a5,a6,0x3
42013a70:	95be                	add	a1,a1,a5
42013a72:	8e9e                	mv	t4,t2
42013a74:	4e01                	li	t3,0
42013a76:	00ce6763          	bltu	t3,a2,42013a84 <jd_decomp+0x5dc>
42013a7a:	47e2                	lw	a5,24(sp)
42013a7c:	0805                	addi	a6,a6,1
42013a7e:	09a1                	addi	s3,s3,8
42013a80:	93be                	add	t2,t2,a5
42013a82:	b6bd                	j	420135f0 <jd_decomp+0x148>
42013a84:	00074783          	lbu	a5,0(a4)
42013a88:	04074883          	lbu	a7,64(a4)
42013a8c:	f8078793          	addi	a5,a5,-128
42013a90:	f8088893          	addi	a7,a7,-128
42013a94:	077f9b63          	bne	t6,s7,42013b0a <jd_decomp+0x662>
42013a98:	4521                	li	a0,8
42013a9a:	06ae1463          	bne	t3,a0,42013b02 <jd_decomp+0x65a>
42013a9e:	03858593          	addi	a1,a1,56
42013aa2:	03888533          	mul	a0,a7,s8
42013aa6:	0005ca83          	lbu	s5,0(a1)
42013aaa:	0e8d                	addi	t4,t4,3
42013aac:	0e05                	addi	t3,t3,1
42013aae:	0585                	addi	a1,a1,1
42013ab0:	03454533          	div	a0,a0,s4
42013ab4:	9556                	add	a0,a0,s5
42013ab6:	3ff57513          	andi	a0,a0,1023
42013aba:	951a                	add	a0,a0,t1
42013abc:	00054503          	lbu	a0,0(a0)
42013ac0:	03a888b3          	mul	a7,a7,s10
42013ac4:	feae8ea3          	sb	a0,-3(t4)
42013ac8:	03978533          	mul	a0,a5,s9
42013acc:	9546                	add	a0,a0,a7
42013ace:	03454533          	div	a0,a0,s4
42013ad2:	40aa8533          	sub	a0,s5,a0
42013ad6:	3ff57513          	andi	a0,a0,1023
42013ada:	951a                	add	a0,a0,t1
42013adc:	00054503          	lbu	a0,0(a0)
42013ae0:	feae8f23          	sb	a0,-2(t4)
42013ae4:	71600513          	li	a0,1814
42013ae8:	02a787b3          	mul	a5,a5,a0
42013aec:	0347c7b3          	div	a5,a5,s4
42013af0:	97d6                	add	a5,a5,s5
42013af2:	3ff7f793          	andi	a5,a5,1023
42013af6:	979a                	add	a5,a5,t1
42013af8:	0007c783          	lbu	a5,0(a5)
42013afc:	fefe8fa3          	sb	a5,-1(t4)
42013b00:	bf9d                	j	42013a76 <jd_decomp+0x5ce>
42013b02:	001e7513          	andi	a0,t3,1
42013b06:	972a                	add	a4,a4,a0
42013b08:	bf69                	j	42013aa2 <jd_decomp+0x5fa>
42013b0a:	0705                	addi	a4,a4,1
42013b0c:	bf59                	j	42013aa2 <jd_decomp+0x5fa>
42013b0e:	458d                	li	a1,3
42013b10:	8e15                	sub	a2,a2,a3
42013b12:	02b60633          	mul	a2,a2,a1
42013b16:	503c                	lw	a5,96(s0)
42013b18:	4801                	li	a6,0
42013b1a:	853e                	mv	a0,a5
42013b1c:	02b685b3          	mul	a1,a3,a1
42013b20:	af0f00e3          	beq	t5,a6,42013600 <jd_decomp+0x158>
42013b24:	00b788b3          	add	a7,a5,a1
42013b28:	872a                	mv	a4,a0
42013b2a:	a839                	j	42013b48 <jd_decomp+0x6a0>
42013b2c:	0007c303          	lbu	t1,0(a5)
42013b30:	078d                	addi	a5,a5,3
42013b32:	070d                	addi	a4,a4,3
42013b34:	fe670ea3          	sb	t1,-3(a4)
42013b38:	ffe7c303          	lbu	t1,-2(a5)
42013b3c:	fe670f23          	sb	t1,-2(a4)
42013b40:	fff7c303          	lbu	t1,-1(a5)
42013b44:	fe670fa3          	sb	t1,-1(a4)
42013b48:	ff1792e3          	bne	a5,a7,42013b2c <jd_decomp+0x684>
42013b4c:	952e                	add	a0,a0,a1
42013b4e:	97b2                	add	a5,a5,a2
42013b50:	0805                	addi	a6,a6,1
42013b52:	b7f9                	j	42013b20 <jd_decomp+0x678>
42013b54:	4901                	li	s2,0
42013b56:	bced                	j	42013650 <jd_decomp+0x1a8>
42013b58:	4515                	li	a0,5
42013b5a:	8082                	ret
42013b5c:	4505                	li	a0,1
42013b5e:	beb9                	j	420136bc <jd_decomp+0x214>
