"""Preserve completed F1 browser runs without rerunning or changing live VMs."""
from pathlib import Path
import datetime as dt
import gzip
import hashlib
import json
import subprocess

BASE = Path('C:/Work/yoRadio')
ROOT = BASE / '.worktree/small-tv-browser-controls-verify'
PARITY = ROOT / 'Small_TV/qemu/parity'
APP = 'f1ada8b4da4338df3248ffb26a39a79e36bf5cf0e365eb2972b75c8721f7ea7b'
QEMU = 'd64f3013739f22b986e07aed39395b25bde474f52ef813b8ffaeedb0991edecc'


def read(path):
    """Read an existing result; never rewrite a tested report."""
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(data):
    """Hash the exact stored bytes."""
    return hashlib.sha256(data).hexdigest()


def archive(folder, source, label):
    """Keep deterministic gzip evidence with original and decompressed hashes."""
    data = source.read_bytes()
    payload = gzip.decompress(data) if source.suffix == '.gz' else data
    target = folder / (label + '.gz')
    assert not target.exists(), target
    target.write_bytes(gzip.compress(payload, mtime=0))
    return dict(file=target.relative_to(PARITY).as_posix(),
                original_file_sha256=sha(data), payload_sha256=sha(payload),
                stored_sha256=sha(target.read_bytes()), original_was_gzip=source.suffix == '.gz')


def verify_inputs(report, expected):
    """Recheck all selected run inputs before publishing the immutable evidence."""
    assert report['passed'] and not report['all_functionality_verified']
    assert report['app_sha256'] == APP and report['qemu_sha256'] == QEMU
    assert len(report['inputs_sha256']) == expected
    for name, value in report['inputs_sha256'].items():
        assert sha(Path(name).read_bytes()) == value, name


def check_browser(browser):
    """Require real successful browser checks and no JavaScript/console errors."""
    assert browser['passed'] and all(row['passed'] for row in browser['checks'])
    assert not browser['console'] and not browser['page_errors']
    return len(browser['checks'])


cleanup = read(PARITY / 'f1-browser-vm-cleanup-20261018.json')
assert len(cleanup['vm_identities']) == 8
assert all(row['state'] in ('absent', 'pid_reused_by_different_identity') for row in cleanup['vm_identities'])
assert cleanup['new_qmp_rsp_clients'] == 0
git_commit = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
for kind, expected_inputs in (('photo', 27), ('wifi', 26)):
    run = ROOT / f'.build/f1-browser-{kind}-20261018'
    report = read(run / 'report.json')
    verify_inputs(report, expected_inputs)
    if kind == 'photo':
        assert all(report['checks'].values()) and len(report['checks']) == 6
        ui_count = sum(check_browser(report[stage]) for stage in ('upload', 'cold'))
        assert ui_count == 23
        storage_count = len(report['checks'])
        stages = report['stages']
        for stage in ('upload', 'cold'):
            assert stages[stage]['rom_boots'] == 1 and stages[stage]['direct_raw_backing']
        candidates = [p for p in run.iterdir() if p.is_file() and p.suffix in ('.json', '.log', '.gz', '.jpg', '.png')]
        source_names = ('browser_photo_qemu.py', 'browser_photo_flow.mjs', 'qemu_storage.py')
        scope = ('Real desktop/mobile crop, Canvas resize/metadata removal, multipart HTTP and cold raw photo persistence. '
                 'No LCD-pixel, physical touch, RF/WPA, PWM, full-suite or H10 acceptance.')
    else:
        assert report['inputs_verified'] == 26
        ui_count = storage_count = 0
        stages = {}
        for name, flow in report['flows'].items():
            assert flow['passed'] and all(flow['checks'].values())
            storage_count += len(flow['checks'])
            ui_count += sum(check_browser(flow[stage]) for stage in ('preflight', 'configure', 'cold'))
            stages[name] = flow['stages']
        assert ui_count == 93 and storage_count == 18
        # Browser products only: no full writable flash dump or live VM internals.
        candidates = [run / 'report.json']
        for name in report['flows']:
            candidates += [p for p in (run / name).iterdir() if p.is_file() and p.suffix in ('.json', '.log', '.gz', '.png')]
        source_names = ('browser_wifi_qemu.py', 'browser_wifi_flow.mjs', 'qemu_storage.py')
        scope = ('Real browser initial Wi-Fi configuration for discovered/literal-manual/manual-entry, invalid input, '
                 'station DHCP/SNTP and cold credential persistence. No physical RF/WPA/captive portal, '
                 'LCD/PWM, full-suite or H10 acceptance.')
    folder = PARITY / f'browser-{kind}-f1-validation-20261018-raw'
    folder.mkdir(exist_ok=False)
    evidence = [archive(folder, path, path.relative_to(run).as_posix().replace('/', '__')) for path in sorted(candidates)]
    sources = {}
    for name in source_names:
        relative = 'Small_TV/src/tests/' + name
        path = ROOT / relative
        canonical = subprocess.check_output(['git', '-C', str(ROOT), 'show', 'HEAD:' + relative])
        assert path.read_bytes().replace(b'\r\n', b'\n') == canonical
        sources[relative] = dict(worktree_sha256=sha(path.read_bytes()), git_lf_sha256=sha(canonical))
        evidence.append(archive(folder, path, name))
    evidence.append(archive(folder, PARITY / 'f1-browser-vm-cleanup-20261018.json', 'owned-os-identities.json'))
    evidence.append(archive(folder, Path(__file__), 'save_f1_browser_evidence_20261018.py'))
    record = dict(passed=True, status=f'f1_browser_{kind}_passed', all_functionality_verified=False,
                  captured_utc=dt.datetime.now(dt.timezone.utc).isoformat(), evidence_parent_commit=git_commit,
                  app_sha256=report['app_sha256'], native_elf_sha256=report['native_elf_sha256'],
                  qemu_sha256=report['qemu_sha256'], input_count=expected_inputs,
                  ui_checks=ui_count, storage_role_source_checks=storage_count, stages=stages,
                  sources=sources, os_cleanup=cleanup, evidence=evidence,
                  production_changed=False, scope=scope)
    target = PARITY / f'browser-{kind}-f1-validation-20261018.json'
    assert not target.exists()
    target.write_text(json.dumps(record, indent=2) + '\n', newline='\n')
    print(json.dumps(dict(kind=kind, passed=True, ui_checks=ui_count, other_checks=storage_count,
                          archived_files=len(evidence))))
