"""Freeze the exact full-suite source, archive, SDK and selected D64 snapshot."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess

BASE=Path('C:/Work/yoRadio')
ROOT=BASE/'.worktree/small-tv-reset-display'
SNAP=ROOT/'.build/reset-display-qemu-complete-20261018'
DEST=ROOT/'Small_TV/qemu/parity/reset-display-complete-full-start-20261018.json'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git','-C',str(ROOT),*args],text=True).strip()
assert not DEST.exists()
assert not git('status','--porcelain')
old=read(BASE/'.worktree/small-tv-jpeg-uploads/Small_TV/qemu/parity/jpeg-dht-full-start-20261018.json')
tests=[dict(file=name,sha256=sha(ROOT/name)) for name in git('ls-files','Small_TV/src/tests').splitlines()]
extra={}
def add(kind,name):
    path=(SNAP if kind=='qemu' else ROOT)/name
    assert path.is_file(),path
    extra[(kind,name)]=dict(root=kind,file=name,sha256=sha(path))
for row in old['extra_inputs']:
    if row['root']=='yoRadio' and row['file']!='.build/run_integrated_full.ps1':
        add('yoRadio',row['file'])
for name in git('ls-files','Small_TV/src').splitlines():
    if not name.startswith('Small_TV/src/tests/'):
        add('yoRadio',name)
snapshot=read(SNAP/'frozen-inputs.json')
for row in snapshot['files']:
    assert sha(SNAP/row['file'])==row['sha256']
    add('qemu',row['file'])
add('qemu','frozen-inputs.json')
add('yoRadio','.build/run_reset_display_complete_full.ps1')
source=read(ROOT/'firmware/development/small-tv-esp32c2-reconstructed/source-manifest.json')
assert source==read(ROOT/'.build/small-tv-esp32c2/resources/source-manifest.json')
for item in source['files']:
    path=(ROOT/'.build/small-tv-esp32c2/resources'/item['file'][10:]) if item['file'].startswith('generated/') else ROOT/'Small_TV/src'/item['file']
    assert sha(path)==item['sha256'],item['file']
    add('yoRadio',path.relative_to(ROOT).as_posix())
app=ROOT/'firmware/development/small-tv-esp32c2-reconstructed/app.bin'
elf=ROOT/'.build/small-tv-esp32c2/small_tv_reconstructed.elf'
assert app.read_bytes()[176:208]==bytes.fromhex(sha(elf))
assert sha(app)=='0592b51036117b81b98d7b7f615bbc7cce7e52e88635627c9f2c48afbed422ec'
assert sha(SNAP/'bin/qemu-system-riscv32.exe')=='d64f3013739f22b986e07aed39395b25bde474f52ef813b8ffaeedb0991edecc'
record=dict(status='frozen_before_start',all_functionality_verified=False,
    captured_utc=dt.datetime.now(dt.timezone.utc).isoformat(),git_head=git('rev-parse','HEAD'),
    yoradio_root=str(ROOT),qemu_root=str(SNAP),qemu_source_reference_commit=snapshot['qemu_source_reference_commit'],
    app_sha256=sha(app),elf_sha256=sha(elf),source_sha256=source['aggregate_sha256'],
    qemu_sha256=sha(SNAP/'bin/qemu-system-riscv32.exe'),tests=tests,extra_inputs=list(extra.values()),
    input_count=len(tests)+len(extra),
    initial_integrity_preflight='Five artifact groups passed; the standalone route-coverage check required the fresh native report that run-all generates before its integrity group. The unsuccessful preflight is retained and no gate was relaxed.',
    scope='Complete standard suite on unchanged 0592/D64, observer 3563b1adc7, and complete board JSON data. Failed full557 and its original snapshot are preserved. Not execution success, H10, classic ESP32/CYD, or physical acceptance.',
    preservation='Do not edit Small_TV/src, archived firmware, exact ELF/resources/SDK inputs, or this snapshot while the full run is live. Use Small_TV/qemu/parity for the ongoing journal.',
    sdk_junction=dict(path=str(ROOT/'.idf'),target='C:/Work/yoRadio/.idf',cleanup='Remove only the junction entry; never recurse into the shared SDK.'))
DEST.write_text(json.dumps(record,indent=2)+'\n',newline='\n')
print(json.dumps(dict(input_count=record['input_count'],tests=len(tests),extra=len(extra),app=record['app_sha256'],qemu=record['qemu_sha256'])))
