"""Complete data dependencies without modifying the failed full557 snapshot."""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import shutil
import sys

BASE=Path('C:/Work/yoRadio')
ROOT=BASE/'.worktree/small-tv-reset-display'
OLD=ROOT/'.build/reset-display-qemu-frozen-20261018'
NEW=ROOT/'.build/reset-display-qemu-complete-20261018'
QEMU=Path('C:/Work/QEMU-ESP32/.worktree/hostfwd-backlog')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
assert not NEW.exists()
record=read(OLD/'frozen-inputs.json')
files=[]
for row in record['files']:
    source=OLD/row['file']; assert sha(source)==row['sha256']
    target=NEW/row['file'];target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target);files.append(row['file'])
for source in sorted((QEMU/'configs/boards').glob('*.json')):
    relative=source.relative_to(QEMU)
    target=NEW/relative;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target);files.append(relative.as_posix())
assert read(NEW/'configs/boards/small-tv-c2.json')==read(ROOT/'Small_TV/qemu/profiles/small-tv-c2.json')
record.update(status='selected_runtime_and_board_data_complete',
    correction='The previous full557 snapshot omitted configs/boards/small-tv-c2.json, read by seed_setup_network. Its failed run and all frozen bytes are preserved. This separate snapshot adds all four existing board JSON data files; application, ELF, emulator and helper code are unchanged.',
    files=[dict(file=name,sha256=sha(NEW/name)) for name in sorted(files)])
(NEW/'frozen-inputs.json').write_text(json.dumps(record,indent=2)+'\n',newline='\n')
sys.path.insert(0,str(NEW/'tools'))
import small_tv_vm as vm
args=SimpleNamespace(yoradio=str(ROOT),firmware='original',network='setup',persistent=False,
    rom_elf=str(BASE/'.idf/tools-v6.1/tools/esp-rom-elfs/20260528/esp32c2_rev200_rom.elf'),
    hardware_profile=str(ROOT/'Small_TV/qemu/profiles/small-tv-c2.json'))
out=BASE/'.build/complete-snapshot-setup-preflight-20261018'
out.mkdir(exist_ok=False)
results={}
for variant in ('original','reconstructed'):
    args.firmware=variant
    result=vm.prepare(args,out/variant)
    data=(out/variant/'flash.bin').read_bytes()
    assert data[0x3e7004:0x3e7045]==bytes(65)
    assert int.from_bytes(data[0x3e7160:0x3e7164],'little')==2
    results[variant]=dict(passed=True,prepared_flash_sha256=result['prepared_flash_sha256'],sources=result['sources'])
proof=dict(passed=True,snapshot_files=len(files),sources_unchanged=all(sha(OLD/row['file'])==row['sha256'] for row in read(OLD/'frozen-inputs.json')['files']),
    default_profile_sha256=sha(NEW/'configs/boards/small-tv-c2.json'),canonical_profile_matches=True,variants=results,
    scope='Actual original and reconstructed setup preparation without starting a VM; not a guest network acceptance.')
(out/'report.json').write_text(json.dumps(proof,indent=2)+'\n',newline='\n')
print(json.dumps(dict(passed=True,snapshot_files=len(files),old_snapshot_unchanged=proof['sources_unchanged'])))
