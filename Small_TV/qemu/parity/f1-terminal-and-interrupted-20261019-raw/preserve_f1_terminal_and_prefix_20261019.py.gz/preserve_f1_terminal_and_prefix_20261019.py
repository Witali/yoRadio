"""Preserve F1 full success, failed publication and interrupted runtime separately."""
from pathlib import Path
import datetime as dt
import gzip
import hashlib
import json

BASE = Path('C:/Work/yoRadio')
OLD = BASE / '.worktree/small-tv-jpeg-headers'
DEST = BASE / '.worktree/small-tv-jpeg-selectors/Small_TV/qemu/parity'
FULL = BASE / '.build/small-tv-functional/jpeg-header-complete-full-20261018'
RUNTIME = OLD / '.build/jpeg-header-h10-20261018'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()
freeze = read(OLD / 'Small_TV/qemu/parity/jpeg-header-complete-full-start-20261018.json')
for row in freeze['tests']:
    assert sha((OLD / row['file']).read_bytes()) == row['sha256'], row['file']
for row in freeze['extra_inputs']:
    root = OLD if row['root'] == 'yoRadio' else Path(freeze['qemu_root'])
    assert sha((root / row['file']).read_bytes()) == row['sha256'], row['file']
assert len(freeze['tests']) + len(freeze['extra_inputs']) == 566
full, terminal = read(FULL / 'report.json'), read(FULL / 'controller-exit.json')
assert full['passed'] and terminal['status'] == 'terminal_passed' and terminal['exit_code'] == 0
assert full['app_sha256'] == freeze['app_sha256'] and full['source_sha256'] == freeze['source_sha256']
assert sum(row['status'] == 'passed' for row in full['groups']) == 19
runtime = read(RUNTIME / 'report.json')
analysis = read(DEST / 'f1-h10-interrupted-analysis-20261019.json')
os_state = read(DEST / 'f1-h10-stopped-os-20261019.json')
assert os_state['all_original_identities_absent'] and not analysis['h10_checks_passed']
assert analysis['complete_cycles_audited'] == 640 and analysis['pending_events'] == 4
assert analysis['checks']['start_record_matches'] and analysis['inputs_verified'] == 32
assert not analysis['checks']['workload_complete']
assert read(DEST / 'f1-full-publisher-attempt-status-20261019.json')['exit_code'] == 1
raw = DEST / 'f1-terminal-and-interrupted-20261019-raw'
raw.mkdir(exist_ok=False)
artifacts = []


def archive(source, label):
    """Keep exact bytes, including stale running flags and absent terminal evidence."""
    data = source.read_bytes()
    target = raw / (label + '.gz')
    assert not target.exists()
    target.write_bytes(gzip.compress(data, mtime=0))
    artifacts.append(dict(file=target.relative_to(DEST).as_posix(), original_sha256=sha(data),
                          stored_sha256=sha(target.read_bytes())))


archive(OLD / 'Small_TV/qemu/parity/jpeg-header-complete-full-start-20261018.json', 'full-start.json')
archive(FULL / 'controller-exit.json', 'full-controller-exit.json')
for source in sorted(FULL.rglob('report.json')):
    archive(source, 'full-' + source.relative_to(FULL).as_posix().replace('/', '__'))
for source in sorted(FULL.glob('*.log')):
    archive(source, 'full-' + source.name)
for name in ('events.jsonl', 'report.json', 'uptime-guard.json', 'vm/session.json', 'vm/uart.log', 'vm/qemu.log'):
    archive(RUNTIME / name, 'runtime-' + name.replace('/', '__'))
archive(Path(str(RUNTIME) + '-supervisor') / 'supervisor.json', 'runtime-supervisor.json')
archive(Path(str(RUNTIME) + '-launch.json'), 'runtime-launch.json')
for name in ('jpeg-header-h10-start-20261018.json', 'jpeg-header-h10-audit-start-20261018.json'):
    archive(OLD / 'Small_TV/qemu/parity' / name, name)
for name in ('f1-h10-interrupted-analysis-20261019.json', 'f1-h10-stopped-os-20261019.json',
             'f1-full-publisher-attempt-status-20261019.json', 'f1-full-publisher-attempt-20261019.log'):
    archive(DEST / name, name)
archive(Path(__file__), Path(__file__).name)
record = dict(captured_utc=dt.datetime.now(dt.timezone.utc).isoformat(), all_functionality_verified=False,
    previous_goal_turn_classification='progress: terminal F1 full success and missing original H10 identities changed the next action',
    app_sha256=freeze['app_sha256'], native_elf_sha256=freeze['elf_sha256'], qemu_sha256=freeze['qemu_sha256'],
    full=dict(runtime_suite_passed=True, passed_groups=19, inputs_verified=566, terminal=terminal,
              publication_passed=False, publication_error='Old photo schema expects22checks while actual header-aware report contains24. Fixed in56010f00; no F1 publication success is claimed.'),
    runtime=dict(status='stopped_without_terminal_footer', periodic_report_cycles=runtime['completed_cycles'],
                 complete_journal_cycles=640, pending_events=4, elapsed_guest_seconds=analysis['elapsed_guest_seconds_observed'],
                 h10_checks_passed=False, final_guard_missing=True, interruption_cause='unknown',
                 scope='Prefix only; no24h, memory-trend or firmware-failure verdict. Stale running state retained verbatim.'),
    evidence=artifacts,
    scope='Historical F1/D64 only. Full run success, publication failure and stopped H10 are independent. No latest B50D, physical board or CYD acceptance.')
(DEST / 'f1-terminal-and-interrupted-20261019.json').write_text(json.dumps(record, indent=2) + '\n', newline='\n')
print(json.dumps(dict(full_groups=19, inputs=566, complete_cycles=640, raw_files=len(artifacts))))
