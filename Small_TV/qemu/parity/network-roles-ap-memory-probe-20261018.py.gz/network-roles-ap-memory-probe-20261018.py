"""Measure AP heap/tasks during matched real setup HTTP and scan phases."""
import argparse
import hashlib
import json
from pathlib import Path
import socket
import sys
import time
from types import SimpleNamespace

ROOT = Path('C:/Work/yoRadio')
TESTS = ROOT / '.worktree/small-tv-netif-observer/Small_TV/src/tests'
QEMU = Path('C:/Work/QEMU-ESP32/.worktree/small-tv-apsta')
sys.path[:0] = [str(TESTS), str(QEMU / 'tools'), str(ROOT / '.build/small-tv-parity/oracle-deps')]
import small_tv_vm as vm
from small_tv_http_test import http, wait_http, clean_uart
from weather_qemu import read_bytes
from qemu_storage import direct_flash_backing
from gdb_observer import Observer
from runtime_memory import MemorySnapshot, native_layout
from runtime_heap_rom import RomHeapCounters


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--yoradio', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    archive = args.yoradio / 'firmware/development/small-tv-esp32c2-reconstructed'
    elf = args.yoradio / '.build/small-tv-esp32c2/small_tv_reconstructed.elf'
    rom = ROOT / '.idf/tools-v6.1/tools/esp-rom-elfs/20260528/esp32c2_rev200_rom.elf'
    layout = native_layout(elf)
    if (archive / 'app.bin').read_bytes()[176:208] != bytes.fromhex(layout['elf_sha256']):
        raise ValueError('ELF/application mismatch')
    with socket.socket() as reservation:
        reservation.bind(('127.0.0.1', 0))
        port = reservation.getsockname()[1]
    options = SimpleNamespace(yoradio=str(args.yoradio), qemu=str(QEMU / 'bin/qemu-system-riscv32.exe'),
        rom_elf=str(rom), hardware_profile=str(args.yoradio / 'Small_TV/qemu/profiles/small-tv-c2.json'),
        network='setup', firmware='reconstructed', display='none', persistent=True, paused=True, gdb_port=port)
    files = [Path(__file__), elf, rom, Path(options.qemu), Path(options.hardware_profile)]
    files += [TESTS / name for name in ('gdb_observer.py', 'runtime_memory.py', 'runtime_heap_rom.py',
                                       'weather_qemu.py', 'qemu_storage.py')]
    files += [QEMU / 'tools' / name for name in ('small_tv_vm.py', 'small_tv_http_test.py', 'small_tv_network.py',
                                               'small_tv_web.py', 'esp_elf.py', 'esp_board.py', 'esp_services.py')]
    files += [archive / name for name in ('app.bin', 'bootloader.bin', 'partition-table.bin', 'assets.bin',
                                         'manifest.json', 'assets-manifest.json', 'source-manifest.json')]
    pins = {str(path): sha(path) for path in files}
    args.output.mkdir(parents=True, exist_ok=False)
    folder = args.output / 'vm'
    result = {'passed': False, 'scope': __doc__, 'inputs_sha256': pins,
              'app_sha256': sha(archive / 'app.bin'), 'native_elf_sha256': layout['elf_sha256'],
              'qemu_sha256': sha(Path(options.qemu)), 'snapshots': [], 'http': []}
    session = observer = None
    counters = RomHeapCounters(rom)
    try:
        session, prepared = vm.launch(options, folder)
        result['sources'] = prepared['sources']
        result['session'] = {'name': session['name'], 'pid': session['pid']}
        observer = Observer(port)
        observer.socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        observer.socket.settimeout(20)
        memory = MemorySnapshot(observer.memory, layout, counters.validate)
        with vm.QMP(session['qmp_port'], session['name']) as qmp:
            if not direct_flash_backing(qmp, folder):
                raise ValueError('VM flash is not direct writable raw')
            before = (folder / 'flash.bin').read_bytes()
            protected = [(a, b, hashlib.sha256(before[a:b]).hexdigest())
                         for a, b in ((0, 0x9000), (0x10000, 0x3e7000))]

            def seconds():
                return int.from_bytes(read_bytes(qmp, 0x6004d000, 4), 'little') / 1e6

            def capture(label):
                observer.interrupt()
                try:
                    address = layout['symbols']['vTaskDelay']['address']
                    if observer.register(32) != address:
                        observer.breakpoint(address)
                        observer.continue_to(address)
                        observer.breakpoint(address, False)
                    row = {'label': label, 'guest_seconds': seconds(),
                           'heap': memory.heaps(), 'tasks': memory.tasks()}
                    if row['heap']['free_bytes'] <= 0 or any(
                            task['stack_high_water_free_bytes'] <= 0 for task in row['tasks']):
                        raise ValueError('No observed runtime headroom')
                    result['snapshots'].append(row)
                finally:
                    observer.resume()

            observer.resume()
            url = session['web_urls']['setup']
            wait_http(url, expected=b'/configure')
            deadline = time.monotonic() + 90
            while seconds() < 30:
                if time.monotonic() > deadline:
                    raise TimeoutError('AP startup did not advance guest time')
                time.sleep(.2)
            capture('ready')
            for cycle in range(4):
                status, body = http(url, '/scan', timeout=30)
                if status != 200 or not any(row['ssid'] == 'yoRadio-QEMU' for row in json.loads(body)):
                    raise ValueError('Real AP scan failed')
                result['http'].append({'path': '/scan', 'status': status})
                capture('scan-' + str(cycle))
                status, body = http(url)
                if status != 200 or b'/configure' not in body:
                    raise ValueError('Real setup HTTP failed')
                result['http'].append({'path': '/', 'status': status})
                capture('http-' + str(cycle))
            result['passed'] = True
    except Exception as error:
        result['error'] = str(error)
        raise
    finally:
        if observer:
            observer.close()
        if session:
            vm.control(folder, 'stop')
            vm.ensure_stopped(folder)
            data = (folder / 'flash.bin').read_bytes()
            result['code_media_unchanged'] = all(hashlib.sha256(data[a:b]).hexdigest() == expected
                                                 for a, b, expected in protected)
            result['uart_clean'] = clean_uart(folder)
        result['rom_counter_checks'] = counters.checks
        result['inputs_unchanged'] = all(sha(Path(path)) == expected for path, expected in pins.items())
        result['passed'] &= all(result.get(key) is True for key in
                                ('inputs_unchanged', 'code_media_unchanged', 'uart_clean'))
        vm.save_json(args.output / 'report.json', result)
    print(json.dumps({'passed': result['passed'], 'snapshots': len(result['snapshots']),
                      'free': [row['heap']['free_bytes'] for row in result['snapshots']]}), flush=True)
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
