"""Archive display and network evidence separately, with shared OS cleanup proof."""
from pathlib import Path
from types import SimpleNamespace
import datetime as dt
import gzip
import hashlib
import json
import subprocess
import sys

BASE=Path('C:/Work/yoRadio')
ROOT=BASE/'.worktree/small-tv-browser-controls-verify'
SNAP=BASE/'.worktree/small-tv-jpeg-headers/.build/jpeg-header-qemu-complete-20261018'
PARITY=ROOT/'Small_TV/qemu/parity'
COLD=ROOT/'.build/display-cold-20-20261018'
PRE=ROOT/'.build/display-cold-preflight-20261018'
NET=ROOT/'.build/network-without-display-20261018'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
git=lambda *a:subprocess.check_output(['git','-C',str(ROOT),*a],text=True).strip()
sys.path.insert(0,str(SNAP/'tools'))
import small_tv_vm as vm
from small_tv_display import ppm_pixels
cleanup=read(PARITY/'independent-gates-owned-vms-20261018.json')
assert len(cleanup['vm_identities'])==44
assert all(row['state']!='owned_still_alive' for row in cleanup['vm_identities'])
cold,pre,net=map(read,(COLD/'report.json',PRE/'report.json',NET/'report.json'))
for report in (cold,pre,net):
    assert report['passed'] and report['inputs_unchanged'] and not report.get('error')
    for path,value in report['inputs_sha256'].items():assert sha(Path(path).read_bytes())==value,path
assert cold['inputs_sha256']==pre['inputs_sha256']
assert len(cold['inputs_sha256'])==62 and len(net['inputs_sha256'])==59
assert cold['app_sha256']==net['app_sha256']=='f1ada8b4da4338df3248ffb26a39a79e36bf5cf0e365eb2972b75c8721f7ea7b'
assert cold['native_elf_sha256']==net['native_elf_sha256']
assert cold['qemu_sha256']==net['qemu_sha256']=='d64f3013739f22b986e07aed39395b25bde474f52ef813b8ffaeedb0991edecc'
assert cold['requested_cycles_per_variant']==20 and len(cold['cycles'])==40
assert not cold['network']['executed'] and cold['network']['passed'] is None
names=[]
for row in cold['cycles']:
    assert row['passed'] and all(row[key]['passed'] for key in ('boot','display','source_integrity'))
    assert row['boot']['rom_boots']==1 and not row['network']['executed']
    assert row['display']['differing_rgb_bytes']==0 and row['display']['rgb_sha256']==cold['expected_rgb_sha256']
    assert row['display']['host_seconds']<90 and row['display']['guest_seconds']<10
    names.append(row['session']['name'])
    for key in ('uart','frame'):assert sha((COLD/row[key]['file']).read_bytes())==row[key]['sha256']
    ppm=gzip.decompress((COLD/row['frame']['file']).read_bytes())
    assert sha(ppm)==row['display']['file_sha256']
    assert len(ppm.split(b'\n',3)[3])==240*240*3
assert len(set(names))==40
unit=read(BASE/'.build/display-boot-unit-final-20261018.json')
assert unit['passed'] and unit['tests']==12 and not unit['failures'] and not unit['errors']
assert unit['observer_source_sha256']==sha((ROOT/'Small_TV/src/tests/display_boot_observer.py').read_bytes())
assert unit['test_source_sha256']==sha((ROOT/'Small_TV/src/tests/display_boot_observer_test.py').read_bytes())
source_profile=read(ROOT/'Small_TV/qemu/profiles/small-tv-c2.json')
actual_profile=read(NET/'network-only-profile.json')
expected_profile=dict(source_profile,name='small-tv-network-without-lcd',devices=[])
assert actual_profile==expected_profile
assert not net['display']['executed'] and net['display']['passed'] is None
assert not any(path.suffix in ('.png','.ppm') for path in NET.rglob('*'))
for variant,row in net['flows'].items():
    assert row['passed'] and row['lcd_absent_qom'] and row['boot']['passed']
    assert row['boot']['rom_boots']==2 and row['source_integrity']['passed']
    assert 'screendump' not in row['qmp_commands']
    assert set(row['phases'])=={'boot','reset'}
    counts=[]
    for phase in ('boot','reset'):
        item=row['phases'][phase];assert item['passed'] and item['http_status']==200
        sample=item['network']['ntp'];assert abs(sample['difference_seconds'])<1
        counts.append(sample['response_count'])
    assert counts==[1,2]
    if variant=='reconstructed':
        state=row['phases']['reset']['network']['state']
        assert state==dict(connected=True,ap_active=False,station_address='10.0.2.15',time_synced=True)

def archive(raw,source,label,already_gzip=False):
    """Keep exact payload hashes without double-compressing UART/frame artifacts."""
    data=source.read_bytes();payload=gzip.decompress(data) if already_gzip else data
    target=raw/(label+'.gz');assert not target.exists();target.write_bytes(gzip.compress(payload,mtime=0))
    return dict(file=target.relative_to(PARITY).as_posix(),original_file_sha256=sha(data),
        payload_sha256=sha(payload),stored_sha256=sha(target.read_bytes()),original_was_gzip=already_gzip)

def sources(names):
    """Bind tested working bytes to committed canonical source, retaining both hashes."""
    result={}
    for name in names:
        path='Small_TV/src/tests/'+name;data=(ROOT/path).read_bytes()
        canonical=subprocess.check_output(['git','-C',str(ROOT),'show','HEAD:'+path])
        assert data.replace(b'\r\n',b'\n')==canonical
        result[path]=dict(worktree_sha256=sha(data),git_lf_sha256=sha(canonical))
    return result

craw=PARITY/'display-cold-20-validation-20261018-raw';craw.mkdir(exist_ok=False)
nraw=PARITY/'network-without-display-validation-20261018-raw';nraw.mkdir(exist_ok=False)
cevidence=[archive(craw,COLD/'report.json','report.json'),archive(craw,PRE/'report.json','preflight-report.json'),
    archive(craw,BASE/'.build/display-boot-unit-final-20261018.json','unit-report.json')]
for row in cold['cycles']:
    for kind in ('uart','frame'):
        source=COLD/row[kind]['file']
        cevidence.append(archive(craw,source,row[kind]['file'].replace('/','__')[:-3],True))
cevidence.append(archive(craw,PARITY/'independent-gates-owned-vms-20261018.json','owned-os-identities.json'))
origin=BASE/'.build/small-tv-functional/jpeg-header-complete-full-20261018/qemu/ap_services-observer/report.json'
cevidence.append(archive(craw,origin,'original-reference-origin-report.json'))
cevidence.append(archive(craw,Path(__file__),'save_independent_display_network_gates.py'))
integrity={}
for variant in ('original','reconstructed'):
    fresh=BASE/f'.build/display-cold-independent-{variant}-20261018'
    assert not fresh.exists()
    args=SimpleNamespace(yoradio=str(ROOT),firmware=variant,network='setup',persistent=True,
        rom_elf=str(BASE/'.idf/tools-v6.1/tools/esp-rom-elfs/20260528/esp32c2_rev200_rom.elf'),
        hardware_profile=str(ROOT/'Small_TV/qemu/profiles/small-tv-c2.json'))
    vm.prepare(args,fresh)
    before=(fresh/'flash.bin').read_bytes();after=(COLD/variant/'flash.bin').read_bytes()
    regions=[]
    for low,high in ((0,0x9000),(0xf000,0x3e7000),(0x3e8000,0x400000)):
        assert before[low:high]==after[low:high]
        regions.append(dict(start=low,end=high,sha256=sha(after[low:high])))
    integrity[variant]=regions
record=dict(status='forty_exact_cold_lcd_cycles_passed',passed=True,all_functionality_verified=False,
    captured_utc=dt.datetime.now(dt.timezone.utc).isoformat(),test_commit=git('rev-parse','HEAD'),
    app_sha256=cold['app_sha256'],native_elf_sha256=cold['native_elf_sha256'],qemu_sha256=cold['qemu_sha256'],
    cycles_per_variant=20,total_vm_processes=40,rom_boots_per_process=1,unit_controls=12,
    expected_rgb_sha256=cold['expected_rgb_sha256'],input_count=62,network_executed=False,
    sources=sources(['display_cold_boot_qemu.py','display_boot_observer.py','display_boot_observer_test.py']),
    independent_final_flash_comparison=integrity,os_cleanup=cleanup,evidence=cevidence,
    timings={v:dict(max_host_seconds=max(r['display']['host_seconds'] for r in cold['cycles'] if r['variant']==v),
        max_guest_seconds=max(r['display']['guest_seconds'] for r in cold['cycles'] if r['variant']==v)) for v in ('original','reconstructed')},
    scope='40 actual cold VM processes and exact full factory setup pixels, with independent boot/source checks. No HTTP/network readiness, physical power interruption, all-theme pixels, GPIO/PWM or H10 acceptance.')
(PARITY/'display-cold-20-validation-20261018.json').write_text(json.dumps(record,indent=2)+'\n',newline='\n')
nevidence=[]
for source in sorted(NET.rglob('*')):
    if source.is_file() and source.suffix in ('.json','.log'):
        nevidence.append(archive(nraw,source,source.relative_to(NET).as_posix().replace('/','__')))
nevidence.append(archive(nraw,PARITY/'independent-gates-owned-vms-20261018.json','owned-os-identities.json'))
nevidence.append(archive(nraw,Path(__file__),'save_independent_display_network_gates.py'))
nrecord=dict(status='http_sntp_without_lcd_passed',passed=True,all_functionality_verified=False,
    captured_utc=dt.datetime.now(dt.timezone.utc).isoformat(),test_commit=git('rev-parse','HEAD'),
    app_sha256=net['app_sha256'],native_elf_sha256=net['native_elf_sha256'],qemu_sha256=net['qemu_sha256'],
    input_count=59,lcd_device_present=False,display_capture_commands=0,display_executed=False,
    recorded_control_http_200=4,ntp_counts={v:[1,2] for v in ('original','reconstructed')},
    max_sdk_wire_difference_seconds=max(abs(p['network']['ntp']['difference_seconds']) for row in net['flows'].values() for p in row['phases'].values()),
    source=sources(['network_without_display_qemu.py']),os_cleanup=cleanup,evidence=nevidence,
    scope='Actual factory/native HTTP and fresh processed UDP SNTP at cold boot and system_reset, with no LCD device. Native SDK STA/DHCP/SNTP observed through matching ELF; factory exact SDK UTC and real TCP/UDP only. No physical RF/WPA, Internet, persistence, LCD/PWM, full/H10 acceptance.')
(PARITY/'network-without-display-validation-20261018.json').write_text(json.dumps(nrecord,indent=2)+'\n',newline='\n')
print(json.dumps(dict(cold_cycles=40,cold_raw=len(cevidence),network_phases=4,network_raw=len(nevidence),owned_vm_identities_closed=44)))
