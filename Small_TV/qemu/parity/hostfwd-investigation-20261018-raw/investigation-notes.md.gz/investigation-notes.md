# Windows host forwarding and parallel browser requests

## Observed failure

A real Chrome page served by the Small TV guest starts six settings requests in
parallel. Some cold loads fail with `net::ERR_CONNECTION_REFUSED` before the
request reaches the guest. The UI then retains a default value: date format 0
instead of stored 2, or red/yellow/white instead of stored green/blue/yellow.
Successful requests and a clean UART alone do not establish correct page load.

The guest has six HTTP client sockets. A separate diagnostic also reproduces the
failure without an extra API probe. Guest packet capture has no corresponding
new-connection reset from the guest. These observations motivate checking the
host listener; they do not by themselves prove the cause.

## Dependency and candidate correction

Static Windows builds use pinned libslirp 4.9.3 commit
`dd76415fce457e319d665eb8210d05c5731360ba` through
`subprojects/slirp-win32.wrap`. The upstream `tcpx_listen()` initially requests
`listen(s, 1)`. The candidate patch requests `SOMAXCONN` on Windows, at the first
listen call. Other platforms retain the existing dependency and backlog.

Microsoft documents both queue-full `WSAECONNREFUSED` and the fact that another
listen call on a listening socket does not change its backlog:
[Winsock listen](https://learn.microsoft.com/en-us/windows/win32/api/winsock2/nf-winsock2-listen).

`FIXED_EMULATION` marks this correction in the maintained dependency diff. It
means a deliberate emulator correction, not an attempt to reproduce an error
in the application firmware. Keep the explanation and source/specification
reference with the correction when updating the dependency.

The second dependency diff changes libslirp's static compiler argument from
`add_global_arguments` to `add_project_arguments`, allowing Meson to build it as
a subproject. Both the unpatched-listener control and candidate use that same
build adjustment. Do not compare different system libslirp versions to attribute
a result solely to the listener change.

## Browser regression

`tools/small_tv_browser_connection_test.py` launches its own disposable station
VM using an existing yoRadio Small TV build and the selected QEMU executable.
The Node worker uses real Chrome and the guest's actual HTML/JavaScript. Each
round loads a new browser context with an extra keep-alive probe, without a
probe, and with a Connection: close probe. Only that VM's loopback origin is
allowed. It verifies six groups of controls against actual stored API values,
all six successful GETs, and absence of browser errors.

The test records exact input hashes, raw browser events, Ethernet capture and
read-only socket snapshots decoded through the exact firmware ELF's DWARF.
The VM is stopped in cleanup; protected flash ranges, UART and one-ROM-boot are
checked. It neither patches guest code/RAM nor changes production firmware.

Example (supply local executable/module paths):

```text
python tools/small_tv_browser_connection_test.py --yoradio <yoRadio-worktree> --dependency-root <yoRadio-root> --qemu-root . --qemu <qemu-executable> --node <node> --playwright-modules <node_modules> --browser-executable <chrome> --rounds 20 --output <new-result-directory>
```

Run the identical harness and firmware with an unpatched-listener control built
using the same compiler, then the candidate. Retain failed control reports. A
successful narrow browser test does not replace the full Wi-Fi setup/cold-boot,
packet, existing-board or firmware regressions.

## Validation status

Investigation in progress. The previous installed QEMU reproduces one failed
load out of 18 in the new harness, with incorrect color controls and all input
hashes unchanged. Same-toolchain control/candidate comparison and network
regressions remain required. No claim of a verified repair is made here yet.


## Actual before/after checkpoint

The same-toolchain original listener failed 6 of 60 real page loads with
CONNECTION_REFUSED. The backlog candidate eliminated that error in this run,
but failed two loads with timeouts; it is **not accepted as a complete repair**.
A bounded poll diagnostic reproduced another timeout with only 9 poll sockets
against FD_SETSIZE 64 and no select error. An observer extension captured a
fourth timeout, including a proxy SYN_SENT entry. All failed reports are kept.

The exact 0592 image passed all three complete Wi-Fi setup/cold-start flows
(93 UI and 18 storage/role checks, 25 exact inputs) on candidate 2a3f. The packet
suite (12), shared NOR write groups (11 on three SoCs), module checks and both
C3 OLED boot profiles also pass. Full CYD compatibility remains unaccepted:
a 60 wall-second control showed no panic, while the candidate showed a cache
panic. The earlier PHY/cache baseline issues are not resolved by these results.

Fresh Meson fetched the pinned dependency, applied both wrap diffs and built it.
Its LF source matches the manual CRLF socket checkout after newline normalization.

## Separate TIME_WAIT collision

A captured host port 62291 was reused with a new initial sequence number.
The guest initially ACKed the old sequence; the proxy stayed SYN_SENT. The new
SYN finally received SYNACK after 41.671 **guest** seconds. Kernel TCP snapshots
show the host side already established during the failed request. The lwIP
`tcp_timewait_input` code ACKs out-of-window SYN and ignores RST in TIME_WAIT;
this is permitted TCP behavior, not grounds to shorten the firmware's timer.
See RFC 9293 section 3.6.1 and the tests' README.

A deterministic peer-port test now forces the actual guest LRU close, then
reuses the host source port. The backlog-only candidate times out in 3 seconds
with clean UART, one ROM boot, and unchanged inputs/protected flash. The first
prototype accidentally regenerated its setup image because persistent mode was
false; its startup failure is retained and excluded from the port-reuse claim.

The remaining correction must avoid reusing a guest-facing TCP tuple while it
can still be retained by the guest. The host and guest TCP port lifetimes must
be considered separately, using virtual time for guest-facing reservations.
Do not mask the collision with a delay, a longer browser timeout or a firmware
TIME_WAIT change. Port exhaustion, AP/STA isolation and migration behavior need
explicit treatment before accepting a generic proxy change.
