
build-esp32c2/subprojects/slirp-win32/libslirp.a.p/src_socket.c.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <sockaddr_size.part.0>:
       0:	48 83 ec 38          	sub    $0x38,%rsp
       4:	4c 8d 0d d8 04 00 00 	lea    0x4d8(%rip),%r9        # 4e3 <sopreprbuf+0xb3>
			7: IMAGE_REL_AMD64_REL32	.rdata
       b:	41 b8 a8 00 00 00    	mov    $0xa8,%r8d
      11:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 18 <sockaddr_size.part.0+0x18>
			14: IMAGE_REL_AMD64_REL32	.rdata
      18:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 47 <sockaddr_equal.part.0+0x17>
			1b: IMAGE_REL_AMD64_REL32	.rdata
      1f:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
      26:	00 00 
      28:	e8 00 00 00 00       	call   2d <sockaddr_size.part.0+0x2d>
			29: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
      2d:	90                   	nop
      2e:	66 90                	xchg   %ax,%ax

0000000000000030 <sockaddr_equal.part.0>:
      30:	48 83 ec 38          	sub    $0x38,%rsp
      34:	4c 8d 0d f8 04 00 00 	lea    0x4f8(%rip),%r9        # 533 <sopreprbuf+0x103>
			37: IMAGE_REL_AMD64_REL32	.rdata
      3b:	41 b8 95 00 00 00    	mov    $0x95,%r8d
      41:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 48 <sockaddr_equal.part.0+0x18>
			44: IMAGE_REL_AMD64_REL32	.rdata
      48:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 77 <solookup+0x17>
			4b: IMAGE_REL_AMD64_REL32	.rdata
      4f:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
      56:	00 00 
      58:	e8 00 00 00 00       	call   5d <sockaddr_equal.part.0+0x2d>
			59: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
      5d:	90                   	nop
      5e:	66 90                	xchg   %ax,%ax

0000000000000060 <solookup>:
      60:	53                   	push   %rbx
      61:	48 83 ec 20          	sub    $0x20,%rsp
      65:	48 8b 01             	mov    (%rcx),%rax
      68:	48 89 cb             	mov    %rcx,%rbx
      6b:	49 89 d2             	mov    %rdx,%r10
      6e:	48 39 d0             	cmp    %rdx,%rax
      71:	74 11                	je     84 <solookup+0x24>
      73:	0f b7 90 d0 00 00 00 	movzwl 0xd0(%rax),%edx
      7a:	66 41 3b 10          	cmp    (%r8),%dx
      7e:	0f 84 1c 01 00 00    	je     1a0 <solookup+0x140>
      84:	49 8b 02             	mov    (%r10),%rax
      87:	49 39 c2             	cmp    %rax,%r10
      8a:	0f 84 f5 00 00 00    	je     185 <solookup+0x125>
      90:	41 0f b7 10          	movzwl (%r8),%edx
      94:	eb 56                	jmp    ec <solookup+0x8c>
      96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
      9d:	00 00 00 
      a0:	66 83 fa 17          	cmp    $0x17,%dx
      a4:	0f 85 a9 01 00 00    	jne    253 <solookup+0x1f3>
      aa:	48 8b 88 d8 00 00 00 	mov    0xd8(%rax),%rcx
      b1:	4c 8b 98 e0 00 00 00 	mov    0xe0(%rax),%r11
      b8:	49 33 48 08          	xor    0x8(%r8),%rcx
      bc:	4d 33 58 10          	xor    0x10(%r8),%r11
      c0:	4c 09 d9             	or     %r11,%rcx
      c3:	74 42                	je     107 <solookup+0xa7>
      c5:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
      ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
      d1:	00 00 00 00 
      d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
      dc:	00 00 00 00 
      e0:	48 8b 00             	mov    (%rax),%rax
      e3:	49 39 c2             	cmp    %rax,%r10
      e6:	0f 84 99 00 00 00    	je     185 <solookup+0x125>
      ec:	66 39 90 d0 00 00 00 	cmp    %dx,0xd0(%rax)
      f3:	75 eb                	jne    e0 <solookup+0x80>
      f5:	66 83 fa 02          	cmp    $0x2,%dx
      f9:	75 a5                	jne    a0 <solookup+0x40>
      fb:	41 8b 48 04          	mov    0x4(%r8),%ecx
      ff:	39 88 d4 00 00 00    	cmp    %ecx,0xd4(%rax)
     105:	75 d9                	jne    e0 <solookup+0x80>
     107:	41 0f b7 48 02       	movzwl 0x2(%r8),%ecx
     10c:	66 39 88 d2 00 00 00 	cmp    %cx,0xd2(%rax)
     113:	75 cb                	jne    e0 <solookup+0x80>
     115:	4d 85 c9             	test   %r9,%r9
     118:	74 3a                	je     154 <solookup+0xf4>
     11a:	0f b7 48 50          	movzwl 0x50(%rax),%ecx
     11e:	66 41 3b 09          	cmp    (%r9),%cx
     122:	75 bc                	jne    e0 <solookup+0x80>
     124:	66 83 f9 02          	cmp    $0x2,%cx
     128:	74 46                	je     170 <solookup+0x110>
     12a:	66 83 f9 17          	cmp    $0x17,%cx
     12e:	0f 85 1f 01 00 00    	jne    253 <solookup+0x1f3>
     134:	48 8b 48 58          	mov    0x58(%rax),%rcx
     138:	4c 8b 58 60          	mov    0x60(%rax),%r11
     13c:	49 33 49 08          	xor    0x8(%r9),%rcx
     140:	4d 33 59 10          	xor    0x10(%r9),%r11
     144:	4c 09 d9             	or     %r11,%rcx
     147:	75 97                	jne    e0 <solookup+0x80>
     149:	41 0f b7 49 02       	movzwl 0x2(%r9),%ecx
     14e:	66 39 48 52          	cmp    %cx,0x52(%rax)
     152:	75 8c                	jne    e0 <solookup+0x80>
     154:	48 89 03             	mov    %rax,(%rbx)
     157:	48 83 c4 20          	add    $0x20,%rsp
     15b:	5b                   	pop    %rbx
     15c:	31 d2                	xor    %edx,%edx
     15e:	31 c9                	xor    %ecx,%ecx
     160:	45 31 c0             	xor    %r8d,%r8d
     163:	45 31 c9             	xor    %r9d,%r9d
     166:	45 31 d2             	xor    %r10d,%r10d
     169:	45 31 db             	xor    %r11d,%r11d
     16c:	c3                   	ret
     16d:	0f 1f 00             	nopl   (%rax)
     170:	41 8b 49 04          	mov    0x4(%r9),%ecx
     174:	39 48 54             	cmp    %ecx,0x54(%rax)
     177:	74 d0                	je     149 <solookup+0xe9>
     179:	48 8b 00             	mov    (%rax),%rax
     17c:	49 39 c2             	cmp    %rax,%r10
     17f:	0f 85 67 ff ff ff    	jne    ec <solookup+0x8c>
     185:	31 c0                	xor    %eax,%eax
     187:	48 83 c4 20          	add    $0x20,%rsp
     18b:	5b                   	pop    %rbx
     18c:	31 d2                	xor    %edx,%edx
     18e:	31 c9                	xor    %ecx,%ecx
     190:	45 31 c0             	xor    %r8d,%r8d
     193:	45 31 c9             	xor    %r9d,%r9d
     196:	45 31 d2             	xor    %r10d,%r10d
     199:	45 31 db             	xor    %r11d,%r11d
     19c:	c3                   	ret
     19d:	0f 1f 00             	nopl   (%rax)
     1a0:	66 83 fa 02          	cmp    $0x2,%dx
     1a4:	74 7a                	je     220 <solookup+0x1c0>
     1a6:	66 83 fa 17          	cmp    $0x17,%dx
     1aa:	0f 85 a3 00 00 00    	jne    253 <solookup+0x1f3>
     1b0:	48 8b 90 d8 00 00 00 	mov    0xd8(%rax),%rdx
     1b7:	48 8b 88 e0 00 00 00 	mov    0xe0(%rax),%rcx
     1be:	49 33 50 08          	xor    0x8(%r8),%rdx
     1c2:	49 33 48 10          	xor    0x10(%r8),%rcx
     1c6:	48 09 ca             	or     %rcx,%rdx
     1c9:	0f 85 b5 fe ff ff    	jne    84 <solookup+0x24>
     1cf:	41 0f b7 50 02       	movzwl 0x2(%r8),%edx
     1d4:	66 39 90 d2 00 00 00 	cmp    %dx,0xd2(%rax)
     1db:	0f 85 a3 fe ff ff    	jne    84 <solookup+0x24>
     1e1:	4d 85 c9             	test   %r9,%r9
     1e4:	0f 84 6d ff ff ff    	je     157 <solookup+0xf7>
     1ea:	0f b7 50 50          	movzwl 0x50(%rax),%edx
     1ee:	66 41 3b 11          	cmp    (%r9),%dx
     1f2:	0f 85 8c fe ff ff    	jne    84 <solookup+0x24>
     1f8:	66 83 fa 02          	cmp    $0x2,%dx
     1fc:	74 34                	je     232 <solookup+0x1d2>
     1fe:	66 83 fa 17          	cmp    $0x17,%dx
     202:	75 4f                	jne    253 <solookup+0x1f3>
     204:	48 8b 50 58          	mov    0x58(%rax),%rdx
     208:	48 8b 48 60          	mov    0x60(%rax),%rcx
     20c:	49 33 51 08          	xor    0x8(%r9),%rdx
     210:	49 33 49 10          	xor    0x10(%r9),%rcx
     214:	48 09 ca             	or     %rcx,%rdx
     217:	0f 85 67 fe ff ff    	jne    84 <solookup+0x24>
     21d:	eb 20                	jmp    23f <solookup+0x1df>
     21f:	90                   	nop
     220:	41 8b 50 04          	mov    0x4(%r8),%edx
     224:	39 90 d4 00 00 00    	cmp    %edx,0xd4(%rax)
     22a:	0f 85 54 fe ff ff    	jne    84 <solookup+0x24>
     230:	eb 9d                	jmp    1cf <solookup+0x16f>
     232:	41 8b 51 04          	mov    0x4(%r9),%edx
     236:	39 50 54             	cmp    %edx,0x54(%rax)
     239:	0f 85 45 fe ff ff    	jne    84 <solookup+0x24>
     23f:	41 0f b7 51 02       	movzwl 0x2(%r9),%edx
     244:	66 39 50 52          	cmp    %dx,0x52(%rax)
     248:	0f 85 36 fe ff ff    	jne    84 <solookup+0x24>
     24e:	e9 04 ff ff ff       	jmp    157 <solookup+0xf7>
     253:	e8 d8 fd ff ff       	call   30 <sockaddr_equal.part.0>
     258:	90                   	nop
     259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000000260 <socreate>:
     260:	56                   	push   %rsi
     261:	53                   	push   %rbx
     262:	48 83 ec 28          	sub    $0x28,%rsp
     266:	48 89 cb             	mov    %rcx,%rbx
     269:	b9 b0 01 00 00       	mov    $0x1b0,%ecx
     26e:	89 d6                	mov    %edx,%esi
     270:	e8 00 00 00 00       	call   275 <socreate+0x15>
			271: IMAGE_REL_AMD64_REL32	g_malloc
     275:	41 b8 b0 01 00 00    	mov    $0x1b0,%r8d
     27b:	31 d2                	xor    %edx,%edx
     27d:	48 89 c1             	mov    %rax,%rcx
     280:	e8 00 00 00 00       	call   285 <socreate+0x25>
			281: IMAGE_REL_AMD64_REL32	memset
     285:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
     289:	40 88 b0 52 01 00 00 	mov    %sil,0x152(%rax)
     290:	c7 80 54 01 00 00 01 	movl   $0x1,0x154(%rax)
     297:	00 00 00 
     29a:	48 89 58 30          	mov    %rbx,0x30(%rax)
     29e:	c7 40 28 ff ff ff ff 	movl   $0xffffffff,0x28(%rax)
     2a5:	0f 11 40 10          	movups %xmm0,0x10(%rax)
     2a9:	48 83 c4 28          	add    $0x28,%rsp
     2ad:	5b                   	pop    %rbx
     2ae:	5e                   	pop    %rsi
     2af:	31 d2                	xor    %edx,%edx
     2b1:	31 c9                	xor    %ecx,%ecx
     2b3:	45 31 c0             	xor    %r8d,%r8d
     2b6:	45 31 c9             	xor    %r9d,%r9d
     2b9:	c3                   	ret
     2ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000002c0 <sofree>:
     2c0:	53                   	push   %rbx
     2c1:	48 83 ec 30          	sub    $0x30,%rsp
     2c5:	4c 8b 41 30          	mov    0x30(%rcx),%r8
     2c9:	48 89 cb             	mov    %rcx,%rbx
     2cc:	48 8b 49 18          	mov    0x18(%rcx),%rcx
     2d0:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
     2d4:	74 0f                	je     2e5 <sofree+0x25>
     2d6:	4c 89 44 24 28       	mov    %r8,0x28(%rsp)
     2db:	e8 00 00 00 00       	call   2e0 <sofree+0x20>
			2dc: IMAGE_REL_AMD64_REL32	slirp_closesocket_wrap
     2e0:	4c 8b 44 24 28       	mov    0x28(%rsp),%r8
     2e5:	49 8b 80 d0 00 00 00 	mov    0xd0(%r8),%rax
     2ec:	49 8d 88 d0 00 00 00 	lea    0xd0(%r8),%rcx
     2f3:	48 39 c1             	cmp    %rax,%rcx
     2f6:	75 10                	jne    308 <sofree+0x48>
     2f8:	eb 46                	jmp    340 <sofree+0x80>
     2fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     300:	48 8b 00             	mov    (%rax),%rax
     303:	48 39 c1             	cmp    %rax,%rcx
     306:	74 38                	je     340 <sofree+0x80>
     308:	48 3b 58 28          	cmp    0x28(%rax),%rbx
     30c:	75 f2                	jne    300 <sofree+0x40>
     30e:	48 8b 50 10          	mov    0x10(%rax),%rdx
     312:	48 c7 40 28 00 00 00 	movq   $0x0,0x28(%rax)
     319:	00 
     31a:	48 39 c2             	cmp    %rax,%rdx
     31d:	74 e1                	je     300 <sofree+0x40>
     31f:	90                   	nop
     320:	48 c7 42 28 00 00 00 	movq   $0x0,0x28(%rdx)
     327:	00 
     328:	48 8b 52 10          	mov    0x10(%rdx),%rdx
     32c:	48 39 c2             	cmp    %rax,%rdx
     32f:	75 ef                	jne    320 <sofree+0x60>
     331:	48 8b 00             	mov    (%rax),%rax
     334:	48 39 c1             	cmp    %rax,%rcx
     337:	75 cf                	jne    308 <sofree+0x48>
     339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     340:	49 8b 80 e0 00 00 00 	mov    0xe0(%r8),%rax
     347:	49 8d 88 e0 00 00 00 	lea    0xe0(%r8),%rcx
     34e:	48 39 c1             	cmp    %rax,%rcx
     351:	75 15                	jne    368 <sofree+0xa8>
     353:	eb 4b                	jmp    3a0 <sofree+0xe0>
     355:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
     35c:	00 00 00 00 
     360:	48 8b 00             	mov    (%rax),%rax
     363:	48 39 c1             	cmp    %rax,%rcx
     366:	74 38                	je     3a0 <sofree+0xe0>
     368:	48 3b 58 28          	cmp    0x28(%rax),%rbx
     36c:	75 f2                	jne    360 <sofree+0xa0>
     36e:	48 8b 50 10          	mov    0x10(%rax),%rdx
     372:	48 c7 40 28 00 00 00 	movq   $0x0,0x28(%rax)
     379:	00 
     37a:	48 39 c2             	cmp    %rax,%rdx
     37d:	74 e1                	je     360 <sofree+0xa0>
     37f:	90                   	nop
     380:	48 c7 42 28 00 00 00 	movq   $0x0,0x28(%rdx)
     387:	00 
     388:	48 8b 52 10          	mov    0x10(%rdx),%rdx
     38c:	48 39 c2             	cmp    %rax,%rdx
     38f:	75 ef                	jne    380 <sofree+0xc0>
     391:	48 8b 00             	mov    (%rax),%rax
     394:	48 39 c1             	cmp    %rax,%rcx
     397:	75 cf                	jne    368 <sofree+0xa8>
     399:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     3a0:	49 39 98 70 03 00 00 	cmp    %rbx,0x370(%r8)
     3a7:	74 67                	je     410 <sofree+0x150>
     3a9:	49 39 98 30 05 00 00 	cmp    %rbx,0x530(%r8)
     3b0:	74 4e                	je     400 <sofree+0x140>
     3b2:	49 39 98 e8 06 00 00 	cmp    %rbx,0x6e8(%r8)
     3b9:	74 65                	je     420 <sofree+0x160>
     3bb:	48 8b 4b 38          	mov    0x38(%rbx),%rcx
     3bf:	e8 00 00 00 00       	call   3c4 <sofree+0x104>
			3c0: IMAGE_REL_AMD64_REL32	m_free
     3c4:	48 83 3b 00          	cmpq   $0x0,(%rbx)
     3c8:	74 0f                	je     3d9 <sofree+0x119>
     3ca:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
     3cf:	74 08                	je     3d9 <sofree+0x119>
     3d1:	48 89 d9             	mov    %rbx,%rcx
     3d4:	e8 00 00 00 00       	call   3d9 <sofree+0x119>
			3d5: IMAGE_REL_AMD64_REL32	slirp_remque
     3d9:	48 8b 8b 58 01 00 00 	mov    0x158(%rbx),%rcx
     3e0:	48 85 c9             	test   %rcx,%rcx
     3e3:	74 05                	je     3ea <sofree+0x12a>
     3e5:	e8 00 00 00 00       	call   3ea <sofree+0x12a>
			3e6: IMAGE_REL_AMD64_REL32	g_free
     3ea:	48 89 d9             	mov    %rbx,%rcx
     3ed:	48 83 c4 30          	add    $0x30,%rsp
     3f1:	5b                   	pop    %rbx
     3f2:	e9 00 00 00 00       	jmp    3f7 <sofree+0x137>
			3f3: IMAGE_REL_AMD64_REL32	g_free
     3f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     3fe:	00 00 
     400:	49 8d 80 80 03 00 00 	lea    0x380(%r8),%rax
     407:	49 89 80 30 05 00 00 	mov    %rax,0x530(%r8)
     40e:	eb ab                	jmp    3bb <sofree+0xfb>
     410:	49 8d 80 c0 01 00 00 	lea    0x1c0(%r8),%rax
     417:	49 89 80 70 03 00 00 	mov    %rax,0x370(%r8)
     41e:	eb 9b                	jmp    3bb <sofree+0xfb>
     420:	49 8d 80 38 05 00 00 	lea    0x538(%r8),%rax
     427:	49 89 80 e8 06 00 00 	mov    %rax,0x6e8(%r8)
     42e:	eb 8b                	jmp    3bb <sofree+0xfb>

0000000000000430 <sopreprbuf>:
     430:	41 54                	push   %r12
     432:	55                   	push   %rbp
     433:	57                   	push   %rdi
     434:	56                   	push   %rsi
     435:	53                   	push   %rbx
     436:	48 83 ec 20          	sub    $0x20,%rsp
     43a:	48 8b 81 58 01 00 00 	mov    0x158(%rcx),%rax
     441:	8b b9 94 01 00 00    	mov    0x194(%rcx),%edi
     447:	2b b9 90 01 00 00    	sub    0x190(%rcx),%edi
     44d:	44 0f b7 60 20       	movzwl 0x20(%rax),%r12d
     452:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 459 <sopreprbuf+0x29>
			455: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     459:	48 89 cb             	mov    %rcx,%rbx
     45c:	48 89 d6             	mov    %rdx,%rsi
     45f:	4c 89 c5             	mov    %r8,%rbp
     462:	f6 00 01             	testb  $0x1,(%rax)
     465:	0f 85 15 01 00 00    	jne    580 <sopreprbuf+0x150>
     46b:	31 c0                	xor    %eax,%eax
     46d:	85 ff                	test   %edi,%edi
     46f:	7e 63                	jle    4d4 <sopreprbuf+0xa4>
     471:	48 8b 83 98 01 00 00 	mov    0x198(%rbx),%rax
     478:	48 c7 46 10 00 00 00 	movq   $0x0,0x10(%rsi)
     47f:	00 
     480:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
     487:	00 
     488:	48 89 06             	mov    %rax,(%rsi)
     48b:	4c 8b 83 98 01 00 00 	mov    0x198(%rbx),%r8
     492:	89 f8                	mov    %edi,%eax
     494:	48 8b 93 a0 01 00 00 	mov    0x1a0(%rbx),%rdx
     49b:	49 39 d0             	cmp    %rdx,%r8
     49e:	73 50                	jae    4f0 <sopreprbuf+0xc0>
     4a0:	4c 29 c2             	sub    %r8,%rdx
     4a3:	48 39 c2             	cmp    %rax,%rdx
     4a6:	48 0f 46 c2          	cmovbe %rdx,%rax
     4aa:	48 89 c1             	mov    %rax,%rcx
     4ad:	49 39 c4             	cmp    %rax,%r12
     4b0:	0f 82 b3 00 00 00    	jb     569 <sopreprbuf+0x139>
     4b6:	48 89 4e 08          	mov    %rcx,0x8(%rsi)
     4ba:	31 c0                	xor    %eax,%eax
     4bc:	ba 01 00 00 00       	mov    $0x1,%edx
     4c1:	48 85 ed             	test   %rbp,%rbp
     4c4:	74 03                	je     4c9 <sopreprbuf+0x99>
     4c6:	89 55 00             	mov    %edx,0x0(%rbp)
     4c9:	48 f7 d8             	neg    %rax
     4cc:	48 23 46 18          	and    0x18(%rsi),%rax
     4d0:	48 03 46 08          	add    0x8(%rsi),%rax
     4d4:	48 83 c4 20          	add    $0x20,%rsp
     4d8:	5b                   	pop    %rbx
     4d9:	5e                   	pop    %rsi
     4da:	5f                   	pop    %rdi
     4db:	5d                   	pop    %rbp
     4dc:	41 5c                	pop    %r12
     4de:	31 d2                	xor    %edx,%edx
     4e0:	31 c9                	xor    %ecx,%ecx
     4e2:	45 31 c0             	xor    %r8d,%r8d
     4e5:	45 31 c9             	xor    %r9d,%r9d
     4e8:	c3                   	ret
     4e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     4f0:	8b 8b 94 01 00 00    	mov    0x194(%rbx),%ecx
     4f6:	48 03 8b a8 01 00 00 	add    0x1a8(%rbx),%rcx
     4fd:	4c 29 c1             	sub    %r8,%rcx
     500:	48 39 c1             	cmp    %rax,%rcx
     503:	48 0f 47 c8          	cmova  %rax,%rcx
     507:	48 89 4e 08          	mov    %rcx,0x8(%rsi)
     50b:	29 cf                	sub    %ecx,%edi
     50d:	74 51                	je     560 <sopreprbuf+0x130>
     50f:	48 8b 83 a8 01 00 00 	mov    0x1a8(%rbx),%rax
     516:	48 63 ff             	movslq %edi,%rdi
     519:	48 89 46 10          	mov    %rax,0x10(%rsi)
     51d:	4c 8b 83 a0 01 00 00 	mov    0x1a0(%rbx),%r8
     524:	49 29 c0             	sub    %rax,%r8
     527:	49 39 f8             	cmp    %rdi,%r8
     52a:	4c 0f 47 c7          	cmova  %rdi,%r8
     52e:	41 8d 04 08          	lea    (%r8,%rcx,1),%eax
     532:	4c 89 46 18          	mov    %r8,0x18(%rsi)
     536:	41 39 c4             	cmp    %eax,%r12d
     539:	7d 16                	jge    551 <sopreprbuf+0x121>
     53b:	99                   	cltd
     53c:	41 f7 fc             	idiv   %r12d
     53f:	89 d0                	mov    %edx,%eax
     541:	4c 39 c0             	cmp    %r8,%rax
     544:	0f 83 86 00 00 00    	jae    5d0 <sopreprbuf+0x1a0>
     54a:	49 29 c0             	sub    %rax,%r8
     54d:	4c 89 46 18          	mov    %r8,0x18(%rsi)
     551:	b8 01 00 00 00       	mov    $0x1,%eax
     556:	ba 02 00 00 00       	mov    $0x2,%edx
     55b:	e9 61 ff ff ff       	jmp    4c1 <sopreprbuf+0x91>
     560:	49 39 cc             	cmp    %rcx,%r12
     563:	0f 83 51 ff ff ff    	jae    4ba <sopreprbuf+0x8a>
     569:	48 89 c8             	mov    %rcx,%rax
     56c:	31 d2                	xor    %edx,%edx
     56e:	49 f7 f4             	div    %r12
     571:	48 29 d1             	sub    %rdx,%rcx
     574:	e9 3d ff ff ff       	jmp    4b6 <sopreprbuf+0x86>
     579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     580:	4c 8d 05 2e 00 00 00 	lea    0x2e(%rip),%r8        # 5b5 <sopreprbuf+0x185>
			583: IMAGE_REL_AMD64_REL32	.rdata
     587:	ba 80 00 00 00       	mov    $0x80,%edx
     58c:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 5bb <sopreprbuf+0x18b>
			58f: IMAGE_REL_AMD64_REL32	.rdata
     593:	e8 00 00 00 00       	call   598 <sopreprbuf+0x168>
			594: IMAGE_REL_AMD64_REL32	g_log
     598:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 59f <sopreprbuf+0x16f>
			59b: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     59f:	f6 00 01             	testb  $0x1,(%rax)
     5a2:	0f 84 c3 fe ff ff    	je     46b <sopreprbuf+0x3b>
     5a8:	49 89 d9             	mov    %rbx,%r9
     5ab:	4c 8d 05 3c 00 00 00 	lea    0x3c(%rip),%r8        # 5ee <sopreprbuf+0x1be>
			5ae: IMAGE_REL_AMD64_REL32	.rdata
     5b2:	ba 80 00 00 00       	mov    $0x80,%edx
     5b7:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 5e6 <sopreprbuf+0x1b6>
			5ba: IMAGE_REL_AMD64_REL32	.rdata
     5be:	e8 00 00 00 00       	call   5c3 <sopreprbuf+0x193>
			5bf: IMAGE_REL_AMD64_REL32	g_log
     5c3:	e9 a3 fe ff ff       	jmp    46b <sopreprbuf+0x3b>
     5c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
     5cf:	00 
     5d0:	44 29 c2             	sub    %r8d,%edx
     5d3:	48 63 d2             	movslq %edx,%rdx
     5d6:	48 29 d1             	sub    %rdx,%rcx
     5d9:	48 89 4e 08          	mov    %rcx,0x8(%rsi)
     5dd:	e9 d8 fe ff ff       	jmp    4ba <sopreprbuf+0x8a>
     5e2:	0f 1f 00             	nopl   (%rax)
     5e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
     5ec:	00 00 00 00 

00000000000005f0 <soread>:
     5f0:	41 57                	push   %r15
     5f2:	41 56                	push   %r14
     5f4:	57                   	push   %rdi
     5f5:	56                   	push   %rsi
     5f6:	53                   	push   %rbx
     5f7:	48 81 ec f0 00 00 00 	sub    $0xf0,%rsp
     5fe:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 605 <soread+0x15>
			601: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     605:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
     60c:	00 
     60d:	48 89 cb             	mov    %rcx,%rbx
     610:	f6 00 01             	testb  $0x1,(%rax)
     613:	0f 85 1f 01 00 00    	jne    738 <soread+0x148>
     619:	48 8d 54 24 50       	lea    0x50(%rsp),%rdx
     61e:	4c 8d 44 24 40       	lea    0x40(%rsp),%r8
     623:	48 89 d9             	mov    %rbx,%rcx
     626:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
     62d:	00 00 
     62f:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
     636:	00 00 
     638:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
     63f:	00 00 
     641:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
     648:	00 00 
     64a:	e8 e1 fd ff ff       	call   430 <sopreprbuf>
     64f:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
     654:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
     659:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
     65e:	4c 8b 7c 24 68       	mov    0x68(%rsp),%r15
     663:	48 85 c0             	test   %rax,%rax
     666:	0f 84 14 01 00 00    	je     780 <soread+0x190>
     66c:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
     670:	48 89 f2             	mov    %rsi,%rdx
     673:	45 31 c9             	xor    %r9d,%r9d
     676:	49 89 f8             	mov    %rdi,%r8
     679:	e8 00 00 00 00       	call   67e <soread+0x8e>
			67a: IMAGE_REL_AMD64_REL32	slirp_recv_wrap
     67e:	48 89 c6             	mov    %rax,%rsi
     681:	41 89 c3             	mov    %eax,%r11d
     684:	85 c0                	test   %eax,%eax
     686:	0f 8e 84 00 00 00    	jle    710 <soread+0x120>
     68c:	41 89 c2             	mov    %eax,%r10d
     68f:	83 7c 24 40 02       	cmpl   $0x2,0x40(%rsp)
     694:	75 09                	jne    69f <soread+0xaf>
     696:	49 39 fa             	cmp    %rdi,%r10
     699:	0f 84 39 01 00 00    	je     7d8 <soread+0x1e8>
     69f:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 6a6 <soread+0xb6>
			6a2: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     6a6:	f6 00 02             	testb  $0x2,(%rax)
     6a9:	0f 85 f1 00 00 00    	jne    7a0 <soread+0x1b0>
     6af:	48 8b 83 98 01 00 00 	mov    0x198(%rbx),%rax
     6b6:	8b 93 94 01 00 00    	mov    0x194(%rbx),%edx
     6bc:	4c 8b 83 a8 01 00 00 	mov    0x1a8(%rbx),%r8
     6c3:	44 01 9b 90 01 00 00 	add    %r11d,0x190(%rbx)
     6ca:	4c 01 d0             	add    %r10,%rax
     6cd:	48 89 c1             	mov    %rax,%rcx
     6d0:	49 01 d0             	add    %rdx,%r8
     6d3:	48 29 d1             	sub    %rdx,%rcx
     6d6:	4c 39 c0             	cmp    %r8,%rax
     6d9:	48 0f 43 c1          	cmovae %rcx,%rax
     6dd:	48 89 83 98 01 00 00 	mov    %rax,0x198(%rbx)
     6e4:	44 89 d8             	mov    %r11d,%eax
     6e7:	48 81 c4 f0 00 00 00 	add    $0xf0,%rsp
     6ee:	5b                   	pop    %rbx
     6ef:	5e                   	pop    %rsi
     6f0:	5f                   	pop    %rdi
     6f1:	41 5e                	pop    %r14
     6f3:	41 5f                	pop    %r15
     6f5:	31 d2                	xor    %edx,%edx
     6f7:	31 c9                	xor    %ecx,%ecx
     6f9:	45 31 c0             	xor    %r8d,%r8d
     6fc:	45 31 c9             	xor    %r9d,%r9d
     6ff:	45 31 d2             	xor    %r10d,%r10d
     702:	45 31 db             	xor    %r11d,%r11d
     705:	c3                   	ret
     706:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
     70d:	00 00 00 
     710:	0f 84 da 01 00 00    	je     8f0 <soread+0x300>
     716:	48 8b 3d 00 00 00 00 	mov    0x0(%rip),%rdi        # 71d <soread+0x12d>
			719: IMAGE_REL_AMD64_REL32	__imp__errno
     71d:	ff d7                	call   *%rdi
     71f:	83 38 04             	cmpl   $0x4,(%rax)
     722:	74 0b                	je     72f <soread+0x13f>
     724:	ff d7                	call   *%rdi
     726:	83 38 0b             	cmpl   $0xb,(%rax)
     729:	0f 85 e9 00 00 00    	jne    818 <soread+0x228>
     72f:	45 31 db             	xor    %r11d,%r11d
     732:	eb b0                	jmp    6e4 <soread+0xf4>
     734:	0f 1f 40 00          	nopl   0x0(%rax)
     738:	4c 8d 05 45 00 00 00 	lea    0x45(%rip),%r8        # 784 <soread+0x194>
			73b: IMAGE_REL_AMD64_REL32	.rdata
     73f:	ba 80 00 00 00       	mov    $0x80,%edx
     744:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 773 <soread+0x183>
			747: IMAGE_REL_AMD64_REL32	.rdata
     74b:	e8 00 00 00 00       	call   750 <soread+0x160>
			74c: IMAGE_REL_AMD64_REL32	g_log
     750:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 757 <soread+0x167>
			753: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     757:	f6 00 01             	testb  $0x1,(%rax)
     75a:	0f 84 b9 fe ff ff    	je     619 <soread+0x29>
     760:	49 89 d9             	mov    %rbx,%r9
     763:	4c 8d 05 3c 00 00 00 	lea    0x3c(%rip),%r8        # 7a6 <soread+0x1b6>
			766: IMAGE_REL_AMD64_REL32	.rdata
     76a:	ba 80 00 00 00       	mov    $0x80,%edx
     76f:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 79e <soread+0x1ae>
			772: IMAGE_REL_AMD64_REL32	.rdata
     776:	e8 00 00 00 00       	call   77b <soread+0x18b>
			777: IMAGE_REL_AMD64_REL32	g_log
     77b:	e9 99 fe ff ff       	jmp    619 <soread+0x29>
     780:	41 b8 c0 00 00 00    	mov    $0xc0,%r8d
     786:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 7dd <soread+0x1ed>
			789: IMAGE_REL_AMD64_REL32	.rdata
     78d:	48 8d 0d 78 00 00 00 	lea    0x78(%rip),%rcx        # 80c <soread+0x21c>
			790: IMAGE_REL_AMD64_REL32	.rdata
     794:	e8 00 00 00 00       	call   799 <soread+0x1a9>
			795: IMAGE_REL_AMD64_REL32	_assert
     799:	e9 ce fe ff ff       	jmp    66c <soread+0x7c>
     79e:	66 90                	xchg   %ax,%ax
     7a0:	45 89 d9             	mov    %r11d,%r9d
     7a3:	4c 8d 05 bb 00 00 00 	lea    0xbb(%rip),%r8        # 865 <soread+0x275>
			7a6: IMAGE_REL_AMD64_REL32	.rdata
     7aa:	ba 80 00 00 00       	mov    $0x80,%edx
     7af:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
     7b4:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 7e3 <soread+0x1f3>
			7b7: IMAGE_REL_AMD64_REL32	.rdata
     7bb:	44 89 5c 24 30       	mov    %r11d,0x30(%rsp)
     7c0:	e8 00 00 00 00       	call   7c5 <soread+0x1d5>
			7c1: IMAGE_REL_AMD64_REL32	g_log
     7c5:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
     7ca:	44 8b 5c 24 30       	mov    0x30(%rsp),%r11d
     7cf:	e9 db fe ff ff       	jmp    6af <soread+0xbf>
     7d4:	0f 1f 40 00          	nopl   0x0(%rax)
     7d8:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
     7dc:	45 31 c9             	xor    %r9d,%r9d
     7df:	4d 89 f8             	mov    %r15,%r8
     7e2:	4c 89 f2             	mov    %r14,%rdx
     7e5:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
     7ea:	89 44 24 38          	mov    %eax,0x38(%rsp)
     7ee:	e8 00 00 00 00       	call   7f3 <soread+0x203>
			7ef: IMAGE_REL_AMD64_REL32	slirp_recv_wrap
     7f3:	44 8b 5c 24 38       	mov    0x38(%rsp),%r11d
     7f8:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
     7fd:	01 c6                	add    %eax,%esi
     7ff:	85 c0                	test   %eax,%eax
     801:	44 0f 4f de          	cmovg  %esi,%r11d
     805:	49 63 c3             	movslq %r11d,%rax
     808:	4c 0f 4f d0          	cmovg  %rax,%r10
     80c:	e9 8e fe ff ff       	jmp    69f <soread+0xaf>
     811:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     818:	66 0f ef c0          	pxor   %xmm0,%xmm0
     81c:	c7 44 24 44 00 00 00 	movl   $0x0,0x44(%rsp)
     823:	00 
     824:	c7 44 24 48 04 00 00 	movl   $0x4,0x48(%rsp)
     82b:	00 
     82c:	c7 44 24 4c 80 00 00 	movl   $0x80,0x4c(%rsp)
     833:	00 
     834:	0f 11 44 24 70       	movups %xmm0,0x70(%rsp)
     839:	0f 11 84 24 80 00 00 	movups %xmm0,0x80(%rsp)
     840:	00 
     841:	0f 11 84 24 90 00 00 	movups %xmm0,0x90(%rsp)
     848:	00 
     849:	0f 11 84 24 a0 00 00 	movups %xmm0,0xa0(%rsp)
     850:	00 
     851:	0f 11 84 24 b0 00 00 	movups %xmm0,0xb0(%rsp)
     858:	00 
     859:	0f 11 84 24 c0 00 00 	movups %xmm0,0xc0(%rsp)
     860:	00 
     861:	0f 11 84 24 d0 00 00 	movups %xmm0,0xd0(%rsp)
     868:	00 
     869:	0f 11 84 24 e0 00 00 	movups %xmm0,0xe0(%rsp)
     870:	00 
     871:	ff d7                	call   *%rdi
     873:	8b 00                	mov    (%rax),%eax
     875:	89 44 24 44          	mov    %eax,0x44(%rsp)
     879:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 880 <soread+0x290>
			87c: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     880:	f6 00 02             	testb  $0x2,(%rax)
     883:	0f 85 3d 01 00 00    	jne    9c6 <soread+0x3d6>
     889:	8b 93 54 01 00 00    	mov    0x154(%rbx),%edx
     88f:	f6 c2 01             	test   $0x1,%dl
     892:	0f 84 18 01 00 00    	je     9b0 <soread+0x3c0>
     898:	89 d1                	mov    %edx,%ecx
     89a:	89 d0                	mov    %edx,%eax
     89c:	81 e1 00 f0 00 00    	and    $0xf000,%ecx
     8a2:	83 e0 fd             	and    $0xfffffffd,%eax
     8a5:	83 c9 01             	or     $0x1,%ecx
     8a8:	83 c8 08             	or     $0x8,%eax
     8ab:	83 e2 10             	and    $0x10,%edx
     8ae:	8b 54 24 44          	mov    0x44(%rsp),%edx
     8b2:	0f 45 c1             	cmovne %ecx,%eax
     8b5:	48 8b 8b 58 01 00 00 	mov    0x158(%rbx),%rcx
     8bc:	83 fa 20             	cmp    $0x20,%edx
     8bf:	89 83 54 01 00 00    	mov    %eax,0x154(%rbx)
     8c5:	0f 94 c0             	sete   %al
     8c8:	83 fa 7e             	cmp    $0x7e,%edx
     8cb:	41 0f 94 c0          	sete   %r8b
     8cf:	44 08 c0             	or     %r8b,%al
     8d2:	75 0c                	jne    8e0 <soread+0x2f0>
     8d4:	8d 42 96             	lea    -0x6a(%rdx),%eax
     8d7:	83 f8 02             	cmp    $0x2,%eax
     8da:	0f 87 1f 01 00 00    	ja     9ff <soread+0x40f>
     8e0:	e8 00 00 00 00       	call   8e5 <soread+0x2f5>
			8e1: IMAGE_REL_AMD64_REL32	tcp_drop
     8e5:	41 bb ff ff ff ff    	mov    $0xffffffff,%r11d
     8eb:	e9 f4 fd ff ff       	jmp    6e4 <soread+0xf4>
     8f0:	66 0f ef c0          	pxor   %xmm0,%xmm0
     8f4:	c7 44 24 44 00 00 00 	movl   $0x0,0x44(%rsp)
     8fb:	00 
     8fc:	48 8b 3d 00 00 00 00 	mov    0x0(%rip),%rdi        # 903 <soread+0x313>
			8ff: IMAGE_REL_AMD64_REL32	__imp__errno
     903:	c7 44 24 48 04 00 00 	movl   $0x4,0x48(%rsp)
     90a:	00 
     90b:	c7 44 24 4c 80 00 00 	movl   $0x80,0x4c(%rsp)
     912:	00 
     913:	0f 11 44 24 70       	movups %xmm0,0x70(%rsp)
     918:	0f 11 84 24 80 00 00 	movups %xmm0,0x80(%rsp)
     91f:	00 
     920:	0f 11 84 24 90 00 00 	movups %xmm0,0x90(%rsp)
     927:	00 
     928:	0f 11 84 24 a0 00 00 	movups %xmm0,0xa0(%rsp)
     92f:	00 
     930:	0f 11 84 24 b0 00 00 	movups %xmm0,0xb0(%rsp)
     937:	00 
     938:	0f 11 84 24 c0 00 00 	movups %xmm0,0xc0(%rsp)
     93f:	00 
     940:	0f 11 84 24 d0 00 00 	movups %xmm0,0xd0(%rsp)
     947:	00 
     948:	0f 11 84 24 e0 00 00 	movups %xmm0,0xe0(%rsp)
     94f:	00 
     950:	ff d7                	call   *%rdi
     952:	8b 00                	mov    (%rax),%eax
     954:	89 44 24 44          	mov    %eax,0x44(%rsp)
     958:	f6 83 54 01 00 00 10 	testb  $0x10,0x154(%rbx)
     95f:	75 17                	jne    978 <soread+0x388>
     961:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
     965:	4c 8d 44 24 4c       	lea    0x4c(%rsp),%r8
     96a:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
     96f:	e8 00 00 00 00       	call   974 <soread+0x384>
			970: IMAGE_REL_AMD64_REL32	slirp_getpeername_wrap
     974:	85 c0                	test   %eax,%eax
     976:	78 2b                	js     9a3 <soread+0x3b3>
     978:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
     97d:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
     981:	4c 8d 4c 24 44       	lea    0x44(%rsp),%r9
     986:	41 b8 07 10 00 00    	mov    $0x1007,%r8d
     98c:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
     991:	ba ff ff 00 00       	mov    $0xffff,%edx
     996:	e8 00 00 00 00       	call   99b <soread+0x3ab>
			997: IMAGE_REL_AMD64_REL32	slirp_getsockopt_wrap
     99b:	85 c0                	test   %eax,%eax
     99d:	0f 89 d6 fe ff ff    	jns    879 <soread+0x289>
     9a3:	ff d7                	call   *%rdi
     9a5:	8b 00                	mov    (%rax),%eax
     9a7:	89 44 24 44          	mov    %eax,0x44(%rsp)
     9ab:	e9 c9 fe ff ff       	jmp    879 <soread+0x289>
     9b0:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
     9b4:	31 d2                	xor    %edx,%edx
     9b6:	e8 00 00 00 00       	call   9bb <soread+0x3cb>
			9b7: IMAGE_REL_AMD64_REL32	slirp_shutdown_wrap
     9bb:	8b 93 54 01 00 00    	mov    0x154(%rbx),%edx
     9c1:	e9 d2 fe ff ff       	jmp    898 <soread+0x2a8>
     9c6:	ff d7                	call   *%rdi
     9c8:	8b 08                	mov    (%rax),%ecx
     9ca:	e8 00 00 00 00       	call   9cf <soread+0x3df>
			9cb: IMAGE_REL_AMD64_REL32	g_strerror
     9cf:	49 89 c6             	mov    %rax,%r14
     9d2:	ff d7                	call   *%rdi
     9d4:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
     9d9:	41 89 f1             	mov    %esi,%r9d
     9dc:	ba 80 00 00 00       	mov    $0x80,%edx
     9e1:	8b 00                	mov    (%rax),%eax
     9e3:	4c 8d 05 88 00 00 00 	lea    0x88(%rip),%r8        # a72 <soreadbuf+0x62>
			9e6: IMAGE_REL_AMD64_REL32	.rdata
     9ea:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # a19 <soreadbuf+0x9>
			9ed: IMAGE_REL_AMD64_REL32	.rdata
     9f1:	89 44 24 20          	mov    %eax,0x20(%rsp)
     9f5:	e8 00 00 00 00       	call   9fa <soread+0x40a>
			9f6: IMAGE_REL_AMD64_REL32	g_log
     9fa:	e9 8a fe ff ff       	jmp    889 <soread+0x299>
     9ff:	e8 00 00 00 00       	call   a04 <soread+0x414>
			a00: IMAGE_REL_AMD64_REL32	tcp_sockclosed
     a04:	e9 dc fe ff ff       	jmp    8e5 <soread+0x2f5>
     a09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000000a10 <soreadbuf>:
     a10:	41 56                	push   %r14
     a12:	41 55                	push   %r13
     a14:	41 54                	push   %r12
     a16:	55                   	push   %rbp
     a17:	57                   	push   %rdi
     a18:	56                   	push   %rsi
     a19:	53                   	push   %rbx
     a1a:	48 83 ec 50          	sub    $0x50,%rsp
     a1e:	48 8b 35 00 00 00 00 	mov    0x0(%rip),%rsi        # a25 <soreadbuf+0x15>
			a21: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     a25:	66 0f ef c0          	pxor   %xmm0,%xmm0
     a29:	48 89 cf             	mov    %rcx,%rdi
     a2c:	49 89 d4             	mov    %rdx,%r12
     a2f:	44 89 c3             	mov    %r8d,%ebx
     a32:	0f 11 44 24 30       	movups %xmm0,0x30(%rsp)
     a37:	0f 11 44 24 40       	movups %xmm0,0x40(%rsp)
     a3c:	f6 06 01             	testb  $0x1,(%rsi)
     a3f:	0f 85 cb 00 00 00    	jne    b10 <soreadbuf+0x100>
     a45:	85 db                	test   %ebx,%ebx
     a47:	0f 8e 07 01 00 00    	jle    b54 <soreadbuf+0x144>
     a4d:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
     a52:	4c 8d 44 24 2c       	lea    0x2c(%rsp),%r8
     a57:	48 89 f9             	mov    %rdi,%rcx
     a5a:	48 63 f3             	movslq %ebx,%rsi
     a5d:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
     a64:	00 00 
     a66:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
     a6d:	00 00 
     a6f:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
     a76:	00 00 
     a78:	e8 b3 f9 ff ff       	call   430 <sopreprbuf>
     a7d:	48 39 f0             	cmp    %rsi,%rax
     a80:	0f 82 f2 00 00 00    	jb     b78 <soreadbuf+0x168>
     a86:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
     a8b:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
     a90:	4c 89 e2             	mov    %r12,%rdx
     a93:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
     a98:	48 39 ee             	cmp    %rbp,%rsi
     a9b:	48 0f 46 ee          	cmovbe %rsi,%rbp
     a9f:	4c 63 f5             	movslq %ebp,%r14
     aa2:	4d 89 f0             	mov    %r14,%r8
     aa5:	e8 00 00 00 00       	call   aaa <soreadbuf+0x9a>
			aa6: IMAGE_REL_AMD64_REL32	memcpy
     aaa:	41 89 d8             	mov    %ebx,%r8d
     aad:	41 29 e8             	sub    %ebp,%r8d
     ab0:	74 0f                	je     ac1 <soreadbuf+0xb1>
     ab2:	4b 8d 14 34          	lea    (%r12,%r14,1),%rdx
     ab6:	4d 63 c0             	movslq %r8d,%r8
     ab9:	4c 89 e9             	mov    %r13,%rcx
     abc:	e8 00 00 00 00       	call   ac1 <soreadbuf+0xb1>
			abd: IMAGE_REL_AMD64_REL32	memcpy
     ac1:	8b 87 94 01 00 00    	mov    0x194(%rdi),%eax
     ac7:	48 8b 8f a8 01 00 00 	mov    0x1a8(%rdi),%rcx
     ace:	48 03 b7 98 01 00 00 	add    0x198(%rdi),%rsi
     ad5:	01 9f 90 01 00 00    	add    %ebx,0x190(%rdi)
     adb:	48 01 c1             	add    %rax,%rcx
     ade:	48 89 f2             	mov    %rsi,%rdx
     ae1:	48 29 c2             	sub    %rax,%rdx
     ae4:	48 39 ce             	cmp    %rcx,%rsi
     ae7:	89 d8                	mov    %ebx,%eax
     ae9:	48 0f 43 f2          	cmovae %rdx,%rsi
     aed:	48 89 b7 98 01 00 00 	mov    %rsi,0x198(%rdi)
     af4:	48 83 c4 50          	add    $0x50,%rsp
     af8:	5b                   	pop    %rbx
     af9:	5e                   	pop    %rsi
     afa:	5f                   	pop    %rdi
     afb:	5d                   	pop    %rbp
     afc:	41 5c                	pop    %r12
     afe:	41 5d                	pop    %r13
     b00:	41 5e                	pop    %r14
     b02:	31 d2                	xor    %edx,%edx
     b04:	31 c9                	xor    %ecx,%ecx
     b06:	45 31 c0             	xor    %r8d,%r8d
     b09:	45 31 c9             	xor    %r9d,%r9d
     b0c:	c3                   	ret
     b0d:	0f 1f 00             	nopl   (%rax)
     b10:	4c 8d 05 d3 00 00 00 	lea    0xd3(%rip),%r8        # bea <soreadbuf+0x1da>
			b13: IMAGE_REL_AMD64_REL32	.rdata
     b17:	ba 80 00 00 00       	mov    $0x80,%edx
     b1c:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # b4b <soreadbuf+0x13b>
			b1f: IMAGE_REL_AMD64_REL32	.rdata
     b23:	e8 00 00 00 00       	call   b28 <soreadbuf+0x118>
			b24: IMAGE_REL_AMD64_REL32	g_log
     b28:	f6 06 01             	testb  $0x1,(%rsi)
     b2b:	0f 84 14 ff ff ff    	je     a45 <soreadbuf+0x35>
     b31:	49 89 f9             	mov    %rdi,%r9
     b34:	4c 8d 05 3c 00 00 00 	lea    0x3c(%rip),%r8        # b77 <soreadbuf+0x167>
			b37: IMAGE_REL_AMD64_REL32	.rdata
     b3b:	ba 80 00 00 00       	mov    $0x80,%edx
     b40:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # b6f <soreadbuf+0x15f>
			b43: IMAGE_REL_AMD64_REL32	.rdata
     b47:	e8 00 00 00 00       	call   b4c <soreadbuf+0x13c>
			b48: IMAGE_REL_AMD64_REL32	g_log
     b4c:	85 db                	test   %ebx,%ebx
     b4e:	0f 8f f9 fe ff ff    	jg     a4d <soreadbuf+0x3d>
     b54:	41 b8 0f 01 00 00    	mov    $0x10f,%r8d
     b5a:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # bb1 <soreadbuf+0x1a1>
			b5d: IMAGE_REL_AMD64_REL32	.rdata
     b61:	48 8d 0d e0 00 00 00 	lea    0xe0(%rip),%rcx        # c48 <sorecvoob+0x58>
			b64: IMAGE_REL_AMD64_REL32	.rdata
     b68:	e8 00 00 00 00       	call   b6d <soreadbuf+0x15d>
			b69: IMAGE_REL_AMD64_REL32	_assert
     b6d:	e9 db fe ff ff       	jmp    a4d <soreadbuf+0x3d>
     b72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     b78:	8b 97 54 01 00 00    	mov    0x154(%rdi),%edx
     b7e:	f6 c2 01             	test   $0x1,%dl
     b81:	74 4d                	je     bd0 <soreadbuf+0x1c0>
     b83:	89 d1                	mov    %edx,%ecx
     b85:	89 d0                	mov    %edx,%eax
     b87:	81 e1 00 f0 00 00    	and    $0xf000,%ecx
     b8d:	83 e0 fd             	and    $0xfffffffd,%eax
     b90:	83 c9 01             	or     $0x1,%ecx
     b93:	83 c8 08             	or     $0x8,%eax
     b96:	83 e2 10             	and    $0x10,%edx
     b99:	0f 45 c1             	cmovne %ecx,%eax
     b9c:	48 8b 8f 58 01 00 00 	mov    0x158(%rdi),%rcx
     ba3:	89 87 54 01 00 00    	mov    %eax,0x154(%rdi)
     ba9:	e8 00 00 00 00       	call   bae <soreadbuf+0x19e>
			baa: IMAGE_REL_AMD64_REL32	tcp_sockclosed
     bae:	4c 8d 05 e9 00 00 00 	lea    0xe9(%rip),%r8        # c9e <sorecvoob+0xae>
			bb1: IMAGE_REL_AMD64_REL32	.rdata
     bb5:	ba 08 00 00 00       	mov    $0x8,%edx
     bba:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # be9 <soreadbuf+0x1d9>
			bbd: IMAGE_REL_AMD64_REL32	.rdata
     bc1:	e8 00 00 00 00       	call   bc6 <soreadbuf+0x1b6>
			bc2: IMAGE_REL_AMD64_REL32	g_log
     bc6:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
     bcb:	e9 24 ff ff ff       	jmp    af4 <soreadbuf+0xe4>
     bd0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
     bd4:	31 d2                	xor    %edx,%edx
     bd6:	e8 00 00 00 00       	call   bdb <soreadbuf+0x1cb>
			bd7: IMAGE_REL_AMD64_REL32	slirp_shutdown_wrap
     bdb:	8b 97 54 01 00 00    	mov    0x154(%rdi),%edx
     be1:	eb a0                	jmp    b83 <soreadbuf+0x173>
     be3:	66 90                	xchg   %ax,%ax
     be5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
     bec:	00 00 00 00 

0000000000000bf0 <sorecvoob>:
     bf0:	56                   	push   %rsi
     bf1:	53                   	push   %rbx
     bf2:	48 83 ec 38          	sub    $0x38,%rsp
     bf6:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # bfd <sorecvoob+0xd>
			bf9: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     bfd:	48 8b b1 58 01 00 00 	mov    0x158(%rcx),%rsi
     c04:	48 89 cb             	mov    %rcx,%rbx
     c07:	f6 00 01             	testb  $0x1,(%rax)
     c0a:	75 4c                	jne    c58 <sorecvoob+0x68>
     c0c:	48 89 d9             	mov    %rbx,%rcx
     c0f:	e8 dc f9 ff ff       	call   5f0 <soread>
     c14:	89 c2                	mov    %eax,%edx
     c16:	85 c0                	test   %eax,%eax
     c18:	7e 27                	jle    c41 <sorecvoob+0x51>
     c1a:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
     c1e:	8b 83 90 01 00 00    	mov    0x190(%rbx),%eax
     c24:	48 89 f1             	mov    %rsi,%rcx
     c27:	03 46 78             	add    0x78(%rsi),%eax
     c2a:	c6 46 22 01          	movb   $0x1,0x22(%rsi)
     c2e:	89 86 80 00 00 00    	mov    %eax,0x80(%rsi)
     c34:	e8 00 00 00 00       	call   c39 <sorecvoob+0x49>
			c35: IMAGE_REL_AMD64_REL32	tcp_output
     c39:	c6 46 22 00          	movb   $0x0,0x22(%rsi)
     c3d:	8b 54 24 2c          	mov    0x2c(%rsp),%edx
     c41:	89 d0                	mov    %edx,%eax
     c43:	48 83 c4 38          	add    $0x38,%rsp
     c47:	5b                   	pop    %rbx
     c48:	5e                   	pop    %rsi
     c49:	31 d2                	xor    %edx,%edx
     c4b:	31 c9                	xor    %ecx,%ecx
     c4d:	45 31 c0             	xor    %r8d,%r8d
     c50:	45 31 c9             	xor    %r9d,%r9d
     c53:	c3                   	ret
     c54:	0f 1f 40 00          	nopl   0x0(%rax)
     c58:	4c 8d 05 04 01 00 00 	lea    0x104(%rip),%r8        # d63 <sosendoob+0xc3>
			c5b: IMAGE_REL_AMD64_REL32	.rdata
     c5f:	ba 80 00 00 00       	mov    $0x80,%edx
     c64:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # c93 <sorecvoob+0xa3>
			c67: IMAGE_REL_AMD64_REL32	.rdata
     c6b:	e8 00 00 00 00       	call   c70 <sorecvoob+0x80>
			c6c: IMAGE_REL_AMD64_REL32	g_log
     c70:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # c77 <sorecvoob+0x87>
			c73: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     c77:	f6 00 01             	testb  $0x1,(%rax)
     c7a:	74 90                	je     c0c <sorecvoob+0x1c>
     c7c:	49 89 d9             	mov    %rbx,%r9
     c7f:	4c 8d 05 3c 00 00 00 	lea    0x3c(%rip),%r8        # cc2 <sosendoob+0x22>
			c82: IMAGE_REL_AMD64_REL32	.rdata
     c86:	ba 80 00 00 00       	mov    $0x80,%edx
     c8b:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # cba <sosendoob+0x1a>
			c8e: IMAGE_REL_AMD64_REL32	.rdata
     c92:	e8 00 00 00 00       	call   c97 <sorecvoob+0xa7>
			c93: IMAGE_REL_AMD64_REL32	g_log
     c97:	e9 70 ff ff ff       	jmp    c0c <sorecvoob+0x1c>
     c9c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000000ca0 <sosendoob>:
     ca0:	57                   	push   %rdi
     ca1:	56                   	push   %rsi
     ca2:	53                   	push   %rbx
     ca3:	48 81 ec 50 08 00 00 	sub    $0x850,%rsp
     caa:	41 b8 00 08 00 00    	mov    $0x800,%r8d
     cb0:	31 d2                	xor    %edx,%edx
     cb2:	8b 79 48             	mov    0x48(%rcx),%edi
     cb5:	48 89 cb             	mov    %rcx,%rbx
     cb8:	48 8d 4c 24 50       	lea    0x50(%rsp),%rcx
     cbd:	e8 00 00 00 00       	call   cc2 <sosendoob+0x22>
			cbe: IMAGE_REL_AMD64_REL32	memset
     cc2:	48 8b 35 00 00 00 00 	mov    0x0(%rip),%rsi        # cc9 <sosendoob+0x29>
			cc5: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     cc9:	f6 06 01             	testb  $0x1,(%rsi)
     ccc:	0f 85 6e 01 00 00    	jne    e40 <sosendoob+0x1a0>
     cd2:	8b 83 70 01 00 00    	mov    0x170(%rbx),%eax
     cd8:	48 8b 93 80 01 00 00 	mov    0x180(%rbx),%rdx
     cdf:	4c 8b 8b 78 01 00 00 	mov    0x178(%rbx),%r9
     ce6:	39 c7                	cmp    %eax,%edi
     ce8:	0f 46 c7             	cmovbe %edi,%eax
     ceb:	41 89 c2             	mov    %eax,%r10d
     cee:	b8 00 08 00 00       	mov    $0x800,%eax
     cf3:	41 39 c2             	cmp    %eax,%r10d
     cf6:	44 0f 47 d0          	cmova  %eax,%r10d
     cfa:	4c 39 ca             	cmp    %r9,%rdx
     cfd:	0f 82 1d 01 00 00    	jb     e20 <sosendoob+0x180>
     d03:	4c 8b 9b 88 01 00 00 	mov    0x188(%rbx),%r11
     d0a:	8b bb 74 01 00 00    	mov    0x174(%rbx),%edi
     d10:	4c 01 df             	add    %r11,%rdi
     d13:	48 29 d7             	sub    %rdx,%rdi
     d16:	41 39 fa             	cmp    %edi,%r10d
     d19:	0f 82 e1 00 00 00    	jb     e00 <sosendoob+0x160>
     d1f:	41 89 f8             	mov    %edi,%r8d
     d22:	48 8d 4c 24 50       	lea    0x50(%rsp),%rcx
     d27:	44 89 54 24 3c       	mov    %r10d,0x3c(%rsp)
     d2c:	4c 89 44 24 30       	mov    %r8,0x30(%rsp)
     d31:	4c 89 5c 24 40       	mov    %r11,0x40(%rsp)
     d36:	4c 89 4c 24 48       	mov    %r9,0x48(%rsp)
     d3b:	e8 00 00 00 00       	call   d40 <sosendoob+0xa0>
			d3c: IMAGE_REL_AMD64_REL32	memcpy
     d40:	44 8b 54 24 3c       	mov    0x3c(%rsp),%r10d
     d45:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
     d4a:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
     d4f:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
     d54:	41 29 fa             	sub    %edi,%r10d
     d57:	74 2a                	je     d83 <sosendoob+0xe3>
     d59:	4d 29 d9             	sub    %r11,%r9
     d5c:	4a 8d 4c 04 50       	lea    0x50(%rsp,%r8,1),%rcx
     d61:	4c 89 da             	mov    %r11,%rdx
     d64:	45 39 ca             	cmp    %r9d,%r10d
     d67:	45 0f 47 d1          	cmova  %r9d,%r10d
     d6b:	4d 63 c2             	movslq %r10d,%r8
     d6e:	44 89 54 24 30       	mov    %r10d,0x30(%rsp)
     d73:	e8 00 00 00 00       	call   d78 <sosendoob+0xd8>
			d74: IMAGE_REL_AMD64_REL32	memcpy
     d78:	44 8b 54 24 30       	mov    0x30(%rsp),%r10d
     d7d:	41 01 fa             	add    %edi,%r10d
     d80:	4d 63 c2             	movslq %r10d,%r8
     d83:	41 b9 01 00 00 00    	mov    $0x1,%r9d
     d89:	48 8d 54 24 50       	lea    0x50(%rsp),%rdx
     d8e:	48 89 d9             	mov    %rbx,%rcx
     d91:	e8 00 00 00 00       	call   d96 <sosendoob+0xf6>
			d92: IMAGE_REL_AMD64_REL32	slirp_send
     d96:	85 c0                	test   %eax,%eax
     d98:	78 44                	js     dde <sosendoob+0x13e>
     d9a:	8b 53 48             	mov    0x48(%rbx),%edx
     d9d:	29 c2                	sub    %eax,%edx
     d9f:	89 53 48             	mov    %edx,0x48(%rbx)
     da2:	f6 06 02             	testb  $0x2,(%rsi)
     da5:	0f 85 05 01 00 00    	jne    eb0 <sosendoob+0x210>
     dab:	8b 8b 74 01 00 00    	mov    0x174(%rbx),%ecx
     db1:	4c 8b 8b 88 01 00 00 	mov    0x188(%rbx),%r9
     db8:	89 c2                	mov    %eax,%edx
     dba:	48 03 93 80 01 00 00 	add    0x180(%rbx),%rdx
     dc1:	29 83 70 01 00 00    	sub    %eax,0x170(%rbx)
     dc7:	49 89 d0             	mov    %rdx,%r8
     dca:	49 01 c9             	add    %rcx,%r9
     dcd:	49 29 c8             	sub    %rcx,%r8
     dd0:	4c 39 ca             	cmp    %r9,%rdx
     dd3:	49 0f 43 d0          	cmovae %r8,%rdx
     dd7:	48 89 93 80 01 00 00 	mov    %rdx,0x180(%rbx)
     dde:	48 81 c4 50 08 00 00 	add    $0x850,%rsp
     de5:	5b                   	pop    %rbx
     de6:	5e                   	pop    %rsi
     de7:	5f                   	pop    %rdi
     de8:	31 d2                	xor    %edx,%edx
     dea:	31 c9                	xor    %ecx,%ecx
     dec:	45 31 c0             	xor    %r8d,%r8d
     def:	45 31 c9             	xor    %r9d,%r9d
     df2:	45 31 d2             	xor    %r10d,%r10d
     df5:	45 31 db             	xor    %r11d,%r11d
     df8:	c3                   	ret
     df9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     e00:	45 89 d0             	mov    %r10d,%r8d
     e03:	48 8d 4c 24 50       	lea    0x50(%rsp),%rcx
     e08:	4c 89 44 24 30       	mov    %r8,0x30(%rsp)
     e0d:	e8 00 00 00 00       	call   e12 <sosendoob+0x172>
			e0e: IMAGE_REL_AMD64_REL32	memcpy
     e12:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
     e17:	e9 67 ff ff ff       	jmp    d83 <sosendoob+0xe3>
     e1c:	0f 1f 40 00          	nopl   0x0(%rax)
     e20:	41 b9 01 00 00 00    	mov    $0x1,%r9d
     e26:	45 89 d0             	mov    %r10d,%r8d
     e29:	48 89 d9             	mov    %rbx,%rcx
     e2c:	e8 00 00 00 00       	call   e31 <sosendoob+0x191>
			e2d: IMAGE_REL_AMD64_REL32	slirp_send
     e31:	e9 60 ff ff ff       	jmp    d96 <sosendoob+0xf6>
     e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
     e3d:	00 00 00 
     e40:	4c 8d 05 11 01 00 00 	lea    0x111(%rip),%r8        # f58 <sowrite+0x78>
			e43: IMAGE_REL_AMD64_REL32	.rdata
     e47:	ba 80 00 00 00       	mov    $0x80,%edx
     e4c:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # e7b <sosendoob+0x1db>
			e4f: IMAGE_REL_AMD64_REL32	.rdata
     e53:	e8 00 00 00 00       	call   e58 <sosendoob+0x1b8>
			e54: IMAGE_REL_AMD64_REL32	g_log
     e58:	f6 06 01             	testb  $0x1,(%rsi)
     e5b:	0f 84 71 fe ff ff    	je     cd2 <sosendoob+0x32>
     e61:	49 89 d9             	mov    %rbx,%r9
     e64:	4c 8d 05 3c 00 00 00 	lea    0x3c(%rip),%r8        # ea7 <sosendoob+0x207>
			e67: IMAGE_REL_AMD64_REL32	.rdata
     e6b:	ba 80 00 00 00       	mov    $0x80,%edx
     e70:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # e9f <sosendoob+0x1ff>
			e73: IMAGE_REL_AMD64_REL32	.rdata
     e77:	e8 00 00 00 00       	call   e7c <sosendoob+0x1dc>
			e78: IMAGE_REL_AMD64_REL32	g_log
     e7c:	44 8b 8b 70 01 00 00 	mov    0x170(%rbx),%r9d
     e83:	f6 06 01             	testb  $0x1,(%rsi)
     e86:	0f 84 46 fe ff ff    	je     cd2 <sosendoob+0x32>
     e8c:	4c 8d 05 1e 01 00 00 	lea    0x11e(%rip),%r8        # fb1 <sowrite+0xd1>
			e8f: IMAGE_REL_AMD64_REL32	.rdata
     e93:	ba 80 00 00 00       	mov    $0x80,%edx
     e98:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # ec7 <sosendoob+0x227>
			e9b: IMAGE_REL_AMD64_REL32	.rdata
     e9f:	e8 00 00 00 00       	call   ea4 <sosendoob+0x204>
			ea0: IMAGE_REL_AMD64_REL32	g_log
     ea4:	e9 29 fe ff ff       	jmp    cd2 <sosendoob+0x32>
     ea9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     eb0:	89 54 24 20          	mov    %edx,0x20(%rsp)
     eb4:	41 89 c1             	mov    %eax,%r9d
     eb7:	4c 8d 05 30 01 00 00 	lea    0x130(%rip),%r8        # fee <sowrite+0x10e>
			eba: IMAGE_REL_AMD64_REL32	.rdata
     ebe:	ba 80 00 00 00       	mov    $0x80,%edx
     ec3:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # ef2 <sowrite+0x12>
			ec6: IMAGE_REL_AMD64_REL32	.rdata
     eca:	89 44 24 30          	mov    %eax,0x30(%rsp)
     ece:	e8 00 00 00 00       	call   ed3 <sosendoob+0x233>
			ecf: IMAGE_REL_AMD64_REL32	g_log
     ed3:	8b 44 24 30          	mov    0x30(%rsp),%eax
     ed7:	e9 cf fe ff ff       	jmp    dab <sosendoob+0x10b>
     edc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000000ee0 <sowrite>:
     ee0:	41 56                	push   %r14
     ee2:	41 54                	push   %r12
     ee4:	55                   	push   %rbp
     ee5:	57                   	push   %rdi
     ee6:	56                   	push   %rsi
     ee7:	53                   	push   %rbx
     ee8:	48 83 ec 48          	sub    $0x48,%rsp
     eec:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # ef3 <sowrite+0x13>
			eef: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     ef3:	8b b9 70 01 00 00    	mov    0x170(%rcx),%edi
     ef9:	48 89 cb             	mov    %rcx,%rbx
     efc:	f6 00 01             	testb  $0x1,(%rax)
     eff:	0f 85 6b 01 00 00    	jne    1070 <sowrite+0x190>
     f05:	8b 73 48             	mov    0x48(%rbx),%esi
     f08:	85 f6                	test   %esi,%esi
     f0a:	0f 85 30 01 00 00    	jne    1040 <sowrite+0x160>
     f10:	48 8b 93 80 01 00 00 	mov    0x180(%rbx),%rdx
     f17:	48 8b 83 78 01 00 00 	mov    0x178(%rbx),%rax
     f1e:	48 63 f7             	movslq %edi,%rsi
     f21:	48 39 c2             	cmp    %rax,%rdx
     f24:	0f 82 f6 00 00 00    	jb     1020 <sowrite+0x140>
     f2a:	48 8b ab 88 01 00 00 	mov    0x188(%rbx),%rbp
     f31:	8b 8b 74 01 00 00    	mov    0x174(%rbx),%ecx
     f37:	48 01 e9             	add    %rbp,%rcx
     f3a:	48 29 d1             	sub    %rdx,%rcx
     f3d:	48 39 f1             	cmp    %rsi,%rcx
     f40:	48 0f 46 f1          	cmovbe %rcx,%rsi
     f44:	29 f7                	sub    %esi,%edi
     f46:	0f 84 1c 02 00 00    	je     1168 <sowrite+0x288>
     f4c:	48 29 e8             	sub    %rbp,%rax
     f4f:	48 63 ff             	movslq %edi,%rdi
     f52:	48 39 f8             	cmp    %rdi,%rax
     f55:	48 0f 46 f8          	cmovbe %rax,%rdi
     f59:	49 89 fe             	mov    %rdi,%r14
     f5c:	bf 02 00 00 00       	mov    $0x2,%edi
     f61:	45 31 c9             	xor    %r9d,%r9d
     f64:	49 89 f0             	mov    %rsi,%r8
     f67:	48 89 d9             	mov    %rbx,%rcx
     f6a:	e8 00 00 00 00       	call   f6f <sowrite+0x8f>
			f6b: IMAGE_REL_AMD64_REL32	slirp_send
     f6f:	49 89 c4             	mov    %rax,%r12
     f72:	41 89 c3             	mov    %eax,%r11d
     f75:	85 c0                	test   %eax,%eax
     f77:	0f 88 7b 01 00 00    	js     10f8 <sowrite+0x218>
     f7d:	0f 84 8a 01 00 00    	je     110d <sowrite+0x22d>
     f83:	41 89 c2             	mov    %eax,%r10d
     f86:	49 39 f2             	cmp    %rsi,%r10
     f89:	75 09                	jne    f94 <sowrite+0xb4>
     f8b:	83 ff 02             	cmp    $0x2,%edi
     f8e:	0f 84 8c 02 00 00    	je     1220 <sowrite+0x340>
     f94:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # f9b <sowrite+0xbb>
			f97: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
     f9b:	f6 00 02             	testb  $0x2,(%rax)
     f9e:	0f 85 1c 01 00 00    	jne    10c0 <sowrite+0x1e0>
     fa4:	48 8b 93 80 01 00 00 	mov    0x180(%rbx),%rdx
     fab:	8b 83 74 01 00 00    	mov    0x174(%rbx),%eax
     fb1:	4c 8b 83 88 01 00 00 	mov    0x188(%rbx),%r8
     fb8:	8b 8b 70 01 00 00    	mov    0x170(%rbx),%ecx
     fbe:	4c 01 d2             	add    %r10,%rdx
     fc1:	49 01 c0             	add    %rax,%r8
     fc4:	44 29 d9             	sub    %r11d,%ecx
     fc7:	4c 39 c2             	cmp    %r8,%rdx
     fca:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     fd0:	89 8b 70 01 00 00    	mov    %ecx,0x170(%rbx)
     fd6:	49 0f 42 c0          	cmovb  %r8,%rax
     fda:	48 29 c2             	sub    %rax,%rdx
     fdd:	8b 83 54 01 00 00    	mov    0x154(%rbx),%eax
     fe3:	48 89 93 80 01 00 00 	mov    %rdx,0x180(%rbx)
     fea:	a8 40                	test   $0x40,%al
     fec:	74 08                	je     ff6 <sowrite+0x116>
     fee:	85 c9                	test   %ecx,%ecx
     ff0:	0f 84 b2 01 00 00    	je     11a8 <sowrite+0x2c8>
     ff6:	44 89 d8             	mov    %r11d,%eax
     ff9:	48 83 c4 48          	add    $0x48,%rsp
     ffd:	5b                   	pop    %rbx
     ffe:	5e                   	pop    %rsi
     fff:	5f                   	pop    %rdi
    1000:	5d                   	pop    %rbp
    1001:	41 5c                	pop    %r12
    1003:	41 5e                	pop    %r14
    1005:	31 d2                	xor    %edx,%edx
    1007:	31 c9                	xor    %ecx,%ecx
    1009:	45 31 c0             	xor    %r8d,%r8d
    100c:	45 31 c9             	xor    %r9d,%r9d
    100f:	45 31 d2             	xor    %r10d,%r10d
    1012:	45 31 db             	xor    %r11d,%r11d
    1015:	c3                   	ret
    1016:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    101d:	00 00 00 
    1020:	48 29 d0             	sub    %rdx,%rax
    1023:	bf 01 00 00 00       	mov    $0x1,%edi
    1028:	48 39 f0             	cmp    %rsi,%rax
    102b:	48 0f 46 f0          	cmovbe %rax,%rsi
    102f:	45 31 f6             	xor    %r14d,%r14d
    1032:	31 ed                	xor    %ebp,%ebp
    1034:	e9 28 ff ff ff       	jmp    f61 <sowrite+0x81>
    1039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1040:	48 89 d9             	mov    %rbx,%rcx
    1043:	e8 58 fc ff ff       	call   ca0 <sosendoob>
    1048:	41 89 c3             	mov    %eax,%r11d
    104b:	85 c0                	test   %eax,%eax
    104d:	0f 8e ba 00 00 00    	jle    110d <sowrite+0x22d>
    1053:	39 f0                	cmp    %esi,%eax
    1055:	72 9f                	jb     ff6 <sowrite+0x116>
    1057:	8b 83 70 01 00 00    	mov    0x170(%rbx),%eax
    105d:	85 c0                	test   %eax,%eax
    105f:	0f 85 ab fe ff ff    	jne    f10 <sowrite+0x30>
    1065:	eb 8f                	jmp    ff6 <sowrite+0x116>
    1067:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    106e:	00 00 
    1070:	4c 8d 05 66 01 00 00 	lea    0x166(%rip),%r8        # 11dd <sowrite+0x2fd>
			1073: IMAGE_REL_AMD64_REL32	.rdata
    1077:	ba 80 00 00 00       	mov    $0x80,%edx
    107c:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 10ab <sowrite+0x1cb>
			107f: IMAGE_REL_AMD64_REL32	.rdata
    1083:	e8 00 00 00 00       	call   1088 <sowrite+0x1a8>
			1084: IMAGE_REL_AMD64_REL32	g_log
    1088:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 108f <sowrite+0x1af>
			108b: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    108f:	f6 00 01             	testb  $0x1,(%rax)
    1092:	0f 84 6d fe ff ff    	je     f05 <sowrite+0x25>
    1098:	49 89 d9             	mov    %rbx,%r9
    109b:	4c 8d 05 3c 00 00 00 	lea    0x3c(%rip),%r8        # 10de <sowrite+0x1fe>
			109e: IMAGE_REL_AMD64_REL32	.rdata
    10a2:	ba 80 00 00 00       	mov    $0x80,%edx
    10a7:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 10d6 <sowrite+0x1f6>
			10aa: IMAGE_REL_AMD64_REL32	.rdata
    10ae:	e8 00 00 00 00       	call   10b3 <sowrite+0x1d3>
			10af: IMAGE_REL_AMD64_REL32	g_log
    10b3:	e9 4d fe ff ff       	jmp    f05 <sowrite+0x25>
    10b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    10bf:	00 
    10c0:	45 89 d9             	mov    %r11d,%r9d
    10c3:	4c 8d 05 71 01 00 00 	lea    0x171(%rip),%r8        # 123b <sowrite+0x35b>
			10c6: IMAGE_REL_AMD64_REL32	.rdata
    10ca:	ba 80 00 00 00       	mov    $0x80,%edx
    10cf:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    10d4:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 1103 <sowrite+0x223>
			10d7: IMAGE_REL_AMD64_REL32	.rdata
    10db:	44 89 5c 24 30       	mov    %r11d,0x30(%rsp)
    10e0:	e8 00 00 00 00       	call   10e5 <sowrite+0x205>
			10e1: IMAGE_REL_AMD64_REL32	g_log
    10e5:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
    10ea:	44 8b 5c 24 30       	mov    0x30(%rsp),%r11d
    10ef:	e9 b0 fe ff ff       	jmp    fa4 <sowrite+0xc4>
    10f4:	0f 1f 40 00          	nopl   0x0(%rax)
    10f8:	48 8b 35 00 00 00 00 	mov    0x0(%rip),%rsi        # 10ff <sowrite+0x21f>
			10fb: IMAGE_REL_AMD64_REL32	__imp__errno
    10ff:	ff d6                	call   *%rsi
    1101:	83 38 0b             	cmpl   $0xb,(%rax)
    1104:	74 7a                	je     1180 <sowrite+0x2a0>
    1106:	ff d6                	call   *%rsi
    1108:	83 38 04             	cmpl   $0x4,(%rax)
    110b:	74 73                	je     1180 <sowrite+0x2a0>
    110d:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 1114 <sowrite+0x234>
			1110: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    1114:	f6 00 02             	testb  $0x2,(%rax)
    1117:	0f 85 d3 00 00 00    	jne    11f0 <sowrite+0x310>
    111d:	8b 93 54 01 00 00    	mov    0x154(%rbx),%edx
    1123:	f6 c2 01             	test   $0x1,%dl
    1126:	0f 84 57 01 00 00    	je     1283 <sowrite+0x3a3>
    112c:	89 d1                	mov    %edx,%ecx
    112e:	89 d0                	mov    %edx,%eax
    1130:	81 e1 00 f0 00 00    	and    $0xf000,%ecx
    1136:	83 e0 fd             	and    $0xfffffffd,%eax
    1139:	83 c9 01             	or     $0x1,%ecx
    113c:	83 c8 10             	or     $0x10,%eax
    113f:	83 e2 08             	and    $0x8,%edx
    1142:	0f 45 c1             	cmovne %ecx,%eax
    1145:	48 8b 8b 58 01 00 00 	mov    0x158(%rbx),%rcx
    114c:	89 83 54 01 00 00    	mov    %eax,0x154(%rbx)
    1152:	e8 00 00 00 00       	call   1157 <sowrite+0x277>
			1153: IMAGE_REL_AMD64_REL32	tcp_sockclosed
    1157:	41 bb ff ff ff ff    	mov    $0xffffffff,%r11d
    115d:	e9 94 fe ff ff       	jmp    ff6 <sowrite+0x116>
    1162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1168:	45 31 f6             	xor    %r14d,%r14d
    116b:	31 ed                	xor    %ebp,%ebp
    116d:	bf 01 00 00 00       	mov    $0x1,%edi
    1172:	e9 ea fd ff ff       	jmp    f61 <sowrite+0x81>
    1177:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    117e:	00 00 
    1180:	45 31 db             	xor    %r11d,%r11d
    1183:	44 89 d8             	mov    %r11d,%eax
    1186:	48 83 c4 48          	add    $0x48,%rsp
    118a:	5b                   	pop    %rbx
    118b:	5e                   	pop    %rsi
    118c:	5f                   	pop    %rdi
    118d:	5d                   	pop    %rbp
    118e:	41 5c                	pop    %r12
    1190:	41 5e                	pop    %r14
    1192:	31 d2                	xor    %edx,%edx
    1194:	31 c9                	xor    %ecx,%ecx
    1196:	45 31 c0             	xor    %r8d,%r8d
    1199:	45 31 c9             	xor    %r9d,%r9d
    119c:	45 31 d2             	xor    %r10d,%r10d
    119f:	45 31 db             	xor    %r11d,%r11d
    11a2:	c3                   	ret
    11a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    11a8:	a8 01                	test   $0x1,%al
    11aa:	0f 84 b0 00 00 00    	je     1260 <sowrite+0x380>
    11b0:	89 c1                	mov    %eax,%ecx
    11b2:	89 c2                	mov    %eax,%edx
    11b4:	81 e1 00 f0 00 00    	and    $0xf000,%ecx
    11ba:	83 e2 fd             	and    $0xfffffffd,%edx
    11bd:	83 c9 01             	or     $0x1,%ecx
    11c0:	83 ca 10             	or     $0x10,%edx
    11c3:	a8 08                	test   $0x8,%al
    11c5:	89 c8                	mov    %ecx,%eax
    11c7:	0f 44 c2             	cmove  %edx,%eax
    11ca:	89 83 54 01 00 00    	mov    %eax,0x154(%rbx)
    11d0:	44 89 d8             	mov    %r11d,%eax
    11d3:	48 83 c4 48          	add    $0x48,%rsp
    11d7:	5b                   	pop    %rbx
    11d8:	5e                   	pop    %rsi
    11d9:	5f                   	pop    %rdi
    11da:	5d                   	pop    %rbp
    11db:	41 5c                	pop    %r12
    11dd:	41 5e                	pop    %r14
    11df:	31 d2                	xor    %edx,%edx
    11e1:	31 c9                	xor    %ecx,%ecx
    11e3:	45 31 c0             	xor    %r8d,%r8d
    11e6:	45 31 c9             	xor    %r9d,%r9d
    11e9:	45 31 d2             	xor    %r10d,%r10d
    11ec:	45 31 db             	xor    %r11d,%r11d
    11ef:	c3                   	ret
    11f0:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 11f6 <sowrite+0x316>
			11f2: IMAGE_REL_AMD64_REL32	__imp__errno
    11f6:	4c 8d 05 90 01 00 00 	lea    0x190(%rip),%r8        # 138d <sotranslate_out+0x1d>
			11f9: IMAGE_REL_AMD64_REL32	.rdata
    11fd:	ba 80 00 00 00       	mov    $0x80,%edx
    1202:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 1231 <sowrite+0x351>
			1205: IMAGE_REL_AMD64_REL32	.rdata
    1209:	8b 00                	mov    (%rax),%eax
    120b:	89 44 24 20          	mov    %eax,0x20(%rsp)
    120f:	44 8b 8b 54 01 00 00 	mov    0x154(%rbx),%r9d
    1216:	e8 00 00 00 00       	call   121b <sowrite+0x33b>
			1217: IMAGE_REL_AMD64_REL32	g_log
    121b:	e9 fd fe ff ff       	jmp    111d <sowrite+0x23d>
    1220:	45 31 c9             	xor    %r9d,%r9d
    1223:	4d 89 f0             	mov    %r14,%r8
    1226:	48 89 ea             	mov    %rbp,%rdx
    1229:	48 89 d9             	mov    %rbx,%rcx
    122c:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
    1231:	89 44 24 38          	mov    %eax,0x38(%rsp)
    1235:	e8 00 00 00 00       	call   123a <sowrite+0x35a>
			1236: IMAGE_REL_AMD64_REL32	slirp_send
    123a:	44 8b 5c 24 38       	mov    0x38(%rsp),%r11d
    123f:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
    1244:	41 01 c4             	add    %eax,%r12d
    1247:	85 c0                	test   %eax,%eax
    1249:	45 0f 4f dc          	cmovg  %r12d,%r11d
    124d:	49 63 c3             	movslq %r11d,%rax
    1250:	4c 0f 4f d0          	cmovg  %rax,%r10
    1254:	e9 3b fd ff ff       	jmp    f94 <sowrite+0xb4>
    1259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1260:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    1264:	ba 01 00 00 00       	mov    $0x1,%edx
    1269:	44 89 5c 24 30       	mov    %r11d,0x30(%rsp)
    126e:	e8 00 00 00 00       	call   1273 <sowrite+0x393>
			126f: IMAGE_REL_AMD64_REL32	slirp_shutdown_wrap
    1273:	8b 83 54 01 00 00    	mov    0x154(%rbx),%eax
    1279:	44 8b 5c 24 30       	mov    0x30(%rsp),%r11d
    127e:	e9 2d ff ff ff       	jmp    11b0 <sowrite+0x2d0>
    1283:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    1287:	ba 01 00 00 00       	mov    $0x1,%edx
    128c:	e8 00 00 00 00       	call   1291 <sowrite+0x3b1>
			128d: IMAGE_REL_AMD64_REL32	slirp_shutdown_wrap
    1291:	8b 93 54 01 00 00    	mov    0x154(%rbx),%edx
    1297:	e9 90 fe ff ff       	jmp    112c <sowrite+0x24c>
    129c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000012a0 <soisfconnecting>:
    12a0:	8b 81 54 01 00 00    	mov    0x154(%rcx),%eax
    12a6:	83 e0 a2             	and    $0xffffffa2,%eax
    12a9:	83 c8 02             	or     $0x2,%eax
    12ac:	89 81 54 01 00 00    	mov    %eax,0x154(%rcx)
    12b2:	31 c0                	xor    %eax,%eax
    12b4:	31 c9                	xor    %ecx,%ecx
    12b6:	c3                   	ret
    12b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    12be:	00 00 

00000000000012c0 <soisfconnected>:
    12c0:	8b 81 54 01 00 00    	mov    0x154(%rcx),%eax
    12c6:	83 e0 bc             	and    $0xffffffbc,%eax
    12c9:	83 c8 04             	or     $0x4,%eax
    12cc:	89 81 54 01 00 00    	mov    %eax,0x154(%rcx)
    12d2:	31 c0                	xor    %eax,%eax
    12d4:	31 c9                	xor    %ecx,%ecx
    12d6:	c3                   	ret
    12d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    12de:	00 00 

00000000000012e0 <sofwdrain>:
    12e0:	48 83 ec 28          	sub    $0x28,%rsp
    12e4:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
    12ea:	8b 81 54 01 00 00    	mov    0x154(%rcx),%eax
    12f0:	49 89 c8             	mov    %rcx,%r8
    12f3:	85 d2                	test   %edx,%edx
    12f5:	74 19                	je     1310 <sofwdrain+0x30>
    12f7:	83 c8 40             	or     $0x40,%eax
    12fa:	41 89 80 54 01 00 00 	mov    %eax,0x154(%r8)
    1301:	48 83 c4 28          	add    $0x28,%rsp
    1305:	31 c0                	xor    %eax,%eax
    1307:	31 d2                	xor    %edx,%edx
    1309:	31 c9                	xor    %ecx,%ecx
    130b:	45 31 c0             	xor    %r8d,%r8d
    130e:	c3                   	ret
    130f:	90                   	nop
    1310:	a8 01                	test   $0x1,%al
    1312:	74 34                	je     1348 <sofwdrain+0x68>
    1314:	89 c2                	mov    %eax,%edx
    1316:	89 c1                	mov    %eax,%ecx
    1318:	81 e2 00 f0 00 00    	and    $0xf000,%edx
    131e:	83 e1 fd             	and    $0xfffffffd,%ecx
    1321:	83 ca 01             	or     $0x1,%edx
    1324:	83 c9 10             	or     $0x10,%ecx
    1327:	a8 08                	test   $0x8,%al
    1329:	89 d0                	mov    %edx,%eax
    132b:	0f 44 c1             	cmove  %ecx,%eax
    132e:	41 89 80 54 01 00 00 	mov    %eax,0x154(%r8)
    1335:	48 83 c4 28          	add    $0x28,%rsp
    1339:	31 c0                	xor    %eax,%eax
    133b:	31 d2                	xor    %edx,%edx
    133d:	31 c9                	xor    %ecx,%ecx
    133f:	45 31 c0             	xor    %r8d,%r8d
    1342:	c3                   	ret
    1343:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1348:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    134c:	ba 01 00 00 00       	mov    $0x1,%edx
    1351:	4c 89 44 24 30       	mov    %r8,0x30(%rsp)
    1356:	e8 00 00 00 00       	call   135b <sofwdrain+0x7b>
			1357: IMAGE_REL_AMD64_REL32	slirp_shutdown_wrap
    135b:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
    1360:	41 8b 80 54 01 00 00 	mov    0x154(%r8),%eax
    1367:	eb ab                	jmp    1314 <sofwdrain+0x34>
    1369:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001370 <sotranslate_out>:
    1370:	53                   	push   %rbx
    1371:	48 83 ec 40          	sub    $0x40,%rsp
    1375:	0f b7 02             	movzwl (%rdx),%eax
    1378:	49 89 c9             	mov    %rcx,%r9
    137b:	49 89 d2             	mov    %rdx,%r10
    137e:	66 83 f8 02          	cmp    $0x2,%ax
    1382:	0f 84 48 01 00 00    	je     14d0 <sotranslate_out+0x160>
    1388:	66 83 f8 17          	cmp    $0x17,%ax
    138c:	74 22                	je     13b0 <sotranslate_out+0x40>
    138e:	45 31 db             	xor    %r11d,%r11d
    1391:	44 89 d8             	mov    %r11d,%eax
    1394:	48 83 c4 40          	add    $0x40,%rsp
    1398:	5b                   	pop    %rbx
    1399:	31 d2                	xor    %edx,%edx
    139b:	31 c9                	xor    %ecx,%ecx
    139d:	45 31 c0             	xor    %r8d,%r8d
    13a0:	45 31 c9             	xor    %r9d,%r9d
    13a3:	45 31 d2             	xor    %r10d,%r10d
    13a6:	45 31 db             	xor    %r11d,%r11d
    13a9:	c3                   	ret
    13aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    13b0:	4c 8b 59 30          	mov    0x30(%rcx),%r11
    13b4:	48 8d 49 58          	lea    0x58(%rcx),%rcx
    13b8:	41 80 bb 90 17 00 00 	cmpb   $0x0,0x1790(%r11)
    13bf:	00 
    13c0:	75 76                	jne    1438 <sotranslate_out+0xc8>
    13c2:	49 8b 41 58          	mov    0x58(%r9),%rax
    13c6:	49 8b 51 60          	mov    0x60(%r9),%rdx
    13ca:	49 33 43 48          	xor    0x48(%r11),%rax
    13ce:	49 33 53 50          	xor    0x50(%r11),%rdx
    13d2:	48 09 d0             	or     %rdx,%rax
    13d5:	75 61                	jne    1438 <sotranslate_out+0xc8>
    13d7:	41 0f b7 59 52       	movzwl 0x52(%r9),%ebx
    13dc:	4c 89 54 24 58       	mov    %r10,0x58(%rsp)
    13e1:	b9 35 00 00 00       	mov    $0x35,%ecx
    13e6:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
    13ed:	00 
    13ee:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
    13f5:	00 
    13f6:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 13fc <sotranslate_out+0x8c>
			13f8: IMAGE_REL_AMD64_REL32	__imp_htons
    13fc:	4c 8b 54 24 58       	mov    0x58(%rsp),%r10
    1401:	66 39 c3             	cmp    %ax,%bx
    1404:	0f 84 86 01 00 00    	je     1590 <sotranslate_out+0x220>
    140a:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1410 <sotranslate_out+0xa0>
			140c: IMAGE_REL_AMD64_REL32	__imp__errno
    1410:	41 bb ff ff ff ff    	mov    $0xffffffff,%r11d
    1416:	c7 00 01 00 00 00    	movl   $0x1,(%rax)
    141c:	44 89 d8             	mov    %r11d,%eax
    141f:	48 83 c4 40          	add    $0x40,%rsp
    1423:	5b                   	pop    %rbx
    1424:	31 d2                	xor    %edx,%edx
    1426:	31 c9                	xor    %ecx,%ecx
    1428:	45 31 c0             	xor    %r8d,%r8d
    142b:	45 31 c9             	xor    %r9d,%r9d
    142e:	45 31 d2             	xor    %r10d,%r10d
    1431:	45 31 db             	xor    %r11d,%r11d
    1434:	c3                   	ret
    1435:	0f 1f 00             	nopl   (%rax)
    1438:	41 0f b6 5b 2c       	movzbl 0x2c(%r11),%ebx
    143d:	49 8d 53 1c          	lea    0x1c(%r11),%rdx
    1441:	4c 89 54 24 58       	mov    %r10,0x58(%rsp)
    1446:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
    144b:	49 89 d8             	mov    %rbx,%r8
    144e:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
    1453:	49 c1 e8 03          	shr    $0x3,%r8
    1457:	41 83 e0 1f          	and    $0x1f,%r8d
    145b:	4c 89 44 24 28       	mov    %r8,0x28(%rsp)
    1460:	e8 00 00 00 00       	call   1465 <sotranslate_out+0xf5>
			1461: IMAGE_REL_AMD64_REL32	memcmp
    1465:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
    146a:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
    146f:	85 c0                	test   %eax,%eax
    1471:	4c 8b 54 24 58       	mov    0x58(%rsp),%r10
    1476:	0f 85 9c 00 00 00    	jne    1518 <sotranslate_out+0x1a8>
    147c:	89 d8                	mov    %ebx,%eax
    147e:	83 e0 07             	and    $0x7,%eax
    1481:	74 23                	je     14a6 <sotranslate_out+0x136>
    1483:	4c 8b 44 24 28       	mov    0x28(%rsp),%r8
    1488:	0f b6 c0             	movzbl %al,%eax
    148b:	b9 08 00 00 00       	mov    $0x8,%ecx
    1490:	29 c1                	sub    %eax,%ecx
    1492:	43 0f b6 54 01 58    	movzbl 0x58(%r9,%r8,1),%edx
    1498:	43 0f b6 44 03 1c    	movzbl 0x1c(%r11,%r8,1),%eax
    149e:	d3 fa                	sar    %cl,%edx
    14a0:	d3 f8                	sar    %cl,%eax
    14a2:	39 c2                	cmp    %eax,%edx
    14a4:	75 72                	jne    1518 <sotranslate_out+0x1a8>
    14a6:	41 80 bb 98 00 00 00 	cmpb   $0x0,0x98(%r11)
    14ad:	00 
    14ae:	0f 85 56 ff ff ff    	jne    140a <sotranslate_out+0x9a>
    14b4:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 14bb <sotranslate_out+0x14b>
			14b7: IMAGE_REL_AMD64_REL32	.refptr.in6addr_loopback
    14bb:	f3 0f 6f 00          	movdqu (%rax),%xmm0
    14bf:	41 0f 11 42 08       	movups %xmm0,0x8(%r10)
    14c4:	e9 c5 fe ff ff       	jmp    138e <sotranslate_out+0x1e>
    14c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    14d0:	48 8b 41 30          	mov    0x30(%rcx),%rax
    14d4:	8b 51 54             	mov    0x54(%rcx),%edx
    14d7:	39 50 44             	cmp    %edx,0x44(%rax)
    14da:	75 09                	jne    14e5 <sotranslate_out+0x175>
    14dc:	80 b8 90 17 00 00 01 	cmpb   $0x1,0x1790(%rax)
    14e3:	75 6b                	jne    1550 <sotranslate_out+0x1e0>
    14e5:	39 50 18             	cmp    %edx,0x18(%rax)
    14e8:	74 09                	je     14f3 <sotranslate_out+0x183>
    14ea:	83 fa ff             	cmp    $0xffffffff,%edx
    14ed:	0f 85 9b fe ff ff    	jne    138e <sotranslate_out+0x1e>
    14f3:	80 b8 98 00 00 00 00 	cmpb   $0x0,0x98(%rax)
    14fa:	0f 85 0a ff ff ff    	jne    140a <sotranslate_out+0x9a>
    1500:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 1507 <sotranslate_out+0x197>
			1503: IMAGE_REL_AMD64_REL32	.refptr.loopback_addr
    1507:	8b 00                	mov    (%rax),%eax
    1509:	41 89 42 04          	mov    %eax,0x4(%r10)
    150d:	e9 7c fe ff ff       	jmp    138e <sotranslate_out+0x1e>
    1512:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1518:	48 b8 00 00 00 00 00 	movabs $0x100000000000000,%rax
    151f:	00 00 01 
    1522:	48 c7 44 24 30 ff 02 	movq   $0x2ff,0x30(%rsp)
    1529:	00 00 
    152b:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    1530:	49 8b 41 58          	mov    0x58(%r9),%rax
    1534:	49 8b 51 60          	mov    0x60(%r9),%rdx
    1538:	48 33 44 24 30       	xor    0x30(%rsp),%rax
    153d:	48 33 54 24 38       	xor    0x38(%rsp),%rdx
    1542:	48 09 d0             	or     %rdx,%rax
    1545:	0f 85 43 fe ff ff    	jne    138e <sotranslate_out+0x1e>
    154b:	e9 56 ff ff ff       	jmp    14a6 <sotranslate_out+0x136>
    1550:	0f b7 59 52          	movzwl 0x52(%rcx),%ebx
    1554:	4c 89 54 24 58       	mov    %r10,0x58(%rsp)
    1559:	b9 35 00 00 00       	mov    $0x35,%ecx
    155e:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1564 <sotranslate_out+0x1f4>
			1560: IMAGE_REL_AMD64_REL32	__imp_htons
    1564:	4c 8b 54 24 58       	mov    0x58(%rsp),%r10
    1569:	66 39 c3             	cmp    %ax,%bx
    156c:	0f 85 98 fe ff ff    	jne    140a <sotranslate_out+0x9a>
    1572:	49 8d 52 02          	lea    0x2(%r10),%rdx
    1576:	49 8d 4a 04          	lea    0x4(%r10),%rcx
    157a:	e8 00 00 00 00       	call   157f <sotranslate_out+0x20f>
			157b: IMAGE_REL_AMD64_REL32	get_dns_addr
    157f:	85 c0                	test   %eax,%eax
    1581:	0f 89 07 fe ff ff    	jns    138e <sotranslate_out+0x1e>
    1587:	e9 7e fe ff ff       	jmp    140a <sotranslate_out+0x9a>
    158c:	0f 1f 40 00          	nopl   0x0(%rax)
    1590:	49 8d 52 02          	lea    0x2(%r10),%rdx
    1594:	49 8d 4a 08          	lea    0x8(%r10),%rcx
    1598:	4c 8d 44 24 30       	lea    0x30(%rsp),%r8
    159d:	e8 00 00 00 00       	call   15a2 <sotranslate_out+0x232>
			159e: IMAGE_REL_AMD64_REL32	get_dns6_addr
    15a2:	85 c0                	test   %eax,%eax
    15a4:	0f 88 60 fe ff ff    	js     140a <sotranslate_out+0x9a>
    15aa:	8b 44 24 30          	mov    0x30(%rsp),%eax
    15ae:	4c 8b 54 24 58       	mov    0x58(%rsp),%r10
    15b3:	44 8b 5c 24 20       	mov    0x20(%rsp),%r11d
    15b8:	41 89 42 18          	mov    %eax,0x18(%r10)
    15bc:	e9 d0 fd ff ff       	jmp    1391 <sotranslate_out+0x21>
    15c1:	0f 1f 40 00          	nopl   0x0(%rax)
    15c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    15cc:	00 00 00 00 

00000000000015d0 <sosendto>:
    15d0:	56                   	push   %rsi
    15d1:	53                   	push   %rbx
    15d2:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    15d9:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 15e0 <sosendto+0x10>
			15dc: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    15e0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    15e4:	48 89 cb             	mov    %rcx,%rbx
    15e7:	48 89 d6             	mov    %rdx,%rsi
    15ea:	0f 11 44 24 30       	movups %xmm0,0x30(%rsp)
    15ef:	0f 11 44 24 40       	movups %xmm0,0x40(%rsp)
    15f4:	0f 11 44 24 50       	movups %xmm0,0x50(%rsp)
    15f9:	0f 11 44 24 60       	movups %xmm0,0x60(%rsp)
    15fe:	0f 11 44 24 70       	movups %xmm0,0x70(%rsp)
    1603:	0f 11 84 24 80 00 00 	movups %xmm0,0x80(%rsp)
    160a:	00 
    160b:	0f 11 84 24 90 00 00 	movups %xmm0,0x90(%rsp)
    1612:	00 
    1613:	0f 11 84 24 a0 00 00 	movups %xmm0,0xa0(%rsp)
    161a:	00 
    161b:	f6 00 01             	testb  $0x1,(%rax)
    161e:	0f 85 1c 01 00 00    	jne    1740 <sosendto+0x170>
    1624:	f3 0f 6f 43 50       	movdqu 0x50(%rbx),%xmm0
    1629:	0f 11 44 24 30       	movups %xmm0,0x30(%rsp)
    162e:	f3 0f 6f 43 60       	movdqu 0x60(%rbx),%xmm0
    1633:	0f 11 44 24 40       	movups %xmm0,0x40(%rsp)
    1638:	f3 0f 6f 43 70       	movdqu 0x70(%rbx),%xmm0
    163d:	0f 11 44 24 50       	movups %xmm0,0x50(%rsp)
    1642:	f3 0f 6f 83 80 00 00 	movdqu 0x80(%rbx),%xmm0
    1649:	00 
    164a:	0f 11 44 24 60       	movups %xmm0,0x60(%rsp)
    164f:	f3 0f 6f 83 90 00 00 	movdqu 0x90(%rbx),%xmm0
    1656:	00 
    1657:	0f 11 44 24 70       	movups %xmm0,0x70(%rsp)
    165c:	f3 0f 6f 83 a0 00 00 	movdqu 0xa0(%rbx),%xmm0
    1663:	00 
    1664:	0f 11 84 24 80 00 00 	movups %xmm0,0x80(%rsp)
    166b:	00 
    166c:	f3 0f 6f 83 b0 00 00 	movdqu 0xb0(%rbx),%xmm0
    1673:	00 
    1674:	0f 11 84 24 90 00 00 	movups %xmm0,0x90(%rsp)
    167b:	00 
    167c:	f3 0f 6f 83 c0 00 00 	movdqu 0xc0(%rbx),%xmm0
    1683:	00 
    1684:	0f 11 84 24 a0 00 00 	movups %xmm0,0xa0(%rsp)
    168b:	00 
    168c:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
    1691:	48 89 d9             	mov    %rbx,%rcx
    1694:	e8 d7 fc ff ff       	call   1370 <sotranslate_out>
    1699:	83 f8 ff             	cmp    $0xffffffff,%eax
    169c:	74 7c                	je     171a <sosendto+0x14a>
    169e:	0f b7 44 24 30       	movzwl 0x30(%rsp),%eax
    16a3:	66 83 f8 02          	cmp    $0x2,%ax
    16a7:	0f 84 83 00 00 00    	je     1730 <sosendto+0x160>
    16ad:	66 83 f8 17          	cmp    $0x17,%ax
    16b1:	0f 85 96 01 00 00    	jne    184d <sosendto+0x27d>
    16b7:	b8 1c 00 00 00       	mov    $0x1c,%eax
    16bc:	48 8b 56 30          	mov    0x30(%rsi),%rdx
    16c0:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    16c4:	89 44 24 28          	mov    %eax,0x28(%rsp)
    16c8:	45 31 c9             	xor    %r9d,%r9d
    16cb:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
    16d0:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    16d5:	4c 63 46 38          	movslq 0x38(%rsi),%r8
    16d9:	e8 00 00 00 00       	call   16de <sosendto+0x10e>
			16da: IMAGE_REL_AMD64_REL32	slirp_sendto_wrap
    16de:	85 c0                	test   %eax,%eax
    16e0:	0f 88 5d 01 00 00    	js     1843 <sosendto+0x273>
    16e6:	8b 83 60 01 00 00    	mov    0x160(%rbx),%eax
    16ec:	85 c0                	test   %eax,%eax
    16ee:	74 14                	je     1704 <sosendto+0x134>
    16f0:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 16f7 <sosendto+0x127>
			16f3: IMAGE_REL_AMD64_REL32	.refptr.curtime
    16f7:	8b 00                	mov    (%rax),%eax
    16f9:	05 80 a9 03 00       	add    $0x3a980,%eax
    16fe:	89 83 60 01 00 00    	mov    %eax,0x160(%rbx)
    1704:	8b 83 54 01 00 00    	mov    0x154(%rbx),%eax
    170a:	25 00 f0 00 00       	and    $0xf000,%eax
    170f:	83 c8 04             	or     $0x4,%eax
    1712:	89 83 54 01 00 00    	mov    %eax,0x154(%rbx)
    1718:	31 c0                	xor    %eax,%eax
    171a:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    1721:	5b                   	pop    %rbx
    1722:	5e                   	pop    %rsi
    1723:	31 d2                	xor    %edx,%edx
    1725:	31 c9                	xor    %ecx,%ecx
    1727:	45 31 c0             	xor    %r8d,%r8d
    172a:	45 31 c9             	xor    %r9d,%r9d
    172d:	c3                   	ret
    172e:	66 90                	xchg   %ax,%ax
    1730:	b8 10 00 00 00       	mov    $0x10,%eax
    1735:	eb 85                	jmp    16bc <sosendto+0xec>
    1737:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    173e:	00 00 
    1740:	4c 8d 05 c9 01 00 00 	lea    0x1c9(%rip),%r8        # 1910 <sotranslate_in+0xb0>
			1743: IMAGE_REL_AMD64_REL32	.rdata
    1747:	ba 80 00 00 00       	mov    $0x80,%edx
    174c:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 177b <sosendto+0x1ab>
			174f: IMAGE_REL_AMD64_REL32	.rdata
    1753:	e8 00 00 00 00       	call   1758 <sosendto+0x188>
			1754: IMAGE_REL_AMD64_REL32	g_log
    1758:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 175f <sosendto+0x18f>
			175b: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    175f:	f6 00 01             	testb  $0x1,(%rax)
    1762:	0f 84 bc fe ff ff    	je     1624 <sosendto+0x54>
    1768:	49 89 d9             	mov    %rbx,%r9
    176b:	4c 8d 05 3c 00 00 00 	lea    0x3c(%rip),%r8        # 17ae <sosendto+0x1de>
			176e: IMAGE_REL_AMD64_REL32	.rdata
    1772:	ba 80 00 00 00       	mov    $0x80,%edx
    1777:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 17a6 <sosendto+0x1d6>
			177a: IMAGE_REL_AMD64_REL32	.rdata
    177e:	e8 00 00 00 00       	call   1783 <sosendto+0x1b3>
			177f: IMAGE_REL_AMD64_REL32	g_log
    1783:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 178a <sosendto+0x1ba>
			1786: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    178a:	f6 00 01             	testb  $0x1,(%rax)
    178d:	0f 84 91 fe ff ff    	je     1624 <sosendto+0x54>
    1793:	49 89 f1             	mov    %rsi,%r9
    1796:	4c 8d 05 d5 01 00 00 	lea    0x1d5(%rip),%r8        # 1972 <sotranslate_in+0x112>
			1799: IMAGE_REL_AMD64_REL32	.rdata
    179d:	ba 80 00 00 00       	mov    $0x80,%edx
    17a2:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 17d1 <sosendto+0x201>
			17a5: IMAGE_REL_AMD64_REL32	.rdata
    17a9:	e8 00 00 00 00       	call   17ae <sosendto+0x1de>
			17aa: IMAGE_REL_AMD64_REL32	g_log
    17ae:	f3 0f 6f 43 50       	movdqu 0x50(%rbx),%xmm0
    17b3:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 17ba <sosendto+0x1ea>
			17b6: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    17ba:	0f 11 44 24 30       	movups %xmm0,0x30(%rsp)
    17bf:	f3 0f 6f 43 60       	movdqu 0x60(%rbx),%xmm0
    17c4:	0f 11 44 24 40       	movups %xmm0,0x40(%rsp)
    17c9:	f3 0f 6f 43 70       	movdqu 0x70(%rbx),%xmm0
    17ce:	0f 11 44 24 50       	movups %xmm0,0x50(%rsp)
    17d3:	f3 0f 6f 83 80 00 00 	movdqu 0x80(%rbx),%xmm0
    17da:	00 
    17db:	0f 11 44 24 60       	movups %xmm0,0x60(%rsp)
    17e0:	f3 0f 6f 83 90 00 00 	movdqu 0x90(%rbx),%xmm0
    17e7:	00 
    17e8:	0f 11 44 24 70       	movups %xmm0,0x70(%rsp)
    17ed:	f3 0f 6f 83 a0 00 00 	movdqu 0xa0(%rbx),%xmm0
    17f4:	00 
    17f5:	0f 11 84 24 80 00 00 	movups %xmm0,0x80(%rsp)
    17fc:	00 
    17fd:	f3 0f 6f 83 b0 00 00 	movdqu 0xb0(%rbx),%xmm0
    1804:	00 
    1805:	0f 11 84 24 90 00 00 	movups %xmm0,0x90(%rsp)
    180c:	00 
    180d:	f3 0f 6f 83 c0 00 00 	movdqu 0xc0(%rbx),%xmm0
    1814:	00 
    1815:	0f 11 84 24 a0 00 00 	movups %xmm0,0xa0(%rsp)
    181c:	00 
    181d:	f6 00 01             	testb  $0x1,(%rax)
    1820:	0f 84 66 fe ff ff    	je     168c <sosendto+0xbc>
    1826:	4c 8d 05 dd 01 00 00 	lea    0x1dd(%rip),%r8        # 1a0a <sotranslate_in+0x1aa>
			1829: IMAGE_REL_AMD64_REL32	.rdata
    182d:	ba 80 00 00 00       	mov    $0x80,%edx
    1832:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 1861 <sotranslate_in+0x1>
			1835: IMAGE_REL_AMD64_REL32	.rdata
    1839:	e8 00 00 00 00       	call   183e <sosendto+0x26e>
			183a: IMAGE_REL_AMD64_REL32	g_log
    183e:	e9 49 fe ff ff       	jmp    168c <sosendto+0xbc>
    1843:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    1848:	e9 cd fe ff ff       	jmp    171a <sosendto+0x14a>
    184d:	e8 ae e7 ff ff       	call   0 <sockaddr_size.part.0>
    1852:	90                   	nop
    1853:	66 90                	xchg   %ax,%ax
    1855:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    185c:	00 00 00 00 

0000000000001860 <sotranslate_in>:
    1860:	53                   	push   %rbx
    1861:	48 83 ec 60          	sub    $0x60,%rsp
    1865:	31 c0                	xor    %eax,%eax
    1867:	4c 8b 51 30          	mov    0x30(%rcx),%r10
    186b:	66 89 44 24 4a       	mov    %ax,0x4a(%rsp)
    1870:	0f b7 02             	movzwl (%rdx),%eax
    1873:	49 89 c9             	mov    %rcx,%r9
    1876:	48 89 d3             	mov    %rdx,%rbx
    1879:	66 83 f8 02          	cmp    $0x2,%ax
    187d:	0f 84 0d 01 00 00    	je     1990 <sotranslate_in+0x130>
    1883:	66 83 f8 17          	cmp    $0x17,%ax
    1887:	0f 85 eb 00 00 00    	jne    1978 <sotranslate_in+0x118>
    188d:	45 0f b6 5a 2c       	movzbl 0x2c(%r10),%r11d
    1892:	48 8d 49 58          	lea    0x58(%rcx),%rcx
    1896:	49 8d 52 1c          	lea    0x1c(%r10),%rdx
    189a:	4c 89 4c 24 70       	mov    %r9,0x70(%rsp)
    189f:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    18a4:	4d 89 d8             	mov    %r11,%r8
    18a7:	44 88 5c 24 37       	mov    %r11b,0x37(%rsp)
    18ac:	49 c1 e8 03          	shr    $0x3,%r8
    18b0:	41 83 e0 1f          	and    $0x1f,%r8d
    18b4:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
    18b9:	e8 00 00 00 00       	call   18be <sotranslate_in+0x5e>
			18ba: IMAGE_REL_AMD64_REL32	memcmp
    18be:	85 c0                	test   %eax,%eax
    18c0:	75 75                	jne    1937 <sotranslate_in+0xd7>
    18c2:	44 0f b6 5c 24 37    	movzbl 0x37(%rsp),%r11d
    18c8:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    18cd:	4c 8b 4c 24 70       	mov    0x70(%rsp),%r9
    18d2:	41 83 e3 07          	and    $0x7,%r11d
    18d6:	74 25                	je     18fd <sotranslate_in+0x9d>
    18d8:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
    18dd:	45 0f b6 db          	movzbl %r11b,%r11d
    18e1:	b9 08 00 00 00       	mov    $0x8,%ecx
    18e6:	44 29 d9             	sub    %r11d,%ecx
    18e9:	43 0f b6 54 01 58    	movzbl 0x58(%r9,%r8,1),%edx
    18ef:	43 0f b6 44 02 1c    	movzbl 0x1c(%r10,%r8,1),%eax
    18f5:	d3 fa                	sar    %cl,%edx
    18f7:	d3 f8                	sar    %cl,%eax
    18f9:	39 c2                	cmp    %eax,%edx
    18fb:	75 3a                	jne    1937 <sotranslate_in+0xd7>
    18fd:	48 8b 0d 00 00 00 00 	mov    0x0(%rip),%rcx        # 1904 <sotranslate_in+0xa4>
			1900: IMAGE_REL_AMD64_REL32	.refptr.in6addr_loopback
    1904:	48 8b 43 08          	mov    0x8(%rbx),%rax
    1908:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    190c:	48 33 01             	xor    (%rcx),%rax
    190f:	48 33 51 08          	xor    0x8(%rcx),%rdx
    1913:	48 09 d0             	or     %rdx,%rax
    1916:	74 15                	je     192d <sotranslate_in+0xcd>
    1918:	49 8b 41 58          	mov    0x58(%r9),%rax
    191c:	49 8b 51 60          	mov    0x60(%r9),%rdx
    1920:	49 33 42 2e          	xor    0x2e(%r10),%rax
    1924:	49 33 52 36          	xor    0x36(%r10),%rdx
    1928:	48 09 d0             	or     %rdx,%rax
    192b:	74 0a                	je     1937 <sotranslate_in+0xd7>
    192d:	f3 41 0f 6f 41 58    	movdqu 0x58(%r9),%xmm0
    1933:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    1937:	66 0f ef c0          	pxor   %xmm0,%xmm0
    193b:	48 8d 4c 24 50       	lea    0x50(%rsp),%rcx
    1940:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
    1945:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
    194c:	00 
    194d:	4c 8d 44 24 4c       	lea    0x4c(%rsp),%r8
    1952:	0f 11 44 24 50       	movups %xmm0,0x50(%rsp)
    1957:	e8 00 00 00 00       	call   195c <sotranslate_in+0xfc>
			1958: IMAGE_REL_AMD64_REL32	get_dns6_addr
    195c:	85 c0                	test   %eax,%eax
    195e:	78 18                	js     1978 <sotranslate_in+0x118>
    1960:	0f b7 44 24 4a       	movzwl 0x4a(%rsp),%eax
    1965:	66 39 43 02          	cmp    %ax,0x2(%rbx)
    1969:	75 0d                	jne    1978 <sotranslate_in+0x118>
    196b:	8b 44 24 4c          	mov    0x4c(%rsp),%eax
    196f:	39 43 18             	cmp    %eax,0x18(%rbx)
    1972:	0f 84 88 00 00 00    	je     1a00 <sotranslate_in+0x1a0>
    1978:	48 83 c4 60          	add    $0x60,%rsp
    197c:	5b                   	pop    %rbx
    197d:	31 c0                	xor    %eax,%eax
    197f:	31 d2                	xor    %edx,%edx
    1981:	31 c9                	xor    %ecx,%ecx
    1983:	45 31 c0             	xor    %r8d,%r8d
    1986:	45 31 c9             	xor    %r9d,%r9d
    1989:	45 31 d2             	xor    %r10d,%r10d
    198c:	45 31 db             	xor    %r11d,%r11d
    198f:	c3                   	ret
    1990:	8b 51 54             	mov    0x54(%rcx),%edx
    1993:	41 8b 42 14          	mov    0x14(%r10),%eax
    1997:	89 d1                	mov    %edx,%ecx
    1999:	21 c1                	and    %eax,%ecx
    199b:	41 3b 4a 10          	cmp    0x10(%r10),%ecx
    199f:	74 37                	je     19d8 <sotranslate_in+0x178>
    19a1:	48 8d 4c 24 50       	lea    0x50(%rsp),%rcx
    19a6:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
    19ab:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
    19b2:	00 
    19b3:	e8 00 00 00 00       	call   19b8 <sotranslate_in+0x158>
			19b4: IMAGE_REL_AMD64_REL32	get_dns_addr
    19b8:	85 c0                	test   %eax,%eax
    19ba:	78 bc                	js     1978 <sotranslate_in+0x118>
    19bc:	0f b7 44 24 4a       	movzwl 0x4a(%rsp),%eax
    19c1:	66 39 43 02          	cmp    %ax,0x2(%rbx)
    19c5:	75 b1                	jne    1978 <sotranslate_in+0x118>
    19c7:	8b 44 24 50          	mov    0x50(%rsp),%eax
    19cb:	39 43 04             	cmp    %eax,0x4(%rbx)
    19ce:	75 a8                	jne    1978 <sotranslate_in+0x118>
    19d0:	eb 49                	jmp    1a1b <sotranslate_in+0x1bb>
    19d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    19d8:	89 d1                	mov    %edx,%ecx
    19da:	f7 d0                	not    %eax
    19dc:	f7 d1                	not    %ecx
    19de:	85 c1                	test   %eax,%ecx
    19e0:	74 4e                	je     1a30 <sotranslate_in+0x1d0>
    19e2:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 19e9 <sotranslate_in+0x189>
			19e5: IMAGE_REL_AMD64_REL32	.refptr.loopback_addr
    19e9:	8b 00                	mov    (%rax),%eax
    19eb:	39 43 04             	cmp    %eax,0x4(%rbx)
    19ee:	74 06                	je     19f6 <sotranslate_in+0x196>
    19f0:	41 3b 52 18          	cmp    0x18(%r10),%edx
    19f4:	74 ab                	je     19a1 <sotranslate_in+0x141>
    19f6:	41 8b 41 54          	mov    0x54(%r9),%eax
    19fa:	89 43 04             	mov    %eax,0x4(%rbx)
    19fd:	eb a2                	jmp    19a1 <sotranslate_in+0x141>
    19ff:	90                   	nop
    1a00:	48 8b 43 08          	mov    0x8(%rbx),%rax
    1a04:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    1a08:	48 33 44 24 50       	xor    0x50(%rsp),%rax
    1a0d:	48 33 54 24 58       	xor    0x58(%rsp),%rdx
    1a12:	48 09 d0             	or     %rdx,%rax
    1a15:	0f 85 5d ff ff ff    	jne    1978 <sotranslate_in+0x118>
    1a1b:	b9 35 00 00 00       	mov    $0x35,%ecx
    1a20:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a26 <sotranslate_in+0x1c6>
			1a22: IMAGE_REL_AMD64_REL32	__imp_htons
    1a26:	66 89 43 02          	mov    %ax,0x2(%rbx)
    1a2a:	e9 49 ff ff ff       	jmp    1978 <sotranslate_in+0x118>
    1a2f:	90                   	nop
    1a30:	41 8b 42 18          	mov    0x18(%r10),%eax
    1a34:	89 43 04             	mov    %eax,0x4(%rbx)
    1a37:	e9 65 ff ff ff       	jmp    19a1 <sotranslate_in+0x141>
    1a3c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000001a40 <sotranslate_accept>:
    1a40:	56                   	push   %rsi
    1a41:	53                   	push   %rbx
    1a42:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    1a49:	0f b7 41 50          	movzwl 0x50(%rcx),%eax
    1a4d:	4c 8b 51 30          	mov    0x30(%rcx),%r10
    1a51:	49 89 c9             	mov    %rcx,%r9
    1a54:	66 83 f8 02          	cmp    $0x2,%ax
    1a58:	0f 84 fa 01 00 00    	je     1c58 <sotranslate_accept+0x218>
    1a5e:	66 83 f8 17          	cmp    $0x17,%ax
    1a62:	0f 84 88 01 00 00    	je     1bf0 <sotranslate_accept+0x1b0>
    1a68:	66 83 f8 01          	cmp    $0x1,%ax
    1a6c:	74 22                	je     1a90 <sotranslate_accept+0x50>
    1a6e:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
    1a75:	5b                   	pop    %rbx
    1a76:	5e                   	pop    %rsi
    1a77:	31 c0                	xor    %eax,%eax
    1a79:	31 d2                	xor    %edx,%edx
    1a7b:	31 c9                	xor    %ecx,%ecx
    1a7d:	45 31 c0             	xor    %r8d,%r8d
    1a80:	45 31 c9             	xor    %r9d,%r9d
    1a83:	45 31 d2             	xor    %r10d,%r10d
    1a86:	45 31 db             	xor    %r11d,%r11d
    1a89:	c3                   	ret
    1a8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1a90:	66 0f ef c0          	pxor   %xmm0,%xmm0
    1a94:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
    1a9b:	00 
    1a9c:	0f 11 44 24 60       	movups %xmm0,0x60(%rsp)
    1aa1:	0f 11 44 24 50       	movups %xmm0,0x50(%rsp)
    1aa6:	0f 11 44 24 6c       	movups %xmm0,0x6c(%rsp)
    1aab:	41 80 7a 0d 00       	cmpb   $0x0,0xd(%r10)
    1ab0:	0f 85 da 01 00 00    	jne    1c90 <sotranslate_accept+0x250>
    1ab6:	41 80 7a 0e 00       	cmpb   $0x0,0xe(%r10)
    1abb:	0f 84 af 04 00 00    	je     1f70 <sotranslate_accept+0x530>
    1ac1:	41 b8 17 00 00 00    	mov    $0x17,%r8d
    1ac7:	0f b6 81 52 01 00 00 	movzbl 0x152(%rcx),%eax
    1ace:	45 31 db             	xor    %r11d,%r11d
    1ad1:	66 44 89 41 50       	mov    %r8w,0x50(%rcx)
    1ad6:	f3 41 0f 6f 42 2e    	movdqu 0x2e(%r10),%xmm0
    1adc:	66 44 89 59 52       	mov    %r11w,0x52(%rcx)
    1ae1:	0f 11 41 58          	movups %xmm0,0x58(%rcx)
    1ae5:	3c 06                	cmp    $0x6,%al
    1ae7:	0f 84 3b 03 00 00    	je     1e28 <sotranslate_accept+0x3e8>
    1aed:	3c 11                	cmp    $0x11,%al
    1aef:	0f 85 54 04 00 00    	jne    1f49 <sotranslate_accept+0x509>
    1af5:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
    1afc:	00 
    1afd:	45 31 c0             	xor    %r8d,%r8d
    1b00:	ba 02 00 00 00       	mov    $0x2,%edx
    1b05:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    1b0a:	b9 17 00 00 00       	mov    $0x17,%ecx
    1b0f:	e8 00 00 00 00       	call   1b14 <sotranslate_accept+0xd4>
			1b10: IMAGE_REL_AMD64_REL32	slirp_socket
    1b14:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
    1b19:	66 0f ef c9          	pxor   %xmm1,%xmm1
    1b1d:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
    1b24:	00 
    1b25:	48 89 c3             	mov    %rax,%rbx
    1b28:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    1b2c:	0f 84 70 03 00 00    	je     1ea2 <sotranslate_accept+0x462>
    1b32:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 1b39 <sotranslate_accept+0xf9>
			1b35: IMAGE_REL_AMD64_REL32	.refptr.in6addr_loopback
    1b39:	ba 17 00 00 00       	mov    $0x17,%edx
    1b3e:	0f 11 4c 24 62       	movups %xmm1,0x62(%rsp)
    1b43:	31 c9                	xor    %ecx,%ecx
    1b45:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    1b4a:	f3 0f 6f 00          	movdqu (%rax),%xmm0
    1b4e:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 1b55 <sotranslate_accept+0x115>
			1b51: IMAGE_REL_AMD64_REL32	__imp_htons
    1b55:	0f 11 4c 24 6c       	movups %xmm1,0x6c(%rsp)
    1b5a:	4c 89 8c 24 a0 00 00 	mov    %r9,0xa0(%rsp)
    1b61:	00 
    1b62:	66 89 54 24 60       	mov    %dx,0x60(%rsp)
    1b67:	48 89 c6             	mov    %rax,%rsi
    1b6a:	0f 11 44 24 68       	movups %xmm0,0x68(%rsp)
    1b6f:	ff d0                	call   *%rax
    1b71:	41 b8 1c 00 00 00    	mov    $0x1c,%r8d
    1b77:	48 8d 54 24 60       	lea    0x60(%rsp),%rdx
    1b7c:	48 89 d9             	mov    %rbx,%rcx
    1b7f:	66 89 44 24 62       	mov    %ax,0x62(%rsp)
    1b84:	e8 00 00 00 00       	call   1b89 <sotranslate_accept+0x149>
			1b85: IMAGE_REL_AMD64_REL32	slirp_bind_wrap
    1b89:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
    1b8e:	85 c0                	test   %eax,%eax
    1b90:	0f 85 ec 02 00 00    	jne    1e82 <sotranslate_accept+0x442>
    1b96:	4c 8d 44 24 4c       	lea    0x4c(%rsp),%r8
    1b9b:	48 8d 54 24 60       	lea    0x60(%rsp),%rdx
    1ba0:	48 89 d9             	mov    %rbx,%rcx
    1ba3:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    1ba8:	c7 44 24 4c 1c 00 00 	movl   $0x1c,0x4c(%rsp)
    1baf:	00 
    1bb0:	e8 00 00 00 00       	call   1bb5 <sotranslate_accept+0x175>
			1bb1: IMAGE_REL_AMD64_REL32	slirp_getsockname_wrap
    1bb5:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
    1bba:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
    1bc1:	00 
    1bc2:	85 c0                	test   %eax,%eax
    1bc4:	0f 85 38 03 00 00    	jne    1f02 <sotranslate_accept+0x4c2>
    1bca:	0f b7 44 24 62       	movzwl 0x62(%rsp),%eax
    1bcf:	49 89 59 18          	mov    %rbx,0x18(%r9)
    1bd3:	66 41 89 41 52       	mov    %ax,0x52(%r9)
    1bd8:	66 85 c0             	test   %ax,%ax
    1bdb:	0f 85 8d fe ff ff    	jne    1a6e <sotranslate_accept+0x2e>
    1be1:	e9 c6 01 00 00       	jmp    1dac <sotranslate_accept+0x36c>
    1be6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    1bed:	00 00 00 
    1bf0:	48 8b 0d 00 00 00 00 	mov    0x0(%rip),%rcx        # 1bf7 <sotranslate_accept+0x1b7>
			1bf3: IMAGE_REL_AMD64_REL32	.refptr.in6addr_any
    1bf7:	49 8b 41 58          	mov    0x58(%r9),%rax
    1bfb:	49 8b 51 60          	mov    0x60(%r9),%rdx
    1bff:	48 33 01             	xor    (%rcx),%rax
    1c02:	48 33 51 08          	xor    0x8(%rcx),%rdx
    1c06:	48 09 d0             	or     %rdx,%rax
    1c09:	74 1f                	je     1c2a <sotranslate_accept+0x1ea>
    1c0b:	48 8b 0d 00 00 00 00 	mov    0x0(%rip),%rcx        # 1c12 <sotranslate_accept+0x1d2>
			1c0e: IMAGE_REL_AMD64_REL32	.refptr.in6addr_loopback
    1c12:	49 8b 41 58          	mov    0x58(%r9),%rax
    1c16:	49 8b 51 60          	mov    0x60(%r9),%rdx
    1c1a:	48 33 01             	xor    (%rcx),%rax
    1c1d:	48 33 51 08          	xor    0x8(%rcx),%rdx
    1c21:	48 09 d0             	or     %rdx,%rax
    1c24:	0f 85 44 fe ff ff    	jne    1a6e <sotranslate_accept+0x2e>
    1c2a:	f3 41 0f 6f 42 2e    	movdqu 0x2e(%r10),%xmm0
    1c30:	41 0f 11 41 58       	movups %xmm0,0x58(%r9)
    1c35:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
    1c3c:	5b                   	pop    %rbx
    1c3d:	5e                   	pop    %rsi
    1c3e:	31 c0                	xor    %eax,%eax
    1c40:	31 d2                	xor    %edx,%edx
    1c42:	31 c9                	xor    %ecx,%ecx
    1c44:	45 31 c0             	xor    %r8d,%r8d
    1c47:	45 31 c9             	xor    %r9d,%r9d
    1c4a:	45 31 d2             	xor    %r10d,%r10d
    1c4d:	45 31 db             	xor    %r11d,%r11d
    1c50:	c3                   	ret
    1c51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1c58:	8b 41 54             	mov    0x54(%rcx),%eax
    1c5b:	85 c0                	test   %eax,%eax
    1c5d:	0f 85 a5 01 00 00    	jne    1e08 <sotranslate_accept+0x3c8>
    1c63:	41 8b 42 18          	mov    0x18(%r10),%eax
    1c67:	41 89 41 54          	mov    %eax,0x54(%r9)
    1c6b:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
    1c72:	5b                   	pop    %rbx
    1c73:	5e                   	pop    %rsi
    1c74:	31 c0                	xor    %eax,%eax
    1c76:	31 d2                	xor    %edx,%edx
    1c78:	31 c9                	xor    %ecx,%ecx
    1c7a:	45 31 c0             	xor    %r8d,%r8d
    1c7d:	45 31 c9             	xor    %r9d,%r9d
    1c80:	45 31 d2             	xor    %r10d,%r10d
    1c83:	45 31 db             	xor    %r11d,%r11d
    1c86:	c3                   	ret
    1c87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    1c8e:	00 00 
    1c90:	b8 02 00 00 00       	mov    $0x2,%eax
    1c95:	66 89 41 50          	mov    %ax,0x50(%rcx)
    1c99:	41 8b 42 18          	mov    0x18(%r10),%eax
    1c9d:	89 41 54             	mov    %eax,0x54(%rcx)
    1ca0:	31 c0                	xor    %eax,%eax
    1ca2:	66 89 41 52          	mov    %ax,0x52(%rcx)
    1ca6:	0f b6 81 52 01 00 00 	movzbl 0x152(%rcx),%eax
    1cad:	3c 06                	cmp    $0x6,%al
    1caf:	0f 84 93 01 00 00    	je     1e48 <sotranslate_accept+0x408>
    1cb5:	3c 11                	cmp    $0x11,%al
    1cb7:	0f 85 65 02 00 00    	jne    1f22 <sotranslate_accept+0x4e2>
    1cbd:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
    1cc4:	00 
    1cc5:	45 31 c0             	xor    %r8d,%r8d
    1cc8:	ba 02 00 00 00       	mov    $0x2,%edx
    1ccd:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    1cd2:	b9 02 00 00 00       	mov    $0x2,%ecx
    1cd7:	e8 00 00 00 00       	call   1cdc <sotranslate_accept+0x29c>
			1cd8: IMAGE_REL_AMD64_REL32	slirp_socket
    1cdc:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
    1ce1:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
    1ce8:	00 
    1ce9:	48 89 c3             	mov    %rax,%rbx
    1cec:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    1cf0:	0f 84 cc 01 00 00    	je     1ec2 <sotranslate_accept+0x482>
    1cf6:	be 02 00 00 00       	mov    $0x2,%esi
    1cfb:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    1d00:	b9 01 00 00 7f       	mov    $0x7f000001,%ecx
    1d05:	4c 89 8c 24 a0 00 00 	mov    %r9,0xa0(%rsp)
    1d0c:	00 
    1d0d:	48 c7 44 24 52 00 00 	movq   $0x0,0x52(%rsp)
    1d14:	00 00 
    1d16:	66 89 74 24 50       	mov    %si,0x50(%rsp)
    1d1b:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
    1d22:	00 00 
    1d24:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1d2a <sotranslate_accept+0x2ea>
			1d26: IMAGE_REL_AMD64_REL32	__imp_htonl
    1d2a:	31 c9                	xor    %ecx,%ecx
    1d2c:	89 44 24 54          	mov    %eax,0x54(%rsp)
    1d30:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 1d37 <sotranslate_accept+0x2f7>
			1d33: IMAGE_REL_AMD64_REL32	__imp_htons
    1d37:	48 89 c6             	mov    %rax,%rsi
    1d3a:	ff d0                	call   *%rax
    1d3c:	41 b8 10 00 00 00    	mov    $0x10,%r8d
    1d42:	48 8d 54 24 50       	lea    0x50(%rsp),%rdx
    1d47:	48 89 d9             	mov    %rbx,%rcx
    1d4a:	66 89 44 24 52       	mov    %ax,0x52(%rsp)
    1d4f:	e8 00 00 00 00       	call   1d54 <sotranslate_accept+0x314>
			1d50: IMAGE_REL_AMD64_REL32	slirp_bind_wrap
    1d54:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
    1d59:	85 c0                	test   %eax,%eax
    1d5b:	0f 85 01 01 00 00    	jne    1e62 <sotranslate_accept+0x422>
    1d61:	4c 8d 44 24 4c       	lea    0x4c(%rsp),%r8
    1d66:	48 8d 54 24 50       	lea    0x50(%rsp),%rdx
    1d6b:	48 89 d9             	mov    %rbx,%rcx
    1d6e:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    1d73:	c7 44 24 4c 10 00 00 	movl   $0x10,0x4c(%rsp)
    1d7a:	00 
    1d7b:	e8 00 00 00 00       	call   1d80 <sotranslate_accept+0x340>
			1d7c: IMAGE_REL_AMD64_REL32	slirp_getsockname_wrap
    1d80:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
    1d85:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
    1d8c:	00 
    1d8d:	85 c0                	test   %eax,%eax
    1d8f:	0f 85 4d 01 00 00    	jne    1ee2 <sotranslate_accept+0x4a2>
    1d95:	0f b7 44 24 52       	movzwl 0x52(%rsp),%eax
    1d9a:	49 89 59 18          	mov    %rbx,0x18(%r9)
    1d9e:	66 41 89 41 52       	mov    %ax,0x52(%r9)
    1da3:	66 85 c0             	test   %ax,%ax
    1da6:	0f 85 c2 fc ff ff    	jne    1a6e <sotranslate_accept+0x2e>
    1dac:	4c 8d 05 58 02 00 00 	lea    0x258(%rip),%r8        # 200b <tcpx_listen+0x6b>
			1daf: IMAGE_REL_AMD64_REL32	.rdata
    1db3:	ba 10 00 00 00       	mov    $0x10,%edx
    1db8:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 1de7 <sotranslate_accept+0x3a7>
			1dbb: IMAGE_REL_AMD64_REL32	.rdata
    1dbf:	4c 89 8c 24 a0 00 00 	mov    %r9,0xa0(%rsp)
    1dc6:	00 
    1dc7:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    1dcc:	e8 00 00 00 00       	call   1dd1 <sotranslate_accept+0x391>
			1dcd: IMAGE_REL_AMD64_REL32	g_log
    1dd1:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
    1dd6:	41 b8 00 00 01 00    	mov    $0x10000,%r8d
    1ddc:	ba 00 c0 00 00       	mov    $0xc000,%edx
    1de1:	49 8b 8a 58 17 00 00 	mov    0x1758(%r10),%rcx
    1de8:	e8 00 00 00 00       	call   1ded <sotranslate_accept+0x3ad>
			1de9: IMAGE_REL_AMD64_REL32	g_rand_int_range
    1ded:	0f b7 c8             	movzwl %ax,%ecx
    1df0:	ff d6                	call   *%rsi
    1df2:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
    1df9:	00 
    1dfa:	66 41 89 41 52       	mov    %ax,0x52(%r9)
    1dff:	e9 6a fc ff ff       	jmp    1a6e <sotranslate_accept+0x2e>
    1e04:	0f 1f 40 00          	nopl   0x0(%rax)
    1e08:	48 8b 15 00 00 00 00 	mov    0x0(%rip),%rdx        # 1e0f <sotranslate_accept+0x3cf>
			1e0b: IMAGE_REL_AMD64_REL32	.refptr.loopback_addr
    1e0f:	33 02                	xor    (%rdx),%eax
    1e11:	48 8b 15 00 00 00 00 	mov    0x0(%rip),%rdx        # 1e18 <sotranslate_accept+0x3d8>
			1e14: IMAGE_REL_AMD64_REL32	.refptr.loopback_mask
    1e18:	85 02                	test   %eax,(%rdx)
    1e1a:	0f 85 4e fc ff ff    	jne    1a6e <sotranslate_accept+0x2e>
    1e20:	e9 3e fe ff ff       	jmp    1c63 <sotranslate_accept+0x223>
    1e25:	0f 1f 00             	nopl   (%rax)
    1e28:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
    1e2f:	00 
    1e30:	45 31 c0             	xor    %r8d,%r8d
    1e33:	ba 01 00 00 00       	mov    $0x1,%edx
    1e38:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    1e3d:	e9 c8 fc ff ff       	jmp    1b0a <sotranslate_accept+0xca>
    1e42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1e48:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
    1e4f:	00 
    1e50:	45 31 c0             	xor    %r8d,%r8d
    1e53:	ba 01 00 00 00       	mov    $0x1,%edx
    1e58:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    1e5d:	e9 70 fe ff ff       	jmp    1cd2 <sotranslate_accept+0x292>
    1e62:	4c 8d 05 1b 02 00 00 	lea    0x21b(%rip),%r8        # 2084 <tcpx_listen+0xe4>
			1e65: IMAGE_REL_AMD64_REL32	.rdata
    1e69:	ba 04 00 00 00       	mov    $0x4,%edx
    1e6e:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 1e9d <sotranslate_accept+0x45d>
			1e71: IMAGE_REL_AMD64_REL32	.rdata
    1e75:	e8 00 00 00 00       	call   1e7a <sotranslate_accept+0x43a>
			1e76: IMAGE_REL_AMD64_REL32	g_log
    1e7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1e80:	eb fe                	jmp    1e80 <sotranslate_accept+0x440>
    1e82:	4c 8d 05 1b 02 00 00 	lea    0x21b(%rip),%r8        # 20a4 <tcpx_listen+0x104>
			1e85: IMAGE_REL_AMD64_REL32	.rdata
    1e89:	ba 04 00 00 00       	mov    $0x4,%edx
    1e8e:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 1ebd <sotranslate_accept+0x47d>
			1e91: IMAGE_REL_AMD64_REL32	.rdata
    1e95:	e8 00 00 00 00       	call   1e9a <sotranslate_accept+0x45a>
			1e96: IMAGE_REL_AMD64_REL32	g_log
    1e9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1ea0:	eb fe                	jmp    1ea0 <sotranslate_accept+0x460>
    1ea2:	4c 8d 05 f0 01 00 00 	lea    0x1f0(%rip),%r8        # 2099 <tcpx_listen+0xf9>
			1ea5: IMAGE_REL_AMD64_REL32	.rdata
    1ea9:	ba 04 00 00 00       	mov    $0x4,%edx
    1eae:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 1edd <sotranslate_accept+0x49d>
			1eb1: IMAGE_REL_AMD64_REL32	.rdata
    1eb5:	e8 00 00 00 00       	call   1eba <sotranslate_accept+0x47a>
			1eb6: IMAGE_REL_AMD64_REL32	g_log
    1eba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1ec0:	eb fe                	jmp    1ec0 <sotranslate_accept+0x480>
    1ec2:	4c 8d 05 f0 01 00 00 	lea    0x1f0(%rip),%r8        # 20b9 <tcpx_listen+0x119>
			1ec5: IMAGE_REL_AMD64_REL32	.rdata
    1ec9:	ba 04 00 00 00       	mov    $0x4,%edx
    1ece:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 1efd <sotranslate_accept+0x4bd>
			1ed1: IMAGE_REL_AMD64_REL32	.rdata
    1ed5:	e8 00 00 00 00       	call   1eda <sotranslate_accept+0x49a>
			1ed6: IMAGE_REL_AMD64_REL32	g_log
    1eda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1ee0:	eb fe                	jmp    1ee0 <sotranslate_accept+0x4a0>
    1ee2:	4c 8d 05 38 02 00 00 	lea    0x238(%rip),%r8        # 2121 <tcpx_listen+0x181>
			1ee5: IMAGE_REL_AMD64_REL32	.rdata
    1ee9:	ba 04 00 00 00       	mov    $0x4,%edx
    1eee:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 1f1d <sotranslate_accept+0x4dd>
			1ef1: IMAGE_REL_AMD64_REL32	.rdata
    1ef5:	e8 00 00 00 00       	call   1efa <sotranslate_accept+0x4ba>
			1ef6: IMAGE_REL_AMD64_REL32	g_log
    1efa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1f00:	eb fe                	jmp    1f00 <sotranslate_accept+0x4c0>
    1f02:	4c 8d 05 38 02 00 00 	lea    0x238(%rip),%r8        # 2141 <tcpx_listen+0x1a1>
			1f05: IMAGE_REL_AMD64_REL32	.rdata
    1f09:	ba 04 00 00 00       	mov    $0x4,%edx
    1f0e:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 1f3d <sotranslate_accept+0x4fd>
			1f11: IMAGE_REL_AMD64_REL32	.rdata
    1f15:	e8 00 00 00 00       	call   1f1a <sotranslate_accept+0x4da>
			1f16: IMAGE_REL_AMD64_REL32	g_log
    1f1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1f20:	eb fe                	jmp    1f20 <sotranslate_accept+0x4e0>
    1f22:	31 c0                	xor    %eax,%eax
    1f24:	4c 8d 0d a0 04 00 00 	lea    0x4a0(%rip),%r9        # 23cb <tcpx_listen+0x42b>
			1f27: IMAGE_REL_AMD64_REL32	.rdata
    1f2b:	41 b8 7a 04 00 00    	mov    $0x47a,%r8d
    1f31:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    1f36:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 1f8d <sotranslate_accept+0x54d>
			1f39: IMAGE_REL_AMD64_REL32	.rdata
    1f3d:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 1f6c <sotranslate_accept+0x52c>
			1f40: IMAGE_REL_AMD64_REL32	.rdata
    1f44:	e8 00 00 00 00       	call   1f49 <sotranslate_accept+0x509>
			1f45: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    1f49:	31 c9                	xor    %ecx,%ecx
    1f4b:	4c 8d 0d a0 04 00 00 	lea    0x4a0(%rip),%r9        # 23f2 <tcpx_listen+0x452>
			1f4e: IMAGE_REL_AMD64_REL32	.rdata
    1f52:	41 b8 a5 04 00 00    	mov    $0x4a5,%r8d
    1f58:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    1f5d:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 1fb4 <tcpx_listen+0x14>
			1f60: IMAGE_REL_AMD64_REL32	.rdata
    1f64:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 1f93 <sotranslate_accept+0x553>
			1f67: IMAGE_REL_AMD64_REL32	.rdata
    1f6b:	e8 00 00 00 00       	call   1f70 <sotranslate_accept+0x530>
			1f6c: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    1f70:	31 c0                	xor    %eax,%eax
    1f72:	4c 8d 0d a0 04 00 00 	lea    0x4a0(%rip),%r9        # 2419 <tcpx_listen+0x479>
			1f75: IMAGE_REL_AMD64_REL32	.rdata
    1f79:	41 b8 c4 04 00 00    	mov    $0x4c4,%r8d
    1f7f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    1f84:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 1fdb <tcpx_listen+0x3b>
			1f87: IMAGE_REL_AMD64_REL32	.rdata
    1f8b:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 1fba <tcpx_listen+0x1a>
			1f8e: IMAGE_REL_AMD64_REL32	.rdata
    1f92:	e8 00 00 00 00       	call   1f97 <sotranslate_accept+0x557>
			1f93: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    1f97:	90                   	nop
    1f98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    1f9f:	00 

0000000000001fa0 <tcpx_listen>:
    1fa0:	41 57                	push   %r15
    1fa2:	41 56                	push   %r14
    1fa4:	41 55                	push   %r13
    1fa6:	41 54                	push   %r12
    1fa8:	55                   	push   %rbp
    1fa9:	57                   	push   %rdi
    1faa:	56                   	push   %rsi
    1fab:	53                   	push   %rbx
    1fac:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    1fb3:	4c 8b 25 00 00 00 00 	mov    0x0(%rip),%r12        # 1fba <tcpx_listen+0x1a>
			1fb6: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    1fba:	8b ac 24 28 01 00 00 	mov    0x128(%rsp),%ebp
    1fc1:	48 89 ce             	mov    %rcx,%rsi
    1fc4:	48 89 d3             	mov    %rdx,%rbx
    1fc7:	45 89 c5             	mov    %r8d,%r13d
    1fca:	4c 89 cf             	mov    %r9,%rdi
    1fcd:	c7 44 24 4c 01 00 00 	movl   $0x1,0x4c(%rsp)
    1fd4:	00 
    1fd5:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
    1fdc:	00 
    1fdd:	41 f6 04 24 01       	testb  $0x1,(%r12)
    1fe2:	0f 85 48 03 00 00    	jne    2330 <tcpx_listen+0x390>
    1fe8:	0f b7 03             	movzwl (%rbx),%eax
    1feb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    1fef:	45 31 c9             	xor    %r9d,%r9d
    1ff2:	c6 84 24 a0 00 00 00 	movb   $0x0,0xa0(%rsp)
    1ff9:	00 
    1ffa:	c7 44 24 5a 00 00 00 	movl   $0x0,0x5a(%rsp)
    2001:	00 
    2002:	66 44 89 4c 24 5e    	mov    %r9w,0x5e(%rsp)
    2008:	0f 11 44 24 60       	movups %xmm0,0x60(%rsp)
    200d:	0f 11 44 24 70       	movups %xmm0,0x70(%rsp)
    2012:	0f 11 84 24 80 00 00 	movups %xmm0,0x80(%rsp)
    2019:	00 
    201a:	0f 11 84 24 90 00 00 	movups %xmm0,0x90(%rsp)
    2021:	00 
    2022:	66 83 f8 02          	cmp    $0x2,%ax
    2026:	74 0a                	je     2032 <tcpx_listen+0x92>
    2028:	66 83 f8 17          	cmp    $0x17,%ax
    202c:	0f 85 45 04 00 00    	jne    2477 <tcpx_listen+0x4d7>
    2032:	4c 8d 74 24 5a       	lea    0x5a(%rsp),%r14
    2037:	41 b9 41 00 00 00    	mov    $0x41,%r9d
    203d:	44 89 ea             	mov    %r13d,%edx
    2040:	c7 44 24 30 0a 00 00 	movl   $0xa,0x30(%rsp)
    2047:	00 
    2048:	c7 44 24 28 06 00 00 	movl   $0x6,0x28(%rsp)
    204f:	00 
    2050:	4c 8b 3d 00 00 00 00 	mov    0x0(%rip),%r15        # 2057 <tcpx_listen+0xb7>
			2053: IMAGE_REL_AMD64_REL32	__imp_getnameinfo
    2057:	4c 8d 44 24 60       	lea    0x60(%rsp),%r8
    205c:	48 89 d9             	mov    %rbx,%rcx
    205f:	4c 89 74 24 20       	mov    %r14,0x20(%rsp)
    2064:	41 ff d7             	call   *%r15
    2067:	85 c0                	test   %eax,%eax
    2069:	0f 85 ab 04 00 00    	jne    251a <tcpx_listen+0x57a>
    206f:	41 f6 04 24 01       	testb  $0x1,(%r12)
    2074:	0f 85 d6 02 00 00    	jne    2350 <tcpx_listen+0x3b0>
    207a:	0f b7 07             	movzwl (%rdi),%eax
    207d:	66 83 f8 02          	cmp    $0x2,%ax
    2081:	74 0a                	je     208d <tcpx_listen+0xed>
    2083:	66 83 f8 17          	cmp    $0x17,%ax
    2087:	0f 85 c3 03 00 00    	jne    2450 <tcpx_listen+0x4b0>
    208d:	c7 44 24 30 0a 00 00 	movl   $0xa,0x30(%rsp)
    2094:	00 
    2095:	41 b9 41 00 00 00    	mov    $0x41,%r9d
    209b:	4c 8d 44 24 60       	lea    0x60(%rsp),%r8
    20a0:	48 89 f9             	mov    %rdi,%rcx
    20a3:	c7 44 24 28 06 00 00 	movl   $0x6,0x28(%rsp)
    20aa:	00 
    20ab:	8b 94 24 20 01 00 00 	mov    0x120(%rsp),%edx
    20b2:	4c 89 74 24 20       	mov    %r14,0x20(%rsp)
    20b7:	41 ff d7             	call   *%r15
    20ba:	85 c0                	test   %eax,%eax
    20bc:	0f 85 84 04 00 00    	jne    2546 <tcpx_listen+0x5a6>
    20c2:	41 f6 04 24 01       	testb  $0x1,(%r12)
    20c7:	0f 85 f3 02 00 00    	jne    23c0 <tcpx_listen+0x420>
    20cd:	89 e8                	mov    %ebp,%eax
    20cf:	f7 d0                	not    %eax
    20d1:	f6 c4 12             	test   $0x12,%ah
    20d4:	0f 84 98 04 00 00    	je     2572 <tcpx_listen+0x5d2>
    20da:	b9 b0 01 00 00       	mov    $0x1b0,%ecx
    20df:	e8 00 00 00 00       	call   20e4 <tcpx_listen+0x144>
			20e0: IMAGE_REL_AMD64_REL32	g_malloc
    20e4:	31 d2                	xor    %edx,%edx
    20e6:	41 b8 b0 01 00 00    	mov    $0x1b0,%r8d
    20ec:	49 89 c4             	mov    %rax,%r12
    20ef:	48 89 c1             	mov    %rax,%rcx
    20f2:	e8 00 00 00 00       	call   20f7 <tcpx_listen+0x157>
			20f3: IMAGE_REL_AMD64_REL32	memset
    20f7:	49 89 74 24 30       	mov    %rsi,0x30(%r12)
    20fc:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
    2100:	4c 89 e1             	mov    %r12,%rcx
    2103:	41 c6 84 24 52 01 00 	movb   $0x6,0x152(%r12)
    210a:	00 06 
    210c:	41 c7 84 24 54 01 00 	movl   $0x1,0x154(%r12)
    2113:	00 01 00 00 00 
    2118:	41 c7 44 24 28 ff ff 	movl   $0xffffffff,0x28(%r12)
    211f:	ff ff 
    2121:	41 0f 11 44 24 10    	movups %xmm0,0x10(%r12)
    2127:	e8 00 00 00 00       	call   212c <tcpx_listen+0x18c>
			2128: IMAGE_REL_AMD64_REL32	tcp_newtcpcb
    212c:	48 8d 96 c0 01 00 00 	lea    0x1c0(%rsi),%rdx
    2133:	4c 89 e1             	mov    %r12,%rcx
    2136:	49 89 84 24 58 01 00 	mov    %rax,0x158(%r12)
    213d:	00 
    213e:	e8 00 00 00 00       	call   2143 <tcpx_listen+0x1a3>
			213f: IMAGE_REL_AMD64_REL32	slirp_insque
    2143:	f7 c5 00 02 00 00    	test   $0x200,%ebp
    2149:	74 11                	je     215c <tcpx_listen+0x1bc>
    214b:	49 8b 84 24 58 01 00 	mov    0x158(%r12),%rax
    2152:	00 
    2153:	ba 2c 01 00 00       	mov    $0x12c,%edx
    2158:	66 89 50 16          	mov    %dx,0x16(%rax)
    215c:	41 8b 84 24 54 01 00 	mov    0x154(%r12),%eax
    2163:	00 
    2164:	25 00 f0 00 00       	and    $0xf000,%eax
    2169:	09 e8                	or     %ebp,%eax
    216b:	80 cc 01             	or     $0x1,%ah
    216e:	41 89 84 24 54 01 00 	mov    %eax,0x154(%r12)
    2175:	00 
    2176:	0f b7 07             	movzwl (%rdi),%eax
    2179:	66 83 f8 02          	cmp    $0x2,%ax
    217d:	0f 84 35 01 00 00    	je     22b8 <tcpx_listen+0x318>
    2183:	66 83 f8 17          	cmp    $0x17,%ax
    2187:	0f 85 5c 03 00 00    	jne    24e9 <tcpx_listen+0x549>
    218d:	b8 1c 00 00 00       	mov    $0x1c,%eax
    2192:	39 84 24 20 01 00 00 	cmp    %eax,0x120(%rsp)
    2199:	0f 8c 4f 03 00 00    	jl     24ee <tcpx_listen+0x54e>
    219f:	49 8d 94 24 d0 00 00 	lea    0xd0(%r12),%rdx
    21a6:	00 
    21a7:	a8 10                	test   $0x10,%al
    21a9:	0f 85 f1 02 00 00    	jne    24a0 <tcpx_listen+0x500>
    21af:	a8 08                	test   $0x8,%al
    21b1:	0f 85 09 03 00 00    	jne    24c0 <tcpx_listen+0x520>
    21b7:	a8 04                	test   $0x4,%al
    21b9:	0f 85 19 03 00 00    	jne    24d8 <tcpx_listen+0x538>
    21bf:	85 c0                	test   %eax,%eax
    21c1:	0f 85 69 02 00 00    	jne    2430 <tcpx_listen+0x490>
    21c7:	0f b7 0b             	movzwl (%rbx),%ecx
    21ca:	45 31 c0             	xor    %r8d,%r8d
    21cd:	ba 01 00 00 00       	mov    $0x1,%edx
    21d2:	e8 00 00 00 00       	call   21d7 <tcpx_listen+0x237>
			21d3: IMAGE_REL_AMD64_REL32	slirp_socket
    21d7:	48 89 c6             	mov    %rax,%rsi
    21da:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    21de:	0f 84 5c 02 00 00    	je     2440 <tcpx_listen+0x4a0>
    21e4:	66 83 3b 17          	cmpw   $0x17,(%rbx)
    21e8:	0f 84 da 00 00 00    	je     22c8 <tcpx_listen+0x328>
    21ee:	45 89 e8             	mov    %r13d,%r8d
    21f1:	48 89 da             	mov    %rbx,%rdx
    21f4:	48 89 f1             	mov    %rsi,%rcx
    21f7:	e8 00 00 00 00       	call   21fc <tcpx_listen+0x25c>
			21f8: IMAGE_REL_AMD64_REL32	slirp_bind_wrap
    21fc:	85 c0                	test   %eax,%eax
    21fe:	0f 88 fc 00 00 00    	js     2300 <tcpx_listen+0x360>
    2204:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    2209:	48 89 f1             	mov    %rsi,%rcx
    220c:	e8 00 00 00 00       	call   2211 <tcpx_listen+0x271>
			220d: IMAGE_REL_AMD64_REL32	slirp_listen_wrap
    2211:	85 c0                	test   %eax,%eax
    2213:	0f 88 e7 00 00 00    	js     2300 <tcpx_listen+0x360>
    2219:	c7 44 24 20 04 00 00 	movl   $0x4,0x20(%rsp)
    2220:	00 
    2221:	4c 8d 4c 24 4c       	lea    0x4c(%rsp),%r9
    2226:	ba ff ff 00 00       	mov    $0xffff,%edx
    222b:	48 89 f1             	mov    %rsi,%rcx
    222e:	41 b8 00 01 00 00    	mov    $0x100,%r8d
    2234:	e8 00 00 00 00       	call   2239 <tcpx_listen+0x299>
			2235: IMAGE_REL_AMD64_REL32	slirp_setsockopt_wrap
    2239:	c7 44 24 20 04 00 00 	movl   $0x4,0x20(%rsp)
    2240:	00 
    2241:	4c 8d 4c 24 54       	lea    0x54(%rsp),%r9
    2246:	48 89 f1             	mov    %rsi,%rcx
    2249:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    224f:	ba 06 00 00 00       	mov    $0x6,%edx
    2254:	c7 44 24 54 01 00 00 	movl   $0x1,0x54(%rsp)
    225b:	00 
    225c:	e8 00 00 00 00       	call   2261 <tcpx_listen+0x2c1>
			225d: IMAGE_REL_AMD64_REL32	slirp_setsockopt_wrap
    2261:	49 8d 54 24 50       	lea    0x50(%r12),%rdx
    2266:	48 89 f1             	mov    %rsi,%rcx
    2269:	4c 8d 44 24 50       	lea    0x50(%rsp),%r8
    226e:	c7 44 24 50 80 00 00 	movl   $0x80,0x50(%rsp)
    2275:	00 
    2276:	e8 00 00 00 00       	call   227b <tcpx_listen+0x2db>
			2277: IMAGE_REL_AMD64_REL32	slirp_getsockname_wrap
    227b:	4c 89 e1             	mov    %r12,%rcx
    227e:	e8 bd f7 ff ff       	call   1a40 <sotranslate_accept>
    2283:	49 89 74 24 10       	mov    %rsi,0x10(%r12)
    2288:	4c 89 e1             	mov    %r12,%rcx
    228b:	e8 00 00 00 00       	call   2290 <tcpx_listen+0x2f0>
			228c: IMAGE_REL_AMD64_REL32	slirp_register_poll_socket
    2290:	4c 89 e0             	mov    %r12,%rax
    2293:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    229a:	5b                   	pop    %rbx
    229b:	5e                   	pop    %rsi
    229c:	5f                   	pop    %rdi
    229d:	5d                   	pop    %rbp
    229e:	41 5c                	pop    %r12
    22a0:	41 5d                	pop    %r13
    22a2:	41 5e                	pop    %r14
    22a4:	41 5f                	pop    %r15
    22a6:	31 d2                	xor    %edx,%edx
    22a8:	31 c9                	xor    %ecx,%ecx
    22aa:	45 31 c0             	xor    %r8d,%r8d
    22ad:	45 31 c9             	xor    %r9d,%r9d
    22b0:	c3                   	ret
    22b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    22b8:	b8 10 00 00 00       	mov    $0x10,%eax
    22bd:	e9 d0 fe ff ff       	jmp    2192 <tcpx_listen+0x1f2>
    22c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    22c8:	c1 ed 0e             	shr    $0xe,%ebp
    22cb:	4c 8d 4c 24 54       	lea    0x54(%rsp),%r9
    22d0:	ba 29 00 00 00       	mov    $0x29,%edx
    22d5:	48 89 c1             	mov    %rax,%rcx
    22d8:	c7 44 24 20 04 00 00 	movl   $0x4,0x20(%rsp)
    22df:	00 
    22e0:	83 e5 01             	and    $0x1,%ebp
    22e3:	41 b8 1b 00 00 00    	mov    $0x1b,%r8d
    22e9:	89 6c 24 54          	mov    %ebp,0x54(%rsp)
    22ed:	e8 00 00 00 00       	call   22f2 <tcpx_listen+0x352>
			22ee: IMAGE_REL_AMD64_REL32	slirp_setsockopt_wrap
    22f2:	85 c0                	test   %eax,%eax
    22f4:	0f 89 f4 fe ff ff    	jns    21ee <tcpx_listen+0x24e>
    22fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2300:	48 8b 1d 00 00 00 00 	mov    0x0(%rip),%rbx        # 2307 <tcpx_listen+0x367>
			2303: IMAGE_REL_AMD64_REL32	__imp__errno
    2307:	ff d3                	call   *%rbx
    2309:	48 89 f1             	mov    %rsi,%rcx
    230c:	8b 38                	mov    (%rax),%edi
    230e:	e8 00 00 00 00       	call   2313 <tcpx_listen+0x373>
			230f: IMAGE_REL_AMD64_REL32	slirp_closesocket_wrap
    2313:	4c 89 e1             	mov    %r12,%rcx
    2316:	45 31 e4             	xor    %r12d,%r12d
    2319:	e8 a2 df ff ff       	call   2c0 <sofree>
    231e:	ff d3                	call   *%rbx
    2320:	89 38                	mov    %edi,(%rax)
    2322:	e9 69 ff ff ff       	jmp    2290 <tcpx_listen+0x2f0>
    2327:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    232e:	00 00 
    2330:	4c 8d 05 7f 02 00 00 	lea    0x27f(%rip),%r8        # 25b6 <tcp_listen+0x16>
			2333: IMAGE_REL_AMD64_REL32	.rdata
    2337:	ba 80 00 00 00       	mov    $0x80,%edx
    233c:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 236b <tcpx_listen+0x3cb>
			233f: IMAGE_REL_AMD64_REL32	.rdata
    2343:	e8 00 00 00 00       	call   2348 <tcpx_listen+0x3a8>
			2344: IMAGE_REL_AMD64_REL32	g_log
    2348:	e9 9b fc ff ff       	jmp    1fe8 <tcpx_listen+0x48>
    234d:	0f 1f 00             	nopl   (%rax)
    2350:	4c 8d 05 97 02 00 00 	lea    0x297(%rip),%r8        # 25ee <tcp_listen+0x4e>
			2353: IMAGE_REL_AMD64_REL32	.rdata
    2357:	ba 80 00 00 00       	mov    $0x80,%edx
    235c:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 238b <tcpx_listen+0x3eb>
			235f: IMAGE_REL_AMD64_REL32	.rdata
    2363:	e8 00 00 00 00       	call   2368 <tcpx_listen+0x3c8>
			2364: IMAGE_REL_AMD64_REL32	g_log
    2368:	41 f6 04 24 01       	testb  $0x1,(%r12)
    236d:	0f 84 07 fd ff ff    	je     207a <tcpx_listen+0xda>
    2373:	4c 8d 4c 24 60       	lea    0x60(%rsp),%r9
    2378:	4c 8d 05 a7 02 00 00 	lea    0x2a7(%rip),%r8        # 2626 <tcp_listen+0x86>
			237b: IMAGE_REL_AMD64_REL32	.rdata
    237f:	ba 80 00 00 00       	mov    $0x80,%edx
    2384:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 23b3 <tcpx_listen+0x413>
			2387: IMAGE_REL_AMD64_REL32	.rdata
    238b:	e8 00 00 00 00       	call   2390 <tcpx_listen+0x3f0>
			238c: IMAGE_REL_AMD64_REL32	g_log
    2390:	41 f6 04 24 01       	testb  $0x1,(%r12)
    2395:	0f 84 df fc ff ff    	je     207a <tcpx_listen+0xda>
    239b:	4d 89 f1             	mov    %r14,%r9
    239e:	4c 8d 05 b3 02 00 00 	lea    0x2b3(%rip),%r8        # 2658 <sodrop+0x28>
			23a1: IMAGE_REL_AMD64_REL32	.rdata
    23a5:	ba 80 00 00 00       	mov    $0x80,%edx
    23aa:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 23d9 <tcpx_listen+0x439>
			23ad: IMAGE_REL_AMD64_REL32	.rdata
    23b1:	e8 00 00 00 00       	call   23b6 <tcpx_listen+0x416>
			23b2: IMAGE_REL_AMD64_REL32	g_log
    23b6:	e9 bf fc ff ff       	jmp    207a <tcpx_listen+0xda>
    23bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    23c0:	4c 8d 4c 24 60       	lea    0x60(%rsp),%r9
    23c5:	4c 8d 05 bf 02 00 00 	lea    0x2bf(%rip),%r8        # 268b <soassign_guest_addr_if_needed+0xb>
			23c8: IMAGE_REL_AMD64_REL32	.rdata
    23cc:	ba 80 00 00 00       	mov    $0x80,%edx
    23d1:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 2400 <tcpx_listen+0x460>
			23d4: IMAGE_REL_AMD64_REL32	.rdata
    23d8:	e8 00 00 00 00       	call   23dd <tcpx_listen+0x43d>
			23d9: IMAGE_REL_AMD64_REL32	g_log
    23dd:	41 f6 04 24 01       	testb  $0x1,(%r12)
    23e2:	0f 84 e5 fc ff ff    	je     20cd <tcpx_listen+0x12d>
    23e8:	4d 89 f1             	mov    %r14,%r9
    23eb:	4c 8d 05 cb 02 00 00 	lea    0x2cb(%rip),%r8        # 26bd <soassign_guest_addr_if_needed+0x3d>
			23ee: IMAGE_REL_AMD64_REL32	.rdata
    23f2:	ba 80 00 00 00       	mov    $0x80,%edx
    23f7:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 2426 <tcpx_listen+0x486>
			23fa: IMAGE_REL_AMD64_REL32	.rdata
    23fe:	e8 00 00 00 00       	call   2403 <tcpx_listen+0x463>
			23ff: IMAGE_REL_AMD64_REL32	g_log
    2403:	41 f6 04 24 01       	testb  $0x1,(%r12)
    2408:	0f 84 bf fc ff ff    	je     20cd <tcpx_listen+0x12d>
    240e:	41 89 e9             	mov    %ebp,%r9d
    2411:	4c 8d 05 d7 02 00 00 	lea    0x2d7(%rip),%r8        # 26ef <soassign_guest_addr_if_needed+0x6f>
			2414: IMAGE_REL_AMD64_REL32	.rdata
    2418:	ba 80 00 00 00       	mov    $0x80,%edx
    241d:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 244c <tcpx_listen+0x4ac>
			2420: IMAGE_REL_AMD64_REL32	.rdata
    2424:	e8 00 00 00 00       	call   2429 <tcpx_listen+0x489>
			2425: IMAGE_REL_AMD64_REL32	g_log
    2429:	e9 9f fc ff ff       	jmp    20cd <tcpx_listen+0x12d>
    242e:	66 90                	xchg   %ax,%ax
    2430:	0f b6 07             	movzbl (%rdi),%eax
    2433:	41 88 84 24 d0 00 00 	mov    %al,0xd0(%r12)
    243a:	00 
    243b:	e9 87 fd ff ff       	jmp    21c7 <tcpx_listen+0x227>
    2440:	48 8b 1d 00 00 00 00 	mov    0x0(%rip),%rbx        # 2447 <tcpx_listen+0x4a7>
			2443: IMAGE_REL_AMD64_REL32	__imp__errno
    2447:	ff d3                	call   *%rbx
    2449:	8b 38                	mov    (%rax),%edi
    244b:	e9 c3 fe ff ff       	jmp    2313 <tcpx_listen+0x373>
    2450:	31 c9                	xor    %ecx,%ecx
    2452:	4c 8d 0d c8 04 00 00 	lea    0x4c8(%rip),%r9        # 2921 <sorecvfrom+0xb1>
			2455: IMAGE_REL_AMD64_REL32	.rdata
    2459:	41 b8 54 03 00 00    	mov    $0x354,%r8d
    245f:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    2464:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 24bb <tcpx_listen+0x51b>
			2467: IMAGE_REL_AMD64_REL32	.rdata
    246b:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 249a <tcpx_listen+0x4fa>
			246e: IMAGE_REL_AMD64_REL32	.rdata
    2472:	e8 00 00 00 00       	call   2477 <tcpx_listen+0x4d7>
			2473: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    2477:	45 31 c0             	xor    %r8d,%r8d
    247a:	4c 8d 0d c8 04 00 00 	lea    0x4c8(%rip),%r9        # 2949 <sorecvfrom+0xd9>
			247d: IMAGE_REL_AMD64_REL32	.rdata
    2481:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 24d8 <tcpx_listen+0x538>
			2484: IMAGE_REL_AMD64_REL32	.rdata
    2488:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    248d:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 24bc <tcpx_listen+0x51c>
			2490: IMAGE_REL_AMD64_REL32	.rdata
    2494:	41 b8 49 03 00 00    	mov    $0x349,%r8d
    249a:	e8 00 00 00 00       	call   249f <tcpx_listen+0x4ff>
			249b: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    249f:	90                   	nop
    24a0:	f3 0f 6f 07          	movdqu (%rdi),%xmm0
    24a4:	0f 11 02             	movups %xmm0,(%rdx)
    24a7:	f3 0f 6f 44 07 f0    	movdqu -0x10(%rdi,%rax,1),%xmm0
    24ad:	0f 11 44 02 f0       	movups %xmm0,-0x10(%rdx,%rax,1)
    24b2:	e9 10 fd ff ff       	jmp    21c7 <tcpx_listen+0x227>
    24b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    24be:	00 00 
    24c0:	48 8b 0f             	mov    (%rdi),%rcx
    24c3:	48 89 0a             	mov    %rcx,(%rdx)
    24c6:	48 8b 4c 07 f8       	mov    -0x8(%rdi,%rax,1),%rcx
    24cb:	48 89 4c 02 f8       	mov    %rcx,-0x8(%rdx,%rax,1)
    24d0:	e9 f2 fc ff ff       	jmp    21c7 <tcpx_listen+0x227>
    24d5:	0f 1f 00             	nopl   (%rax)
    24d8:	8b 0f                	mov    (%rdi),%ecx
    24da:	89 0a                	mov    %ecx,(%rdx)
    24dc:	8b 4c 07 fc          	mov    -0x4(%rdi,%rax,1),%ecx
    24e0:	89 4c 02 fc          	mov    %ecx,-0x4(%rdx,%rax,1)
    24e4:	e9 de fc ff ff       	jmp    21c7 <tcpx_listen+0x227>
    24e9:	e8 12 db ff ff       	call   0 <sockaddr_size.part.0>
    24ee:	48 8d 05 1c 03 00 00 	lea    0x31c(%rip),%rax        # 2811 <soassign_guest_addr_if_needed+0x191>
			24f1: IMAGE_REL_AMD64_REL32	.rdata
    24f5:	4c 8d 0d b8 04 00 00 	lea    0x4b8(%rip),%r9        # 29b4 <sorecvfrom+0x144>
			24f8: IMAGE_REL_AMD64_REL32	.rdata
    24fc:	41 b8 b0 00 00 00    	mov    $0xb0,%r8d
    2502:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    2507:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 250e <tcpx_listen+0x56e>
			250a: IMAGE_REL_AMD64_REL32	.rdata
    250e:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 253d <tcpx_listen+0x59d>
			2511: IMAGE_REL_AMD64_REL32	.rdata
    2515:	e8 00 00 00 00       	call   251a <tcpx_listen+0x57a>
			2516: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    251a:	48 8d 05 8e 02 00 00 	lea    0x28e(%rip),%rax        # 27af <soassign_guest_addr_if_needed+0x12f>
			251d: IMAGE_REL_AMD64_REL32	.rdata
    2521:	4c 8d 0d c8 04 00 00 	lea    0x4c8(%rip),%r9        # 29f0 <sorecvfrom+0x180>
			2524: IMAGE_REL_AMD64_REL32	.rdata
    2528:	41 b8 3d 03 00 00    	mov    $0x33d,%r8d
    252e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    2533:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 258a <tcpx_listen+0x5ea>
			2536: IMAGE_REL_AMD64_REL32	.rdata
    253a:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 2569 <tcpx_listen+0x5c9>
			253d: IMAGE_REL_AMD64_REL32	.rdata
    2541:	e8 00 00 00 00       	call   2546 <tcpx_listen+0x5a6>
			2542: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    2546:	48 8d 05 8e 02 00 00 	lea    0x28e(%rip),%rax        # 27db <soassign_guest_addr_if_needed+0x15b>
			2549: IMAGE_REL_AMD64_REL32	.rdata
    254d:	4c 8d 0d c8 04 00 00 	lea    0x4c8(%rip),%r9        # 2a1c <sorecvfrom+0x1ac>
			2550: IMAGE_REL_AMD64_REL32	.rdata
    2554:	41 b8 4f 03 00 00    	mov    $0x34f,%r8d
    255a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    255f:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 25b6 <tcp_listen+0x16>
			2562: IMAGE_REL_AMD64_REL32	.rdata
    2566:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 2595 <tcpx_listen+0x5f5>
			2569: IMAGE_REL_AMD64_REL32	.rdata
    256d:	e8 00 00 00 00       	call   2572 <tcpx_listen+0x5d2>
			256e: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    2572:	48 8d 05 e8 02 00 00 	lea    0x2e8(%rip),%rax        # 2861 <soassign_guest_addr_if_needed+0x1e1>
			2575: IMAGE_REL_AMD64_REL32	.rdata
    2579:	4c 8d 0d c8 04 00 00 	lea    0x4c8(%rip),%r9        # 2a48 <sorecvfrom+0x1d8>
			257c: IMAGE_REL_AMD64_REL32	.rdata
    2580:	41 b8 5f 03 00 00    	mov    $0x35f,%r8d
    2586:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    258b:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 25e2 <tcp_listen+0x42>
			258e: IMAGE_REL_AMD64_REL32	.rdata
    2592:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 25c1 <tcp_listen+0x21>
			2595: IMAGE_REL_AMD64_REL32	.rdata
    2599:	e8 00 00 00 00       	call   259e <tcpx_listen+0x5fe>
			259a: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    259e:	90                   	nop
    259f:	90                   	nop

00000000000025a0 <tcp_listen>:
    25a0:	48 83 ec 58          	sub    $0x58,%rsp
    25a4:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    25aa:	41 bb 02 00 00 00    	mov    $0x2,%r11d
    25b0:	89 d0                	mov    %edx,%eax
    25b2:	66 44 89 44 24 32    	mov    %r8w,0x32(%rsp)
    25b8:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
    25bd:	41 b8 10 00 00 00    	mov    $0x10,%r8d
    25c3:	89 44 24 34          	mov    %eax,0x34(%rsp)
    25c7:	8b 84 24 80 00 00 00 	mov    0x80(%rsp),%eax
    25ce:	c7 44 24 20 10 00 00 	movl   $0x10,0x20(%rsp)
    25d5:	00 
    25d6:	66 89 44 24 42       	mov    %ax,0x42(%rsp)
    25db:	8b 84 24 88 00 00 00 	mov    0x88(%rsp),%eax
    25e2:	44 89 4c 24 44       	mov    %r9d,0x44(%rsp)
    25e7:	4c 8d 4c 24 40       	lea    0x40(%rsp),%r9
    25ec:	89 44 24 28          	mov    %eax,0x28(%rsp)
    25f0:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
    25f7:	00 00 
    25f9:	66 44 89 54 24 30    	mov    %r10w,0x30(%rsp)
    25ff:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
    2606:	00 00 
    2608:	66 44 89 5c 24 40    	mov    %r11w,0x40(%rsp)
    260e:	e8 8d f9 ff ff       	call   1fa0 <tcpx_listen>
    2613:	48 83 c4 58          	add    $0x58,%rsp
    2617:	31 d2                	xor    %edx,%edx
    2619:	31 c9                	xor    %ecx,%ecx
    261b:	45 31 c0             	xor    %r8d,%r8d
    261e:	45 31 c9             	xor    %r9d,%r9d
    2621:	45 31 d2             	xor    %r10d,%r10d
    2624:	45 31 db             	xor    %r11d,%r11d
    2627:	c3                   	ret
    2628:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    262f:	00 

0000000000002630 <sodrop>:
    2630:	53                   	push   %rbx
    2631:	48 83 ec 20          	sub    $0x20,%rsp
    2635:	48 89 cb             	mov    %rcx,%rbx
    2638:	48 63 d2             	movslq %edx,%rdx
    263b:	48 8d 89 90 01 00 00 	lea    0x190(%rcx),%rcx
    2642:	e8 00 00 00 00       	call   2647 <sodrop+0x17>
			2643: IMAGE_REL_AMD64_REL32	sbdrop
    2647:	84 c0                	test   %al,%al
    2649:	74 25                	je     2670 <sodrop+0x40>
    264b:	48 8b 43 30          	mov    0x30(%rbx),%rax
    264f:	48 8b 88 78 17 00 00 	mov    0x1778(%rax),%rcx
    2656:	48 8b 80 70 17 00 00 	mov    0x1770(%rax),%rax
    265d:	48 8b 40 40          	mov    0x40(%rax),%rax
    2661:	48 83 c4 20          	add    $0x20,%rsp
    2665:	5b                   	pop    %rbx
    2666:	48 ff e0             	rex.W jmp *%rax
    2669:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2670:	48 83 c4 20          	add    $0x20,%rsp
    2674:	5b                   	pop    %rbx
    2675:	31 c0                	xor    %eax,%eax
    2677:	31 d2                	xor    %edx,%edx
    2679:	31 c9                	xor    %ecx,%ecx
    267b:	c3                   	ret
    267c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000002680 <soassign_guest_addr_if_needed>:
    2680:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
    2687:	66 0f ef c9          	pxor   %xmm1,%xmm1
    268b:	45 31 c0             	xor    %r8d,%r8d
    268e:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    2692:	c6 84 24 b0 00 00 00 	movb   $0x0,0xb0(%rsp)
    2699:	00 
    269a:	c7 44 24 4a 00 00 00 	movl   $0x0,0x4a(%rsp)
    26a1:	00 
    26a2:	66 44 89 44 24 4e    	mov    %r8w,0x4e(%rsp)
    26a8:	0f 11 4c 24 70       	movups %xmm1,0x70(%rsp)
    26ad:	0f 11 8c 24 80 00 00 	movups %xmm1,0x80(%rsp)
    26b4:	00 
    26b5:	0f 11 8c 24 90 00 00 	movups %xmm1,0x90(%rsp)
    26bc:	00 
    26bd:	0f 11 8c 24 a0 00 00 	movups %xmm1,0xa0(%rsp)
    26c4:	00 
    26c5:	f6 81 55 01 00 00 10 	testb  $0x10,0x155(%rcx)
    26cc:	0f 84 44 01 00 00    	je     2816 <soassign_guest_addr_if_needed+0x196>
    26d2:	0f b7 41 50          	movzwl 0x50(%rcx),%eax
    26d6:	66 83 f8 02          	cmp    $0x2,%ax
    26da:	0f 84 e8 00 00 00    	je     27c8 <soassign_guest_addr_if_needed+0x148>
    26e0:	66 83 f8 17          	cmp    $0x17,%ax
    26e4:	74 1a                	je     2700 <soassign_guest_addr_if_needed+0x80>
    26e6:	31 c0                	xor    %eax,%eax
    26e8:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
    26ef:	31 d2                	xor    %edx,%edx
    26f1:	31 c9                	xor    %ecx,%ecx
    26f3:	45 31 c0             	xor    %r8d,%r8d
    26f6:	45 31 c9             	xor    %r9d,%r9d
    26f9:	45 31 d2             	xor    %r10d,%r10d
    26fc:	c3                   	ret
    26fd:	0f 1f 00             	nopl   (%rax)
    2700:	48 8b 81 d8 00 00 00 	mov    0xd8(%rcx),%rax
    2707:	48 0b 81 e0 00 00 00 	or     0xe0(%rcx),%rax
    270e:	0f 11 4c 24 50       	movups %xmm1,0x50(%rsp)
    2713:	75 d1                	jne    26e6 <soassign_guest_addr_if_needed+0x66>
    2715:	48 8b 82 44 17 00 00 	mov    0x1744(%rdx),%rax
    271c:	48 0b 82 4c 17 00 00 	or     0x174c(%rdx),%rax
    2723:	0f 11 4c 24 60       	movups %xmm1,0x60(%rsp)
    2728:	0f 84 d2 00 00 00    	je     2800 <soassign_guest_addr_if_needed+0x180>
    272e:	4c 8d 54 24 4a       	lea    0x4a(%rsp),%r10
    2733:	f3 0f 6f 82 44 17 00 	movdqu 0x1744(%rdx),%xmm0
    273a:	00 
    273b:	4c 8d 44 24 70       	lea    0x70(%rsp),%r8
    2740:	48 81 c1 d0 00 00 00 	add    $0xd0,%rcx
    2747:	41 b9 41 00 00 00    	mov    $0x41,%r9d
    274d:	ba 80 00 00 00       	mov    $0x80,%edx
    2752:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
    2756:	c7 44 24 30 0a 00 00 	movl   $0xa,0x30(%rsp)
    275d:	00 
    275e:	c7 44 24 28 06 00 00 	movl   $0x6,0x28(%rsp)
    2765:	00 
    2766:	4c 89 54 24 20       	mov    %r10,0x20(%rsp)
    276b:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 2771 <soassign_guest_addr_if_needed+0xf1>
			276d: IMAGE_REL_AMD64_REL32	__imp_getnameinfo
    2771:	85 c0                	test   %eax,%eax
    2773:	0f 85 c9 00 00 00    	jne    2842 <soassign_guest_addr_if_needed+0x1c2>
    2779:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 2780 <soassign_guest_addr_if_needed+0x100>
			277c: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    2780:	4c 8d 54 24 4a       	lea    0x4a(%rsp),%r10
    2785:	f6 00 02             	testb  $0x2,(%rax)
    2788:	0f 84 58 ff ff ff    	je     26e6 <soassign_guest_addr_if_needed+0x66>
    278e:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
    2793:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    2798:	4c 8d 0d 80 04 00 00 	lea    0x480(%rip),%r9        # 2c1f <sorecvfrom+0x3af>
			279b: IMAGE_REL_AMD64_REL32	.rdata
    279f:	ba 80 00 00 00       	mov    $0x80,%edx
    27a4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    27a9:	4c 8d 05 44 03 00 00 	lea    0x344(%rip),%r8        # 2af4 <sorecvfrom+0x284>
			27ac: IMAGE_REL_AMD64_REL32	.rdata
    27b0:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 27df <soassign_guest_addr_if_needed+0x15f>
			27b3: IMAGE_REL_AMD64_REL32	.rdata
    27b7:	e8 00 00 00 00       	call   27bc <soassign_guest_addr_if_needed+0x13c>
			27b8: IMAGE_REL_AMD64_REL32	g_log
    27bc:	e9 25 ff ff ff       	jmp    26e6 <soassign_guest_addr_if_needed+0x66>
    27c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    27c8:	8b 91 d4 00 00 00    	mov    0xd4(%rcx),%edx
    27ce:	85 d2                	test   %edx,%edx
    27d0:	0f 85 10 ff ff ff    	jne    26e6 <soassign_guest_addr_if_needed+0x66>
    27d6:	31 c0                	xor    %eax,%eax
    27d8:	4c 8d 0d 80 04 00 00 	lea    0x480(%rip),%r9        # 2c5f <sorecvfrom+0x3ef>
			27db: IMAGE_REL_AMD64_REL32	.rdata
    27df:	41 b8 eb 04 00 00    	mov    $0x4eb,%r8d
    27e5:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    27ea:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 2841 <soassign_guest_addr_if_needed+0x1c1>
			27ed: IMAGE_REL_AMD64_REL32	.rdata
    27f1:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 2820 <soassign_guest_addr_if_needed+0x1a0>
			27f4: IMAGE_REL_AMD64_REL32	.rdata
    27f8:	e8 00 00 00 00       	call   27fd <soassign_guest_addr_if_needed+0x17d>
			27f9: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    27fd:	0f 1f 00             	nopl   (%rax)
    2800:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 2806 <soassign_guest_addr_if_needed+0x186>
			2802: IMAGE_REL_AMD64_REL32	__imp__errno
    2806:	c7 00 6e 00 00 00    	movl   $0x6e,(%rax)
    280c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    2811:	e9 d2 fe ff ff       	jmp    26e8 <soassign_guest_addr_if_needed+0x68>
    2816:	48 8d 05 2a 03 00 00 	lea    0x32a(%rip),%rax        # 2b47 <sorecvfrom+0x2d7>
			2819: IMAGE_REL_AMD64_REL32	.rdata
    281d:	4c 8d 0d 80 04 00 00 	lea    0x480(%rip),%r9        # 2ca4 <sorecvfrom+0x434>
			2820: IMAGE_REL_AMD64_REL32	.rdata
    2824:	41 b8 e6 04 00 00    	mov    $0x4e6,%r8d
    282a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    282f:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 2886 <sorecvfrom+0x16>
			2832: IMAGE_REL_AMD64_REL32	.rdata
    2836:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 2865 <soassign_guest_addr_if_needed+0x1e5>
			2839: IMAGE_REL_AMD64_REL32	.rdata
    283d:	e8 00 00 00 00       	call   2842 <soassign_guest_addr_if_needed+0x1c2>
			283e: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    2842:	48 8d 05 8e 02 00 00 	lea    0x28e(%rip),%rax        # 2ad7 <sorecvfrom+0x267>
			2845: IMAGE_REL_AMD64_REL32	.rdata
    2849:	4c 8d 0d 80 04 00 00 	lea    0x480(%rip),%r9        # 2cd0 <sorecvfrom+0x460>
			284c: IMAGE_REL_AMD64_REL32	.rdata
    2850:	41 b8 fb 04 00 00    	mov    $0x4fb,%r8d
    2856:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    285b:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 28b2 <sorecvfrom+0x42>
			285e: IMAGE_REL_AMD64_REL32	.rdata
    2862:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 2891 <sorecvfrom+0x21>
			2865: IMAGE_REL_AMD64_REL32	.rdata
    2869:	e8 00 00 00 00       	call   286e <soassign_guest_addr_if_needed+0x1ee>
			286a: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    286e:	90                   	nop
    286f:	90                   	nop

0000000000002870 <sorecvfrom>:
    2870:	41 56                	push   %r14
    2872:	57                   	push   %rdi
    2873:	56                   	push   %rsi
    2874:	53                   	push   %rbx
    2875:	48 81 ec d8 02 00 00 	sub    $0x2d8,%rsp
    287c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    2880:	31 c0                	xor    %eax,%eax
    2882:	c7 44 24 48 80 00 00 	movl   $0x80,0x48(%rsp)
    2889:	00 
    288a:	48 89 cb             	mov    %rcx,%rbx
    288d:	0f 11 44 24 50       	movups %xmm0,0x50(%rsp)
    2892:	0f 11 44 24 60       	movups %xmm0,0x60(%rsp)
    2897:	0f 11 44 24 70       	movups %xmm0,0x70(%rsp)
    289c:	0f 11 84 24 80 00 00 	movups %xmm0,0x80(%rsp)
    28a3:	00 
    28a4:	0f 11 84 24 90 00 00 	movups %xmm0,0x90(%rsp)
    28ab:	00 
    28ac:	0f 11 84 24 a0 00 00 	movups %xmm0,0xa0(%rsp)
    28b3:	00 
    28b4:	0f 11 84 24 b0 00 00 	movups %xmm0,0xb0(%rsp)
    28bb:	00 
    28bc:	0f 11 84 24 c0 00 00 	movups %xmm0,0xc0(%rsp)
    28c3:	00 
    28c4:	0f 11 84 24 d0 00 00 	movups %xmm0,0xd0(%rsp)
    28cb:	00 
    28cc:	0f 11 84 24 e0 00 00 	movups %xmm0,0xe0(%rsp)
    28d3:	00 
    28d4:	0f 11 84 24 f0 00 00 	movups %xmm0,0xf0(%rsp)
    28db:	00 
    28dc:	0f 11 84 24 00 01 00 	movups %xmm0,0x100(%rsp)
    28e3:	00 
    28e4:	0f 11 84 24 10 01 00 	movups %xmm0,0x110(%rsp)
    28eb:	00 
    28ec:	0f 11 84 24 20 01 00 	movups %xmm0,0x120(%rsp)
    28f3:	00 
    28f4:	0f 11 84 24 30 01 00 	movups %xmm0,0x130(%rsp)
    28fb:	00 
    28fc:	0f 11 84 24 40 01 00 	movups %xmm0,0x140(%rsp)
    2903:	00 
    2904:	0f 11 84 24 50 01 00 	movups %xmm0,0x150(%rsp)
    290b:	00 
    290c:	0f 11 84 24 60 01 00 	movups %xmm0,0x160(%rsp)
    2913:	00 
    2914:	0f 11 84 24 70 01 00 	movups %xmm0,0x170(%rsp)
    291b:	00 
    291c:	0f 11 84 24 80 01 00 	movups %xmm0,0x180(%rsp)
    2923:	00 
    2924:	0f 11 84 24 90 01 00 	movups %xmm0,0x190(%rsp)
    292b:	00 
    292c:	0f 11 84 24 a0 01 00 	movups %xmm0,0x1a0(%rsp)
    2933:	00 
    2934:	0f 11 84 24 b0 01 00 	movups %xmm0,0x1b0(%rsp)
    293b:	00 
    293c:	0f 11 84 24 c0 01 00 	movups %xmm0,0x1c0(%rsp)
    2943:	00 
    2944:	66 0f ef c0          	pxor   %xmm0,%xmm0
    2948:	89 c2                	mov    %eax,%edx
    294a:	83 c0 40             	add    $0x40,%eax
    294d:	0f 11 84 14 d0 01 00 	movups %xmm0,0x1d0(%rsp,%rdx,1)
    2954:	00 
    2955:	0f 11 84 14 e0 01 00 	movups %xmm0,0x1e0(%rsp,%rdx,1)
    295c:	00 
    295d:	0f 11 84 14 f0 01 00 	movups %xmm0,0x1f0(%rsp,%rdx,1)
    2964:	00 
    2965:	0f 11 84 14 00 02 00 	movups %xmm0,0x200(%rsp,%rdx,1)
    296c:	00 
    296d:	3d 00 01 00 00       	cmp    $0x100,%eax
    2972:	72 d4                	jb     2948 <sorecvfrom+0xd8>
    2974:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 297b <sorecvfrom+0x10b>
			2977: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    297b:	f6 00 01             	testb  $0x1,(%rax)
    297e:	75 70                	jne    29f0 <sorecvfrom+0x180>
    2980:	0f b6 b3 52 01 00 00 	movzbl 0x152(%rbx),%esi
    2987:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    298b:	40 80 fe 01          	cmp    $0x1,%sil
    298f:	0f 84 23 03 00 00    	je     2cb8 <sorecvfrom+0x448>
    2995:	40 80 fe 3a          	cmp    $0x3a,%sil
    2999:	0f 84 a1 00 00 00    	je     2a40 <sorecvfrom+0x1d0>
    299f:	4c 8d 44 24 4c       	lea    0x4c(%rsp),%r8
    29a4:	ba 7f 66 04 40       	mov    $0x4004667f,%edx
    29a9:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
    29b0:	00 
    29b1:	e8 00 00 00 00       	call   29b6 <sorecvfrom+0x146>
			29b2: IMAGE_REL_AMD64_REL32	slirp_ioctlsocket_wrap
    29b6:	85 c0                	test   %eax,%eax
    29b8:	0f 84 f2 00 00 00    	je     2ab0 <sorecvfrom+0x240>
    29be:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 29c5 <sorecvfrom+0x155>
			29c1: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    29c5:	f6 00 02             	testb  $0x2,(%rax)
    29c8:	0f 85 b2 03 00 00    	jne    2d80 <sorecvfrom+0x510>
    29ce:	48 81 c4 d8 02 00 00 	add    $0x2d8,%rsp
    29d5:	5b                   	pop    %rbx
    29d6:	5e                   	pop    %rsi
    29d7:	5f                   	pop    %rdi
    29d8:	41 5e                	pop    %r14
    29da:	31 c0                	xor    %eax,%eax
    29dc:	31 d2                	xor    %edx,%edx
    29de:	31 c9                	xor    %ecx,%ecx
    29e0:	45 31 c0             	xor    %r8d,%r8d
    29e3:	45 31 c9             	xor    %r9d,%r9d
    29e6:	45 31 d2             	xor    %r10d,%r10d
    29e9:	c3                   	ret
    29ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    29f0:	4c 8d 05 59 03 00 00 	lea    0x359(%rip),%r8        # 2d50 <sorecvfrom+0x4e0>
			29f3: IMAGE_REL_AMD64_REL32	.rdata
    29f7:	ba 80 00 00 00       	mov    $0x80,%edx
    29fc:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 2a2b <sorecvfrom+0x1bb>
			29ff: IMAGE_REL_AMD64_REL32	.rdata
    2a03:	e8 00 00 00 00       	call   2a08 <sorecvfrom+0x198>
			2a04: IMAGE_REL_AMD64_REL32	g_log
    2a08:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 2a0f <sorecvfrom+0x19f>
			2a0b: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    2a0f:	f6 00 01             	testb  $0x1,(%rax)
    2a12:	0f 84 68 ff ff ff    	je     2980 <sorecvfrom+0x110>
    2a18:	49 89 d9             	mov    %rbx,%r9
    2a1b:	4c 8d 05 3c 00 00 00 	lea    0x3c(%rip),%r8        # 2a5e <sorecvfrom+0x1ee>
			2a1e: IMAGE_REL_AMD64_REL32	.rdata
    2a22:	ba 80 00 00 00       	mov    $0x80,%edx
    2a27:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 2a56 <sorecvfrom+0x1e6>
			2a2a: IMAGE_REL_AMD64_REL32	.rdata
    2a2e:	e8 00 00 00 00       	call   2a33 <sorecvfrom+0x1c3>
			2a2f: IMAGE_REL_AMD64_REL32	g_log
    2a33:	e9 48 ff ff ff       	jmp    2980 <sorecvfrom+0x110>
    2a38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    2a3f:	00 
    2a40:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
    2a45:	45 31 c9             	xor    %r9d,%r9d
    2a48:	41 b8 00 01 00 00    	mov    $0x100,%r8d
    2a4e:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    2a53:	48 8d 44 24 50       	lea    0x50(%rsp),%rax
    2a58:	48 8d 94 24 d0 01 00 	lea    0x1d0(%rsp),%rdx
    2a5f:	00 
    2a60:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    2a65:	e8 00 00 00 00       	call   2a6a <sorecvfrom+0x1fa>
			2a66: IMAGE_REL_AMD64_REL32	slirp_recvfrom_wrap
    2a6a:	83 c0 01             	add    $0x1,%eax
    2a6d:	83 f8 01             	cmp    $0x1,%eax
    2a70:	0f 86 92 02 00 00    	jbe    2d08 <sorecvfrom+0x498>
    2a76:	48 8b 4b 38          	mov    0x38(%rbx),%rcx
    2a7a:	e8 00 00 00 00       	call   2a7f <sorecvfrom+0x20f>
			2a7b: IMAGE_REL_AMD64_REL32	icmp6_reflect
    2a7f:	48 c7 43 38 00 00 00 	movq   $0x0,0x38(%rbx)
    2a86:	00 
    2a87:	48 89 d9             	mov    %rbx,%rcx
    2a8a:	e8 00 00 00 00       	call   2a8f <sorecvfrom+0x21f>
			2a8b: IMAGE_REL_AMD64_REL32	udp_detach
    2a8f:	90                   	nop
    2a90:	48 81 c4 d8 02 00 00 	add    $0x2d8,%rsp
    2a97:	5b                   	pop    %rbx
    2a98:	5e                   	pop    %rsi
    2a99:	5f                   	pop    %rdi
    2a9a:	41 5e                	pop    %r14
    2a9c:	31 c0                	xor    %eax,%eax
    2a9e:	31 d2                	xor    %edx,%edx
    2aa0:	31 c9                	xor    %ecx,%ecx
    2aa2:	45 31 c0             	xor    %r8d,%r8d
    2aa5:	45 31 c9             	xor    %r9d,%r9d
    2aa8:	45 31 d2             	xor    %r10d,%r10d
    2aab:	c3                   	ret
    2aac:	0f 1f 40 00          	nopl   0x0(%rax)
    2ab0:	48 8b 4b 30          	mov    0x30(%rbx),%rcx
    2ab4:	e8 00 00 00 00       	call   2ab9 <sorecvfrom+0x249>
			2ab5: IMAGE_REL_AMD64_REL32	m_get
    2ab9:	48 89 c6             	mov    %rax,%rsi
    2abc:	48 85 c0             	test   %rax,%rax
    2abf:	0f 84 09 ff ff ff    	je     29ce <sorecvfrom+0x15e>
    2ac5:	0f b7 43 50          	movzwl 0x50(%rbx),%eax
    2ac9:	66 83 f8 02          	cmp    $0x2,%ax
    2acd:	0f 84 85 02 00 00    	je     2d58 <sorecvfrom+0x4e8>
    2ad3:	66 83 f8 17          	cmp    $0x17,%ax
    2ad7:	0f 85 af 06 00 00    	jne    318c <sorecvfrom+0x91c>
    2add:	48 8b 46 30          	mov    0x30(%rsi),%rax
    2ae1:	4c 63 46 24          	movslq 0x24(%rsi),%r8
    2ae5:	48 8d 50 40          	lea    0x40(%rax),%rdx
    2ae9:	48 89 56 30          	mov    %rdx,0x30(%rsi)
    2aed:	f6 46 20 01          	testb  $0x1,0x20(%rsi)
    2af1:	0f 84 7b 02 00 00    	je     2d72 <sorecvfrom+0x502>
    2af7:	4c 03 46 58          	add    0x58(%rsi),%r8
    2afb:	49 29 d0             	sub    %rdx,%r8
    2afe:	8b 4e 38             	mov    0x38(%rsi),%ecx
    2b01:	8b 44 24 4c          	mov    0x4c(%rsp),%eax
    2b05:	41 29 c8             	sub    %ecx,%r8d
    2b08:	41 39 c0             	cmp    %eax,%r8d
    2b0b:	0f 82 2f 03 00 00    	jb     2e40 <sorecvfrom+0x5d0>
    2b11:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
    2b16:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    2b1a:	45 31 c9             	xor    %r9d,%r9d
    2b1d:	4d 63 c0             	movslq %r8d,%r8
    2b20:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    2b25:	48 8d 44 24 50       	lea    0x50(%rsp),%rax
    2b2a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    2b2f:	e8 00 00 00 00       	call   2b34 <sorecvfrom+0x2c4>
			2b30: IMAGE_REL_AMD64_REL32	slirp_recvfrom_wrap
    2b34:	89 46 38             	mov    %eax,0x38(%rsi)
    2b37:	89 c2                	mov    %eax,%edx
    2b39:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 2b40 <sorecvfrom+0x2d0>
			2b3c: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    2b40:	f6 00 02             	testb  $0x2,(%rax)
    2b43:	0f 85 3f 03 00 00    	jne    2e88 <sorecvfrom+0x618>
    2b49:	85 d2                	test   %edx,%edx
    2b4b:	0f 88 87 03 00 00    	js     2ed8 <sorecvfrom+0x668>
    2b51:	8b 8b 60 01 00 00    	mov    0x160(%rbx),%ecx
    2b57:	85 c9                	test   %ecx,%ecx
    2b59:	0f 85 51 04 00 00    	jne    2fb0 <sorecvfrom+0x740>
    2b5f:	f3 0f 6f 44 24 50    	movdqu 0x50(%rsp),%xmm0
    2b65:	48 8d 94 24 d0 00 00 	lea    0xd0(%rsp),%rdx
    2b6c:	00 
    2b6d:	48 89 d9             	mov    %rbx,%rcx
    2b70:	0f 11 84 24 d0 00 00 	movups %xmm0,0xd0(%rsp)
    2b77:	00 
    2b78:	f3 0f 6f 44 24 60    	movdqu 0x60(%rsp),%xmm0
    2b7e:	0f 11 84 24 e0 00 00 	movups %xmm0,0xe0(%rsp)
    2b85:	00 
    2b86:	f3 0f 6f 44 24 70    	movdqu 0x70(%rsp),%xmm0
    2b8c:	0f 11 84 24 f0 00 00 	movups %xmm0,0xf0(%rsp)
    2b93:	00 
    2b94:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
    2b9b:	00 00 
    2b9d:	0f 11 84 24 00 01 00 	movups %xmm0,0x100(%rsp)
    2ba4:	00 
    2ba5:	f3 0f 6f 84 24 90 00 	movdqu 0x90(%rsp),%xmm0
    2bac:	00 00 
    2bae:	0f 11 84 24 10 01 00 	movups %xmm0,0x110(%rsp)
    2bb5:	00 
    2bb6:	f3 0f 6f 84 24 a0 00 	movdqu 0xa0(%rsp),%xmm0
    2bbd:	00 00 
    2bbf:	0f 11 84 24 20 01 00 	movups %xmm0,0x120(%rsp)
    2bc6:	00 
    2bc7:	f3 0f 6f 84 24 b0 00 	movdqu 0xb0(%rsp),%xmm0
    2bce:	00 00 
    2bd0:	0f 11 84 24 30 01 00 	movups %xmm0,0x130(%rsp)
    2bd7:	00 
    2bd8:	f3 0f 6f 84 24 c0 00 	movdqu 0xc0(%rsp),%xmm0
    2bdf:	00 00 
    2be1:	0f 11 84 24 40 01 00 	movups %xmm0,0x140(%rsp)
    2be8:	00 
    2be9:	e8 72 ec ff ff       	call   1860 <sotranslate_in>
    2bee:	f6 83 55 01 00 00 10 	testb  $0x10,0x155(%rbx)
    2bf5:	0f 85 5d 03 00 00    	jne    2f58 <sorecvfrom+0x6e8>
    2bfb:	f3 0f 6f 83 d0 00 00 	movdqu 0xd0(%rbx),%xmm0
    2c02:	00 
    2c03:	0f b7 43 50          	movzwl 0x50(%rbx),%eax
    2c07:	0f 11 84 24 50 01 00 	movups %xmm0,0x150(%rsp)
    2c0e:	00 
    2c0f:	f3 0f 6f 83 e0 00 00 	movdqu 0xe0(%rbx),%xmm0
    2c16:	00 
    2c17:	0f 11 84 24 60 01 00 	movups %xmm0,0x160(%rsp)
    2c1e:	00 
    2c1f:	f3 0f 6f 83 f0 00 00 	movdqu 0xf0(%rbx),%xmm0
    2c26:	00 
    2c27:	0f 11 84 24 70 01 00 	movups %xmm0,0x170(%rsp)
    2c2e:	00 
    2c2f:	f3 0f 6f 83 00 01 00 	movdqu 0x100(%rbx),%xmm0
    2c36:	00 
    2c37:	0f 11 84 24 80 01 00 	movups %xmm0,0x180(%rsp)
    2c3e:	00 
    2c3f:	f3 0f 6f 83 10 01 00 	movdqu 0x110(%rbx),%xmm0
    2c46:	00 
    2c47:	0f 11 84 24 90 01 00 	movups %xmm0,0x190(%rsp)
    2c4e:	00 
    2c4f:	f3 0f 6f 83 20 01 00 	movdqu 0x120(%rbx),%xmm0
    2c56:	00 
    2c57:	0f 11 84 24 a0 01 00 	movups %xmm0,0x1a0(%rsp)
    2c5e:	00 
    2c5f:	f3 0f 6f 83 30 01 00 	movdqu 0x130(%rbx),%xmm0
    2c66:	00 
    2c67:	0f 11 84 24 b0 01 00 	movups %xmm0,0x1b0(%rsp)
    2c6e:	00 
    2c6f:	f3 0f 6f 83 40 01 00 	movdqu 0x140(%rbx),%xmm0
    2c76:	00 
    2c77:	0f 11 84 24 c0 01 00 	movups %xmm0,0x1c0(%rsp)
    2c7e:	00 
    2c7f:	66 83 f8 02          	cmp    $0x2,%ax
    2c83:	0f 84 87 01 00 00    	je     2e10 <sorecvfrom+0x5a0>
    2c89:	66 83 f8 17          	cmp    $0x17,%ax
    2c8d:	0f 85 d2 04 00 00    	jne    3165 <sorecvfrom+0x8f5>
    2c93:	4c 8d 8c 24 50 01 00 	lea    0x150(%rsp),%r9
    2c9a:	00 
    2c9b:	4c 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%r8
    2ca2:	00 
    2ca3:	48 89 f2             	mov    %rsi,%rdx
    2ca6:	48 89 d9             	mov    %rbx,%rcx
    2ca9:	e8 00 00 00 00       	call   2cae <sorecvfrom+0x43e>
			2caa: IMAGE_REL_AMD64_REL32	udp6_output
    2cae:	e9 1b fd ff ff       	jmp    29ce <sorecvfrom+0x15e>
    2cb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2cb8:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
    2cbd:	45 31 c9             	xor    %r9d,%r9d
    2cc0:	41 b8 00 01 00 00    	mov    $0x100,%r8d
    2cc6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    2ccb:	48 8d 44 24 50       	lea    0x50(%rsp),%rax
    2cd0:	48 8d 94 24 d0 01 00 	lea    0x1d0(%rsp),%rdx
    2cd7:	00 
    2cd8:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    2cdd:	e8 00 00 00 00       	call   2ce2 <sorecvfrom+0x472>
			2cde: IMAGE_REL_AMD64_REL32	slirp_recvfrom_wrap
    2ce2:	83 c0 01             	add    $0x1,%eax
    2ce5:	83 f8 01             	cmp    $0x1,%eax
    2ce8:	0f 86 d2 00 00 00    	jbe    2dc0 <sorecvfrom+0x550>
    2cee:	48 8b 4b 38          	mov    0x38(%rbx),%rcx
    2cf2:	e8 00 00 00 00       	call   2cf7 <sorecvfrom+0x487>
			2cf3: IMAGE_REL_AMD64_REL32	icmp_reflect
    2cf7:	48 c7 43 38 00 00 00 	movq   $0x0,0x38(%rbx)
    2cfe:	00 
    2cff:	e9 83 fd ff ff       	jmp    2a87 <sorecvfrom+0x217>
    2d04:	0f 1f 40 00          	nopl   0x0(%rax)
    2d08:	48 8b 3d 00 00 00 00 	mov    0x0(%rip),%rdi        # 2d0f <sorecvfrom+0x49f>
			2d0b: IMAGE_REL_AMD64_REL32	__imp__errno
    2d0f:	be 03 00 00 00       	mov    $0x3,%esi
    2d14:	ff d7                	call   *%rdi
    2d16:	83 38 6e             	cmpl   $0x6e,(%rax)
    2d19:	74 0c                	je     2d27 <sorecvfrom+0x4b7>
    2d1b:	ff d7                	call   *%rdi
    2d1d:	83 38 76             	cmpl   $0x76,(%rax)
    2d20:	40 0f 95 c6          	setne  %sil
    2d24:	c1 e6 02             	shl    $0x2,%esi
    2d27:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 2d2e <sorecvfrom+0x4be>
			2d2a: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    2d2e:	f6 00 02             	testb  $0x2,(%rax)
    2d31:	0f 85 e1 02 00 00    	jne    3018 <sorecvfrom+0x7a8>
    2d37:	41 89 f0             	mov    %esi,%r8d
    2d3a:	48 8b 4b 38          	mov    0x38(%rbx),%rcx
    2d3e:	ba 03 00 00 00       	mov    $0x3,%edx
    2d43:	41 83 e0 07          	and    $0x7,%r8d
    2d47:	e8 00 00 00 00       	call   2d4c <sorecvfrom+0x4dc>
			2d48: IMAGE_REL_AMD64_REL32	icmp6_send_error
    2d4c:	e9 36 fd ff ff       	jmp    2a87 <sorecvfrom+0x217>
    2d51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2d58:	48 8b 46 30          	mov    0x30(%rsi),%rax
    2d5c:	4c 63 46 24          	movslq 0x24(%rsi),%r8
    2d60:	48 8d 50 2c          	lea    0x2c(%rax),%rdx
    2d64:	48 89 56 30          	mov    %rdx,0x30(%rsi)
    2d68:	f6 46 20 01          	testb  $0x1,0x20(%rsi)
    2d6c:	0f 85 85 fd ff ff    	jne    2af7 <sorecvfrom+0x287>
    2d72:	4e 8d 44 06 60       	lea    0x60(%rsi,%r8,1),%r8
    2d77:	49 29 d0             	sub    %rdx,%r8
    2d7a:	e9 7f fd ff ff       	jmp    2afe <sorecvfrom+0x28e>
    2d7f:	90                   	nop
    2d80:	48 8b 1d 00 00 00 00 	mov    0x0(%rip),%rbx        # 2d87 <sorecvfrom+0x517>
			2d83: IMAGE_REL_AMD64_REL32	__imp__errno
    2d87:	ff d3                	call   *%rbx
    2d89:	8b 08                	mov    (%rax),%ecx
    2d8b:	e8 00 00 00 00       	call   2d90 <sorecvfrom+0x520>
			2d8c: IMAGE_REL_AMD64_REL32	g_strerror
    2d90:	48 89 c6             	mov    %rax,%rsi
    2d93:	ff d3                	call   *%rbx
    2d95:	4c 8d 05 9e 03 00 00 	lea    0x39e(%rip),%r8        # 313a <sorecvfrom+0x8ca>
			2d98: IMAGE_REL_AMD64_REL32	.rdata
    2d9c:	ba 80 00 00 00       	mov    $0x80,%edx
    2da1:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 2dd0 <sorecvfrom+0x560>
			2da4: IMAGE_REL_AMD64_REL32	.rdata
    2da8:	44 8b 08             	mov    (%rax),%r9d
    2dab:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
    2db0:	e8 00 00 00 00       	call   2db5 <sorecvfrom+0x545>
			2db1: IMAGE_REL_AMD64_REL32	g_log
    2db5:	e9 14 fc ff ff       	jmp    29ce <sorecvfrom+0x15e>
    2dba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2dc0:	48 8b 3d 00 00 00 00 	mov    0x0(%rip),%rdi        # 2dc7 <sorecvfrom+0x557>
			2dc3: IMAGE_REL_AMD64_REL32	__imp__errno
    2dc7:	ff d7                	call   *%rdi
    2dc9:	83 38 6e             	cmpl   $0x6e,(%rax)
    2dcc:	0f 85 1e 02 00 00    	jne    2ff0 <sorecvfrom+0x780>
    2dd2:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 2dd9 <sorecvfrom+0x569>
			2dd5: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    2dd9:	f6 00 02             	testb  $0x2,(%rax)
    2ddc:	0f 85 6e 02 00 00    	jne    3050 <sorecvfrom+0x7e0>
    2de2:	ff d7                	call   *%rdi
    2de4:	8b 08                	mov    (%rax),%ecx
    2de6:	e8 00 00 00 00       	call   2deb <sorecvfrom+0x57b>
			2de7: IMAGE_REL_AMD64_REL32	g_strerror
    2deb:	48 8b 4b 38          	mov    0x38(%rbx),%rcx
    2def:	45 31 c9             	xor    %r9d,%r9d
    2df2:	44 0f b6 c6          	movzbl %sil,%r8d
    2df6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    2dfb:	ba 03 00 00 00       	mov    $0x3,%edx
    2e00:	e8 00 00 00 00       	call   2e05 <sorecvfrom+0x595>
			2e01: IMAGE_REL_AMD64_REL32	icmp_send_error
    2e05:	e9 7d fc ff ff       	jmp    2a87 <sorecvfrom+0x217>
    2e0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2e10:	0f b6 83 50 01 00 00 	movzbl 0x150(%rbx),%eax
    2e17:	4c 8d 8c 24 50 01 00 	lea    0x150(%rsp),%r9
    2e1e:	00 
    2e1f:	48 89 f2             	mov    %rsi,%rdx
    2e22:	48 89 d9             	mov    %rbx,%rcx
    2e25:	4c 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%r8
    2e2c:	00 
    2e2d:	89 44 24 20          	mov    %eax,0x20(%rsp)
    2e31:	e8 00 00 00 00       	call   2e36 <sorecvfrom+0x5c6>
			2e32: IMAGE_REL_AMD64_REL32	udp_output
    2e36:	e9 93 fb ff ff       	jmp    29ce <sorecvfrom+0x15e>
    2e3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2e40:	4c 8d 4e 60          	lea    0x60(%rsi),%r9
    2e44:	8d 44 01 01          	lea    0x1(%rcx,%rax,1),%eax
    2e48:	48 89 f1             	mov    %rsi,%rcx
    2e4b:	4c 29 ca             	sub    %r9,%rdx
    2e4e:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    2e53:	01 c2                	add    %eax,%edx
    2e55:	89 54 24 4c          	mov    %edx,0x4c(%rsp)
    2e59:	e8 00 00 00 00       	call   2e5e <sorecvfrom+0x5ee>
			2e5a: IMAGE_REL_AMD64_REL32	m_inc
    2e5e:	4c 63 46 24          	movslq 0x24(%rsi),%r8
    2e62:	48 8b 56 30          	mov    0x30(%rsi),%rdx
    2e66:	f6 46 20 01          	testb  $0x1,0x20(%rsi)
    2e6a:	0f 85 98 01 00 00    	jne    3008 <sorecvfrom+0x798>
    2e70:	4c 03 44 24 38       	add    0x38(%rsp),%r8
    2e75:	49 29 d0             	sub    %rdx,%r8
    2e78:	44 2b 46 38          	sub    0x38(%rsi),%r8d
    2e7c:	e9 90 fc ff ff       	jmp    2b11 <sorecvfrom+0x2a1>
    2e81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2e88:	48 8b 15 00 00 00 00 	mov    0x0(%rip),%rdx        # 2e8f <sorecvfrom+0x61f>
			2e8b: IMAGE_REL_AMD64_REL32	__imp__errno
    2e8f:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    2e94:	ff d2                	call   *%rdx
    2e96:	8b 08                	mov    (%rax),%ecx
    2e98:	e8 00 00 00 00       	call   2e9d <sorecvfrom+0x62d>
			2e99: IMAGE_REL_AMD64_REL32	g_strerror
    2e9d:	48 89 c7             	mov    %rax,%rdi
    2ea0:	ff 54 24 38          	call   *0x38(%rsp)
    2ea4:	44 8b 4e 38          	mov    0x38(%rsi),%r9d
    2ea8:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
    2ead:	ba 80 00 00 00       	mov    $0x80,%edx
    2eb2:	8b 00                	mov    (%rax),%eax
    2eb4:	4c 8d 05 c0 03 00 00 	lea    0x3c0(%rip),%r8        # 327b <sorecvfrom+0xa0b>
			2eb7: IMAGE_REL_AMD64_REL32	.rdata
    2ebb:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 2eea <sorecvfrom+0x67a>
			2ebe: IMAGE_REL_AMD64_REL32	.rdata
    2ec2:	89 44 24 20          	mov    %eax,0x20(%rsp)
    2ec6:	e8 00 00 00 00       	call   2ecb <sorecvfrom+0x65b>
			2ec7: IMAGE_REL_AMD64_REL32	g_log
    2ecb:	8b 56 38             	mov    0x38(%rsi),%edx
    2ece:	e9 76 fc ff ff       	jmp    2b49 <sorecvfrom+0x2d9>
    2ed3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2ed8:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 2edf <sorecvfrom+0x66f>
			2edb: IMAGE_REL_AMD64_REL32	__imp__errno
    2edf:	48 89 c7             	mov    %rax,%rdi
    2ee2:	ff d0                	call   *%rax
    2ee4:	83 38 7e             	cmpl   $0x7e,(%rax)
    2ee7:	0f 84 9a fb ff ff    	je     2a87 <sorecvfrom+0x217>
    2eed:	0f b7 83 d0 00 00 00 	movzwl 0xd0(%rbx),%eax
    2ef4:	66 83 f8 02          	cmp    $0x2,%ax
    2ef8:	0f 84 8a 01 00 00    	je     3088 <sorecvfrom+0x818>
    2efe:	66 83 f8 17          	cmp    $0x17,%ax
    2f02:	0f 85 ac 02 00 00    	jne    31b4 <sorecvfrom+0x944>
    2f08:	ff d7                	call   *%rdi
    2f0a:	41 b9 03 00 00 00    	mov    $0x3,%r9d
    2f10:	83 38 6e             	cmpl   $0x6e,(%rax)
    2f13:	74 0d                	je     2f22 <sorecvfrom+0x6b2>
    2f15:	ff d7                	call   *%rdi
    2f17:	83 38 76             	cmpl   $0x76,(%rax)
    2f1a:	41 0f 95 c1          	setne  %r9b
    2f1e:	41 c1 e1 02          	shl    $0x2,%r9d
    2f22:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 2f29 <sorecvfrom+0x6b9>
			2f25: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    2f29:	45 0f b6 c9          	movzbl %r9b,%r9d
    2f2d:	f6 00 02             	testb  $0x2,(%rax)
    2f30:	0f 85 cb 01 00 00    	jne    3101 <sorecvfrom+0x891>
    2f36:	48 8b 4b 38          	mov    0x38(%rbx),%rcx
    2f3a:	45 89 c8             	mov    %r9d,%r8d
    2f3d:	ba 01 00 00 00       	mov    $0x1,%edx
    2f42:	e8 00 00 00 00       	call   2f47 <sorecvfrom+0x6d7>
			2f43: IMAGE_REL_AMD64_REL32	icmp6_send_error
    2f47:	48 89 f1             	mov    %rsi,%rcx
    2f4a:	e8 00 00 00 00       	call   2f4f <sorecvfrom+0x6df>
			2f4b: IMAGE_REL_AMD64_REL32	m_free
    2f4f:	e9 7a fa ff ff       	jmp    29ce <sorecvfrom+0x15e>
    2f54:	0f 1f 40 00          	nopl   0x0(%rax)
    2f58:	48 89 d9             	mov    %rbx,%rcx
    2f5b:	e8 20 f7 ff ff       	call   2680 <soassign_guest_addr_if_needed>
    2f60:	83 f8 ff             	cmp    $0xffffffff,%eax
    2f63:	0f 85 92 fc ff ff    	jne    2bfb <sorecvfrom+0x38b>
    2f69:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 2f70 <sorecvfrom+0x700>
			2f6c: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    2f70:	f6 00 02             	testb  $0x2,(%rax)
    2f73:	0f 85 cf 01 00 00    	jne    3148 <sorecvfrom+0x8d8>
    2f79:	0f b7 83 d0 00 00 00 	movzwl 0xd0(%rbx),%eax
    2f80:	66 83 f8 02          	cmp    $0x2,%ax
    2f84:	0f 84 4f 01 00 00    	je     30d9 <sorecvfrom+0x869>
    2f8a:	66 83 f8 17          	cmp    $0x17,%ax
    2f8e:	0f 85 48 02 00 00    	jne    31dc <sorecvfrom+0x96c>
    2f94:	48 8b 4b 38          	mov    0x38(%rbx),%rcx
    2f98:	41 b8 03 00 00 00    	mov    $0x3,%r8d
    2f9e:	ba 01 00 00 00       	mov    $0x1,%edx
    2fa3:	e8 00 00 00 00       	call   2fa8 <sorecvfrom+0x738>
			2fa4: IMAGE_REL_AMD64_REL32	icmp6_send_error
    2fa8:	eb 9d                	jmp    2f47 <sorecvfrom+0x6d7>
    2faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2fb0:	0f b7 7b 52          	movzwl 0x52(%rbx),%edi
    2fb4:	b9 35 00 00 00       	mov    $0x35,%ecx
    2fb9:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 2fbf <sorecvfrom+0x74f>
			2fbb: IMAGE_REL_AMD64_REL32	__imp_htons
    2fbf:	89 c1                	mov    %eax,%ecx
    2fc1:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 2fc8 <sorecvfrom+0x758>
			2fc4: IMAGE_REL_AMD64_REL32	.refptr.curtime
    2fc8:	8b 00                	mov    (%rax),%eax
    2fca:	8d 90 80 a9 03 00    	lea    0x3a980(%rax),%edx
    2fd0:	05 10 27 00 00       	add    $0x2710,%eax
    2fd5:	66 39 cf             	cmp    %cx,%di
    2fd8:	0f 45 c2             	cmovne %edx,%eax
    2fdb:	89 83 60 01 00 00    	mov    %eax,0x160(%rbx)
    2fe1:	e9 79 fb ff ff       	jmp    2b5f <sorecvfrom+0x2ef>
    2fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    2fed:	00 00 00 
    2ff0:	ff d7                	call   *%rdi
    2ff2:	83 38 76             	cmpl   $0x76,(%rax)
    2ff5:	41 0f 95 c2          	setne  %r10b
    2ff9:	43 8d 34 52          	lea    (%r10,%r10,2),%esi
    2ffd:	e9 d0 fd ff ff       	jmp    2dd2 <sorecvfrom+0x562>
    3002:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3008:	4c 03 46 58          	add    0x58(%rsi),%r8
    300c:	49 29 d0             	sub    %rdx,%r8
    300f:	e9 64 fe ff ff       	jmp    2e78 <sorecvfrom+0x608>
    3014:	0f 1f 40 00          	nopl   0x0(%rax)
    3018:	ff d7                	call   *%rdi
    301a:	8b 08                	mov    (%rax),%ecx
    301c:	e8 00 00 00 00       	call   3021 <sorecvfrom+0x7b1>
			301d: IMAGE_REL_AMD64_REL32	g_strerror
    3021:	49 89 c6             	mov    %rax,%r14
    3024:	ff d7                	call   *%rdi
    3026:	4c 8d 05 82 03 00 00 	lea    0x382(%rip),%r8        # 33af <sorecvfrom+0xb3f>
			3029: IMAGE_REL_AMD64_REL32	.rdata
    302d:	ba 80 00 00 00       	mov    $0x80,%edx
    3032:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 3061 <sorecvfrom+0x7f1>
			3035: IMAGE_REL_AMD64_REL32	.rdata
    3039:	44 8b 08             	mov    (%rax),%r9d
    303c:	4c 89 74 24 20       	mov    %r14,0x20(%rsp)
    3041:	e8 00 00 00 00       	call   3046 <sorecvfrom+0x7d6>
			3042: IMAGE_REL_AMD64_REL32	g_log
    3046:	e9 ec fc ff ff       	jmp    2d37 <sorecvfrom+0x4c7>
    304b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3050:	ff d7                	call   *%rdi
    3052:	8b 08                	mov    (%rax),%ecx
    3054:	e8 00 00 00 00       	call   3059 <sorecvfrom+0x7e9>
			3055: IMAGE_REL_AMD64_REL32	g_strerror
    3059:	49 89 c6             	mov    %rax,%r14
    305c:	ff d7                	call   *%rdi
    305e:	4c 8d 05 67 03 00 00 	lea    0x367(%rip),%r8        # 33cc <sorecvfrom+0xb5c>
			3061: IMAGE_REL_AMD64_REL32	.rdata
    3065:	ba 80 00 00 00       	mov    $0x80,%edx
    306a:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 3099 <sorecvfrom+0x829>
			306d: IMAGE_REL_AMD64_REL32	.rdata
    3071:	44 8b 08             	mov    (%rax),%r9d
    3074:	4c 89 74 24 20       	mov    %r14,0x20(%rsp)
    3079:	e8 00 00 00 00       	call   307e <sorecvfrom+0x80e>
			307a: IMAGE_REL_AMD64_REL32	g_log
    307e:	e9 5f fd ff ff       	jmp    2de2 <sorecvfrom+0x572>
    3083:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3088:	ff d7                	call   *%rdi
    308a:	48 89 c2             	mov    %rax,%rdx
    308d:	b8 01 00 00 00       	mov    $0x1,%eax
    3092:	83 3a 6e             	cmpl   $0x6e,(%rdx)
    3095:	74 0b                	je     30a2 <sorecvfrom+0x832>
    3097:	ff d7                	call   *%rdi
    3099:	83 38 76             	cmpl   $0x76,(%rax)
    309c:	0f 95 c0             	setne  %al
    309f:	8d 04 40             	lea    (%rax,%rax,2),%eax
    30a2:	44 0f b6 f0          	movzbl %al,%r14d
    30a6:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 30ad <sorecvfrom+0x83d>
			30a9: IMAGE_REL_AMD64_REL32	.refptr.slirp_debug
    30ad:	f6 00 02             	testb  $0x2,(%rax)
    30b0:	75 76                	jne    3128 <sorecvfrom+0x8b8>
    30b2:	ff d7                	call   *%rdi
    30b4:	8b 08                	mov    (%rax),%ecx
    30b6:	e8 00 00 00 00       	call   30bb <sorecvfrom+0x84b>
			30b7: IMAGE_REL_AMD64_REL32	g_strerror
    30bb:	48 8b 4b 38          	mov    0x38(%rbx),%rcx
    30bf:	45 31 c9             	xor    %r9d,%r9d
    30c2:	45 89 f0             	mov    %r14d,%r8d
    30c5:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    30ca:	ba 03 00 00 00       	mov    $0x3,%edx
    30cf:	e8 00 00 00 00       	call   30d4 <sorecvfrom+0x864>
			30d0: IMAGE_REL_AMD64_REL32	icmp_send_error
    30d4:	e9 6e fe ff ff       	jmp    2f47 <sorecvfrom+0x6d7>
    30d9:	48 8d 05 58 04 00 00 	lea    0x458(%rip),%rax        # 3538 <sorecvfrom+0xcc8>
			30dc: IMAGE_REL_AMD64_REL32	.rdata
    30e0:	48 8b 4b 38          	mov    0x38(%rbx),%rcx
    30e4:	45 31 c9             	xor    %r9d,%r9d
    30e7:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    30ed:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    30f2:	ba 03 00 00 00       	mov    $0x3,%edx
    30f7:	e8 00 00 00 00       	call   30fc <sorecvfrom+0x88c>
			30f8: IMAGE_REL_AMD64_REL32	icmp_send_error
    30fc:	e9 46 fe ff ff       	jmp    2f47 <sorecvfrom+0x6d7>
    3101:	4c 8d 05 08 04 00 00 	lea    0x408(%rip),%r8        # 3510 <sorecvfrom+0xca0>
			3104: IMAGE_REL_AMD64_REL32	.rdata
    3108:	ba 80 00 00 00       	mov    $0x80,%edx
    310d:	44 89 4c 24 38       	mov    %r9d,0x38(%rsp)
    3112:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 3141 <sorecvfrom+0x8d1>
			3115: IMAGE_REL_AMD64_REL32	.rdata
    3119:	e8 00 00 00 00       	call   311e <sorecvfrom+0x8ae>
			311a: IMAGE_REL_AMD64_REL32	g_log
    311e:	44 8b 4c 24 38       	mov    0x38(%rsp),%r9d
    3123:	e9 0e fe ff ff       	jmp    2f36 <sorecvfrom+0x6c6>
    3128:	45 89 f1             	mov    %r14d,%r9d
    312b:	4c 8d 05 e0 03 00 00 	lea    0x3e0(%rip),%r8        # 3512 <sorecvfrom+0xca2>
			312e: IMAGE_REL_AMD64_REL32	.rdata
    3132:	ba 80 00 00 00       	mov    $0x80,%edx
    3137:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 3166 <sorecvfrom+0x8f6>
			313a: IMAGE_REL_AMD64_REL32	.rdata
    313e:	e8 00 00 00 00       	call   3143 <sorecvfrom+0x8d3>
			313f: IMAGE_REL_AMD64_REL32	g_log
    3143:	e9 6a ff ff ff       	jmp    30b2 <sorecvfrom+0x842>
    3148:	4c 8d 05 30 04 00 00 	lea    0x430(%rip),%r8        # 357f <sorecvfrom+0xd0f>
			314b: IMAGE_REL_AMD64_REL32	.rdata
    314f:	ba 80 00 00 00       	mov    $0x80,%edx
    3154:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 3183 <sorecvfrom+0x913>
			3157: IMAGE_REL_AMD64_REL32	.rdata
    315b:	e8 00 00 00 00       	call   3160 <sorecvfrom+0x8f0>
			315c: IMAGE_REL_AMD64_REL32	g_log
    3160:	e9 14 fe ff ff       	jmp    2f79 <sorecvfrom+0x709>
    3165:	31 c0                	xor    %eax,%eax
    3167:	4c 8d 0d e8 04 00 00 	lea    0x4e8(%rip),%r9        # 3656 <sorecvfrom+0xde6>
			316a: IMAGE_REL_AMD64_REL32	.rdata
    316e:	41 b8 f9 02 00 00    	mov    $0x2f9,%r8d
    3174:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    3179:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 31d0 <sorecvfrom+0x960>
			317c: IMAGE_REL_AMD64_REL32	.rdata
    3180:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 31af <sorecvfrom+0x93f>
			3183: IMAGE_REL_AMD64_REL32	.rdata
    3187:	e8 00 00 00 00       	call   318c <sorecvfrom+0x91c>
			3188: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    318c:	45 31 c9             	xor    %r9d,%r9d
    318f:	41 b8 85 02 00 00    	mov    $0x285,%r8d
    3195:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 31ec <sorecvfrom+0x97c>
			3198: IMAGE_REL_AMD64_REL32	.rdata
    319c:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    31a1:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 31d0 <sorecvfrom+0x960>
			31a4: IMAGE_REL_AMD64_REL32	.rdata
    31a8:	4c 8d 0d e8 04 00 00 	lea    0x4e8(%rip),%r9        # 3697 <sorecvfrom+0xe27>
			31ab: IMAGE_REL_AMD64_REL32	.rdata
    31af:	e8 00 00 00 00       	call   31b4 <sorecvfrom+0x944>
			31b0: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    31b4:	45 31 c0             	xor    %r8d,%r8d
    31b7:	4c 8d 0d e8 04 00 00 	lea    0x4e8(%rip),%r9        # 36a6 <sorecvfrom+0xe36>
			31ba: IMAGE_REL_AMD64_REL32	.rdata
    31be:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 3215 <sorecvfrom+0x9a5>
			31c1: IMAGE_REL_AMD64_REL32	.rdata
    31c5:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    31ca:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 31f9 <sorecvfrom+0x989>
			31cd: IMAGE_REL_AMD64_REL32	.rdata
    31d1:	41 b8 bf 02 00 00    	mov    $0x2bf,%r8d
    31d7:	e8 00 00 00 00       	call   31dc <sorecvfrom+0x96c>
			31d8: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    31dc:	31 d2                	xor    %edx,%edx
    31de:	4c 8d 0d e8 04 00 00 	lea    0x4e8(%rip),%r9        # 36cd <sorecvfrom+0xe5d>
			31e1: IMAGE_REL_AMD64_REL32	.rdata
    31e5:	41 b8 e7 02 00 00    	mov    $0x2e7,%r8d
    31eb:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    31f0:	48 8d 0d 28 00 00 00 	lea    0x28(%rip),%rcx        # 321f <sorecvfrom+0x9af>
			31f3: IMAGE_REL_AMD64_REL32	.rdata
    31f7:	48 8d 15 50 00 00 00 	lea    0x50(%rip),%rdx        # 324e <sorecvfrom+0x9de>
			31fa: IMAGE_REL_AMD64_REL32	.rdata
    31fe:	e8 00 00 00 00       	call   3203 <sorecvfrom+0x993>
			31ff: IMAGE_REL_AMD64_REL32	g_assertion_message_expr
    3203:	90                   	nop
    3204:	90                   	nop
    3205:	90                   	nop
    3206:	90                   	nop
    3207:	90                   	nop
    3208:	90                   	nop
    3209:	90                   	nop
    320a:	90                   	nop
    320b:	90                   	nop
    320c:	90                   	nop
    320d:	90                   	nop
    320e:	90                   	nop
    320f:	90                   	nop
    3210:	90                   	nop
    3211:	90                   	nop
    3212:	90                   	nop
    3213:	90                   	nop
    3214:	90                   	nop
    3215:	90                   	nop
    3216:	90                   	nop
    3217:	90                   	nop
    3218:	90                   	nop
    3219:	90                   	nop
    321a:	90                   	nop
    321b:	90                   	nop
    321c:	90                   	nop
    321d:	90                   	nop
    321e:	90                   	nop
    321f:	90                   	nop
