#pragma once
#include <stdint.h>
typedef struct {const uint8_t *data; unsigned width,height,stride,first,count;} factory_font_table_t;
typedef struct {const uint8_t *data; unsigned width,height,stride;} factory_symbol_table_t;
#define FACTORY_FONT_COUNT 6
extern const factory_font_table_t factory_fonts[6];
#define FACTORY_SYMBOL_COUNT 6
extern const factory_symbol_table_t factory_symbols[6];
